package com.latestfunroulette.ZerotoNineRoulette.base.baseclass;

import com.latestfunroulette.ZerotoNineRoulette.base.interfaces.BaseState;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.SessionBean;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.UserBetBean;
import com.latestfunroulette.ZerotoNineRoulette.client.RemoveBetNumbersCustomise;
import com.latestfunroulette.common.BetNumberZeroToNine;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;

public abstract class BasebetPlaceState extends BaseState {

	@Override
	protected void init(GameBean pGameBane, int pStateTime) {
		super.init(pGameBane, pStateTime);
		SessionBean sessionBean = GameMainExtension.gameCacheZeroToNine.getGameSessionBySessionId()
				.getValueByKey(pGameBane.getSession_id());
		if (sessionBean != null) {
			Utils.Logger(GameMainExtension.extension, "BaseState::::::::::::::::::::" + sessionBean.toString());

		} else {
			Utils.Logger(GameMainExtension.extension, "BaseState::::::::::::::::::::is null");

		}

	}

	@SuppressWarnings("null")
	protected void updateBetStatus(User pUser, String session_id, double coins, int number, int gameid) {

		Utils.Logger(GameMainExtension.extension, "BasebetPlaceState  ::::::: " + "userid" + pUser + "sessionid"
				+ session_id + "coins" + coins + "selectednumbers" + number);

		BetNumberZeroToNine.ZeroToNine(pUser, session_id, coins, number, gameid);

	}

	public void cancelSpecificBet(User user, String session_id) {

		// String betAmount = "";
		SessionBean tempGameSessionBean = GameMainExtension.gameCacheZeroToNine.getGameSessionBySessionId()
				.getValueByKey(session_id);
		if (tempGameSessionBean != null) {
			UserBetBean tempUser = tempGameSessionBean.getUserBetBeanByUserId(user.getName());
			// List<RouletteBetBeans> tempRouletteBets = tempUser.getUserRouletteBets();
			if (tempUser != null) {

				// betAmount = tempUser.getTotalBetAmount();
				// betAmount = String.valueOf(tempRouletteBets.get((tempRouletteBets.size() -
				// 1)).getBetAmount());
			}
			// tempGameSessionBean.cancelSpecifiChooseAdmin(user.getName());

			// getEvents().specificClearBet(this, betAmount,user);
		}
	}

	public void clearAllBetsRoulette(User pUser, String session_id, String roomname) {
		double betamount = 0;

		SessionBean tempSessionBean = GameMainExtension.gameCacheZeroToNine.getGameSessionBySessionId()
				.getValueByKey(session_id);
		if (tempSessionBean != null) {
			UserBetBean tempUser = tempSessionBean.getUserBetBeanByUserId(pUser.getName());
			if (tempUser != null) {

				betamount = Double.parseDouble((tempUser.getTotalBetAmount()));
			}

			tempSessionBean.cancelAllRouletteBet(pUser.getName());
			getEvents().clearBet(this, betamount, pUser);

		}

	}

	public void onUserBetSave(String roomname, User user, String session_id) {

		SessionBean tempSession = GameMainExtension.gameCacheZeroToNine.getGameSessionBySessionId()
				.getValueByKey(session_id);
		if (tempSession != null) {
			UserBetBean tempUserBetBean = tempSession.getUserBetBeanByUserId(user.getName());

			if (tempUserBetBean != null) {
				tempUserBetBean.setBetStatus(true);
				Utils.Logger(GameMainExtension.extension, "true");
				getEvents().betSave(this, user, session_id, roomname);
			}
		}
	}

	public void betRemoveUser(String session_id, String roomname, int betno, User user, double coins) {

		// SessionBean tempSessionBean =
		// GameMainExtension.gameCacheZeroToNine.getGameSessionBySessionId().getValueByKey(session_id);

		RemoveBetNumbersCustomise.splitBetNumbersRemove(session_id, betno, user, coins);

		getEvents().betRemoveUser(this, user);

	}

	public void betPrintExeUser(String roomname, String sessionid, User user) {

		getEvents().sendUserbetsDetails(this, roomname, sessionid, user);

	}

	public void betCancelByTicketIdUser(String roomname, String sessionid, User user, String ticket_id,int gameid,double betamount) {

		getEvents().betCancelByTicketId(this, roomname, sessionid, user, ticket_id,gameid,betamount);

	}

	public void betClaimByTicketId(String roomname, String sessionid, User user, String ticket_id,int gameid,String gametype) {

		getEvents().betClaimByTicket(this, roomname, sessionid, user, ticket_id,gameid,gametype);

	}

	public void getGameDetails_ZerotoNineRoulette(String roomname, User user) {
		getEvents().getGameDetails(this, roomname, user);

	}

	public void getGameDetailsRouletteStartAndEndDate_ZerotoNineRoulette(String roomname, User user, String startDate,
			String EndDate) {
		getEvents().getGameDetailsDateWise(this, roomname, user, startDate, EndDate);

	}

	public void getGameDetails_ZerotoNine(String roomName, User pUser) {
		getEvents().getGame_Details(this, roomName, pUser);
	}
	
	
	public void betAllShow(String roomName, User pUser,String ticketid) {
		getEvents().getAllbetsByTicketId(this, roomName, pUser,ticketid);
	}
	

}