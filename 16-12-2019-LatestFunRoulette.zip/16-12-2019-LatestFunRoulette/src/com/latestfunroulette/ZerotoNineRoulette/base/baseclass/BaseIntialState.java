package com.latestfunroulette.ZerotoNineRoulette.base.baseclass;

import com.latestfunroulette.ZerotoNineRoulette.base.interfaces.BaseState;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean;

public abstract class BaseIntialState extends BaseState {

	@Override
	protected void init(GameBean pGameBane, int pStateTime) {
		// TODO Auto-generated method stub
		super.init(pGameBane, pStateTime);
		updateSessionId();
	}

	private void updateSessionId() {

	}

}
