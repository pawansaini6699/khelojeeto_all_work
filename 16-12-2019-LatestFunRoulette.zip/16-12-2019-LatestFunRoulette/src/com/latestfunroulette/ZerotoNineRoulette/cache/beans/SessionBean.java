/**
 * 
 */
package com.latestfunroulette.ZerotoNineRoulette.cache.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.latestfunroulette.ZerotoNineRoulette.cache.caching.RouletteBetPlaceAmountCache;
import com.latestfunroulette.ZerotoNineRoulette.cache.caching.UserBetCache;
import com.latestfunroulette.ZerotoNineRoulette.cache.caching.interfaces.IRouletteBetPlaceAmountCache;
import com.latestfunroulette.ZerotoNineRoulette.cache.caching.interfaces.IUserBetCache;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.SFSObject;

/**
 * @author nagjee
 *
 */
public class SessionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String sessionId;
	private IUserBetCache<String, UserBetBean> userBets = new UserBetCache();
	private double totalSessionBetAmount = 0.0;
	private String rouletteWinPosition = "-1";
	private IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> rouletteBetPlaceAmount = new RouletteBetPlaceAmountCache();

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
		addBetPlaces();
	}

	public UserBetBean getUserBetBeanByUserId(String pUserId) {
		return userBets.getValueByKey(pUserId);
	}

	public List<UserBetBean> getAllUserBets() {
		return userBets.getAllValue();
	}
	


	public String getRouletteWinPosition() {
		return rouletteWinPosition;
	}

	public void setRouletteWinPosition(String rouletteWinPosition) {
		this.rouletteWinPosition = rouletteWinPosition;
	}

	public void addUserBet(String pUserId, String sessionid, double pBetAmount, String pBetNos, double pBetWinAmount,
			int gameid) {

		Utils.Logger(GameMainExtension.extension,
				"SessionBean ::: before add amount ::::  User Id :::: " + pUserId + " ::: Session Id ::: " + sessionid
						+ " :::: Bet Amount ::: " + pBetAmount + "::::pBetNos:::::" + pBetNos
						+ "::::::::::pBetWinAmount::::::" + pBetWinAmount);

		UserBetBean tempUserBetBean = null;
		if ((tempUserBetBean = getUserBetBeanByUserId(pUserId)) == null) {
			tempUserBetBean = new UserBetBean(); // tempUserBetBean.setUserId(pUserId);
			tempUserBetBean.setUserId(pUserId);
			tempUserBetBean.setGameid(gameid);
			userBets.add(tempUserBetBean);
		}

		tempUserBetBean.addRouletteBet(pBetAmount, pBetNos, pBetWinAmount);
		// updateBetAmount(tempUserBetBean, pBetNos, pBetAmount);
		updateSessionTotalBetAmount(pBetAmount);

		Utils.Logger(GameMainExtension.extension,
				"addUserBetWithoutSplit:::::::::::::SessionBean ::: after add amount ::::  User Id :::: " + pUserId
						+ " ::: Session Id ::: " + sessionid + " :::: Bet Amount ::: "
						+ tempUserBetBean.getTotalBetAmount());

		// getSessionBetDetail();
	}

	public void addUserBetWithoutSplit(String pUserId, String sessionid, double coins, String pBetNos, String command) {

		Utils.Logger(GameMainExtension.extension,
				"addUserBetWithoutSplit:::::::::::::SessionBean ::: before add amount ::::  User Id :::: " + pUserId
						+ " ::: Session Id ::: " + sessionid + " :::: Bet Amount ::: " + coins + "::::pBetNos:::::"
						+ pBetNos);

		UserBetBean tempUserBetBean = null;
		if ((tempUserBetBean = getUserBetBeanByUserId(pUserId)) == null) {
			tempUserBetBean = new UserBetBean(); // tempUserBetBean.setUserId(pUserId);
			tempUserBetBean.setUserId(pUserId);
			userBets.add(tempUserBetBean);
		}

		tempUserBetBean.addRouletteBetWithOutSplit(coins, pBetNos, command);
		// updateBetAmount(tempUserBetBean, pBetNos);
		updateSessionTotalBetAmount(coins);

		Utils.Logger(GameMainExtension.extension,
				"addUserBetWithoutSplit::::::::::::::::::::::::SessionBean ::: after add amount ::::  User Id :::: "
						+ pUserId + " ::: Session Id ::: " + sessionid + " :::: Bet Amount ::: "
						+ tempUserBetBean.getTotalBetAmount());

		// getSessionBetDetail();
	}

	public void addUserBetDouble(String pUserID) {

		new Thread() {

			@Override
			public void run() {

				UserBetBean tempUserBet = getUserBetBeanByUserId(pUserID);
				BigDecimal tempUserBetAmount = new BigDecimal(tempUserBet.getTotalBetAmount());

				updateSessionTotalBetAmount(tempUserBetAmount.doubleValue());
				double userTotalBetAmount = tempUserBetAmount.doubleValue() * 2;
				tempUserBet.setTotalBetAmount(String.valueOf(userTotalBetAmount));

				try {
					HashMap<String, RouletteBetBeans> tempUserBetssinglechance = tempUserBet.getUserRouletteBetsmap();

					Utils.Logger(GameMainExtension.extension,
							"tempUserBetsplaymart:::::::::::::::::::::" + tempUserBetssinglechance);

					for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempUserBetssinglechance
							.entrySet()) {

						String betno = (String) tempRouletteBetBeans.getKey();

						RouletteBetBeans tempRouletteBetBeanssingle = tempUserBetssinglechance.get(betno);

						tempRouletteBetBeanssingle.setBetAmount(tempRouletteBetBeanssingle.getBetAmount() * 2);

					}
				} catch (Exception e) {
					Utils.ErrorLogger(GameMainExtension.extension, "SessionId::::::::::::::::::::error" + e);

				}

				/*
				 * for (int bp = 0; bp < 10; bp++) {
				 * 
				 * RouletteBetPlaceAmountBean tempURBP = tempUserBets.get(String.valueOf(bp));
				 * RouletteBetPlaceAmountBean tempSRBP =
				 * rouletteBetPlaceAmount.getValueByKey(String.valueOf(bp));
				 * 
				 * tempSRBP.updateBetAmount(tempURBP.getBetAmount()*2);
				 * tempURBP.updateBetAmount(tempURBP.getBetAmount());
				 * 
				 * 
				 * 
				 * }
				 * 
				 * 
				 * List<RouletteBetBeans> tempRouletteBets = tempUserBet.getUserRouletteBets();
				 * for (int rb = 0; rb < tempRouletteBets.size(); rb++) { RouletteBetBeans
				 * tempRouletteBet = tempRouletteBets.get(rb);
				 * tempRouletteBet.setBetAmount(tempRouletteBet.getBetAmount() * 2);
				 * 
				 * }
				 */
				Utils.Logger(GameMainExtension.extension,
						"Session Bean ::: AddUserBetDouble :::: TotalSession Amount :::: " + getTotalBetAmount()
								+ " ::::: User Total Bet Amount ::::: " + tempUserBet.getTotalBetAmount());

			}
		}.start();

	}

	/*
	 * public void cancelSpecificRouletteBet(String pUserId) { UserBetBean
	 * tempUserBetBean = userBets.getValueByKey(pUserId); if (tempUserBetBean !=
	 * null) { if (!tempUserBetBean.isBetStatus()) { //
	 * userBets.getValueByKey(pUserId).getCurrentRouletteBetWithoutSplit();
	 * removeBetAmount(tempUserBetBean,
	 * userBets.getValueByKey(pUserId).getCurrentRouletteBet());
	 * tempUserBetBean.cancelSpecificRouletteBet();
	 * 
	 * 
	 * List<RouletteBetBeans> userBeans = tempUserBetBean.getUserRouletteBets();
	 * 
	 * if (userBeans.size() == 0) { userBets.delete(pUserId);
	 * Utils.Logger(GameMainExtension.extension,
	 * "cancelSpecificRouletteBet::::::::::::::::::userBeans:::::::::::::::" +
	 * userBeans.size() + "userBets:::::::" + userBets);
	 * 
	 * }
	 * 
	 * 
	 * } }
	 * 
	 * // getSessionBetDetail();
	 * 
	 * }
	 */

	public void cancelSpecifiChooseAdmin(String betno, String pUserId, double coins) {
		Utils.Logger(GameMainExtension.extension,
				"cancelSpecifiChooseAdmin::::::::::::::::::::betno" + betno + "pUserId" + pUserId + "coins " + coins);

		UserBetBean tempUserBetBean = null;
		if ((tempUserBetBean = userBets.getValueByKey(pUserId)) != null) {

			Utils.Logger(GameMainExtension.extension,
					"cancelSpecifiChooseAdmin:::::::::::::::::::::::::::::::::::::::::!tempUserBetBean.isBetStatus()"
							+ tempUserBetBean.isBetStatus());
			if (!tempUserBetBean.isBetStatus()) {
				Utils.Logger(GameMainExtension.extension, "cancelSpecifiChooseAdmin");

				tempUserBetBean.cancelRandomBets(betno, coins, pUserId);
				tempUserBetBean.remainingTotalBetAmount(coins);
				clearSessionTotalBetAmount(coins);
				tempUserBetBean.cancelRandomBetsWithoutSplit(tempUserBetBean, betno, coins, pUserId);

			}
			HashMap<String, RouletteBetBeans> hashMap = tempUserBetBean.getUserRouletteBetsmap();

			System.out.println(
					"hashmap::::::::::::::ggfdgdfsgdgdfsgfdsgdsgdsg::::::::::::::::::::::::: ssize::::::::::::::::::::::::::::"
							+ hashMap.size());

			if (hashMap.size() == 0) {
				userBets.delete(pUserId);
			}

		}

	}

	/*
	 * private void removeBetAmountSpecific(UserBetBean pUserBetBean, String betno,
	 * double coins, RouletteBetBeans pUserRouletteBet) {
	 * 
	 * Utils.Logger(GameMainExtension.extension, "UserBetBean:::::::::::::::::" +
	 * pUserBetBean); Utils.Logger(GameMainExtension.extension, "hello");
	 * 
	 * double pBetSplitAmount = pUserRouletteBet.getSplitBetAmount();
	 * 
	 * clearSessionTotalBetAmount(coins);
	 * 
	 * String[] tempBets = betno.split(","); for (int b = 0; b < tempBets.length;
	 * b++) { String tempBetNo = tempBets[b].trim(); RouletteBetPlaceAmountBean
	 * tempRBP = rouletteBetPlaceAmount.getValueByKey(tempBetNo);
	 * 
	 * if (tempRBP != null) {
	 * 
	 * tempRBP.removeBetAmount(pBetSplitAmount);
	 * 
	 * Utils.Logger(GameMainExtension.extension, " Bet :::: " + tempBetNo +
	 * "    :::: Totale remove Bet Amount :::: " + tempRBP.getBetAmount()); }
	 * 
	 * RouletteBetPlaceAmountBean tempUserRBP =
	 * pUserBetBean.getUserBetPlaceAmount().getValueByKey(tempBetNo);
	 * Utils.Logger(GameMainExtension.extension,
	 * "removeBetAmountSpecific::::::::::::tempRBP" + tempRBP.toString()); if
	 * (tempUserRBP != null) { tempUserRBP.removeBetAmount(pBetSplitAmount);
	 * Utils.Logger(GameMainExtension.extension, " Bet :::: " + tempBetNo +
	 * "   ::::::  " + pUserBetBean.getUserId() +
	 * " :::: Totale user remove Bet Amount :::: " + tempUserRBP.getBetAmount()); }
	 * }
	 * 
	 * }
	 */

	public void cancelAllRouletteBet(String pUserId) {

		UserBetBean tempUserBetBean = null;
		if ((tempUserBetBean = userBets.getValueByKey(pUserId)) != null) {
			if (!tempUserBetBean.isBetStatus()) {

				double tempUserBetAmount = Double.parseDouble(tempUserBetBean.getTotalBetAmount());
				clearSessionTotalBetAmount(tempUserBetAmount);
				tempUserBetBean.cancelAllRouletteBet();
				userBets.delete(pUserId);
			}
		}
		// getSessionBetDetail();
	}

//////////////////////////////////////////////////////////////////////////////

	public IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> getRouletteBetPlaceAmount() {
		return rouletteBetPlaceAmount;
	}

	private void addBetPlaces() {
		for (int bp = 0; bp < 10; bp++) {
			RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
			tempRBP.setBetNo(String.valueOf(bp));
			rouletteBetPlaceAmount.add(tempRBP);
		}
	}

	public void deleteUserId(String pUserId) {

		userBets.delete(pUserId);
	}

	/*
	 * private void updateBetAmount(UserBetBean pUserBetBean, String pBetNos, double
	 * pBetAmount) { Utils.Logger(GameMainExtension.extension,
	 * "SessionBean:::::::::::::updateBetAmount::::::::::pBetNos" + pBetNos);
	 * 
	 * String[] tempBets = pBetNos.split(","); for (int b = 0; b < tempBets.length;
	 * b++) { String tempBetNo = tempBets[b].trim(); RouletteBetPlaceAmountBean
	 * tempRBP = rouletteBetPlaceAmount.getValueByKey(tempBetNo);
	 * Utils.Logger(GameMainExtension.extension, " Bet :::: " + tempBetNo +
	 * " tempBets : " + tempRBP.getBetAmount());
	 * 
	 * if (tempRBP != null) { tempRBP.updateBetAmount(pBetAmount);
	 * Utils.Logger(GameMainExtension.extension, " Bet :::: " + tempBetNo +
	 * "    :::: Totale update Bet Amount :::: " + tempRBP.getBetAmount()); }
	 * 
	 * RouletteBetPlaceAmountBean tempUserRBP =
	 * pUserBetBean.getUserBetPlaceAmount().getValueByKey(tempBetNo);
	 * 
	 * if (tempUserRBP != null) { tempUserRBP.updateBetAmount(pBetAmount);
	 * Utils.Logger(GameMainExtension.extension, " Bet :::: " + tempBetNo +
	 * "  ::::: User Id ::::: " + pUserBetBean.getUserId() +
	 * "  :::: Totale user update Bet Amount :::: " + tempUserRBP.getBetAmount()); }
	 * }
	 */
	/*
	 * RouletteBetPlaceAmountBean tempRBP =
	 * rouletteBetPlaceAmount.getValueByKey(pBetNos); if (tempRBP != null) {
	 * tempRBP.updateBetAmount(pBetAmount);
	 * Utils.Logger(GameMainExtension.extension, " Bet :::: " + pBetNos +
	 * "    :::: Totale update Bet Amount :::: " + tempRBP.getBetAmount()); }
	 * 
	 * RouletteBetPlaceAmountBean tempUserRBP =
	 * pUserBetBean.getUserBetPlaceAmount().getValueByKey(pBetNos); if (tempUserRBP
	 * != null) { tempUserRBP.updateBetAmount(pBetAmount);
	 * Utils.Logger(GameMainExtension.extension," Bet :::: " + pBetNos +
	 * "  ::::: User Id ::::: " + pUserBetBean.getUserId() +
	 * "  :::: Totale user update Bet Amount :::: " + tempUserRBP.getBetAmount()); }
	 */
	// }

	/*
	 * private void removeBetAmount(UserBetBean pUserBetBean, RouletteBetBeans
	 * rouletteBetBeans) { String pBetNos = rouletteBetBeans.getBetNos(); double
	 * pBetSplitAmount = rouletteBetBeans.getSplitBetAmount();
	 * clearSessionTotalBetAmount(rouletteBetBeans.getBetAmount());
	 * 
	 * RouletteBetPlaceAmountBean tempRBP =
	 * rouletteBetPlaceAmount.getValueByKey(pBetNos); if (tempRBP != null) {
	 * 
	 * tempRBP.removeBetAmount(pBetSplitAmount);
	 * 
	 * Utils.Logger(GameMainExtension.extension, " Bet :::: " + pBetNos +
	 * "    :::: Totale remove Bet Amount :::: " + tempRBP.getBetAmount()); }
	 * 
	 * RouletteBetPlaceAmountBean tempUserRBP =
	 * pUserBetBean.getUserBetPlaceAmount().getValueByKey(pBetNos); if (tempUserRBP
	 * != null) { tempUserRBP.removeBetAmount(pBetSplitAmount);
	 * Utils.Logger(GameMainExtension.extension, " Bet :::: " + pBetNos +
	 * "   ::::::  " + pUserBetBean.getUserId() +
	 * " :::: Totale user remove Bet Amount :::: " + tempUserRBP.getBetAmount());
	 * 
	 * }
	 * 
	 * }
	 */

	/*
	 * private void clearAllUserBetAmout(UserBetBean pUserBetBean,
	 * List<RouletteBetBeans> pAllUserRouletteBets) { for (RouletteBetBeans
	 * rouletteBetBeans : pAllUserRouletteBets) { removeBetAmount(pUserBetBean,
	 * rouletteBetBeans); } }
	 */

	/*
	 * private synchronized void clearAllUserBetAmout(UserBetBean pUserBetBean) {
	 * 
	 * 
	 * 
	 * 
	 * }
	 */

/////////////////////////////////////////////////////////////////

	private synchronized void updateSessionTotalBetAmount(double pBetAmount) {
		totalSessionBetAmount += pBetAmount;
	}

	private synchronized void clearSessionTotalBetAmount(double pBetAmount) {
		Utils.Logger(GameMainExtension.extension, "clearsessiontotelbetamount:::::::::" + pBetAmount
				+ "totalSessionBetAmount:::::::::" + totalSessionBetAmount);
		totalSessionBetAmount -= pBetAmount;
		Utils.Logger(GameMainExtension.extension, "clearsessiontotelbetamount:::::::::" + pBetAmount
				+ "totalSessionBetAmount:::::::::" + totalSessionBetAmount);
		totalSessionBetAmount -= pBetAmount;
		if (totalSessionBetAmount < 0)
			totalSessionBetAmount = 0.0;
	}

	public double getTotalBetAmount() {
		return totalSessionBetAmount;
	}

	public void setSessionBetAmount(double totalSessionBetAmount) {
		this.totalSessionBetAmount = totalSessionBetAmount;
	}

	public String getSessionBetDetail() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString("TOTAL_SESSION_BET_AMOUNT", String.valueOf(totalSessionBetAmount));
		SFSArray sfsArray = new SFSArray();
		for (int bp = 0; bp < 10; bp++) {

			sfsArray.addUtfString(
					String.valueOf(rouletteBetPlaceAmount.getValueByKey(String.valueOf(bp)).getBetAmount()));

		}

		tempSFSObj.putSFSArray("SESSION_BETS", sfsArray);

		return tempSFSObj.toJson().toString();
	}

	@Override
	public String toString() {
		return "SessionBean [sessionId=" + sessionId + "]";
	}

}