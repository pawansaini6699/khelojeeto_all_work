/**
 * 
 */
package com.latestfunroulette.ZerotoNineRoulette.cache.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import com.latestfunroulette.ZerotoNineRoulette.cache.caching.RouletteBetPlaceAmountCache;
import com.latestfunroulette.ZerotoNineRoulette.cache.caching.interfaces.IRouletteBetPlaceAmountCache;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

public class UserBetBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userId;
	private int gameId;

	List<RouletteBetBeans> tempamountwithoutsplit = new ArrayList<RouletteBetBeans>();
	HashSet<String> betnohashset = new HashSet<String>();
	private BigDecimal totalBetAmount1 = new BigDecimal(0.0);
	HashMap<String, RouletteBetBeans> tempRouletteBetBeansMap = new HashMap<String, RouletteBetBeans>();
	HashMap<String, RouletteBetBeans> tempRouletteBetBeansPrintMap = new HashMap<String, RouletteBetBeans>();;

	/* Bet Status :- Save : true and default : false */
	private boolean betStatus = false;

	// private String totalBetAmount = "0";
	public int getGameId() {
		return gameId;
	}

	public void setGameid(int gameId) {
		this.gameId = gameId;
	}

	
	// private List<RouletteBetBeans> tempRouletteBets = new
	// ArrayList<RouletteBetBeans>();
	private IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> rouletteBetPlaceAmount = new RouletteBetPlaceAmountCache();

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
		// addBetPlaces();
	}

	public boolean isBetStatus() {
		return betStatus;
	}

	public void setBetStatus(boolean betStatus) {
		this.betStatus = betStatus;
	}

	public String getTotalBetAmount() {
		return totalBetAmount1.toString();
	}

	public void setTotalBetAmount(String totalBetAmount) {
		this.totalBetAmount1 = new BigDecimal(totalBetAmount);
		System.out.println("setTotalBetAmount:::::::::"+totalBetAmount1);
	}

	public HashMap<String, RouletteBetBeans> getUserRouletteBetsmapPrint() {

		System.out.println("tempRouletteBetBeansMap::::::::::::::::::" + tempRouletteBetBeansMap.toString());
		return tempRouletteBetBeansPrintMap = tempRouletteBetBeansMap;

	}

	/*
	 * public List<RouletteBetBeans> getUserRouletteBets() { return
	 * tempRouletteBets; }
	 */

	public HashMap<String, RouletteBetBeans> getUserRouletteBetsmap() {
		return tempRouletteBetBeansMap;
	}

	public void setUserRouletteBetsmapPrint(HashMap<String, RouletteBetBeans> tempRouletteBetBeansMapPrint1) {

		this.tempRouletteBetBeansPrintMap = tempRouletteBetBeansMapPrint1;

	}

	public  void setUserRouletteBetsmap(HashMap<String, RouletteBetBeans> tempRouletteBetBeansMap) {

		this.tempRouletteBetBeansMap = tempRouletteBetBeansMap;

	}

	public List<RouletteBetBeans> getUserRouletteBetsZeroToNine() {
		return tempamountwithoutsplit;
	}

	public RouletteBetBeans getUserplayerData(String betno) {
		return tempRouletteBetBeansMap.get(betno);
	}

	public synchronized void addRouletteBet(double pBetAmount, String pBetNos, double pBetWinAmount) {
		// totalBetAmount = String.valueOf(Double.parseDouble(totalBetAmount) +
		// pBetAmount);
		totalBetAmount1 = totalBetAmount1.add(new BigDecimal(pBetAmount));
		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		/*
		 * RouletteBetBeans tempRouletteBet = new RouletteBetBeans();
		 * tempRouletteBet.setBetAmount(pBetAmount); tempRouletteBet.setBetNos(pBetNos);
		 * // tempRouletteBet.setBetPlaceCount(pBetPlaceCount); // //
		 * tempRouletteBet.setSplitBetAmount(pBetSplitAmount);
		 * tempRouletteBet.setBetWinAmount(pBetWinAmount); // //
		 * tempRouletteBet.setBetCommands(pCommand);
		 * tempRouletteBets.add(tempRouletteBet);
		 */

		updateUserBetData(pBetNos, pBetAmount, pBetWinAmount);

	}

	public void updateUserBetData(String BetNo, double coins, double pBetWinAmount) {

		String[] tempBets = BetNo.split(",");
		for (int b = 0; b < tempBets.length; b++) {
			String pBetNos = tempBets[b].trim();
			//
			// tableKeyRouletteMap.get(tabletype);
			// suppose bet No : 5

			if (tempRouletteBetBeansMap.containsKey(pBetNos)) {

				RouletteBetBeans rouletteBetBeans = tempRouletteBetBeansMap.get(pBetNos);

				rouletteBetBeans.setBetAmount(rouletteBetBeans.getBetAmount() + coins);

			} else {
				RouletteBetBeans tempRouletteBet = new RouletteBetBeans();
				tempRouletteBet.setBetAmount(coins);
				tempRouletteBet.setBetNos(pBetNos);
				tempRouletteBet.setBetWinAmount(pBetWinAmount);
				// tempRouletteBet.setDevicetype(devicetype);

				tempRouletteBetBeansMap.put(pBetNos, tempRouletteBet);

			}
			Utils.Logger(GameMainExtension.extension,
					"tempRouletteBetBeansMap:::::::::::::::::::" + tempRouletteBetBeansMap);

		}
	}

	/*
	 * public void printedTicketId(String BetNo, double coins, double pBetWinAmount,
	 * String ticketid, String devicetype) {
	 * 
	 * String[] tempBets = BetNo.split(","); for (int b = 0; b < tempBets.length;
	 * b++) { String pBetNos = tempBets[b].trim(); // //
	 * stableKeyRouletteMap.get(tabletype); // suppose bet No : 5
	 * 
	 * RouletteBetBeans ticketRouletteBetBean = TicketPrint.isBetNoExist(BetNo,
	 * ticketid);
	 * 
	 * if (tempRouletteBetBeansMap.containsKey(pBetNos)) {
	 * 
	 * RouletteBetBeans rouletteBetBeans = tempRouletteBetBeansMap.get(pBetNos);
	 * 
	 * if (TicketPrint.isTicketExist(ticketid) && ticketRouletteBetBean != null) {
	 * 
	 * if (rouletteBetBeans.isFirstTime()) { rouletteBetBeans.setFirstTime(false);
	 * rouletteBetBeans.setBetAmount(coins); } else
	 * rouletteBetBeans.setBetAmount(rouletteBetBeans.getBetAmount() + coins); }
	 * 
	 * } else { RouletteBetBeans tempRouletteBet = new RouletteBetBeans();
	 * tempRouletteBet.setBetAmount(coins); tempRouletteBet.setBetNos(pBetNos);
	 * tempRouletteBet.setBetWinAmount(pBetWinAmount);
	 * tempRouletteBet.setDevicetype(devicetype);
	 * tempRouletteBetBeansMap.put(pBetNos, tempRouletteBet); }
	 * Utils.Logger(GameMainExtension.extension,
	 * "tempRouletteBetBeansMap:::::::::::::::::::" + tempRouletteBetBeansMap);
	 * 
	 * } }
	 */

	public synchronized void addRouletteBetWithOutSplit(double pBetAmount, String pBetNos, String pCommand) {
		RouletteBetBeans tempRouletteBet = new RouletteBetBeans();

		Utils.Logger(GameMainExtension.extension,
				"addRouletteBetWithOutSplit:::::::::::::::::::::::::::else part:::::");
		/*
		 * tempRouletteBet.setBetAmount(pBetAmount); tempRouletteBet.setBetNos(pBetNos);
		 * // tempRouletteBet.setBetWinAmount(pBetWinAmount);
		 * tempRouletteBet.setCommands(pCommand);
		 * tempamountwithoutsplit.add(tempRouletteBet);
		 */

		if (betnohashset.contains(pBetNos)) {
			Utils.Logger(GameMainExtension.extension,
					"addRouletteBetWithOutSplit::::::::::::::::::::if part:::::::::::::::");
			for (int i = 0; i < tempamountwithoutsplit.size(); i++) {
				if (tempamountwithoutsplit.get(i).getBetNos().equals(pBetNos)) {

					tempamountwithoutsplit.get(i)
							.setBetAmount(pBetAmount + tempamountwithoutsplit.get(i).getBetAmount());
					break;
				}
			}

		} else {
			Utils.Logger(GameMainExtension.extension,
					"addRouletteBetWithOutSplit:::::::::::::::::::::::::::else part:::::");
			tempRouletteBet.setBetAmount(pBetAmount);
			tempRouletteBet.setBetNos(pBetNos); //
			// tempRouletteBet.setBetWinAmount(pBetWinAmount);
			tempRouletteBet.setCommands(pCommand);
			tempamountwithoutsplit.add(tempRouletteBet);

		}

		betnohashset.add(pBetNos);

	}

	/*
	 * public synchronized void cancelRandomBets(UserBetBean userBetBean, String
	 * betNo,String userid) {
	 * 
	 * List<RouletteBetBeans> newlist = new ArrayList<RouletteBetBeans>();
	 * Utils.Logger(GameMainExtension.extension,"LIST" + tempRouletteBets + "size" +
	 * tempRouletteBets.size());
	 * 
	 * Utils.Logger(GameMainExtension.extension,userBetBean.getUserId());
	 * if(userid.equalsIgnoreCase(userBetBean.getUserId())) //{
	 * newlist.addAll(tempRouletteBets);
	 * Utils.Logger(GameMainExtension.extension,"newlist" + newlist.toString());
	 * 
	 * int count = 0; for (int i = 0; i <= newlist.size() - 1; i++) {
	 * 
	 * Utils.Logger(GameMainExtension.extension,tempRouletteBets.get(count).
	 * getBetNos());
	 * 
	 * if (tempRouletteBets.get(count).getBetNos().equalsIgnoreCase(betNo)) {
	 * 
	 * tempRouletteBets.remove(count);
	 * Utils.Logger(GameMainExtension.extension,"true");
	 * Utils.Logger(GameMainExtension.extension,tempRouletteBets); } else { count++;
	 * Utils.Logger(GameMainExtension.extension,"false"); }
	 * 
	 * }}
	 */

	public synchronized void cancelRandomBets(String pBetNos, double betamount, String userId) {

		Utils.Logger(GameMainExtension.extension,
				"play mart chance::::::::::::::UserBetBean:::::::::::::::::::::totalBetAmount1:::::::::::::::::::::::::"
						+ totalBetAmount1);

		List<String> removableBetNoList = new ArrayList<String>();
		String[] tempBets = pBetNos.split(",");
		for (int b = 0; b < tempBets.length; b++) {
			String Ubetno = tempBets[b].trim();

			System.out.println(
					"cancelSpecificRouletteBet::::::::::::::::betno::::::::::::::" + " user betno::::::: " + Ubetno);

			for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempRouletteBetBeansMap.entrySet()) {

				String betno = (String) tempRouletteBetBeans.getKey();

				RouletteBetBeans tempRouletteBetBeanssinglechance = tempRouletteBetBeansMap.get(betno);

				System.out.println("betno::::::::::::::::" + betno + "user betno:::::::::::::" + Ubetno);

				if (betno.equalsIgnoreCase(Ubetno)) {

					tempRouletteBetBeanssinglechance.setBetAmount(
							BigDecimal.valueOf(tempRouletteBetBeanssinglechance.getBetAmount() - betamount)
									.setScale(2, RoundingMode.HALF_UP).doubleValue());

					System.out.println(
							"useramount:::::::::::::::::::::" + tempRouletteBetBeanssinglechance.getBetAmount());
				}
				if (tempRouletteBetBeanssinglechance.getBetAmount() == 0) {

					removableBetNoList.add(betno);

					System.out.println("list size::::::::::::::::::::::" + removableBetNoList);

				}
			}

		}
		System.out.println("before remove bets size:::::::::::::::::::::::::::::::" + tempRouletteBetBeansMap.size());

		for (int i = 0; i < removableBetNoList.size(); i++) {

			String betno = removableBetNoList.get(i);
			if (tempRouletteBetBeansMap.containsKey(betno)) {

				tempRouletteBetBeansMap.remove(betno);

			}
		}

		System.out.println("After remove bets size:::::::::::::::::::::::::::::::" + tempRouletteBetBeansMap.size());

	} // getSessionBetDetail(); }

	/*
	 * public synchronized void cancelRandomBets(UserBetBean userBetBean, String
	 * betNo, String userid) {
	 * 
	 * Utils.Logger(GameMainExtension.extension,
	 * ":::: user bet bean::::::::::::::::cancelRandomBets :::::::totalBetAmount1::"
	 * + totalBetAmount1);
	 * 
	 * List<RouletteBetBeans> selectedbetlist = new ArrayList<RouletteBetBeans>();
	 * List<RouletteBetBeans> unselectedbetlist = new ArrayList<RouletteBetBeans>();
	 * 
	 * ListIterator<RouletteBetBeans> iterator = tempRouletteBets.listIterator();
	 * 
	 * while (iterator.hasNext()) {
	 * 
	 * RouletteBetBeans rouletteBetBeans = (RouletteBetBeans) iterator.next();
	 * 
	 * if (rouletteBetBeans.getBetNos().equals(betNo)) {
	 * 
	 * selectedbetlist.add(rouletteBetBeans);
	 * 
	 * Utils.Logger(GameMainExtension.extension, "selectedbetlist" +
	 * selectedbetlist); } else { unselectedbetlist.add(rouletteBetBeans);
	 * Utils.Logger(GameMainExtension.extension, "unselectedbetlist" +
	 * unselectedbetlist); }
	 * 
	 * }
	 * 
	 * if (selectedbetlist.size() > 0) {
	 * 
	 * totalBetAmount1 = totalBetAmount1 .subtract((new
	 * BigDecimal((selectedbetlist.get(selectedbetlist.size() -
	 * 1)).getBetAmount())));
	 * 
	 * totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);
	 * 
	 * selectedbetlist.remove(selectedbetlist.size() - 1);
	 * 
	 * Utils.Logger(GameMainExtension.extension,
	 * "selectedbetlist::::::::::::::::remove" + selectedbetlist);
	 * 
	 * Utils.Logger(GameMainExtension.extension,
	 * " UserBet BEan cancelRandomBets()  totalBetAmount1 " + totalBetAmount1);
	 * 
	 * if (totalBetAmount1.doubleValue() < 0) totalBetAmount1 = new BigDecimal(0.0);
	 * 
	 * } tempRouletteBets.clear(); Utils.Logger(GameMainExtension.extension,
	 * "list++++++++++++" + tempRouletteBets);
	 * tempRouletteBets.addAll(selectedbetlist);
	 * tempRouletteBets.addAll(unselectedbetlist);
	 * Utils.Logger(GameMainExtension.extension, "list:::::::::::::::" +
	 * tempRouletteBets); }
	 */

	public synchronized void cancelRandomBetsWithoutSplit(UserBetBean userBetBean, String betNo, double coins,
			String userid) {

		Utils.Logger(GameMainExtension.extension,
				":::: user bet bean::::::::::::::::cancelRandomBetsWithoutSplit :::::::betNo::" + betNo);

		List<RouletteBetBeans> selectedbetWithoutsplitlist = new ArrayList<RouletteBetBeans>();
		List<RouletteBetBeans> unselectedbetWithoutsplitlist = new ArrayList<RouletteBetBeans>();

		ListIterator<RouletteBetBeans> iterator = tempamountwithoutsplit.listIterator();

		while (iterator.hasNext()) {

			RouletteBetBeans rouletteBetBeans = (RouletteBetBeans) iterator.next();

			if (rouletteBetBeans.getBetNos().equals(betNo)) {

				selectedbetWithoutsplitlist.add(rouletteBetBeans);

				Utils.Logger(GameMainExtension.extension, "selectedbetWithoutsplitlist" + selectedbetWithoutsplitlist);
			} else {
				unselectedbetWithoutsplitlist.add(rouletteBetBeans);
				Utils.Logger(GameMainExtension.extension,
						"unselectedbetWithoutsplitlist" + unselectedbetWithoutsplitlist);
			}

		}

		if (selectedbetWithoutsplitlist.size() > 0) {

			Utils.Logger(GameMainExtension.extension, "selectedbetWithoutsplitlist:::::::::::::::::"
					+ selectedbetWithoutsplitlist + ":::::::::size::::::::  " + selectedbetWithoutsplitlist.size());
			RouletteBetBeans tempRouletteBetBeans = (selectedbetWithoutsplitlist
					.get(selectedbetWithoutsplitlist.size() - 1));

			if (tempRouletteBetBeans.getBetAmount() == 0) {
				Utils.Logger(GameMainExtension.extension,
						"selectedbetWithoutsplitlist:::::::::::::::::size" + selectedbetWithoutsplitlist.size());
				selectedbetWithoutsplitlist.remove(tempRouletteBetBeans);
			} else {
				tempRouletteBetBeans.setBetAmount(tempRouletteBetBeans.getBetAmount() - coins);

			}

		}
		tempamountwithoutsplit.clear();
		Utils.Logger(GameMainExtension.extension, "list++++++++++++" + tempamountwithoutsplit);
		tempamountwithoutsplit.addAll(selectedbetWithoutsplitlist);
		tempamountwithoutsplit.addAll(unselectedbetWithoutsplitlist);
		Utils.Logger(GameMainExtension.extension, "list:::::::::::::::" + tempamountwithoutsplit);
	}

	public RouletteBetBeans getCurrentRouletteBet(String betno) {
		return tempRouletteBetBeansMap.get(betno);
	}

	public RouletteBetBeans getCurrentRouletteBetWithoutSplit() {
		return tempamountwithoutsplit.get(tempamountwithoutsplit.size() - 1);

	}

	public synchronized void remainingTotalBetAmount(double totalcoins) {

		Utils.Logger(GameMainExtension.extension,
				"remainingTotalBetAmount::::::::::::::totalBetAmount1:::::::::::::::::::::::" + totalBetAmount1
						+ " totalcoins::::::::::::::: " + totalcoins);
		totalBetAmount1 = totalBetAmount1.subtract(new BigDecimal(totalcoins));
		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension, "remainingTotalBetAmount:::::::::::::::::" + totalBetAmount1);
		if (totalBetAmount1.doubleValue() < 0)
			totalBetAmount1 = new BigDecimal(0.0);

	}

	public void cancelAllRouletteBet() {

		Utils.Logger(GameMainExtension.extension,
				" UserBet BEan cancelAllRouletteBet() tempRouletteBets  " + tempRouletteBetBeansMap.toString());
		tempRouletteBetBeansMap.clear();
		tempamountwithoutsplit.clear();

	}

	//////////////////////////////////////////////////////////////////////////

	public IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> getUserBetPlaceAmount() {
		return rouletteBetPlaceAmount;
	}

	/*
	 * private void addBetPlaces() { for (int bp = 0; bp < 10; bp++) {
	 * 
	 * 
	 * if (bp == 0) { RouletteBetPlaceAmountBean tempRBP = new
	 * RouletteBetPlaceAmountBean(); tempRBP.setBetNo("00");
	 * rouletteBetPlaceAmount.add(tempRBP);
	 * 
	 * } else {
	 * 
	 * 
	 * RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
	 * tempRBP.setBetNo(String.valueOf((bp))); rouletteBetPlaceAmount.add(tempRBP);
	 * // } } }
	 */

	@Override
	public String toString() {
		return "UserBetBean [userId=" + userId + ", betStatus=" + betStatus + ", totalBetAmount=" + totalBetAmount1
				+ ", gameId=" + gameId + ", tempRouletteBetBeansMap=" + tempRouletteBetBeansMap + "]";
	}

}