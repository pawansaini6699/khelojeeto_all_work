/**
 * 
 */
package com.latestfunroulette.ZerotoNineRoulette.cache.beans;

import java.io.Serializable;

/**
 * @author nagjee
 *
 */
public class RouletteBetBeans implements Serializable {

	private static final long serialVersionUID = 1L;

	private double betAmount = 0.0;
	private double betWinAmount = 0.0;

	private String betNos;
	private int betPlaceCount = 0;
	private double splitBetAmount = 0.0;
	private String commands;
	private String ticketId;
	private String devicetype;

	public String getDevicetype() {
		return devicetype;
	}

	public void setDevicetype(String devicetype) {
		this.devicetype = devicetype;
	}

	private boolean firstTime = true;

	public boolean isFirstTime() {
		return firstTime;
	}

	public void setFirstTime(boolean firstTime) {
		this.firstTime = firstTime;
	}

	public String getTicketId() {
		return ticketId;
	}

	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}

	public String getCommands() {
		return commands;
	}

	public void setCommands(String commands) {
		this.commands = commands;
	}

	public double getBetAmount() {
		return betAmount;
	}

	public void setBetAmount(double betAmount) {
		this.betAmount = betAmount;
	}

	public double getBetWinAmount() {
		return betWinAmount;
	}

	public void setBetWinAmount(double betWinAmount) {
		this.betWinAmount = betWinAmount;
	}

	public String getBetNos() {
		return betNos;
	}

	public void setBetNos(String betNos) {
		this.betNos = betNos;
	}

	public int getBetPlaceCount() {
		return betPlaceCount;
	}

	public void setBetPlaceCount(int betPlaceCount) {
		this.betPlaceCount = betPlaceCount;
	}

	public double getSplitBetAmount() {
		return splitBetAmount;
	}

	public void setSplitBetAmount(double splitBetAmount) {
		this.splitBetAmount = splitBetAmount;
	}

	@Override
	public String toString() {
		return "RouletteBetBeans [betAmount=" + betAmount + ", betWinAmount=" + betWinAmount + ", betNos=" + betNos
				+ ", betPlaceCount=" + betPlaceCount + ", splitBetAmount=" + splitBetAmount + ", commands=" + commands
				+ ", ticketId=" + ticketId + "]";
	}

}