package com.latestfunroulette.ZerotoNineRoulette.cache.caching.interfaces;

public interface IAvatarCache<K, V> extends IBaseCache<K, V> {

}