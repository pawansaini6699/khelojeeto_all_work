package com.latestfunroulette.ZerotoNineRoulette.cache.caching.interfaces;

public interface IGameBeanCache<K, V> extends IBaseCache<K, V> {

}