/**
 * 
 */
package com.latestfunroulette.ZerotoNineRoulette.cache.caching.interfaces;

/**
 * @author nagjee
 *
 */
public interface IUserBetCache<K,V> extends IBaseCache<K, V> {

}
