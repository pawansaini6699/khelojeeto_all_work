package com.latestfunroulette.ZerotoNineRoulette.cache.caching;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.ZerotoNineRoulette.cache.beans.AvatarBean;
import com.latestfunroulette.ZerotoNineRoulette.cache.caching.interfaces.IAvatarCache;



public class AvatarCache extends HashMap<String, AvatarBean> implements Serializable, IAvatarCache<String, AvatarBean> {

	private static final long serialVersionUID = -5123758194286792979L;

	@Override
	public void add(AvatarBean v) {
		put(v.getAvatarid(), v);
	}

	@Override
	public void delete(String k) {
		remove(k);
	}

	@Override
	public AvatarBean getValueByKey(String k) {
		return get(k);
	}

	@Override
	public List<AvatarBean> getAllValue() {
		return new ArrayList<AvatarBean>(values());
	}

	@Override
	public HashMap<String, AvatarBean> getAll() {
		return getAll();
	}

	@Override
	public void update(String k, AvatarBean v) {
		// TODO Auto-generated method stub
		
	}

	
}