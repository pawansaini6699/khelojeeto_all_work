package com.latestfunroulette.ZerotoNineRoulette.cache.caching.interfaces;

public interface IPlayerCache<K, V> extends IBaseCache<K, V> {

}