/**
 * 
 */
package com.latestfunroulette.ZerotoNineRoulette.cache.caching;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetPlaceAmountBean;
import com.latestfunroulette.ZerotoNineRoulette.cache.caching.interfaces.IRouletteBetPlaceAmountCache;



/**
 * @author Akshay Agarwal
 * @Date 26-07-1994
 */
public class RouletteBetPlaceAmountCache extends HashMap<String, RouletteBetPlaceAmountBean>
		implements Serializable, IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> {

	private static final long serialVersionUID = 1L;

	@Override
	public void add(RouletteBetPlaceAmountBean v) {
		put(v.getBetNo(), v);
	}

	@Override
	public void delete(String k) {
		remove(k);
	}

	@Override
	public RouletteBetPlaceAmountBean getValueByKey(String k) {
		return get(k);
	}

	@Override
	public List<RouletteBetPlaceAmountBean> getAllValue() {
		return new ArrayList<>(values());
	}

	@Override
	public HashMap<String, RouletteBetPlaceAmountBean> getAll() {
		return this;
	}

	@Override
	public void update(String k, RouletteBetPlaceAmountBean v) {

	}

	


}
