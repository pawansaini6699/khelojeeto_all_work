package com.latestfunroulette.ZerotoNineRoulette.state;

import com.latestfunroulette.ZerotoNineRoulette.base.interfaces.BaseState;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean;
import com.latestfunroulette.ZerotoNineRoulette.state.interfaces.IGameWaitingState;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.GameStateZeroToNineTime;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

public class GameResultState extends BaseState implements IGameWaitingState<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,
				"SingleChance:::::::::::::::::::GameResultState::::::::::::onStart::::::");
		super.init(g, GameStateZeroToNineTime.GAME_RESULT_TIME);
        
		getEvents().sendLiveTime(this);

	}

	@Override
	public void onProcess() {
	
		long currenttime=getTimer().getElapsedTime();
		Utils.Logger(GameMainExtension.extension,
				"SingleChance::::::::::::::::::GameResultState:::::::::onProcess():::::::::::::::::::::::timer"
						+ currenttime);
		if (currenttime >= getStateTime()) {
			onExist();

		}
	}

	@Override
	public void onJoin(String pLoginId) {
		print("GameResultWaitingState :::: OnJoin()");
		getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);
		// TODO Auto-generated method stub

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {

		getGameBean().setGameState(GameState.BETPLACESTATE);
		getGameMachine().onNext(getGameBean().getGameState());

	}

}
