package com.latestfunroulette.ZerotoNineRoulette.state.interfaces;

import com.smartfoxserver.v2.entities.User;

public interface IBetPlaceState<G> extends IBaseState<G> {

	void onCancelBet(String roomname, User user, String session_id);

	void onClearAll(String roomname, User user, String session_id);

	void onRebetRequest(String roomname, User user, String session_id);

	void betPlaceState(User user, String session_id, double coins, int numbers, int gameid);

	void userBetSave(String roomname, User user, String session_id);

	void userBetRemove(String roomname, String session_id, int betno, User user, double coins);

	void betPrintExe(String roomname, String sessionId, User user);

	void betCancelByTicketId(String roomname, String sessionId, User user, String ticketid, int gameid,
			double betamount);

	void BetClaimByTicket(String roomname, String sessionId, User user, String ticketid, int gameid, String gametype);

	void UsersDayWiseDetails(String roomname, User user);

	void userGameDetails(String roomname, User user);

	void userGameDetailsStartAndEndDate(String roomname, User user, String startDate, String endDate);

	void betShowAllDetails(String roomname, User user, String ticketid);
}
