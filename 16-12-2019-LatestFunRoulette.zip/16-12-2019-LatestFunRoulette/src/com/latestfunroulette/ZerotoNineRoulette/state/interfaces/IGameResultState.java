package com.latestfunroulette.ZerotoNineRoulette.state.interfaces;

public interface IGameResultState<G> extends IBaseState<G> {

}
