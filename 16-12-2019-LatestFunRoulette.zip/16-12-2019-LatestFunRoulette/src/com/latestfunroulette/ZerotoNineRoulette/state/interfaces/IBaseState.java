package com.latestfunroulette.ZerotoNineRoulette.state.interfaces;

import com.latestfunroulette.ZerotoNineRoulette.base.interfaces.IState;

public interface IBaseState<G> extends IState<G> {

	


}
