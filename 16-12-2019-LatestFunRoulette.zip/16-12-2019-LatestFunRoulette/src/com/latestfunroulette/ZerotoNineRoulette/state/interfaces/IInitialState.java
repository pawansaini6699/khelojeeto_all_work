package com.latestfunroulette.ZerotoNineRoulette.state.interfaces;

public interface IInitialState<G> extends IBaseState<G> {

}