package com.latestfunroulette.ZerotoNineRoulette.state;

import com.latestfunroulette.ZerotoNineRoulette.base.baseclass.BaseIntialState;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean;
import com.latestfunroulette.ZerotoNineRoulette.state.interfaces.IInitialState;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.GameStateZeroToNineTime;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

public class InitialState extends BaseIntialState implements IInitialState<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension, "ZerotoNineRoulette:::::::::::::::::::::::::::::::::InitialState");
		super.init(g, GameStateZeroToNineTime.INITIAL_TIME);

	}

	@Override
	public void onProcess() {
		
		long currenttime = getTimer().getElapsedTime();
	
		Utils.Logger(GameMainExtension.extension,
				"SingleChance:::::::::::::::::::InitialState :::: OnProcess():::::::: getTimer().getElapsedTime()"
						+ currenttime);

		

			if (currenttime > getStateTime()) {
			onExist();
		}

		/*
		 * else if (currenttime == 0) { DBManager.machineTime(); }
		 * 
		 * else if (currenttime == 14) {
		 * 
		 * DBManager.machineTime();
		 * 
		 * } else if (currenttime == 2) {
		 * 
		 * DBManager.machineTime();
		 * 
		 * }
		 */

	}

	@Override
	public void onJoin(String pLoginId) {
		print("ZerotoNineRoulette:::::::::::::::InitialState :::: OnJoin()");

		getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {
		Utils.Logger(GameMainExtension.extension, "ZerotoNineRoulette::::::::::::::::onExist::::::::::::::::::");
		getGameBean().setGameState(GameState.BETPLACESTATE);
		getGameMachine().onNext(getGameBean().getGameState());
	}

}