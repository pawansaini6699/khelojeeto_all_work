package com.latestfunroulette.ZerotoNineRoulette.common.interfaces;

public interface IGloblaIdZeroToNine {

	void updateId();

	int getCurrentId();

	int getNextId();

	String getNextId(String f);
}