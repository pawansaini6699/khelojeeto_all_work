package com.latestfunroulette.ZerotoNineRoulette.common;

import com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean;
import com.latestfunroulette.ZerotoNineRoulette.common.interfaces.IGameEventManager;
import com.latestfunroulette.ZerotoNineRoulette.state.interfaces.IBetPlaceState;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;

public class GameEventMangaer implements IGameEventManager {

	@Override
	public void onPlayerLeave(User pUser, ISFSObject params, CallBack pCallBack) {
		Utils.Logger(GameMainExtension.extension, " onPlayerLeave() :::: Request :::: User :::: " + pUser.getName()
				+ " :::::: Params :::: " + params.getDump());
		String roomName = params.getUtfString(Param.ROOMNAME);
		getGameMachine(roomName).onLeave(pUser.getName());
		pCallBack.call(roomName);
	}

	@Override
	public void onLiveBet(User pUser, ISFSObject params, CallBack pCallBack) {

		Utils.Logger(GameMainExtension.extension, " onLiveBet() :::: Request :::: User :::: " + pUser.getName()
				+ " :::::: Params :::: " + params.getDump() + "::::pUser " + pUser.getName());
		String roomName = params.getUtfString(Param.ROOMNAME);
		// String user_id = params.getUtfString(Param.USERID);
		String session_id = params.getUtfString(Param.SESSIONID);

		double coins = params.getDouble(Param.COINS);
		// String command = params.getUtfString(Params.COMMANDNAME);
		int numbers = params.getInt(Param.ID);
		int gameid = params.getInt(Param.GAMEID);
		// String ticketid = params.getUtfString(Param.TICKETID);
		// String devicetype = params.getUtfString(Param.DEVICETYPE);

		Utils.Logger(GameMainExtension.extension,
				"ROOMNAME::::::::" + roomName + "  pUser " + pUser.getName() + "sessionid::::::" + session_id
						+ "  coins :::::::::  " + coins + "numbers" + numbers + " gmaeid::::::::::::::" + gameid);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);

		Utils.Logger(GameMainExtension.extension, " tempstate::::: " + tempState);

		tempState.betPlaceState(pUser, session_id, coins, numbers, gameid);

	}

	@Override
	public void onCancelSpecificBet(User pUser, ISFSObject params, CallBack pCallBack) {

		Utils.Logger(GameMainExtension.extension, " onCancelSpecificBet() :::: Request :::: User :::: "
				+ pUser.getName() + " :::::: Params ::::" + params.getDump());

		String roomName = params.getUtfString(Param.ROOMNAME);
		String user_id = params.getUtfString(Param.USERID);
		String session_id = params.getUtfString(Param.SESSIONID);

		Utils.Logger(GameMainExtension.extension, "onCancelSpecificBet::::::::::::userid" + user_id);
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.onCancelBet(roomName, pUser, session_id);

	}

	@Override
	public void onClearAllBet(User pUser, ISFSObject params, CallBack pCallBack) {
		Utils.Logger(GameMainExtension.extension, " onClearAllBet() :::: Request :::: User :::: " + pUser.getName()
				+ " :::::: Params ::::" + params.getDump());
		String roomName = params.getUtfString(Param.ROOMNAME);
		// String user_id = params.getUtfString(Param.USERID);
		String session_id = params.getUtfString(Param.SESSIONID);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.onClearAll(roomName, pUser, session_id);
	}

	@Override
	public void onRebet(User pUser, ISFSObject params, CallBack pCallBack) {

		String roomName = params.getUtfString(Param.ROOMNAME);
		String session_id = params.getUtfString(Param.SESSIONID);

		Utils.Logger(GameMainExtension.extension, "GameEventManager:::::::::::::::::onRebet:::::::");

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.onRebetRequest(roomName, pUser, session_id);

	}

	@Override
	public void onGetWinningNumber(User pUser, ISFSObject params, CallBack pCallBack) {

		// String roomName = params.getUtfString(Params.ROOMNAME);

		// IGameWaitingState<GameBean> iGameWaitingState = (IGameWaitingState<GameBean>)
		// getCurrentState(roomName);

		// iGameWaitingState.onGetWinNumber(roomName);

	}

	@Override
	public void onBetOK(User pUser, ISFSObject params, CallBack pCallBack) {

		String sessionId = params.getUtfString(Param.SESSIONID);
		String userId = params.getUtfString(Param.USERID);
		String roomName = params.getUtfString(Param.ROOMNAME);
		Utils.Logger(GameMainExtension.extension, "GameEventManager:::::::::::::::onBetOk::::::userid" + userId);
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.userBetSave(roomName, pUser, sessionId);

	}

	@Override
	public void onRemoveBetCustomise(User pUser, ISFSObject params, CallBack pCallBack) {
		Utils.Logger(GameMainExtension.extension, "onRemoveBetCustomise:::::::::::::::::::::::pUser" + pUser.getName());
		String roomName = params.getUtfString(Param.ROOMNAME);
		// String userId = params.getUtfString(Param.USERID);
		String sessionId = params.getUtfString(Param.SESSIONID);
		int id = params.getInt(Param.ID);
		long coins = params.getLong(Param.COINS);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.userBetRemove(roomName, sessionId, id, pUser, coins);

	}

	@Override
	public void onBetPrintExe(User pUsers, ISFSObject params, CallBack pCallBack) {

		String sessionId = params.getUtfString(Param.SESSIONID);
		String roomName = params.getUtfString(Param.ROOMNAME);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.betPrintExe(roomName, sessionId, pUsers);

	}

	@Override
	public void onCancelTicket(User pUser, ISFSObject params, CallBack pCallBack) {

		String sessionId = params.getUtfString(Param.SESSIONID);
		String roomName = params.getUtfString(Param.ROOMNAME);
		String ticketid = params.getUtfString(Param.TICKETID);
		int gameid = params.getInt(Param.GAMEID);
		double betamount = params.getDouble(Param.BETAMOUNT);
		

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);

		tempState.betCancelByTicketId(roomName, sessionId, pUser, ticketid,gameid,betamount);

	}

	@Override
	public void onClaimTicket(User pUser, ISFSObject params, CallBack pCallBack) {

		String sessionId = params.getUtfString(Param.SESSIONID);
		String roomName = params.getUtfString(Param.ROOMNAME);
		String ticketid = params.getUtfString(Param.TICKETID);
		int gameid = params.getInt(Param.GAMEID);
		String gametype = params.getUtfString(Param.GAMETYPE);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);

		tempState.BetClaimByTicket(roomName, sessionId, pUser, ticketid, gameid, gametype);

	}

	@Override
	public void onUserGameDetails(User pUser, ISFSObject params, CallBack pCallBack) {
		String roomName = params.getUtfString(Param.ROOMNAME);
		// String sessionId = params.getUtfString(Param.SESSIONID);

		System.out.println("Room Name is :::::::::::::::::::" + roomName);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.userGameDetails(roomName, pUser);

	}

	@Override
	public void onUserGameDetailsStartAndEndDate(User pUser, ISFSObject params, CallBack pCallBack) {
		String roomName = params.getUtfString(Param.ROOMNAME);
		String startdate = params.getUtfString(Param.STARTDATE);
		String enddate = params.getUtfString(Param.ENDDATE);

		Utils.Logger(GameMainExtension.extension,
				"roomName::::::::::" + roomName + "startdate::::::::" + startdate + "enddate:::::::::::" + enddate);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.userGameDetailsStartAndEndDate(roomName, pUser, startdate, enddate);

	}

	@Override
	public void UsersDayWiseResult(User user, ISFSObject params, CallBack callBack) {

		String roomName = params.getUtfString(Param.ROOMNAME);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.UsersDayWiseDetails(roomName, user);
	}

	@Override
	public void betAllDetailsShowByTicketId(User pUser, ISFSObject params, CallBack pCallBack) {
		
		String roomName = params.getUtfString(Param.ROOMNAME);
		String ticketid = params.getUtfString(Param.TICKETID);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.betShowAllDetails(roomName, pUser,ticketid);

	}

}