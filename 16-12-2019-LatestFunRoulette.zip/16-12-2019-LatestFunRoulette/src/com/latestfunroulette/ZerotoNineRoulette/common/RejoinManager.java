package com.latestfunroulette.ZerotoNineRoulette.common;

import com.latestfunroulette.cache.beans.Player;
import com.smartfoxserver.v2.entities.User;

public class RejoinManager {

	public void rejoin(User pUser, Player tempPlayer) {
		/*
		 * new Thread() {
		 * 
		 * @Override public void run() {
		 * print("RejoinManager ::: Rejoin ::: Player Name :: " + pUser.getName());
		 * 
		 * List<String> tempPlayerGameList = tempPlayer.getPlayerGameList();
		 * HashMap<String, String> playerGameMap = tempPlayer.getPlayerGameMap();
		 * List<GameBean> tempPlayerActiveGameList = new ArrayList<>();
		 * 
		 * if (tempPlayerGameList == null || tempPlayerGameList.isEmpty()) {
		 * print("RejoinManager ::: Rejoin ::: Player Game List is null"); return; } if
		 * (playerGameMap == null || playerGameMap.isEmpty()) {
		 * print("RejoinManager ::: Rejoin ::: Player Game Map is null"); return; } else
		 * { for (int g = 0; g < tempPlayerGameList.size(); g++) { String
		 * tempPlayerGameRoom = tempPlayerGameList.get(g);
		 * print("RejoinManager ::: Rejoin ::: Player status and game state ::: After Find Room Name :: "
		 * + tempPlayerGameRoom); GameBean tempGame = GameMainExtension.cache.getGames()
		 * .getValueByKey(tempPlayerGameRoom); print(" :::: Rejoin GAME_BEAN :::: " +
		 * tempGame);
		 * 
		 * if (tempGame != null) { if
		 * (!tempGame.getGameState().equalsIgnoreCase(GameState.PLAYERWAIT) ||
		 * !tempGame.getGameState().equalsIgnoreCase(GameState.EXIT)) {
		 * tempPlayerActiveGameList.add(tempGame); } } } }
		 * 
		 * print(" :::: Rejoin tempPlayerActiveGameList :::: " +
		 * tempPlayerActiveGameList.size());
		 * 
		 * if (tempPlayerActiveGameList.isEmpty()) { return; }
		 * 
		 * if (!tempPlayerActiveGameList.isEmpty()) {
		 * 
		 * CommonEvents.sendRejoinEvent(tempPlayerActiveGameList, pUser);
		 * 
		 * Utils.SleepThread(3000);
		 * 
		 * for (int g = 0; g < tempPlayerActiveGameList.size(); g++) { GameBean tempGame
		 * = tempPlayerActiveGameList.get(g); if
		 * (tempGame.getGameMachine().currentState() != null &&
		 * (!tempGame.getGameState().equalsIgnoreCase(GameState.PLAYERWAIT) ||
		 * !tempGame.getGameState().equalsIgnoreCase(GameState.EXIT))) {
		 * print(" :::: Rejoin GameBean :::: " + tempGame.toSFSObj().getDump()); String
		 * seatNo = playerGameMap.get(tempGame.getRoomName()); List<GamePlayerBean>
		 * beans = tempGame.getPlayers(); String botLoginId = ""; for (GamePlayerBean
		 * gamePlayerBean : beans) { if
		 * (seatNo.equalsIgnoreCase(gamePlayerBean.getSeatNo())) { botLoginId =
		 * gamePlayerBean.getLoginid(); break; } } GameBean gameBean =
		 * GameMainExtension.cache.getGames() .getValueByKey(tempGame.getRoomName()); //
		 * gameBean.removeAndReplaceBotWithPlayer(pUser.getName(), botLoginId);
		 * tempPlayer.setReconnectStatus("reconnect");
		 * gameBean.getGameMachine().onJoinInMiddleNew(pUser, pUser.getName(),
		 * botLoginId, gameBean);
		 * //gameBean.getGameMachine().currentState().onPlayerReconnect(pUser); } } } }
		 * }.start();
		 */
	}

	/*
	 * private void print(String msg) { Utils.Logger(GameMainExtension.extension,
	 * "RejoinManager :::: " + msg); }
	 */
}