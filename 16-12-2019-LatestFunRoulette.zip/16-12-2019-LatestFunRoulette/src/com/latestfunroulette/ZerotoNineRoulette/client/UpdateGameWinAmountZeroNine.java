package com.latestfunroulette.ZerotoNineRoulette.client;

import java.util.List;

import com.latestfunroulette.ZerotoNineRoulette.base.interfaces.BaseState;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.SessionBean;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.UserBetBean;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Events;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.SFSExtension;

import scala.ref.WeakReference;

public class UpdateGameWinAmountZeroNine {
	@SuppressWarnings("unused")
	private WeakReference<SFSExtension> ref_extension = null;

	public UpdateGameWinAmountZeroNine(SFSExtension extension) {
		ref_extension = new WeakReference<SFSExtension>(extension);
	}

	public static void updateWinAmount(BaseState basestate, String pSession, int pWinnumber, Room roomname,
			int jackport, String ticketid) {

		System.out.println("UpdateGameWinAmountZeroNine:::::::::::::::::::::ticketid" + ticketid);
		new Thread() {
			@Override
			public void run() {

				Utils.Logger(GameMainExtension.extension,
						"UpdateGameWinAmountManager" + "sessionid" + pSession + " winnnumber" + pWinnumber);

				GameBean gameBean = basestate.getGameBean();
				Player player = GameMainExtension.cache.getPlayer().getValueByKey(gameBean.getUserid());
				SessionBean tempSession = GameMainExtension.gameCacheZeroToNine.getGameSessionBySessionId()
						.getValueByKey(pSession);
				Room tempRoom = GameMainExtension.extension.getParentZone().getRoomByName(gameBean.getRoomName());

				Utils.Logger(GameMainExtension.extension,
						"UpdateGameWinAmountZeroNine:::::::::::::::::::::::::sessionbean" + tempSession);
				double winamount = 0;
				long tempWinnumberBetAmount = 0;
				String tempWinamount = "";
				double amount = 0;

				if (tempSession != null) {

					List<UserBetBean> tempUserBetBeans = tempSession.getAllUserBets();
					if (tempUserBetBeans != null) {
						Utils.Logger(GameMainExtension.extension,
								"tempUserBetBeans:::::::::::::::::::::::::" + tempUserBetBeans.toString());
						for (int u = 0; u < tempUserBetBeans.size(); u++) {
							UserBetBean tempUser = tempUserBetBeans.get(u);

							int gameid = tempUser.getGameId();

							User tempSFSUser = tempRoom.getUserByName(tempUser.getUserId());

							if (tempUser != null && tempUser.isBetStatus()) {

								List<String> tempStrings = TicketPrint.getTempRouletteBetBeans();

								System.out.println(
										"UpdateGameWinAmountZeroNine:::::::::::::tempStrings:::::::::" + tempStrings);

								if (tempStrings != null && tempStrings.size() > 0) {

									for (String ticketno : tempStrings) {
										System.out.println(
												"UpdateGameWinAmountZeroNine:::::::::::::ticketno:::::::::" + ticketno);

										RouletteBetBeans tEMPBeans = TicketPrint
												.getRouletteBeanByWinningNumberandTicketId(ticketno,
														String.valueOf(pWinnumber));

										if (tEMPBeans != null) {

											tempWinnumberBetAmount = (long) tEMPBeans.getBetAmount();

											Utils.Logger(GameMainExtension.extension,
													"UpdateGameWinAmountZeroNine:::::::::::::::::::::tempWinnumberBetAmount::"
															+ tempWinnumberBetAmount + "jackport" + jackport);

											Utils.Logger(GameMainExtension.extension,
													"UpdateGameWinAmountZeroNine:::::::::::::::::::::tempWinnumberBetAmount::"
															+ tempWinnumberBetAmount + "jackport" + jackport);

											winamount = tempWinnumberBetAmount * 9 * jackport;

										} else {
											winamount = 0;
										}
										gameBean.setWinner(String.valueOf(winamount));

										// BigDecimal tempBigDecimal = new BigDecimal((tempWinnumberBetAmount *36));
										tempWinamount = String.valueOf(winamount);

										Utils.Logger(GameMainExtension.extension,
												"UpdateGameWinAmountManager::::::::" + "tempWinamount" + tempWinamount);

										int userexistStatus = 1;

										if (tempSFSUser != null) {
											Utils.Logger(GameMainExtension.extension,
													"---------- UpdateUserCreditsbeforeTakeHandler----------userexistStatus "
															+ userexistStatus);

											userexistStatus = 0;
										}

										gameBean.setTotalsessionwinamount(String.valueOf(winamount));
										GameMainExtension.gameCacheZeroToNine.getGames().add(gameBean);
										// final int winamountuser=winamount;

										DBManager.updateUserWinAmountsqlZeroToNine(tempUser.getUserId(), jackport,
												tempWinamount, pWinnumber, pSession, ticketno, new CallBack() {

													@Override
													public void call(Object... callback) {

														ISFSObject isfsObject = (ISFSObject) callback[0];

														Utils.Logger(GameMainExtension.extension,
																"isfsObject:::::::::::::::" + isfsObject.getDump());
													}
												});
									}
								}

								/*
								 * DBManager.updateUserWinAmountmongoZeroToNinne(tempUser.getUserId(), pSession,
								 * jackport, pWinnumber, tempWinamount, userexistStatus, player.getChips());
								 * 
								 * Utils.Logger(GameMainExtension.extension,
								 * "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
								 * Utils.Logger(GameMainExtension.extension,
								 * "  :::: UpdateGameWinAmount :::: User Id :::: " + tempUser.getUserId() +
								 * " :::: Win number :::: " + pWinnumber + " :::  Win number bet amount :::: " +
								 * tempWinnumberBetAmount + " :::: Win amount ::: " + tempWinamount);
								 * Utils.Logger(GameMainExtension.extension,
								 * "::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
								 * 
								 * }
								 * 
								 * Utils.Logger(GameMainExtension.extension, "gameid:::::::::::::::::::::::::" +
								 * gameid);
								 * 
								 * DBManager.updateLiveTimeDataZeroToNine(tempSession.getTotalBetAmount(),
								 * String.valueOf(winamount), gameid,jackport);
								 * 
								 * }
								 */

								else {

									RouletteBetBeans tempRoulettebeansSingleChance = tempUser
											.getUserplayerData(String.valueOf((pWinnumber)));

									if (tempRoulettebeansSingleChance != null) {
										amount = (tempRoulettebeansSingleChance.getBetAmount());

										winamount = amount * 9 * jackport;

										Utils.Logger(GameMainExtension.extension,
												"UpdateGameWinAmountZeroNine ::::::::::::::::::::::::::::::::::tempRoulettebeansSingle "
														+ winamount);
									} else {
										Utils.Logger(GameMainExtension.extension,
												"UpdateGameWinAmountZeroNine:::::::::::::::::::::::::::tempRoulettebeansSingle "
														+ tempRoulettebeansSingleChance);
										tempRoulettebeansSingleChance = new RouletteBetBeans();
									}

									Utils.Logger(GameMainExtension.extension,
											"UpdateGameWinAmountZeroNine:::::::::::::::::::::tempWinnumberBetAmount::"
													+ tempWinnumberBetAmount + "jackport" + jackport);

									gameBean.setWinner(String.valueOf(winamount));

									// BigDecimal tempBigDecimal = new BigDecimal((tempWinnumberBetAmount *36));
									tempWinamount = String.valueOf(winamount);

									Utils.Logger(GameMainExtension.extension,
											"UpdateGameWinAmountManager::::::::" + "tempWinamount" + tempWinamount);

									int userexistStatus = 1;
									if (tempSFSUser != null) {
										Utils.Logger(GameMainExtension.extension,
												"---------- UpdateUserCreditsbeforeTakeHandler----------userexistStatus "
														+ userexistStatus);

										userexistStatus = 0;
									}

									gameBean.setTotalsessionwinamount(String.valueOf(winamount));
									GameMainExtension.gameCacheZeroToNine.getGames().add(gameBean);
									// final int winamountuser=winamount;

									DBManager.updateUserWinAmountsqlZeroToNine(tempUser.getUserId(), jackport,
											tempWinamount, pWinnumber, pSession, ticketid, new CallBack() {

												@Override
												public void call(Object... callback) {

													{

														ISFSObject isfsObject = (ISFSObject) callback[0];

														// isfsObject.putUtfString(Param.WINAMOUNT,
														// String.valueOf(winamountuser));
														Utils.Logger(GameMainExtension.extension,
																"---------- UpdateUserCreditsbeforeTakeHandler----------response "
																		+ isfsObject.getDump());
														GameMainExtension.extension.send(Events.UPDATEUSERCREDITS,
																isfsObject, tempSFSUser);
													}

												}
											});

									DBManager.updateUserWinAmountmongoZeroToNinne(tempUser.getUserId(), pSession,
											jackport, pWinnumber, tempWinamount, userexistStatus, player.getChips());

									Utils.Logger(GameMainExtension.extension,
											"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
									Utils.Logger(GameMainExtension.extension,
											"  :::: UpdateGameWinAmount :::: User Id :::: " + tempUser.getUserId()
													+ " :::: Win number :::: " + pWinnumber
													+ " :::  Win number bet amount :::: " + tempWinnumberBetAmount
													+ " :::: Win amount ::: " + tempWinamount);
									Utils.Logger(GameMainExtension.extension,
											"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
								}
								Utils.Logger(GameMainExtension.extension,
										"else:::::::::::::::::::::::gameid:::::::::::::::::::::::::" + gameid);
								DBManager.updateLiveTimeDataZeroToNine(tempSession.getTotalBetAmount(),
										String.valueOf(winamount), gameid, jackport);
							}
						}

					}
				}
			}
		}.start();
	}

}
