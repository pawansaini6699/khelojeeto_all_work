package com.latestfunroulette.ZerotoNineRoulette.client;

import com.latestfunroulette.ZerotoNineRoulette.common.GameEventMangaer;
import com.latestfunroulette.ZerotoNineRoulette.common.interfaces.IGameEventManager;
import com.latestfunroulette.common.CallBack;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class SingleChanceBetDetailByUserId extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUsers, ISFSObject Params) {

		IGameEventManager iGameEventManager = new GameEventMangaer();

		iGameEventManager.betAllDetailsShowByTicketId(pUsers, Params, new CallBack() {

			@Override
			public void call(Object... values) {
				// TODO Auto-generated method stub

			}
		});

	}

}
