package com.latestfunroulette.ZerotoNineRoulette.client;

import java.util.List;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class UpdateTaskHandlerZeroToNine {

	public static GameMainExtension extension2 = null;
	ScheduledFuture<?> taskHandlerForGames;

	public UpdateTaskHandlerZeroToNine(SFSExtension pExtension) {

		Utils.Logger(pExtension, "UpdateTaskHandler::::::::::::::::::::::extension");
	}

	public void startGameUpdate(SmartFoxServer pSFS) {
		taskHandlerForGames = pSFS.getTaskScheduler().scheduleAtFixedRate(new Runnable() {

			@Override
			public void run() {
				List<GameBean> tempGames = GameMainExtension.gameCacheZeroToNine.getGames().getAllValue();
				// List<GameBean> tempGames =new ArrayList<GameBean>();
				int i = 0;

				while (tempGames.size() > i) {
					GameBean game = tempGames.get(i);
					game.setGameTurnTime(1);
					if (game.getGameMachine() != null) {
						new Thread() {
							@Override
							public void run() {
								boolean gamestatus = game.getGameMachine().isMachineStatus();
								/*
								 * Utils.Logger(GameMainExtension.extension,
								 * ">>>>>>>>>>>>>>>>>>> Update Task Handler :::::::::::::game status ::::::: " +
								 * gamestatus + " ::::::::::::::: Game Room name :::::" + game.getRoomName());
								 */
								if (gamestatus) {
									game.getGameMachine().onProcess();
								}
							}
						}.start();
					}

					++i;
				}
			}
		}, 15, 1, TimeUnit.SECONDS);
	}

}