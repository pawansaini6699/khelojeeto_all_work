package com.latestfunroulette.ZerotoNineRoulette.machine.interfaces;

public interface IMachineManager {

	void join(String pLoginId, String pRoomName);

}