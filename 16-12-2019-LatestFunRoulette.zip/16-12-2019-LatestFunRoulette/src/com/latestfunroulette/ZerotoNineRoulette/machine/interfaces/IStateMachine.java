/**
 * 
 */
package com.latestfunroulette.ZerotoNineRoulette.machine.interfaces;

import com.latestfunroulette.ZerotoNineRoulette.base.interfaces.IState;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean;
import com.latestfunroulette.ZerotoNineRoulette.client.RTimer;
import com.latestfunroulette.ZerotoNineRoulette.state.BetPlaceBetAmountState;
import com.latestfunroulette.ZerotoNineRoulette.state.GameResultState;
import com.latestfunroulette.ZerotoNineRoulette.state.GameResultWaitingState;
import com.latestfunroulette.ZerotoNineRoulette.state.InitialState;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

/**
 * @author Ubuntu
 *
 */
public interface IStateMachine<G> extends IState<G> {

	void onNext(String pState);

	IState<G> currentState();

	RTimer getTimer();

	boolean isMachineStatus();

	boolean setMachineStatusZeroToNine(boolean status);

	default IState<GameBean> getState(String pState) {
		Utils.Logger(GameMainExtension.extension, "IStateMachine:::::::::::pState" + pState);
		IState<GameBean> tempState = null;

		if (pState.equalsIgnoreCase(GameState.INITIAL)) {
			tempState = new InitialState();

			// Utils.Logger(GameMainExtension.extension, "INITIAL" + tempState);
		} else if (pState.equalsIgnoreCase(GameState.BETPLACESTATE)) {

			tempState = new BetPlaceBetAmountState();
			// Utils.Logger(GameMainExtension.extension, "PLAYERWAIT" + pState);

		} else if (pState.equalsIgnoreCase(GameState.RESULTWAIT)) {
			tempState = new GameResultWaitingState();

		} else if (pState.equalsIgnoreCase(GameState.RESULT)) {
			tempState = new GameResultState();
		} else if (pState.equalsIgnoreCase(GameState.EXIT)) {

			//
		}
		return tempState;
	}
}