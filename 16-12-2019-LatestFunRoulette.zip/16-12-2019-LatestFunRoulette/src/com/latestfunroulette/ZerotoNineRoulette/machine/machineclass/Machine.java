package com.latestfunroulette.ZerotoNineRoulette.machine.machineclass;

import com.latestfunroulette.ZerotoNineRoulette.base.baseclass.BaseStateMachine;
import com.latestfunroulette.ZerotoNineRoulette.base.interfaces.IState;
import com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean;
import com.latestfunroulette.ZerotoNineRoulette.client.RTimer;
import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

public class Machine extends BaseStateMachine<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,"Machine ::::ZerotoNineRoulette OnStart()");
		// print("Machine :::: OnStart()");
		super.setGameBean(g);
		onNext(g.getGameState());
		onGetStatus(g.isStatus());
	}

	@Override
	public void onProcess() {
		// Utils.Logger(GameMainExtension.extension,"Machine :::ZerotoNineRoulette: OnProcess()");
		// print("Machine :::: OnProcess()");
		if (getMachinState()) {
			getCurrentState().onProcess();
		} else {
			onExist();
		}
	}

	// getCurrentState = initial state
	@Override
	public void onNext(String pState) {

		print("Machine :::::::::::::::onNext()" + pState);

		if (pState.equalsIgnoreCase(GameState.EXIT)) {
			onExist();
		} else {
			setCurrentState(pState);

			getCurrentState().onStart(getGameBean());
			// getCurrentState().onProcess();
		}
	}
	
	public void onGetStatus(boolean status) {

		if (status) {
			super.setMachineStatus(EnableStatus.ENABLE);
		} else {

		}

	}

	@Override
	public void onJoin(String pLoginId) {

		Utils.Logger(GameMainExtension.extension,"ZerotoNineRoulette::::::::::ploginid:::::::::::::" + pLoginId);
		getCurrentState().onJoin(pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getCurrentState().onLeave(pLoginId);

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {
		// TODO Auto-generated method stub

	}

	@Override
	public IState<GameBean> currentState() {
		// TODO Auto-generated method stub
		return getCurrentState();
	}

	@Override
	public RTimer getTimer() {

		return getTimers();
	}

	@Override
	public boolean isMachineStatus() {
		return getMachinState();
	}

	@Override
	public boolean setMachineStatusZeroToNine(boolean status) {

		setMachineStatus(status);
		return status;

	}

}