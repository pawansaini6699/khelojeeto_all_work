package com.latestfunroulette.TripleRoulette.base.baseclass;

import com.latestfunroulette.TripleRoulette.base.interfaces.BaseState;
import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;

public abstract class BaseIntialState extends BaseState {

	@Override
	protected void init(GameBean pGameBane, int pStateTime) {
		// TODO Auto-generated method stub
		super.init(pGameBane, pStateTime);
		updateSessionId();
	}

	private void updateSessionId() {

	}

}
