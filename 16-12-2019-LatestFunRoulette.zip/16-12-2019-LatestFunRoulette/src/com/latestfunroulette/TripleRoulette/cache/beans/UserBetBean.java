/**
 * 
 */
package com.latestfunroulette.TripleRoulette.cache.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

public class UserBetBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userId;

	private int gameId;

	/* Bet Status :- Save : true and default : false */
	private boolean betStatus = false;
	private BigDecimal totalBetAmount1 = new BigDecimal(0.0);
	private BigDecimal splitamount = new BigDecimal(0.0);
	// RouletteBetBeans tempRouletteBet = new RouletteBetBeans();
	private HashMap<String, HashMap<String, RouletteBetBeans>> tableKeyRouletteMap = new HashMap<String, HashMap<String, RouletteBetBeans>>();
	// List<RouletteBetBeans> tempamountwithoutsplit = new
	// ArrayList<RouletteBetBeans>();
	// HashSet<String> betnohashset = new HashSet<String>();
	// private IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean>
	// rouletteBetPlaceAmount = new RouletteBetPlaceAmountCache();
	// private IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean>
	// rouletteBetPlaceAmountSingle = new RouletteBetPlaceAmountCache();

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
		// addBetPlaces();
		// addBetPlacesSingleChace();
	}

	public int getGameId() {
		return gameId;
	}

	public void setGameId(int gameId) {
		this.gameId = gameId;
	}

	public boolean isBetStatus() {
		return betStatus;
	}

	public void setBetStatus(boolean betStatus) {
		this.betStatus = betStatus;
	}

	public String getTotalBetAmount() {
		return totalBetAmount1.toString();
	}

	public void setTotalBetAmount(String totalBetAmount) {
		this.totalBetAmount1 = new BigDecimal(totalBetAmount);
	}

	public HashMap<String, HashMap<String, RouletteBetBeans>> getUserRouletteBets() {
		return tableKeyRouletteMap;
	}

	public HashMap<String, RouletteBetBeans> getUserRouletteBetsTableType(String tableType) {

		return tableKeyRouletteMap.get(tableType);
	}

	public void setUserRouletteBetsmap(HashMap<String, HashMap<String, RouletteBetBeans>> tableKeyRouletteMap) {

		this.tableKeyRouletteMap = tableKeyRouletteMap;

	}

	public RouletteBetBeans getUserRouletteBetsByBetNoAndTableType(String betNo, String tableType) {

		HashMap<String, RouletteBetBeans> tempbetnoRouletteBetBean = getUserRouletteBetsTableType(tableType);

		if (tempbetnoRouletteBetBean == null) {
			return null;
		}
		return tempbetnoRouletteBetBean.get(betNo);

	}

	public synchronized void addUpdateRouletteBet(double pBetAmount, String pBetNos, double pBetWinAmount,
			String tabletype) {
		// totalBetAmount = String.valueOf(Double.parseDouble(totalBetAmount) +
		// pBetAmount);
		totalBetAmount1 = totalBetAmount1.add(new BigDecimal(pBetAmount));
		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension,
				"UserBetBean::::::::::::::addRouletteBet:::::::::::::::::::totalBetAmount1:::::::::::::::::"
						+ totalBetAmount1 + "betno" + pBetNos + ":::::::::::::::::::::totalsplitamount" + splitamount);

		// tempRouletteBet.setCommands(pCommand);
//		hashmapbetno.put(pBetNos,tempRouletteBet);

		updateUserBetData(tabletype, pBetNos, pBetAmount, pBetWinAmount);

	}

	public void updateUserBetData(String tabletype, String pBetNos, double pBetAmount, double pBetWinAmount) {

		if (tableKeyRouletteMap.containsKey(tabletype)) {
			HashMap<String, RouletteBetBeans> tempRouletteBetBeansMap = tableKeyRouletteMap.get(tabletype);
			// suppose bet No : 5

			if (tempRouletteBetBeansMap.containsKey(pBetNos)) {
				RouletteBetBeans rouletteBetBeans = tempRouletteBetBeansMap.get(pBetNos);
				rouletteBetBeans.setBetAmount(rouletteBetBeans.getBetAmount() + pBetAmount);
			} else {
				RouletteBetBeans tempRouletteBet = new RouletteBetBeans();
				tempRouletteBet.setBetAmount(pBetAmount);
				tempRouletteBet.setBetNos(pBetNos);
				tempRouletteBet.setBetWinAmount(pBetWinAmount);
				tempRouletteBet.setTabletype(tabletype);
				tempRouletteBetBeansMap.put(pBetNos, tempRouletteBet);
			}

		} else {

			HashMap<String, RouletteBetBeans> tempRouletteBetBeansMap = new HashMap<String, RouletteBetBeans>();

			RouletteBetBeans tempRouletteBet = new RouletteBetBeans();
			tempRouletteBet.setBetAmount(pBetAmount);
			tempRouletteBet.setBetNos(pBetNos);
			tempRouletteBet.setBetWinAmount(pBetWinAmount);
			tempRouletteBet.setTabletype(tabletype);
			tempRouletteBetBeansMap.put(pBetNos, tempRouletteBet);

			tableKeyRouletteMap.put(tabletype, tempRouletteBetBeansMap);

		}

	}

	public synchronized void cancelSpecificRouletteBet(String pBetNos, double betamount) {

		// updateSessionTotalBetAmount(tempUserBetAmount.doubleValue() - betamount);

		HashMap<String, RouletteBetBeans> tempUserBetsSingle = getUserRouletteBetsTableType("SINGLE");
		HashMap<String, RouletteBetBeans> tempUserBetsDouble = getUserRouletteBetsTableType("DOUBLE");
		HashMap<String, RouletteBetBeans> tempUserBetsTriple = getUserRouletteBetsTableType("TRIPLE");
		try {
			for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempUserBetsSingle.entrySet()) {

				String betno = (String) tempRouletteBetBeans.getKey();

				if (betno.equalsIgnoreCase(pBetNos)) {
					RouletteBetBeans tempRouletteBetBeanssingle = tempUserBetsSingle.get(betno);

					tempRouletteBetBeanssingle.setBetAmount(tempRouletteBetBeanssingle.getBetAmount() - betamount);
				}
			}
		} catch (Exception e) {

			Utils.ErrorLogger(GameMainExtension.extension, "Single chance:::::::::::::::error ::::::::::::::" + e);
		}

		try {
			for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempUserBetsDouble.entrySet()) {

				String betno = (String) tempRouletteBetBeans.getKey();

				if (betno.equalsIgnoreCase(pBetNos)) {
					RouletteBetBeans tempRouletteBetBeansDouble = tempUserBetsDouble.get(betno);

					tempRouletteBetBeansDouble.setBetAmount(tempRouletteBetBeansDouble.getBetAmount() - betamount);
				}
			}
		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension, " Double Chance:::::::::::::::::error ::::::::::::::" + e);
		}

		try {

			for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempUserBetsTriple.entrySet()) {

				String betno = (String) tempRouletteBetBeans.getKey();

				if (betno.equalsIgnoreCase(pBetNos)) {
					RouletteBetBeans tempRouletteBetBeansTriple = tempUserBetsTriple.get(betno);

					tempRouletteBetBeansTriple.setBetAmount(tempRouletteBetBeansTriple.getBetAmount() - betamount);
					Utils.Logger(GameMainExtension.extension,
							"tempUserBetsTriple::::::::::::::AMOUNT::::::" + tempRouletteBetBeansTriple.getBetAmount());

				}
			}
		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension, " Triple Chance:::::::::::::::::error ::::::::::::::" + e);

		}

	} // getSessionBetDetail(); }

	/*
	 * public RouletteBetBeans getCurrentRouletteBet() { // return
	 * rouletteBetBeans.getBetAmount() - betamount);
	 * 
	 * return null; }
	 */
	/*
	 * public RouletteBetBeans getCurrentRouletteBetWithoutSplit() {
	 * Utils.Logger(GameMainExtension.extension,
	 * "SingleRoulette::::::::::::::::::::::::::::::tempamountwithoutsplit::::::::size"
	 * +tempamountwithoutsplit.size()+"tempamountwithoutsplit"+
	 * tempamountwithoutsplit.toString());
	 * 
	 * return tempamountwithoutsplit.remove(tempamountwithoutsplit.size() - 1);
	 * 
	 * }
	 */

	public void cancelAllRouletteBet() {

		Utils.Logger(GameMainExtension.extension,
				" UserBet BEan cancelAllRouletteBet() tempRouletteBets  " + tableKeyRouletteMap.toString());
		tableKeyRouletteMap.clear();

	}

	//////////////////////////////////////////////////////////////////////////

	/*
	 * public IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean>
	 * getUserBetPlaceAmount() { return rouletteBetPlaceAmount; }
	 * 
	 * public IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean>
	 * getUserBetPlaceAmountSingleChance() { return rouletteBetPlaceAmountSingle; }
	 */

	/*
	 * private void addBetPlaces() { for (int bp = 0; bp < 100; bp++) {
	 * 
	 * RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
	 * tempRBP.setBetNo(String.valueOf(bp)); rouletteBetPlaceAmount.add(tempRBP); }
	 * 
	 * }
	 * 
	 * private void addBetPlacesSingleChace() { for (int bp = 0; bp < 10; bp++) {
	 * RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
	 * tempRBP.setBetNo(String.valueOf(bp));
	 * rouletteBetPlaceAmountSingle.add(tempRBP); } }
	 */

	public synchronized void doubletotalBetAmount(double pBetAmount) { //
		// totalBetAmount = String.valueOf(Double.parseDouble(totalBetAmount) +
		// pBetAmount);

		totalBetAmount1 = totalBetAmount1.add(new BigDecimal(pBetAmount));
		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension, "totalBetAmount1:::::::::::::::::" + totalBetAmount1);

	}

	public synchronized void remainingTotalBetAmount(double totalcoins) {

		Utils.Logger(GameMainExtension.extension,
				"remainingTotalBetAmount::::::::::::::totalBetAmount1:::::::::::::::::::::::" + totalBetAmount1
						+ " totalcoins::::::::::::::: " + totalcoins);
		totalBetAmount1 = totalBetAmount1.subtract(new BigDecimal(totalcoins));
		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension, "remainingTotalBetAmount:::::::::::::::::" + totalBetAmount1);
		if (totalBetAmount1.doubleValue() < 0)
			totalBetAmount1 = new BigDecimal(0.0);

	}

	@Override
	public String toString() {
		return "UserBetBean [userId=" + userId + ", gameId=" + gameId + ", betStatus=" + betStatus
				+ ", totalBetAmount1=" + totalBetAmount1 + ", splitamount=" + splitamount + ", tableKeyRouletteMap="
				+ tableKeyRouletteMap + "]";
	}

}