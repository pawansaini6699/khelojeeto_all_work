/**
 * 
 */
package com.latestfunroulette.TripleRoulette.cache.beans;

import java.io.Serializable;

import com.latestfunroulette.TripleRoulette.cache.caching.interfaces.ICurrentSession;





/**
 * @author Lal Chand Sharma
 *
 */
public class CurrentSessionBean implements Serializable, ICurrentSession<String>{

	private static final long serialVersionUID = 1L;

	private String currentSession = "";


	@Override
	public synchronized void updateCurrentSession(String s) {
		currentSession = s;
	}

	@Override
	public String getCurrentSession() {
		return currentSession;
	}
	
	
	
}
