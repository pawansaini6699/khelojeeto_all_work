/**
 * 
 */
package com.latestfunroulette.TripleRoulette.cache.caching.interfaces;

/**
 * @author Lal Chand Sharma
 *
 */
public interface IRouletteBetPlaceAmountCache<K,V> extends IBaseCache<K, V> {

}
