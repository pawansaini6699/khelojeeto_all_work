/**
 * 
 */
package com.latestfunroulette.TripleRoulette.cache.caching;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.TripleRoulette.cache.beans.UserBetBean;
import com.latestfunroulette.TripleRoulette.cache.caching.interfaces.IUserBetCache;



/**
 * @author nagjee
 *
 */
public class UserBetCache extends HashMap<String, UserBetBean> implements Serializable, IUserBetCache<String, UserBetBean> {

	private static final long serialVersionUID = 1L;

	@Override
	public void add(UserBetBean v) {
		put(v.getUserId(), v);
	}

	@Override
	public void delete(String k) {
		remove(k);
	}

	@Override
	public UserBetBean getValueByKey(String k) {
		
		return get(k);
	}

	@Override
	public List<UserBetBean> getAllValue() {
		return new ArrayList<>(values());
	}

	@Override
	public HashMap<String, UserBetBean> getAll() {
		// TODO Auto-generated method stub
		return this;
	}

	@Override
	public void update(String k, UserBetBean v) {
		// TODO Auto-generated method stub
		
	}

	
}