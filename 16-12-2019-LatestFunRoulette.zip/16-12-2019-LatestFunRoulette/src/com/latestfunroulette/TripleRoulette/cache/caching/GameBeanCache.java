package com.latestfunroulette.TripleRoulette.cache.caching;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;
import com.latestfunroulette.TripleRoulette.cache.caching.interfaces.IGameBeanCache;


public class GameBeanCache extends HashMap<String, GameBean> implements Serializable, IGameBeanCache<String, GameBean> {

	private static final long serialVersionUID = 1L;

	@Override
	public void add(GameBean v) {
		put(v.getRoomName(), v);
		print("GameBeanCache ::::: Add :::: Room Name :::: " + v.getRoomName() + " :::: Total Size :::: " + size()
				+ " :::: \n GameBean ::: " + v.toString());
	}

	@Override
	public void delete(String k) {
		remove(k);
	}

	
	@Override
	public GameBean getValueByKey(String k) {
		return get(k);
	}

	@Override
	public List<GameBean> getAllValue() {
		return new ArrayList<>(values());
	}

	@Override
	public HashMap<String, GameBean> getAll() {
		return getAll();
	}

	@Override
	public void update(String k, GameBean v) {
		if (containsKey(k)) {
			put(k, v);
		}
	}

}