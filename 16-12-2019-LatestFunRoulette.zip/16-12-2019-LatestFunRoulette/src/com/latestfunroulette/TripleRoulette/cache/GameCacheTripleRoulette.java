package com.latestfunroulette.TripleRoulette.cache;

import com.latestfunroulette.TripleRoulette.cache.beans.AvatarBean;
import com.latestfunroulette.TripleRoulette.cache.beans.CurrentSessionBean;
import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;
import com.latestfunroulette.TripleRoulette.cache.beans.SessionBean;
import com.latestfunroulette.TripleRoulette.cache.caching.AvatarCache;
import com.latestfunroulette.TripleRoulette.cache.caching.GameBeanCache;
import com.latestfunroulette.TripleRoulette.cache.caching.SessionCache;
import com.latestfunroulette.TripleRoulette.cache.caching.interfaces.IAvatarCache;
import com.latestfunroulette.TripleRoulette.cache.caching.interfaces.ICurrentSession;
import com.latestfunroulette.TripleRoulette.cache.caching.interfaces.IGameBeanCache;
import com.latestfunroulette.TripleRoulette.cache.caching.interfaces.ISessionCache;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.cache.caching.PlayerCache;
import com.latestfunroulette.cache.caching.interfaces.IPlayerCache;

/**
 * @author nagjee
 *
 */
public class GameCacheTripleRoulette {

	private volatile static IPlayerCache<String, Player> tempPlayerCache;
	private ISessionCache<String, SessionBean> tempSessionCache = null;

	// private ISessionCache<String, SessionBeanCaching> tempSessionBeanCache =
	// null;

	private ICurrentSession<String> tempGameSession = null;
	private static IGameBeanCache<String, GameBean> tempGame;
	private static IAvatarCache<String, AvatarBean> tempAvatar;

	public GameCacheTripleRoulette() {
		tempAvatar = new AvatarCache();
		tempPlayerCache = new PlayerCache();
		tempGame = new GameBeanCache();
		tempSessionCache = new SessionCache();
		tempGameSession = new CurrentSessionBean();
		// tempSessionBeanCache = new TempSessionCache();
	}

	public ISessionCache<String, SessionBean> getGameSessionBySessionId() {
		return tempSessionCache;
	}

	/*
	 * public ISessionCache<String, SessionBeanCaching> getGameSessionBySessionId1()
	 * { return tempSessionBeanCache; }
	 */

	public ICurrentSession<String> getSession() {
		return tempGameSession;
	}

	public IGameBeanCache<String, GameBean> getGames() {
		return tempGame;
	}

	public IAvatarCache<String, AvatarBean> getAvatar() {
		return tempAvatar;
	}

	public IPlayerCache<String, Player> getPlayer() {
		return tempPlayerCache;
	}
}