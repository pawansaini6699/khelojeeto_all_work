package com.latestfunroulette.TripleRoulette.client;

import java.util.List;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class UpdateTaskHandlerTripleNine {

	public static GameMainExtension extension2 = null;
	ScheduledFuture<?> taskHandlerForGames;

	public UpdateTaskHandlerTripleNine(SFSExtension pExtension) {

		Utils.Logger(pExtension,"UpdateTaskHandlerTripleNine::::::::::::::::::::::extension");
	}

	public void startGameUpdate(SmartFoxServer pSFS) {
		taskHandlerForGames = pSFS.getTaskScheduler().scheduleAtFixedRate(new Runnable() {

			@Override
			public void run() {
				List<GameBean> tempGames = GameMainExtension.gameCacheTripleRoulette.getGames().getAllValue();

				int i = 0;

				while (tempGames.size() > i) {
					GameBean game = tempGames.get(i);
					game.setGameTurnTime(1);
					if (game.getGameMachine() != null) {
						new Thread() {
							@Override
							public void run() {

								boolean gamestatus = game.getGameMachine().isMachineStatus();
								if (gamestatus) {
									game.getGameMachine().onProcess();
								}

							}
						}.start();
					}

					++i;
				}
			}
		}, 15, 1, TimeUnit.SECONDS);
	}

}