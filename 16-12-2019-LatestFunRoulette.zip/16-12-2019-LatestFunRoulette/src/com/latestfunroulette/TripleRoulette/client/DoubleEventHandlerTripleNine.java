package com.latestfunroulette.TripleRoulette.client;

import com.latestfunroulette.TripleRoulette.cache.beans.SessionBean;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class DoubleEventHandlerTripleNine extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject param) {

		new Thread() {
			@Override
			public void run() {

				Utils.Logger(GameMainExtension.extension,
						"DoubleEventHandlerDoubleNine:::::::::::::::::::::::::::::::::::param" + param.getDump());

				String psessionid = param.getUtfString(Param.SESSIONID);

				SessionBean oldtempSession = GameMainExtension.gameCacheTripleRoulette.getGameSessionBySessionId()
						.getValueByKey(psessionid);

				oldtempSession.addUserBetDouble(pUser.getName());
			}
		}.start();

	}

}
