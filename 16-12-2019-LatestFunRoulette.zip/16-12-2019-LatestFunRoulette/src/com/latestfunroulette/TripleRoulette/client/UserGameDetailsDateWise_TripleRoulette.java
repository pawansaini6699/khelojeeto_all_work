package com.latestfunroulette.TripleRoulette.client;

import com.latestfunroulette.TripleRoulette.comman.GameEventMangaer;
import com.latestfunroulette.TripleRoulette.comman.interfaces.IGameEventManager;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class UserGameDetailsDateWise_TripleRoulette extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User user, ISFSObject params) {
		
		
		new Thread() {

			@Override
			public void run() {

				Utils.Logger(getParentExtension(), " ::UserGameDetailsDateWise_TripleRoulette:: Request :::: User ::: "
						+ user.getName() + " ::: Params :::: " + params.getDump());

				try {

					IGameEventManager tempEvents = new GameEventMangaer();

					tempEvents.onUserGameDetailsStartAndEndDate(user, params, new CallBack() {

						@Override
						public void call(Object... values) {

							
						}
						
					});
				} catch (Exception e) {

				}

			}

		}.start();

	}
		
		
		
		
		
	}