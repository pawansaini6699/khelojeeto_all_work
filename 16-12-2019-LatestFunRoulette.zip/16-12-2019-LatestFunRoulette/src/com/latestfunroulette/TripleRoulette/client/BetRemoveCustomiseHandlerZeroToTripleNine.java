package com.latestfunroulette.TripleRoulette.client;

import com.latestfunroulette.TripleRoulette.comman.GameEventMangaer;
import com.latestfunroulette.TripleRoulette.comman.interfaces.IGameEventManager;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

/*
 * Akshay
 */
public class BetRemoveCustomiseHandlerZeroToTripleNine extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User user, ISFSObject params) {

		Utils.Logger(getParentExtension(), " ::BetRemoveCustomiseHandler:: Request :::: User ::: " + user.getName()
				+ " ::: Params :::: " + params.getDump());

		try {

			IGameEventManager tempEvents = new GameEventMangaer();

			tempEvents.onCancelSpecificBet(user, params, new CallBack() {

				@Override
				public void call(Object... values) {

				}

			});
		} catch (Exception e) {

		}

	}

}
