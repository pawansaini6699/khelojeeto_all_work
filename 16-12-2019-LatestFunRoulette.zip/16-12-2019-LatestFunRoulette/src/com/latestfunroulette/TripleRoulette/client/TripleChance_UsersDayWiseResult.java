package com.latestfunroulette.TripleRoulette.client;

import com.latestfunroulette.TripleRoulette.comman.GameEventMangaer;
import com.latestfunroulette.TripleRoulette.comman.interfaces.IGameEventManager;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class TripleChance_UsersDayWiseResult extends BaseClientRequestHandler{

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		
		new Thread()
		{
			public void run()
			{
				
				Utils.Logger(getParentExtension(), " ::PlayMart_UsersDayWiseResult:: Request :::: User ::: "
						+ pUser.getName() + " ::: Params :::: " + params.getDump());

				try {

					IGameEventManager tempEvents = new GameEventMangaer();

					tempEvents.UsersDayWiseResult(pUser, params, new CallBack() {

						@Override
						public void call(Object... values) {

							
						}
						
					});
				} catch (Exception e) {

				}
			}
		}.start();
		
	}

}
