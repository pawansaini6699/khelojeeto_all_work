package com.latestfunroulette.TripleRoulette.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans;

public class TicketPrint {

	private TicketPrint() {

	}

	static HashMap<String, HashMap<String, HashMap<String, RouletteBetBeans>>> ticketGenerateHashMap = new HashMap<String, HashMap<String, HashMap<String, RouletteBetBeans>>>();
	static List<String> ticketList = new ArrayList<String>();

	public static List<String> getTempRouletteBetBeans() {
		return ticketList;
	}

	public static void setTempRouletteBetBeans(List<String> ticketList) {
		TicketPrint.ticketList = ticketList;
	}

	public static HashMap<String, HashMap<String, RouletteBetBeans>> getTableTypeHashMapByTicketId(String ticketid) {

		if (ticketGenerateHashMap.containsKey(ticketid)) {

			return ticketGenerateHashMap.get(ticketid);
		}
		return null;
	}

	public static HashMap<String, RouletteBetBeans> getBetNoRouletteBetBeanByTicketIdAndTableType(String ticketid,
			String talbetype) {

		if (ticketGenerateHashMap.containsKey(ticketid)) {

			HashMap<String, HashMap<String, RouletteBetBeans>> temptableMap = ticketGenerateHashMap.get(ticketid);
			if (temptableMap.containsKey(talbetype)) {

				return temptableMap.get(talbetype);
			}
		}
		return null;
	}

	public static RouletteBetBeans getRouletteBetBeanByTicketIdOrTableTypeOrBetNo(String ticketId, String tableType,
			String betNo) {

		if (ticketGenerateHashMap.containsKey(ticketId)) {

			HashMap<String, HashMap<String, RouletteBetBeans>> temptableMap = ticketGenerateHashMap.get(ticketId);
			if (temptableMap.containsKey(tableType)) {
				HashMap<String, RouletteBetBeans> tempBetNoMap = temptableMap.get(tableType);

				if (tempBetNoMap.containsKey(betNo)) {

					return tempBetNoMap.get(betNo);
				}

			}
		}
		return null;
	}

	/* Ticket id getter setter method:::::::::::::::::::::::::::: */
	public static void setTempRouletteBetBeans(
			HashMap<String, HashMap<String, HashMap<String, RouletteBetBeans>>> tempRouletteBetBeansTableTypeKey) {
		TicketPrint.ticketGenerateHashMap = tempRouletteBetBeansTableTypeKey;
	}

	public static HashMap<String, HashMap<String, HashMap<String, RouletteBetBeans>>> getTicketGenerateHashMap() {
		return ticketGenerateHashMap;
	}

	public static boolean isTicketExist(String ticketno) {

		return ticketno == null ? false : ticketGenerateHashMap.containsKey(ticketno);

	}

}
