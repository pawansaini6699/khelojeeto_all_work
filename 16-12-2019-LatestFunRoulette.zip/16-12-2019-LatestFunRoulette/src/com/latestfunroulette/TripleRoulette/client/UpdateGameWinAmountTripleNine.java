package com.latestfunroulette.TripleRoulette.client;

import java.util.List;

import com.latestfunroulette.TripleRoulette.base.interfaces.BaseState;
import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;
import com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans;
import com.latestfunroulette.TripleRoulette.cache.beans.SessionBean;
import com.latestfunroulette.TripleRoulette.cache.beans.UserBetBean;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Events;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.SFSExtension;

import scala.ref.WeakReference;

public class UpdateGameWinAmountTripleNine {
	@SuppressWarnings("unused")
	private WeakReference<SFSExtension> ref_extension = null;

	public UpdateGameWinAmountTripleNine(SFSExtension extension) {
		ref_extension = new WeakReference<SFSExtension>(extension);
	}

	public static void updateWinAmount(BaseState basestate, String pSession, String pWinnumber, Room roomname,
			int jackport, String ticketid) {

		new Thread() {
			@Override
			public void run() {

				Utils.Logger(GameMainExtension.extension, "Triplechance:::::::::::::::::UpdateGameWinAmountManager"
						+ "sessionid" + pSession + " winnnumber" + pWinnumber);

				GameBean gameBean = basestate.getGameBean();
				Player player = GameMainExtension.cache.getPlayer().getValueByKey(gameBean.getUserid());
				SessionBean tempSession = GameMainExtension.gameCacheTripleRoulette.getGameSessionBySessionId()
						.getValueByKey(pSession);
				Room tempRoom = GameMainExtension.extension.getParentZone().getRoomByName(gameBean.getRoomName());

				int winamountsingle = 0;
				int winamountdouble = 0;
				int winamounttriple = 0;
				String tempWinamount = "";
				int betamountsingle = 0;
				int betamountdouble = 0;
				int betamounttriple = 0;

				if (tempSession != null) {

					List<UserBetBean> tempUserBetBeans = tempSession.getAllUserBets();
					if (tempUserBetBeans != null) {
						for (int u = 0; u < tempUserBetBeans.size(); u++) {
							UserBetBean tempUser = tempUserBetBeans.get(u);
							int gameId = tempUser.getGameId();
							User tempSFSUser = tempRoom.getUserByName(tempUser.getUserId());

							if (tempUser != null && tempUser.isBetStatus()) {

								List<String> tempStrings = TicketPrint.getTempRouletteBetBeans();

								System.out.println(
										"UpdateGameWinAmountTripleNine:::::::::::::tempStrings:::::::::" + tempStrings);

								if (tempStrings.size() > 0) {

									for (String ticketno : tempStrings) {
										System.out.println("UpdateGameWinAmountZeroNine:::::::::::::ticketno:::::::::"
												+ tempStrings);

										RouletteBetBeans tEMPBeansSingle = TicketPrint
												.getRouletteBetBeanByTicketIdOrTableTypeOrBetNo(ticketno, "SINGLE",
														String.valueOf(pWinnumber));

										RouletteBetBeans tEMPBeansDouble = TicketPrint
												.getRouletteBetBeanByTicketIdOrTableTypeOrBetNo(ticketno, "DOUBLE",
														String.valueOf(pWinnumber));

										RouletteBetBeans tEMPBeansTriple = TicketPrint
												.getRouletteBetBeanByTicketIdOrTableTypeOrBetNo(ticketno, "TRIPLE",
														String.valueOf(pWinnumber));

										if (tEMPBeansSingle != null) {
											betamountsingle = (int) (tEMPBeansSingle.getBetAmount());
											winamountsingle = betamountsingle * 9 * jackport;
											Utils.Logger(GameMainExtension.extension,
													"Triple chance:::::::::::::::SINGLE CHANCE::::::::::tempRoulettebeansSingle "
															+ winamountsingle);

										} else {
											Utils.Logger(GameMainExtension.extension,
													"Triple chance:::::::::::::::SINGLE CHANCE::::::::::tempRoulettebeansSingle "
															+ tEMPBeansSingle);
											tEMPBeansSingle = new RouletteBetBeans();
										}
										if (tEMPBeansDouble != null) {
											Utils.Logger(GameMainExtension.extension,
													"Triplechance::::::::::::::::::::::UpdateGameWinAmountTripleNine :::::::::double::::::::::::tempRoulettebeansDouble::NOT NULL:"
															+ tEMPBeansDouble.toString());

											betamountdouble = (int) tEMPBeansDouble.getBetAmount();
											winamountdouble = betamountdouble * 90 * jackport;
										} else {
											Utils.Logger(GameMainExtension.extension,
													"Triplechance::::::::::::::::::::::UpdateGameWinAmountTripleNine :::::::::double::::::::::::::::::::tempRoulettebeansDouble:::::null");

											tEMPBeansDouble = new RouletteBetBeans();
										}

										if (tEMPBeansTriple != null) {
											Utils.Logger(GameMainExtension.extension,
													"<><><><><><><><><><><><><><><><><><> UpdateGameWIn Triple ::::: bean is not null");
											betamounttriple = (int) (tEMPBeansTriple.getBetAmount());
											winamounttriple = betamounttriple * 900 * jackport;
										} else {
											Utils.Logger(GameMainExtension.extension,
													"<><><><><><><><><><><><><><><><><><> UpdateGameWIn Triple ::::: bean is null");
											tEMPBeansTriple = new RouletteBetBeans();
										}

										gameBean.setWinner(
												String.valueOf(winamountsingle + winamountdouble + winamounttriple));
										tempWinamount = String
												.valueOf(winamountsingle + winamountdouble + winamounttriple);

										Utils.Logger(GameMainExtension.extension,
												"Doublechance::::::::::::::::::::::::UpdateGameWinAmountManager::::::::"
														+ "tempWinamount" + tempWinamount);

										int userexistStatus = 1;

// User tempSFSUser = tempRoom.getUserByName(tempUser.getUserId());

										if (tempSFSUser != null) {
											Utils.Logger(GameMainExtension.extension,
													"Doublechance:::::::::::::::::::::::: UpdateUserCreditsbeforeTakeHandler:::::::::::::::::::userexistStatus "
															+ userexistStatus);

											userexistStatus = 0;
										}

										gameBean.setTotalsessionwinamount(String.valueOf(tempWinamount));
										gameBean.setJackport(jackport);
										GameMainExtension.gameCacheTripleRoulette.getGames().add(gameBean);
// final int winamountuser=winamount;

										DBManager.updateUserWinAmountsqlZeroToTripleNine(tempUser.getUserId(), jackport,
												tempWinamount, pWinnumber, pSession, winamountsingle, winamountdouble,
												winamounttriple, ticketno, new CallBack() {

													@Override
													public void call(Object... callback) {

														{

															ISFSObject isfsObject = (ISFSObject) callback[0];

// isfsObject.putUtfString(Param.WINAMOUNT,
// String.valueOf(winamountuser));
															Utils.Logger(GameMainExtension.extension,
																	"--<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>-------- UpdateUserCreditsbeforeTakeHandler----------response "
																			+ isfsObject.getDump());
															GameMainExtension.extension.send(Events.UPDATEUSERCREDITS,
																	isfsObject, tempSFSUser);
														}

													}
												});

										DBManager.updateUserWinAmountmongoZeroToTripleNine(tempUser.getUserId(),
												pSession, jackport, pWinnumber, tempWinamount, userexistStatus,
												player.getChips());

										DBManager.updateUserWinAmountmongoTripleChanceZeroToDoubleNine(
												tempUser.getUserId(), pSession, jackport, pWinnumber, tempWinamount,
												userexistStatus, player.getChips());

										DBManager.updateUserWinAmountmongoTripleChanceZeroToNine(tempUser.getUserId(),
												pSession, jackport, pWinnumber, tempWinamount, userexistStatus,
												player.getChips());

									}

									Utils.Logger(GameMainExtension.extension,
											"::::::::: UpdateGameWinAmount :::::::::::::totalsessionbetamount"
													+ tempSession.getTotalBetAmount()
													+ "::::::::::: winamount ::::::::::::::::" + tempWinamount);
									DBManager.updateLiveTimeDataZeroToTripleNine(tempSession.getTotalBetAmount(),
											String.valueOf(tempWinamount), gameId, jackport);

								}

								else {

									try {
										RouletteBetBeans tempRoulettebeansSingle = tempUser
												.getUserRouletteBetsByBetNoAndTableType(
														String.valueOf(pWinnumber.charAt(0)), "SINGLE");

										if (tempRoulettebeansSingle != null) {
											betamountsingle = (int) (tempRoulettebeansSingle.getBetAmount());
											winamountsingle = betamountsingle * 9 * jackport;
											Utils.Logger(GameMainExtension.extension,
													"Triple chance:::::::::::::::SINGLE CHANCE::::::::::tempRoulettebeansSingle "
															+ winamountsingle);
										} else {
											Utils.Logger(GameMainExtension.extension,
													"Triple chance:::::::::::::::SINGLE CHANCE::::::::::tempRoulettebeansSingle "
															+ tempRoulettebeansSingle);
											tempRoulettebeansSingle = new RouletteBetBeans();
										}
									} catch (Exception e) {
										Utils.Logger(GameMainExtension.extension,
												"Triplechance::::::::::::::::UpdateGameWinAmountTripleNine:::::::::::single::::::::::error"
														+ e);
									}

									try {
										RouletteBetBeans tempRoulettebeansDouble = tempUser
												.getUserRouletteBetsByBetNoAndTableType(pWinnumber.substring(0, 2),
														"DOUBLE");

										if (tempRoulettebeansDouble != null) {
											Utils.Logger(GameMainExtension.extension,
													"Triplechance::::::::::::::::::::::UpdateGameWinAmountTripleNine :::::::::double::::::::::::tempRoulettebeansDouble::NOT NULL:"
															+ tempRoulettebeansDouble.toString());

											betamountdouble = (int) tempRoulettebeansDouble.getBetAmount();
											winamountdouble = betamountdouble * 90 * jackport;
										} else {
											Utils.Logger(GameMainExtension.extension,
													"Triplechance::::::::::::::::::::::UpdateGameWinAmountTripleNine :::::::::double::::::::::::::::::::tempRoulettebeansDouble:::::null");

											tempRoulettebeansDouble = new RouletteBetBeans();
										}
									} catch (Exception e) {
										Utils.Logger(GameMainExtension.extension,
												"Triplechance:::::::::::::::::::::::::::UpdateGameWinAmountTripleNine::::::::::::double:::::::::error"
														+ e);
									}

									try {
										RouletteBetBeans tempRoulettebeansSingle = tempUser
												.getUserRouletteBetsByBetNoAndTableType(String.valueOf(pWinnumber),
														"TRIPLE");

										if (tempRoulettebeansSingle != null) {
											Utils.Logger(GameMainExtension.extension,
													"<><><><><><><><><><><><><><><><><><> UpdateGameWIn Triple ::::: bean is not null");
											betamounttriple = (int) (tempRoulettebeansSingle.getBetAmount());
											winamounttriple = betamounttriple * 900 * jackport;
										} else {
											Utils.Logger(GameMainExtension.extension,
													"<><><><><><><><><><><><><><><><><><> UpdateGameWIn Triple ::::: bean is null");
											tempRoulettebeansSingle = new RouletteBetBeans();
										}
									} catch (Exception e) {
										Utils.Logger(GameMainExtension.extension,
												"Triplechance::::::::::::::::UpdateGameWinAmountDoubleNine:::::::::::triple::::::::::error"
														+ e);
									}

									gameBean.setWinner(
											String.valueOf(winamountsingle + winamountdouble + winamounttriple));

// BigDecimal tempBigDecimal = new BigDecimal((tempWinnumberBetAmount *36));
// tempWinamount = String.valueOf(winamountsingle + winamountdouble);
									tempWinamount = String.valueOf(winamountsingle + winamountdouble + winamounttriple);

									Utils.Logger(GameMainExtension.extension,
											"Doublechance::::::::::::::::::::::::UpdateGameWinAmountManager::::::::"
													+ "tempWinamount" + tempWinamount);

									int userexistStatus = 1;

// User tempSFSUser = tempRoom.getUserByName(tempUser.getUserId());

									if (tempSFSUser != null) {
										Utils.Logger(GameMainExtension.extension,
												"Doublechance:::::::::::::::::::::::: UpdateUserCreditsbeforeTakeHandler:::::::::::::::::::userexistStatus "
														+ userexistStatus);

										userexistStatus = 0;
									}

									gameBean.setTotalsessionwinamount(String.valueOf(tempWinamount));
									gameBean.setJackport(jackport);
									GameMainExtension.gameCacheTripleRoulette.getGames().add(gameBean);
// final int winamountuser=winamount;

									DBManager.updateUserWinAmountsqlZeroToTripleNine(tempUser.getUserId(), jackport,
											tempWinamount, pWinnumber, pSession, winamountsingle, winamountdouble,
											winamounttriple, ticketid, new CallBack() {

												@Override
												public void call(Object... callback) {

													{

														ISFSObject isfsObject = (ISFSObject) callback[0];

// isfsObject.putUtfString(Param.WINAMOUNT,
// String.valueOf(winamountuser));
														Utils.Logger(GameMainExtension.extension,
																"--<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>-------- UpdateUserCreditsbeforeTakeHandler----------response "
																		+ isfsObject.getDump());
														GameMainExtension.extension.send(Events.UPDATEUSERCREDITS,
																isfsObject, tempSFSUser);
													}

												}
											});

									DBManager.updateUserWinAmountmongoZeroToTripleNine(tempUser.getUserId(), pSession,
											jackport, pWinnumber, tempWinamount, userexistStatus, player.getChips());

									DBManager.updateUserWinAmountmongoTripleChanceZeroToDoubleNine(tempUser.getUserId(),
											pSession, jackport, pWinnumber, tempWinamount, userexistStatus,
											player.getChips());

									DBManager.updateUserWinAmountmongoTripleChanceZeroToNine(tempUser.getUserId(),
											pSession, jackport, pWinnumber, tempWinamount, userexistStatus,
											player.getChips());

								}

								Utils.Logger(GameMainExtension.extension,
										"::::::::: UpdateGameWinAmount :::::::::::::totalsessionbetamount"
												+ tempSession.getTotalBetAmount()
												+ "::::::::::: winamount ::::::::::::::::" + tempWinamount);
								DBManager.updateLiveTimeDataZeroToTripleNine(tempSession.getTotalBetAmount(),
										String.valueOf(tempWinamount), gameId, jackport);

							}
						}

					}
				}
			}

		}.start();
	}

}