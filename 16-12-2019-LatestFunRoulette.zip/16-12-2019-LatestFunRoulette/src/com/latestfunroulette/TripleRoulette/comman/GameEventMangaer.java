package com.latestfunroulette.TripleRoulette.comman;

import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;
import com.latestfunroulette.TripleRoulette.comman.interfaces.IGameEventManager;
import com.latestfunroulette.TripleRoulette.state.interfaces.IBetPlaceState;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.StaticRooms;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;

public class GameEventMangaer implements IGameEventManager {

	@Override
	public void onPlayerLeave(User pUser, ISFSObject params, CallBack pCallBack) {
		Utils.Logger(GameMainExtension.extension, " onPlayerLeave() :::: Request :::: User :::: " + pUser.getName()
				+ " :::::: Params :::: " + params.getDump());
		String roomName = params.getUtfString(Param.ROOMNAME);
		getGameMachine(roomName).onLeave(pUser.getName());
		pCallBack.call(roomName);
	}

	@Override
	public void onLiveBet(User pUser, ISFSObject params, CallBack pCallBack) {

		GameBean gameBean = new GameBean();
		Utils.Logger(GameMainExtension.extension,
				"Triple Roulette:::::::::::::::::::::: onLiveBet() :::: Request :::: User :::: " + pUser.getName()
						+ " :::::: Params :::: " + params.getDump() + "::::pUser " + pUser.getName());
		String roomName = params.getUtfString(Param.ROOMNAME);
		// String user_id = params.getUtfString(Param.USERID);
		String session_id = params.getUtfString(Param.SESSIONID);

		double coins = params.getDouble(Param.COINS);
		// String command = params.getUtfString(Params.COMMANDNAME);
		int numbers = params.getInt(Param.ID);
		String tabletype = params.getUtfString(Param.TABLE_TYPE);
		int gameid = params.getInt(Param.GAMEID);

		gameBean.setGameid(gameid);

		GameMainExtension.gameCacheTripleRoulette.getGames().add(gameBean);

		Utils.Logger(GameMainExtension.extension,
				"ROOMNAME::::::::" + roomName + "  user " + pUser.getName() + "sessionid::::::" + session_id
						+ "  coins :::::::::  " + coins + "numbers" + numbers + "tabletype::::::::::::::::::"
						+ tabletype + "gameid" + gameid);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(StaticRooms.TRIPLE_CHANCE_ROOM);

		Utils.Logger(GameMainExtension.extension, " tempstate::::: " + tempState);

		tempState.betPlaceState(pUser.getName(), session_id, coins, numbers, tabletype, gameid);

	}

	@Override
	public void onCancelSpecificBet(User pUser, ISFSObject params, CallBack pCallBack) {

		Utils.Logger(GameMainExtension.extension, " onCancelSpecificBet() :::: Request :::: User :::: "
				+ pUser.getName() + " :::::: Params ::::" + params.getDump());

		String roomName = params.getUtfString(Param.ROOMNAME);
		String session_id = params.getUtfString(Param.SESSIONID);

		String tabletype = params.getUtfString(Param.TABLE_TYPE);
		int betno = params.getInt(Param.BETNO);
		double betamount = params.getDouble(Param.BETAMOUNT);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.onCancelBet(roomName, pUser, session_id, tabletype, betno, betamount);

	}

	@Override
	public void onClearAllBet(User pUser, ISFSObject params, CallBack pCallBack) {
		Utils.Logger(GameMainExtension.extension, " onClearAllBet() :::: Request :::: User :::: " + pUser.getName()
				+ " :::::: Params ::::" + params.getDump());
		String roomName = params.getUtfString(Param.ROOMNAME);
		String user_id = params.getUtfString(Param.USERID);
		String session_id = params.getUtfString(Param.SESSIONID);

		Utils.Logger(GameMainExtension.extension,
				"DoubleRoulette:::::::::::::::GameEventManager:::::::::::::onClearAllBet:::::::::userid" + user_id);
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.onClearAll(pUser, session_id);
	}

	@Override
	public void onRebet(User pUser, ISFSObject params, CallBack pCallBack) {

		String roomName = params.getUtfString(Param.ROOMNAME);
		String user_id = params.getUtfString(Param.USERID);
		String session_id = params.getUtfString(Param.SESSIONID);

		Utils.Logger(GameMainExtension.extension, "GameEventManager:::::::::::::::::onRebet::::::::userid" + user_id);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.onRebetRequest(roomName, pUser, session_id);

	}

	@Override
	public void onGetWinningNumber(User pUser, ISFSObject params, CallBack pCallBack) {

		// String roomName = params.getUtfString(Params.ROOMNAME);

		// IGameWaitingState<GameBean> iGameWaitingState = (IGameWaitingState<GameBean>)
		// getCurrentState(roomName);

		// iGameWaitingState.onGetWinNumber(roomName);

	}

	@Override
	public void onBetOK(User pUser, ISFSObject params, CallBack pCallBack) {

		String sessionId = params.getUtfString(Param.SESSIONID);
		String userId = params.getUtfString(Param.USERID);
		String roomName = params.getUtfString(Param.ROOMNAME);
		Utils.Logger(GameMainExtension.extension, "GameEventManager:::::::::::::::onBetOk::::::userid" + userId);
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.userBetSave(roomName, pUser, sessionId);

	}

	@Override
	public void onRemoveBetCustomise(User pUser, ISFSObject params, CallBack pCallBack) {
		String roomName = params.getUtfString(Param.ROOMNAME);
		String userId = params.getUtfString(Param.USERID);
		String sessionId = params.getUtfString(Param.SESSIONID);
		int id = params.getInt(Param.ID);

		Utils.Logger(GameMainExtension.extension,
				"GameEventManager:::::::::::::::::onRemoveBetCustomise::::::::userid" + userId);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.userBetRemove(roomName, sessionId, String.valueOf(id), pUser);

	}

	@Override
	public void onTripleRandomBets(User pUser, ISFSObject params, CallBack pCallBack) {
		String roomName = params.getUtfString(Param.ROOMNAME);
		String sessionId = params.getUtfString(Param.SESSIONID);
		double coins = params.getDouble(Param.COINS);
		// String command = params.getUtfString(Params.COMMANDNAME);
		int numbers = params.getInt(Param.ID);
		int tablebetnumbers = params.getInt(Param.TABLE_NUMBERS);
		String tabletype = params.getUtfString(Param.TABLE_TYPE);
		int gameid = params.getInt(Param.GAMEID);

		Utils.Logger(GameMainExtension.extension,
				"onTripleRandomBets:::::::::::::::::::::::::::::::ROOMNAME::::::::" + roomName + "  user "
						+ pUser.getName() + "sessionid::::::" + sessionId + "  coins :::::::::  " + coins + "numbers"
						+ numbers + "tabletype::::::::::::::::::" + tabletype + "gameid" + gameid);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(StaticRooms.TRIPLE_CHANCE_ROOM);

		Utils.Logger(GameMainExtension.extension, " tempstate::::: " + tempState);

		tempState.betPlaceRandomWise(pUser, sessionId, coins, numbers, tabletype, gameid, tablebetnumbers);

	}

	@Override
	public void onBetPrintExe(User pUser, ISFSObject params, CallBack pCallBack) {

		String sessionId = params.getUtfString(Param.SESSIONID);
		String roomName = params.getUtfString(Param.ROOMNAME);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.betPrintExe(roomName, sessionId, pUser);

	}

	@Override
	public void onUserGameDetails(User pUser, ISFSObject params, CallBack pCallBack) {
		String roomName = params.getUtfString(Param.ROOMNAME);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.userGameDetails(roomName, pUser);

	}

	@Override
	public void onUserGameDetailsStartAndEndDate(User pUser, ISFSObject params, CallBack pCallBack) {
		String roomName = params.getUtfString(Param.ROOMNAME);
		String startdate = params.getUtfString(Param.STARTDATE);
		String enddate = params.getUtfString(Param.ENDDATE);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.userGameDetailsStartAndEndDate(roomName, pUser, startdate, enddate);

	}

	@Override
	public void UsersDayWiseResult(User pUser, ISFSObject params, CallBack pCallBack) {

		String roomName = params.getUtfString(Param.ROOMNAME);
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.UsersDayWiseResultDetails_Triplechance(roomName, pUser);

	}

	@Override
	public void onCancelTicketTripleChance(User pUser, ISFSObject params, CallBack pCallBack) {

		String sessionId = params.getUtfString(Param.SESSIONID);
		String roomName = params.getUtfString(Param.ROOMNAME);
		String ticketid = params.getUtfString(Param.TICKETID);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);

		tempState.betCancelByTicketId_TripleChance(roomName, sessionId, pUser, ticketid);
	}

	@Override
	public void onClaimTicket(User pUser, ISFSObject params, CallBack pCallBack) {

		String sessionId = params.getUtfString(Param.SESSIONID);
		String roomName = params.getUtfString(Param.ROOMNAME);
		String ticketid = params.getUtfString(Param.TICKETID);
		int gameid = params.getInt(Param.TICKETID);
		String gametype = params.getUtfString(Param.TICKETID);

		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);

		tempState.betClaimByTicketId_TripleChance(roomName, sessionId, pUser, ticketid,gameid,gametype);
	}

}