package com.latestfunroulette.TripleRoulette.comman.interfaces;


import com.latestfunroulette.TripleRoulette.base.interfaces.IState;
import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;
import com.latestfunroulette.TripleRoulette.machine.interfaces.IStateMachine;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;

public interface IGameEventManager {

void onLiveBet(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onGetWinningNumber(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onCancelSpecificBet(User pUser, ISFSObject params,CallBack pCallBack);
	
	void onClearAllBet(User pUser, ISFSObject params,CallBack pCallBack);
	
	void onRebet(User pUser, ISFSObject params,CallBack pCallBack);
	
	void onBetOK(User pUser, ISFSObject params,CallBack pCallBack);
	
	void onTripleRandomBets(User pUser, ISFSObject params,CallBack pCallBack);
	
	
	void onUserGameDetails(User user, ISFSObject params, CallBack callBack);
	void onUserGameDetailsStartAndEndDate(User pUser, ISFSObject params, CallBack pCallBack);

	void onPlayerLeave(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onRemoveBetCustomise(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onBetPrintExe(User pUser, ISFSObject params, CallBack pCallBack);
	
	void UsersDayWiseResult(User pUser, ISFSObject params, CallBack pCallBack);

    void onCancelTicketTripleChance(User pUser, ISFSObject params, CallBack pCallBack);
  
    void onClaimTicket(User pUser, ISFSObject params, CallBack pCallBack);

	/////////////////////////////////////////////////////////////////////////////////////

	default IStateMachine<GameBean> getGameMachine(String pRoomName) {
		if (GameMainExtension.cache.getGames().getValueByKey(pRoomName) != null) {
			print(" ::::::: GAME IS FOUND  ::::::::  " + pRoomName);
			return GameMainExtension.gameCacheTripleRoulette.getGames().getValueByKey(pRoomName).getGameMachine();
		} else {
			print(" ::::::: GAME IS NULL   ::::::::  " + pRoomName);
			return null;
		}
	}

	default IState<GameBean> getCurrentState(String pRoomName) {
		
		GameBean gb=GameMainExtension.gameCacheTripleRoulette.getGames().getValueByKey(pRoomName);
			return gb.getGameMachine().currentState();
	}

	default void print(String msg) {
		Utils.Logger(GameMainExtension.extension, "GameEventManager ::::: " + msg);
	}

}