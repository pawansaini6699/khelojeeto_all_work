package com.latestfunroulette.TripleRoulette.comman.interfaces;

public interface IGloblaId {

	void updateId();

	int getCurrentId();

	int getNextId();

	String getNextId(String f);
}