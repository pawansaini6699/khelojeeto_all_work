package com.latestfunroulette.TripleRoulette.comman.interfaces;

public interface IGloblaIdTripleChance {

	void updateId();

	int getCurrentId();

	int getNextId();

	String getNextId(String f);
}