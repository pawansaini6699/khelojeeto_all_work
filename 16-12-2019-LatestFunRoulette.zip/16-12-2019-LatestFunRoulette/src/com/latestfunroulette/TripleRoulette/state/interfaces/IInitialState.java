package com.latestfunroulette.TripleRoulette.state.interfaces;

public interface IInitialState<G> extends IBaseState<G> {

}