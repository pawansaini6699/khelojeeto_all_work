package com.latestfunroulette.TripleRoulette.state.interfaces;

public interface IGameWaitingState<G> extends IBaseState<G> {
	
	
//	void betSaveingState(String roomname,String userid,String sessionid,String totalbet);

}
