package com.latestfunroulette.TripleRoulette.state.interfaces;

public interface IGameResultState<G> extends IBaseState<G> {

}
