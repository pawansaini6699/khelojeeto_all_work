package com.latestfunroulette.TripleRoulette.state.interfaces;

import com.latestfunroulette.TripleRoulette.base.interfaces.IState;

public interface IBaseState<G> extends IState<G> {

	


}
