package com.latestfunroulette.TripleRoulette.state;

import com.latestfunroulette.TripleRoulette.base.interfaces.BaseState;
import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;
import com.latestfunroulette.TripleRoulette.state.interfaces.IGameWaitingState;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.GameStateZeroToTripleNineTime;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

public class GameResultWaitingState extends BaseState implements IGameWaitingState<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,
				"TripleChance::::::::::::::::::::GameResultWaitingState :::: OnStart():::::::::::::::::::");
		super.init(g, GameStateZeroToTripleNineTime.GAME_WAIT_TIME);

	}

	@Override
	public void onProcess() {

		long currenttime=getTimer().getElapsedTime();
		Utils.Logger(GameMainExtension.extension,
				"TripleChance::::::::::::::::::::::::GameResultWaitingState:::::::::onProcess::::::::::::::::::::::::::::timer"
						+ currenttime);
		if (currenttime > getStateTime()) {
			onExist();
		} else if (currenttime == 52) {
		
			getEvents().betinsertOnTime(this, currenttime);

		}

	}

	public void onJoin(String pLoginId) {
		print("GameResultWaitingState :::: OnJoin()");
		getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {
		getGameBean().setGameState(GameState.RESULT);
		getGameMachine().onNext(getGameBean().getGameState());

	}

}
