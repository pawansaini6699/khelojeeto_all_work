package com.latestfunroulette.TripleRoulette.state;

import com.latestfunroulette.TripleRoulette.base.baseclass.BasebetPlaceState;
import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;
import com.latestfunroulette.TripleRoulette.state.interfaces.IBetPlaceState;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.GameStateZeroToTripleNineTime;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;

public class BetPlaceBetAmountState extends BasebetPlaceState implements IBetPlaceState<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,
				"TRIPLECHANCE::::::::::::::::::: OnStart()::::::::::::::::::::::::BetPlaceBetAmountState"
						+ g.getGameTurnTime());
		super.init(g, GameStateZeroToTripleNineTime.BET_PLACE_TIME);
		// int time = (int) getTimer().getElapsedTime();
		getTimer().resetTimer();
		getEvents().newSessionGenarate(this);

	}

	@Override
	public void onProcess() {

		long currenttime = getTimer().getElapsedTime();

		Utils.Logger(GameMainExtension.extension,
				"TRIPLECHANCE:::::::::::::::::::::::::::::::BetPlaceBetAmountState:::::::::::::::timer " + currenttime);

		if (currenttime > getStateTime()) {
			onExist();
		} else if (currenttime == 48) {
			getEvents().betSaveOnTime(this);
		}

	}

	@Override
	public void onJoin(String pLoginId) {
		getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);

	}

	@Override
	public void playWaitingState() {

	}

	@Override
	public void gameResultState() {

	}

	@Override
	public void onExist() {
		getGameBean().setGameState(GameState.RESULTWAIT);
		getGameMachine().onNext(getGameBean().getGameState());

	}

	@Override
	public void betPlaceState(String userid, String session_id, double coins, int selectednumber, String table_type,
			int gameid) {

		Utils.Logger(GameMainExtension.extension,
				"TRIPLECHANCE::::::::::::::BetPlaceBetAmountState:::::::::::::::betPlaceState :::: betPlaceState() "
						+ " ::::: user id ::: " + userid + ":::::::  session_id :::: ::" + session_id
						+ " coins :::::::: " + coins + " :::::selectednumbers :::::::: " + selectednumber);
		updateBetStatus(userid, session_id, coins, selectednumber, table_type, gameid);

	}

	@Override
	public void onCancelBet(String roomname, User user, String session_id, String tableType, int betNo,
			double BetAmount) {

		Utils.Logger(GameMainExtension.extension,
				"TRIPLECHANCE::::::::::::::::::::::::::onCancelBet :::: onCancelBet() :::: roomname ::: " + roomname
						+ " ::::: user id ::: " + user.getName() + ":::::::  session_id :::: ::" + session_id);

		cancelSpecificBet(user, session_id, tableType, betNo, BetAmount);

	}

	@Override
	public void onClearAll(User user, String session_id) {

		Utils.Logger(GameMainExtension.extension, "TRIPLECHANCE::::::::::::::::onClearAll :::: onClearAll() :::: "
				+ " ::::: user id ::: " + user.getName() + ":::::::  session_id :::: ::" + session_id);

		clearAllBetsRoulette(user, session_id);

	}

	@Override
	public void onRebetRequest(String roomname, User user, String session_id) {

		Utils.Logger(GameMainExtension.extension, "onRebetRequest :::: onRebetRequest() :::: roomname ::: " + roomname
				+ " ::::: user id ::: " + user.getName() + ":::::::  session_id :::: ::" + session_id);
		getEvents().onRebetRoulette(this, user, session_id);

	}

	@Override
	public void userBetSave(String roomname, User user, String session_id) {
		Utils.Logger(GameMainExtension.extension, "userBetSave :::: userBetSave() :::: roomname ::: " + roomname
				+ " ::::: user id ::: " + user.getName() + ":::::::  session_id :::: ::" + session_id);
		getEvents().betSave(this, user, session_id, roomname);

		// onUserBetSave(roomname, userid, session_id);

	}

	@Override
	public void userBetRemove(String roomname, String session_id, String betno, User user) {

		Utils.Logger(GameMainExtension.extension,
				"userBetSave :::: userBetSave() :::: roomname ::: " + roomname + " ::::: user id ::: " + user.getName()
						+ ":::::::  session_id :::: ::" + session_id + "betno::::::::" + betno);
		getEvents().betRemoveUser(this, session_id, roomname, betno, user);

	}

	@Override
	public void betPlaceRandomWise(User user, String session_id, double coins, int numbers, String tabletype,
			int gameid, int tablebetno) {
		Utils.Logger(GameMainExtension.extension,
				"TRIPLECHANCE::::::::::::::BetPlaceBetAmountState:::::::::::::::betPlaceState :::: betPlaceState() "
						+ " ::::: user id ::: " + user.getName() + ":::::::  session_id :::: ::" + session_id
						+ " coins :::::::: " + coins);
		placeBetNoRandom(user, session_id, coins, numbers, tabletype, gameid, tablebetno);

	}

	@Override
	public void betPrintExe(String roomName, String sessionId, User pUser) {

		betPrintExeUser(roomName, sessionId, pUser);

	}

	@Override
	public void userGameDetails(String roomname, User user) {

		Utils.Logger(GameMainExtension.extension, "userGameDetails :::: userGameDetails() :::: roomname ::: " + roomname
				+ " ::::::  user  :::::  " + user.getName());
		getGameDetailsTripleChance(roomname, user);

	}

	@Override
	public void userGameDetailsStartAndEndDate(String roomname, User user, String startDate, String endDate) {

		Utils.Logger(GameMainExtension.extension,
				"userGameDetailsStartAndEndDate  :::: userGameDetailsStartAndEndDate() :::: roomname ::: " + roomname
						+ " ::::::  user  :::::  " + user.getName());
		getGameDetailsRouletteStartAndEndDatePlayMart(roomname, user, startDate, endDate);

	}

	@Override
	public void UsersDayWiseResultDetails_Triplechance(String roomname, User pUser) {

		Utils.Logger(GameMainExtension.extension,
				"TripleChance:::::::::::::::UsersDayWiseResultDetails_Triplechance :::: :::: roomname ::: " + roomname
						+ " ::::::  user  :::::  " + pUser.getName());
		getGameDetailsResult_Roulette(roomname, pUser);
	}

	@Override
	public void betCancelByTicketId_TripleChance(String roomname, String sessionId, User user, String ticketid) {

		Utils.Logger(GameMainExtension.extension,
				"betCancelByTicketId_TripleChance:::::::::::::::::::::roomaname::::::::" + roomname
						+ "sessionid:::::::::::::::::" + sessionId + "  user" + user + "ticketid" + ticketid);
		betCancelByTicketIdUser(roomname, sessionId, user, ticketid);
	}

	@Override
	public void betClaimByTicketId_TripleChance(String roomname, String sessionId, User user, String ticketid,
			int gameid, String gametype) {

		betClaimByTicketId(roomname, sessionId, user, ticketid, gameid, gametype);

	}

}
