package com.latestfunroulette.TripleRoulette.machine.machineclass;


import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;
import com.latestfunroulette.TripleRoulette.machine.interfaces.IMachineManager;
import com.latestfunroulette.TripleRoulette.machine.interfaces.IStateMachine;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

public class MachineManager implements IMachineManager {

	@Override
	public void join(String pLoginId, String pRoomName) {
		GameBean tempGameBean = GameMainExtension.gameCacheTripleRoulette.getGames().getValueByKey(pRoomName);
		Utils.Logger(GameMainExtension.extension,tempGameBean.getGameMachine());
		if (tempGameBean.getGameMachine() == null) {
			IStateMachine<GameBean> tempStateMachine = new Machine();
			tempGameBean.setGameMachine(tempStateMachine);;
		//	tempGameBean.setGameState(GameState.PLAYERWAIT);
			tempStateMachine.onStart(tempGameBean);
			tempStateMachine.onJoin(pLoginId);
		} else {
			tempGameBean.getGameMachine().onJoin(pLoginId);
		}
	}
}