/**
 * 
 */
package com.latestfunroulette.TripleRoulette.machine.interfaces;

import com.latestfunroulette.TripleRoulette.base.interfaces.IState;
import com.latestfunroulette.TripleRoulette.cache.beans.GameBean;
import com.latestfunroulette.TripleRoulette.client.RTimer;
import com.latestfunroulette.TripleRoulette.state.BetPlaceBetAmountState;
import com.latestfunroulette.TripleRoulette.state.GameResultState;
import com.latestfunroulette.TripleRoulette.state.GameResultWaitingState;
import com.latestfunroulette.TripleRoulette.state.InitialState;
import com.latestfunroulette.common.Constants.GameState;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

/**
 * @author Ubuntu
 *
 */
public interface IStateMachine<G> extends IState<G> {

	void onNext(String pState);

	IState<G> currentState();

	boolean setMachineStatusTripleChance(boolean status);

	boolean isMachineStatus();
	RTimer getTimer();

	default IState<GameBean> getState(String pState) {
		Utils.Logger(GameMainExtension.extension, "IStateMachine:::::::::::pState" + pState);
		IState<GameBean> tempState = null;

		if (pState.equalsIgnoreCase(GameState.INITIAL)) {
			tempState = new InitialState();

			// Utils.Logger(GameMainExtension.extension, "INITIAL" + tempState);
		} else if (pState.equalsIgnoreCase(GameState.BETPLACESTATE)) {

			tempState = new BetPlaceBetAmountState();
			// Utils.Logger(GameMainExtension.extension, "PLAYERWAIT" + pState);

		} else if (pState.equalsIgnoreCase(GameState.RESULTWAIT)) {
			tempState = new GameResultWaitingState();

		} else if (pState.equalsIgnoreCase(GameState.RESULT)) {
			tempState = new GameResultState();
		} else if (pState.equalsIgnoreCase(GameState.EXIT)) {

			//
		}
		return tempState;
	}
}