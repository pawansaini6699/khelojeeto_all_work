package com.latestfunroulette.TripleRoulette.machine.interfaces;

public interface IMachineManager {

	void join(String pLoginId, String pRoomName);

}