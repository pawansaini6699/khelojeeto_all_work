package com.latestfunroulette.extension.clients;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CommonEvents;
import com.latestfunroulette.common.StaticRoomManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class ZeroToTripleNineUnjoinEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		new Thread() {
			@Override
			public void run() {
				try {
					Utils.Logger(getParentExtension(),
							"ZeroToTripleNineUnjoinEventHandler :: Request ::: User :::: " + pUser.getName()
									+ " ::: Params ::: " + params.getDump());
					StaticRoomManager.unJoinThreeRouletteLobbyRoom(pUser);
					Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(pUser.getName());
					CommonEvents.sendUserDetails(tempPlayer, pUser);
				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(),
							" :: " + this.getClass().getName() + " :: ERROR :: ", e);
				}
			}
		}.start();

	}
}
