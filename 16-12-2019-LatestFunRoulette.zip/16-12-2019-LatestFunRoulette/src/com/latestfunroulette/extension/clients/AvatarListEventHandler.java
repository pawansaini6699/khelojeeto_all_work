package com.latestfunroulette.extension.clients;

import java.util.List;

import com.latestfunroulette.cache.beans.AvatarBean;
import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.Message;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class AvatarListEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		new Thread() {
			@Override
			public void run() {
				try {
					print("Request :: AvatarListEventHandler :: User ::: " + pUser.getName() + " ::: Params ::: "
							+ params.getDump());

					List<AvatarBean> tempAvatars = GameMainExtension.cache.getAvatar().getAllValue();
					ISFSArray tempSFSArr = new SFSArray();
					if (tempAvatars.size() == 0) {
						DBManager.getAllAvatars();
					}
					for (AvatarBean bean : tempAvatars) {
						tempSFSArr.addSFSObject(bean.toSFSObj());
					}

					params.putUtfString(Param.STATUS, EnableStatus.TRUE);
					params.putUtfString(Param.MESSAGE, Message.SUCCESSFULLY);
					params.putSFSArray(Param.AVATAR_LIST, tempSFSArr);

					print("Response ::::: User :::: " + pUser.getName() + " :::: Params :::: " + params.getDump());
					send(Request.AVATAR_LIST_REQUEST, params, pUser);
				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(),
							" ::: " + this.getClass().getName() + " :: ERROR :: ", e);
				}
			}
		}.start();
	}

	public void print(String msg) {
		Utils.Logger(getParentExtension(), "AvatarListEventHandler :::: " + msg);
	}
}
