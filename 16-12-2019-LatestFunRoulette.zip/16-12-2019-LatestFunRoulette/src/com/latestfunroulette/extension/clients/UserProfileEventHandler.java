package com.latestfunroulette.extension.clients;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.Message;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class UserProfileEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		new Thread() {
			@Override
			public void run() {
				try {
					print("Request :::: User :::: " + pUser.getName() + " ::::: Params :::: " + params.getDump());

					Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(pUser.getName());
					ISFSObject tempSFSObj = null;
					if (tempPlayer != null) {
						tempSFSObj = tempPlayer.toProfileSFS();

						int avatarId = DBManager.getAvatarId(tempPlayer.getUserid());
						tempSFSObj.putUtfString(Param.AVATAR_ID, String.valueOf(avatarId));
						tempSFSObj.putUtfString(Param.STATUS, EnableStatus.TRUE);
						tempSFSObj.putUtfString(Param.MESSAGE, Message.SUCCESSFULLY);
					} else {
						tempSFSObj = new SFSObject();
						tempSFSObj.putUtfString(Param.STATUS, EnableStatus.FALSE);
						tempSFSObj.putUtfString(Param.MESSAGE, Message.USER_NOT_FOUND);
					}

					print("Response ::::: User :::: " + pUser.getName() + " :::: Params :::: " + tempSFSObj.getDump());
					send(Request.PROFILE_REQUEST, tempSFSObj, pUser);
				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(), " :: " + this.getClass().getName() + " :: ERROR :: ", e);
				}
			}
		}.start();
	}

	private void print(String msg) {
		Utils.Logger(getParentExtension(), "UserProfileEventHandler ::::: " + msg);
	}

}
