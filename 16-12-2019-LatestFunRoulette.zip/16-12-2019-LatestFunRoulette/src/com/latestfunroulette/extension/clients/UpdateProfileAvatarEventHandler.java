package com.latestfunroulette.extension.clients;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class UpdateProfileAvatarEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		new Thread() {
			@Override
			public void run() {
				try {
					print("Request ::::: User :::: " + pUser.getName() + " :::: Params :::: " + params.getDump());

					String loginId = pUser.getName();
					String avatarId = params.getUtfString(Param.AVATAR_ID);

					DBManager.updateUserAvatar(loginId, avatarId, pUser, new CallBack() {
						
					

						@Override
						public void call(Object... values) {
							String status = (String) values[0];
							String message = (String) values[1];

							params.putUtfString(Param.STATUS, status);
							params.putUtfString(Param.MESSAGE, message);

							print("Response ::::: User :::: " + pUser.getName() + " :::: Params :::: "
									+ params.getDump());
							send(Request.UPDATE_AVATAR_REQUEST, params, pUser);
						}
					});
				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(),
							" :: " + this.getClass().getName() + " :: ERROR :: ", e);
				}
			}
		}.start();
	}

	private void print(String msg) {
		Utils.Logger(getParentExtension(), "UpdateProfileAvatarEventHandler ::::: " + msg);
	}
}