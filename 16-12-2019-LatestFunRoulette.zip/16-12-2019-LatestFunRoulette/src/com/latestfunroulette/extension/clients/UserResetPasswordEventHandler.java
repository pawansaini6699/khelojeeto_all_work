package com.latestfunroulette.extension.clients;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.Message;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class UserResetPasswordEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		new Thread() {
			@Override
			public void run() {
				try {
					print("Request :::: User :::: " + pUser.getName() + " ::::: Params :::: " + params.getDump());

					String oldpassword = params.getUtfString(Param.OLD_PASSWORD);
					String newpassword = params.getUtfString(Param.NEW_PASSWORD);
					ISFSObject tempSFSObj = new SFSObject();

					if (!oldpassword.equals(newpassword)) {
						DBManager.resetPassword(pUser.getName(), oldpassword, newpassword, new CallBack() {

							@Override
							public void call(Object... values) {
								String status = (String) values[0];
								String message = (String) values[1];
								tempSFSObj.putUtfString(Param.STATUS, status);
								tempSFSObj.putUtfString(Param.MESSAGE, message);
								print("Response :::: User ::: " + pUser.getName() + " :::: Params ::: "
										+ tempSFSObj.getDump());
								send(Request.RESET_PASSWORD_REQUEST, tempSFSObj, pUser);
							}
						});
					} else {

						tempSFSObj.putUtfString(Param.STATUS, EnableStatus.FALSE);
						tempSFSObj.putUtfString(Param.MESSAGE, Message.YOU_CAN_NOT_ENTRY_OLD_PASSWORD);
						print("Response :::: User ::: " + pUser.getName() + " :::: Params ::: " + tempSFSObj.getDump());
						send(Request.RESET_PASSWORD_REQUEST, tempSFSObj, pUser);
					}
				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(), " :: " + this.getClass().getName() + " :: ERROR :: ", e);
				}
			}
		}.start();
	}

	private void print(String msg) {
		Utils.Logger(getParentExtension(), "UserResetPasswordEventHandler ::: " + msg);
	}

}