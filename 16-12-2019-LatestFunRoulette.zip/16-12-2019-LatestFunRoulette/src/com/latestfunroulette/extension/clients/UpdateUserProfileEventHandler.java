package com.latestfunroulette.extension.clients;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class UpdateUserProfileEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		new Thread() {
			@Override
			public void run() {
				try {
					print("Request :::: User ::: " + pUser.getName() + " ::::: Params :::: " + params.getDump());
					String name = params.getUtfString(Param.NAME);

					DBManager.updateProfile(pUser, name, new CallBack() {

						@Override
						public void call(Object... values) {
							String status = (String) values[0];
							String message = (String) values[1];

							ISFSObject tempSFSObj = new SFSObject();
							tempSFSObj.putUtfString(Param.STATUS, status);
							tempSFSObj.putUtfString(Param.MESSAGE, message);

							print("Response :::: User ::: " + pUser.getName() + " ::::: Params :::: "
									+ tempSFSObj.getDump());
							send(Request.UPDATE_PROFILE_REQUEST, tempSFSObj, pUser);
						}
					});
				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(), " :: " + this.getClass().getName() + " :: ERROR :: ", e);
				}
			}
		}.start();
	}

	private void print(String msg) {
		Utils.Logger(getParentExtension(), "UpdateUserProfileEventHandler :::::: " + msg);
	}

}