package com.latestfunroulette.extension.clients;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class UserLogoutRequestHandler extends BaseClientRequestHandler   {
	public void handleClientRequest(User user, ISFSObject params) {
		Utils.Logger(getParentExtension(),":::::::::::::::UserLogoutRequestHandler::::::::::::::params:::::" + params.getDump());
		String userId = params.getUtfString(Param.USERID);
		new Thread() {
			@Override
			public void run() {
				DBManager.userLogout(userId, new CallBack() {
					@Override
					public void call(Object... callback) {
						ISFSObject isfsObject = (ISFSObject) callback[0];
						
						Utils.Logger(getParentExtension(), "UserLogoutRequestHandler:::::::::::::::::response:::::::::::::"+isfsObject.getDump());
						
						send(Request.LOGOUTREQUEST, isfsObject, user);
					}
				});
			}
		}.start();
	}
}