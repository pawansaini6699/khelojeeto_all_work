package com.latestfunroulette.extension.clients;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.CommonEvents;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class GustUserLoginEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		new Thread() {
			@Override
			public void run() {
				try {
					print("Request :::: User ::: " + pUser.getName() + " ::: Params ::: " + params.getDump());

					Player tempPlayer = new Player();

					String deviceId = params.getUtfString(Param.DEVICE_ID);
					String deviceType = params.getUtfString(Param.DEVICE_TYPE);
					String userType = params.getUtfString(Param.USER_TYPE);
					String ipaddress = pUser.getSession().getAddress();

					tempPlayer.setDeviceId(deviceId);
					tempPlayer.setDeviceType(deviceType);
					tempPlayer.setUserType(userType);
					tempPlayer.setIpaddress(ipaddress);

					DBManager.guestUserLogin(tempPlayer, new CallBack() {

						@Override
						public void call(Object... values) {
							String status = (String) values[0];
							String message = (String) values[1];

							ISFSObject tempSFSObj = new SFSObject();
							tempSFSObj.putUtfString(Param.STATUS, status);
							tempSFSObj.putUtfString(Param.MESSAGE, message);
							if (status.equalsIgnoreCase("true")) {
								pUser.setName(tempPlayer.getUserid());
								tempSFSObj.putUtfString(Param.USERID, tempPlayer.getUserid());
							} else {
								tempSFSObj.putNull(Param.USERID);
							}

							print("Response :::: User ::: " + pUser.getName() + " ::: Params ::: "
									+ tempSFSObj.getDump());
							send(Request.GUEST_LOGIN_REQUEST, tempSFSObj,pUser);

							if (status.equalsIgnoreCase("true"))
								CommonEvents.sendUserDetails(tempPlayer, pUser);
						}
					});
				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(), " :: " + this.getClass().getName() + " :: ERROR :: ",
							e);
				}
			}
		}.start();
	}

	private void print(String msg) {
		Utils.Logger(getParentExtension(), "GustUserLoginEventHandler ::: " + msg);
	}

}
