package com.latestfunroulette.extension.clients;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.StaticRoomManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class Zero2DoubleNineEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		new Thread() {
			@Override
			public void run() {
				try {

					Utils.Logger(getParentExtension(),
							"::::::::::::::::::::::::::::::::::::::::::::    Zero2DoubleNineEventHandler :::: Request ::: User ::: "
									+ pUser.getName() + " ::: Params ::: " + params.getDump());

					String tempLoginId = pUser.getName();
					Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(tempLoginId);

					System.out.println("tempplayer:::::::::::::::::::::::::::::::::::::::" + tempPlayer.toString());
					if (tempPlayer != null && tempPlayer.getUserBlockStatus() == 0) {
						Utils.Logger(getParentExtension(),
								" ::::::::::::::::::::::::::::::::: Zero2DoubleNineEventHandler :::: Player is not null"
										+ tempPlayer.toSFS().getDump());

						StaticRoomManager.joinTwoRouletteLobbyRoom(pUser);

					} else {
						Utils.Logger(getParentExtension(),
								" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  Zero2DoubleNineEventHandler :::: Player is not null");
					}

				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(), " :: " + this.getClass().getName() + " :: ERROR :: ", e);
				}
			}
		}.start();
	}
}