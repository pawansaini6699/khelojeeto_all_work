package com.latestfunroulette.extension.clients;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.CommonEvents;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class ConvertPermanentEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		new Thread() {
			@Override
			public void run() {
				try {
					print("Request ::::: User ::: " + pUser.getName() + " :::: Params ::: " + params.getDump());

					Player tempPlayer = new Player();

					String name = params.getUtfString(Param.NAME);
					String userloginid = params.getUtfString(Param.USERID);
					String username = params.getUtfString(Param.USER_NAME);
					String socialId = params.getUtfString(Param.SOCIAL_ID);
					String userType = params.getUtfString(Param.USER_TYPE);
					String deviceId = params.getUtfString(Param.DEVICE_ID);
					String deviceType = params.getUtfString(Param.DEVICE_TYPE);
				    String image = params.getUtfString(Param.USER_IMAGE);
					String emailid = params.getUtfString(Param.USERID);
					String mobileno = params.getUtfString(Param.MOBILE_NO);
					// String password = params.getUtfString(Param.PASSWORD);
					// String chips = params.getUtfString(Param.CHIPS);
				

					tempPlayer.setName(name);
					tempPlayer.setUserid(userloginid);
					tempPlayer.setUsername(username);
					tempPlayer.setSocialId(socialId);
					tempPlayer.setUserType(userType);
					tempPlayer.setDeviceId(deviceId);
					tempPlayer.setDeviceType(deviceType);
					tempPlayer.setImage(image);
					tempPlayer.setEmailid(emailid);
					tempPlayer.setMobileno(mobileno);
					tempPlayer.setIpaddress(pUser.getSession().getAddress());
				

					DBManager.updateguestlogin(tempPlayer, new CallBack() {
						
					
						@Override
						public void call(Object... values) {
							String status = (String) values[0];
							String message = (String) values[1];

							ISFSObject tempSFSObj = new SFSObject();
							tempSFSObj.putUtfString(Param.STATUS, status);
							tempSFSObj.putUtfString(Param.MESSAGE, message);
							if (status.equalsIgnoreCase("true")) {
								pUser.setName(tempPlayer.getUserid());
								tempSFSObj.putUtfString(Param.USERID, tempPlayer.getUserid());
								tempSFSObj.putUtfString(Param.USER_IMAGE, tempPlayer.getImage());
							} else {
								tempSFSObj.putNull(Param.USERID);
							}

							print("Response :::: User ::: " + pUser.getName() + " ::: Params ::: "
									+ tempSFSObj.getDump());
							send(Request.CONVERT_PERMANENT_REQUEST, tempSFSObj, pUser);

							if (status.equalsIgnoreCase("true"))
								CommonEvents.sendUserDetails(tempPlayer, pUser);
						}
					});
				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(),
							" :: " + this.getClass().getName() + " :: ERROR :: ", e);
				}
			}
		}.start();
	}

	private void print(String msg) {
		Utils.Logger(getParentExtension(), "ConvertPermanentEventHandler :::: " + msg);
	}

}
