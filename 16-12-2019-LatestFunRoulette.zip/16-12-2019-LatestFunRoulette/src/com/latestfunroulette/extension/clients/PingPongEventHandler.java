package com.latestfunroulette.extension.clients;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class PingPongEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		 Utils.Logger(getParentExtension(),"PingPongEventHandler :::::: Request ::::User :::: " + pUser.getName());
	
	
	Utils.Logger(GameMainExtension.extension,pUser.getLastRequestTime());
	Utils.Logger(GameMainExtension.extension,System.currentTimeMillis());
	}
}