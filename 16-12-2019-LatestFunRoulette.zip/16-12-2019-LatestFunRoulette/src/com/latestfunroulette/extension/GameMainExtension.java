package com.latestfunroulette.extension;

import com.latestfunroulette.TripleRoulette.cache.GameCacheTripleRoulette;
import com.latestfunroulette.TripleRoulette.client.BetRemoveCustomiseHandlerZeroToTripleNine;
import com.latestfunroulette.TripleRoulette.client.ClearAllHandlerTripleNine;
import com.latestfunroulette.TripleRoulette.client.DoubleEventHandlerTripleNine;
import com.latestfunroulette.TripleRoulette.client.LiveUpdateBetsHandlerTripleNine;
import com.latestfunroulette.TripleRoulette.client.RebetHandlerClassTripleNine;
import com.latestfunroulette.TripleRoulette.client.TicketClaimHandlerTripleChance;
import com.latestfunroulette.TripleRoulette.client.TripleChanceBetHandler;
import com.latestfunroulette.TripleRoulette.client.TripleChanceBetPrintHandler;
import com.latestfunroulette.TripleRoulette.client.TripleChance_UsersDayWiseResult;
import com.latestfunroulette.TripleRoulette.client.UserGameDetailsDateWise_TripleRoulette;
import com.latestfunroulette.TripleRoulette.client.UserGameDetails_TripleRoulette;
import com.latestfunroulette.ZerotoNineRoulette.cache.GameCacheZeroToNine;
import com.latestfunroulette.ZerotoNineRoulette.client.BetRemoveCustomiseHandlerZeroToNine;
import com.latestfunroulette.ZerotoNineRoulette.client.CancelTicketPrintHandler;
import com.latestfunroulette.ZerotoNineRoulette.client.ClearAllHandlerZeroToNine;
import com.latestfunroulette.ZerotoNineRoulette.client.DoubleEventHandlerZeroToNine;
import com.latestfunroulette.ZerotoNineRoulette.client.LiveUpdateBetsHandlerZeroToNine;
import com.latestfunroulette.ZerotoNineRoulette.client.RebetHandlerClassZeroToNine;
import com.latestfunroulette.ZerotoNineRoulette.client.SingleChanceBetDetailByUserId;
import com.latestfunroulette.ZerotoNineRoulette.client.SingleChanceBetPrintHandler;
import com.latestfunroulette.ZerotoNineRoulette.client.TicketClaimHandler;
import com.latestfunroulette.ZerotoNineRoulette.client.UserGameDetailsDateWise_ZerotoNineRoulette;
import com.latestfunroulette.ZerotoNineRoulette.client.UserGameDetails_ZerotoNineRoulette;
import com.latestfunroulette.ZerotoNineRoulette.client.ZerotoNineRoulette_UsersDayWiseResult;
import com.latestfunroulette.base.GameBaseSFSExtesion;
import com.latestfunroulette.cache.GameCache;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.SupportTriggers;
import com.latestfunroulette.dubliRoulette.cache.GameCacheDoubleRoulette;
import com.latestfunroulette.dubliRoulette.client.BetRemoveCustomiseHandlerZeroToDoubleNine;
import com.latestfunroulette.dubliRoulette.client.ClearAllHandlerDoubleNine;
import com.latestfunroulette.dubliRoulette.client.DoubleChanceBetHandler;
import com.latestfunroulette.dubliRoulette.client.DoubleChanceBetPrintHandler;
import com.latestfunroulette.dubliRoulette.client.DoubleEventHandlerDoubleNine;
import com.latestfunroulette.dubliRoulette.client.LiveUpdateBetsHandlerDoubleNine;
import com.latestfunroulette.dubliRoulette.client.RebetHandlerClassDoubleNine;
import com.latestfunroulette.dubliRoulette.client.TicketClaimHandlerDoubleChance;
import com.latestfunroulette.dubliRoulette.client.UserGameDetailsDateWise_DoubleChance;
import com.latestfunroulette.dubliRoulette.client.UserGameDetails_DoubleChance;
import com.latestfunroulette.exeRoulette.cache.GameCacheExe;
import com.latestfunroulette.extension.clients.AvatarListEventHandler;
import com.latestfunroulette.extension.clients.ConvertPermanentEventHandler;
import com.latestfunroulette.extension.clients.GustUserLoginEventHandler;
import com.latestfunroulette.extension.clients.PingPongEventHandler;
import com.latestfunroulette.extension.clients.PlayMartEventHandler;
import com.latestfunroulette.extension.clients.PlayMartUnJoinEventHnadler;
import com.latestfunroulette.extension.clients.RouletteBetPrintHandler;
import com.latestfunroulette.extension.clients.SingleRouletteEventHandler;
import com.latestfunroulette.extension.clients.SingleRouletteOutEventHandler;
import com.latestfunroulette.extension.clients.SocialUserLoginEventHandler;
import com.latestfunroulette.extension.clients.UpdateProfileAvatarEventHandler;
import com.latestfunroulette.extension.clients.UpdateUserProfileEventHandler;
import com.latestfunroulette.extension.clients.UserCustomLoginEventHandler;
import com.latestfunroulette.extension.clients.UserForgotPasswordEventHandler;
import com.latestfunroulette.extension.clients.UserLogoutRequestHandler;
import com.latestfunroulette.extension.clients.UserRegistrationEventHandler;
import com.latestfunroulette.extension.clients.UserResetPasswordEventHandler;
import com.latestfunroulette.extension.clients.Zero2DoubleNineEventHandler;
import com.latestfunroulette.extension.clients.Zero2DoubleNineUnJoinEventHandler;
import com.latestfunroulette.extension.clients.ZeroToNineEventHandler;
import com.latestfunroulette.extension.clients.ZeroToNineUnJoinEventHnadler;
import com.latestfunroulette.extension.clients.ZeroToTripleNineEventHandler;
import com.latestfunroulette.extension.clients.ZeroToTripleNineUnjoinEventHandler;
import com.latestfunroulette.extension.game.BetRemoveCustomiseHandler;
import com.latestfunroulette.extension.game.CancelTicketPrintHandlerRoulette;
import com.latestfunroulette.extension.game.ClearAllHandler;
import com.latestfunroulette.extension.game.DoubleEventHandler;
import com.latestfunroulette.extension.game.LiveUpdateBetsHandlerClass;
import com.latestfunroulette.extension.game.NewSessionGenarate;
import com.latestfunroulette.extension.game.PaymentHistoryEventHandler;
import com.latestfunroulette.extension.game.RebetHandlerClass;
import com.latestfunroulette.extension.game.RemoveLiveBetsHandler;
import com.latestfunroulette.extension.game.Roulette_UsersDayWiseResult;
import com.latestfunroulette.extension.game.SendServerLivetimer;
import com.latestfunroulette.extension.game.TicketClaimHandlerRoulette;
import com.latestfunroulette.extension.game.UpdatePlayerGameScoresHandler;
import com.latestfunroulette.extension.game.UserGameDetailsDateWiseRouletteHandler;
import com.latestfunroulette.extension.game.UserGameDetailsRouletteHandler;
import com.latestfunroulette.extension.server.GameRoomRemoveEventHandler;
import com.latestfunroulette.extension.server.RoomAddEventHandler;
import com.latestfunroulette.extension.server.ServerReadyEventHandler;
import com.latestfunroulette.extension.server.UserDisconnectEventHandler;
import com.latestfunroulette.extension.server.UserJoinRoomEventHandler;
import com.latestfunroulette.extension.server.UserJoinZoneEventHandler;
import com.latestfunroulette.extension.server.UserLeaveRoomEventHandler;
import com.latestfunroulette.extension.server.UserLoginEventHandler;
import com.latestfunroulette.extension.server.UserLogoutServerEventHandler;
import com.latestfunroulette.playMart.cache.GameCachePlayMart;
import com.latestfunroulette.playMart.client.BetRemoveCustomiseHandlerPlayMart;
import com.latestfunroulette.playMart.client.ClearAllHandlerPlayMart;
import com.latestfunroulette.playMart.client.DoubleEventHandlerPlayMart;
import com.latestfunroulette.playMart.client.LiveUpdateBetsHandlerPlayMart;
import com.latestfunroulette.playMart.client.PlayMartBetPrintHandler;
import com.latestfunroulette.playMart.client.PlayMart_UsersDayWiseResult;
import com.latestfunroulette.playMart.client.RebetHandlerClassPlayMart;
import com.latestfunroulette.playMart.client.TicketClaimHandlerPlayMart;
import com.latestfunroulette.playMart.client.UserGameDetailsDateWise_PlayMart;
import com.latestfunroulette.playMart.client.UserGameDetails_PlayMart;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.core.SFSEventType;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class GameMainExtension extends GameBaseSFSExtesion {

	public static GameMainExtension extension = null;
	public static GameCache cache;
	public static GameCacheTripleRoulette gameCacheTripleRoulette;
	public static GameCacheZeroToNine gameCacheZeroToNine;
	public static GameCacheDoubleRoulette gameCacheDoubleRoulette;
	public static GameCachePlayMart gamecachePlayMart;
	public static GameCacheExe GameCacheexe;
	private static SupportTriggers supportTriggers;

	@Override
	public void init(SFSExtension et) {
		extension = this;
		cache = new GameCache();
		supportTriggers = new SupportTriggers();
		gameCacheZeroToNine = new GameCacheZeroToNine();
		gameCacheDoubleRoulette = new GameCacheDoubleRoulette();
		gameCacheTripleRoulette = new GameCacheTripleRoulette();
		gamecachePlayMart = new GameCachePlayMart();
		GameCacheexe = new GameCacheExe();

	}

	@Override
	public void serverEventHandler() {

		addEventHandler(SFSEventType.SERVER_READY, ServerReadyEventHandler.class);
		addEventHandler(SFSEventType.USER_LOGIN, UserLoginEventHandler.class);
		addEventHandler(SFSEventType.USER_LOGOUT, UserLogoutServerEventHandler.class);
		addEventHandler(SFSEventType.USER_DISCONNECT, UserDisconnectEventHandler.class);
		addEventHandler(SFSEventType.USER_JOIN_ZONE, UserJoinZoneEventHandler.class);
		addEventHandler(SFSEventType.USER_JOIN_ROOM, UserJoinRoomEventHandler.class);
		addEventHandler(SFSEventType.USER_LEAVE_ROOM, UserLeaveRoomEventHandler.class);
		addEventHandler(SFSEventType.ROOM_REMOVED, GameRoomRemoveEventHandler.class);
		addEventHandler(SFSEventType.ROOM_ADDED, RoomAddEventHandler.class);
	}

	@Override
	public void clientEventHandler() {

		addRequestHandler(Request.CUSTOM_REGISTRATION_REQUEST, UserRegistrationEventHandler.class);
		addRequestHandler(Request.CUSTOM_LOGIN_REQUEST, UserCustomLoginEventHandler.class);
		addRequestHandler(Request.GUEST_LOGIN_REQUEST, GustUserLoginEventHandler.class);
		addRequestHandler(Request.SOCIAL_LOGIN_REQUEST, SocialUserLoginEventHandler.class);
		addRequestHandler(Request.CONVERT_PERMANENT_REQUEST, ConvertPermanentEventHandler.class);
		addRequestHandler(Request.PING_PONG_REQUEST, PingPongEventHandler.class);
		addRequestHandler(Request.FORGOT_PASSWORD_REQUEST, UserForgotPasswordEventHandler.class);
		addRequestHandler(Request.AVATAR_LIST_REQUEST, AvatarListEventHandler.class);
		addRequestHandler(Request.UPDATE_AVATAR_REQUEST, UpdateProfileAvatarEventHandler.class);
		addRequestHandler(Request.UPDATE_PROFILE_REQUEST, UpdateUserProfileEventHandler.class);
		addRequestHandler(Request.RESET_PASSWORD_REQUEST, UserResetPasswordEventHandler.class);
		addRequestHandler(Request.PAYMENT_HISTORY_REQUEST, PaymentHistoryEventHandler.class);
		addRequestHandler(Request.LOGOUTREQUEST, UserLogoutRequestHandler.class);
		// addRequestHandler(Request.USER_GAME_DETAILS,
		// UserGameDetailsRouletteHandler.class);

	}

	@Override
	public void SingleEventHandler() {

		addRequestHandler(Request.SINGLE_ROULETTE_LOBBY_REQUEST, SingleRouletteEventHandler.class);
		addRequestHandler(Request.LEAVE_SINGLE_ROULETTE_LOBBY_REQUEST, SingleRouletteOutEventHandler.class);

	}

	@Override
	public void DoubleEventHandler() {
		addRequestHandler(Request.DOUBLE_CHANCE_LOBBY_REQUEST, Zero2DoubleNineEventHandler.class);
		addRequestHandler(Request.LEAVE_DOUBLE_CHANCE_LOBBY_REQUEST, Zero2DoubleNineUnJoinEventHandler.class);

	}

	@Override
	public void ThripleEventHandler() {
		addRequestHandler(Request.TRIPLE_CHANCE_LOBBY_REQUEST, ZeroToTripleNineEventHandler.class);
		addRequestHandler(Request.LEAVE_TRIPLE_CHANCE_LOBBY_REQUEST, ZeroToTripleNineUnjoinEventHandler.class);

	}

	@Override
	public void ZeroToNineEventHandler() {
		addRequestHandler(Request.ZERO_TO_NINE_ROULETTE_LOBBY_REQUEST, ZeroToNineEventHandler.class);
		addRequestHandler(Request.LEAVE_ZERO_TO_NINE_ROULETTE_LOBBY_REQUEST, ZeroToNineUnJoinEventHnadler.class);

	}

	@Override
	public void PlayMartEventHandler() {

		addRequestHandler(Request.PLAY_MART_LOBBY_REQUEST, PlayMartEventHandler.class);
		addRequestHandler(Request.LEAVE_PLAY_MART_LOBBY_REQUEST, PlayMartUnJoinEventHnadler.class);

	}

	@Override
	public void GameEventHandler() {
		addRequestHandler(Request.LIVEBETSHANDLER, LiveUpdateBetsHandlerClass.class);
		addRequestHandler(Request.REMOVELIVEBETREQUEST, RemoveLiveBetsHandler.class);
		addRequestHandler(Request.CLEARALL, ClearAllHandler.class);
		addRequestHandler(Request.GETLIVERSERVERTIME, SendServerLivetimer.class);
		addRequestHandler(Request.NEWSESSIONGENERATE, NewSessionGenarate.class);
		addRequestHandler(Request.REBET_NUMBERS, RebetHandlerClass.class);
		addRequestHandler(Request.BETOK, UpdatePlayerGameScoresHandler.class);
		addRequestHandler(Request.BETREMOVECUSTOMISE, BetRemoveCustomiseHandler.class);
		addRequestHandler(Request.DOUBLEBETROULETTE, DoubleEventHandler.class);
		addRequestHandler(Request.PRINT_BET_NUMBERS_ROULETTE, RouletteBetPrintHandler.class);
		addRequestHandler(Request.USER_GAME_DETAILS_DATE_WISE, UserGameDetailsDateWiseRouletteHandler.class);
		addRequestHandler(Request.USER_GAME_DETAILS_DAY_WISE, UserGameDetailsRouletteHandler.class);
		addRequestHandler(Request.GET_USERS_DAY_WISE_RESULT_ROULETTE, Roulette_UsersDayWiseResult.class);
		addRequestHandler(Request.CANCEL_BET_NUMBERS_BY_TICKET_ROULETTE, CancelTicketPrintHandlerRoulette.class);
		addRequestHandler(Request.CLAIM_BET_NUMBERS_BY_TICKET_ROULETTE, TicketClaimHandlerRoulette.class);

		/* :::::::::ZeroToNine SINGLE CHANCE:::::::::: */

		addRequestHandler(Request.DOUBLE_BET_SINGLECHANCE, DoubleEventHandlerZeroToNine.class);
		addRequestHandler(Request.LIVE_BETS_HANDLER_SINGLECHANCE, LiveUpdateBetsHandlerZeroToNine.class);
		addRequestHandler(Request.REBET_NUMBERS_SINGLECHANCE, RebetHandlerClassZeroToNine.class);
		addRequestHandler(Request.CLEARALL_SINGLECHANCE, ClearAllHandlerZeroToNine.class);
		addRequestHandler(Request.BETREMOVECUSTOMISEZEROTONINE, BetRemoveCustomiseHandlerZeroToNine.class);
		addRequestHandler(Request.USER_GAME_DETAILS_DAY_WISE_SINGLECHANCE, UserGameDetails_ZerotoNineRoulette.class);
		addRequestHandler(Request.USER_GAME_DETAILS_DATE_WISE_SINGLECHANCE,
				UserGameDetailsDateWise_ZerotoNineRoulette.class);
		addRequestHandler(Request.PRINT_BET_NUMBERS, SingleChanceBetPrintHandler.class);
		addRequestHandler(Request.CANCEL_BET_NUMBERS_BY_TICKET_SINGLECHANCE, CancelTicketPrintHandler.class);
		addRequestHandler(Request.GET_USERS_DAY_WISE_RESULT_SINGLECHANCE, ZerotoNineRoulette_UsersDayWiseResult.class);
		addRequestHandler(Request.CLAIM_BET_NUMBERS_BY_TICKET_SC, TicketClaimHandler.class);
		addRequestHandler(Request.GET_BET_ALL_DETAILS_SC, SingleChanceBetDetailByUserId.class);

		/* :::::::::::::Double Chance ::::::::::::::::: */

		addRequestHandler(Request.DOUBLE_BET_DOUBLE_CHANCE, DoubleEventHandlerDoubleNine.class);
		addRequestHandler(Request.LIVE_BETS_HANDLER_DOUBLE_CHANCE, LiveUpdateBetsHandlerDoubleNine.class);
		addRequestHandler(Request.REBET_NUMBERS_DOUBLE_CHANCE, RebetHandlerClassDoubleNine.class);
		addRequestHandler(Request.CLEARALL_DOUBLE_CHANCE, ClearAllHandlerDoubleNine.class);
		addRequestHandler(Request.BET_REMOVE_CUSTOMISE_DOUBLE_CHANCE, BetRemoveCustomiseHandlerZeroToDoubleNine.class);
		addRequestHandler(Request.USER_GAME_DETAILS_DAY_WISE_DOUBLE_CHANCE, UserGameDetails_DoubleChance.class);
		addRequestHandler(Request.USER_GAME_DETAILS_DATE_WISE_DOUBLE_CHANCE,
				UserGameDetailsDateWise_DoubleChance.class);
		addRequestHandler(Request.REMOVE_BET_CUSTOMISE_REQUEST, BetRemoveCustomiseHandlerZeroToDoubleNine.class);
		addRequestHandler(Request.USER_BETS_TABLE_DOUBLE, DoubleChanceBetHandler.class);
		addRequestHandler(Request.PRINT_BET_NUMBERS_DOUBLECHANCE, DoubleChanceBetPrintHandler.class);
		addRequestHandler(Request.CANCEL_BET_NUMBERS_BY_TICKET_DOUBLECHANCE, CancelTicketPrintHandler.class);
		addRequestHandler(Request.CLAIM_BET_NUMBERS_BY_TICKET_DC, TicketClaimHandlerDoubleChance.class);

		/* ::::::::::::::::::::::::::TripleRoulette ::::::::::::::::::::::::::: */

		addRequestHandler(Request.DOUBLE_BET_TRIPLE_CHANCE, DoubleEventHandlerTripleNine.class);
		addRequestHandler(Request.LIVE_BETS_HANDLER_TRIPLE_CHANCE, LiveUpdateBetsHandlerTripleNine.class);
		addRequestHandler(Request.REBET_NUMBERS_TRIPLE_CHANCE, RebetHandlerClassTripleNine.class);
		addRequestHandler(Request.CLEARALL_TRIPLE_CHANCE, ClearAllHandlerTripleNine.class);
		addRequestHandler(Request.BET_REMOVE_CUSTOMISE_TRIPLE_CHANCE, BetRemoveCustomiseHandlerZeroToTripleNine.class);
		addRequestHandler(Request.USER_BETS_TABLE, TripleChanceBetHandler.class);
		addRequestHandler(Request.USER_GAME_DETAILS_DAY_WISE__TRIPLE_CHANCE, UserGameDetails_TripleRoulette.class);
		addRequestHandler(Request.USER_GAME_DETAILS_DATE_WISE_TRIPLE_CHANCE,
				UserGameDetailsDateWise_TripleRoulette.class);
		addRequestHandler(Request.PRINT_BET_NUMBERS_TRIPLECHANCE, TripleChanceBetPrintHandler.class);
		addRequestHandler(Request.GET_USERS_DAY_WISE_RESULT_TRIPLECHANCE, TripleChance_UsersDayWiseResult.class);
		addRequestHandler(Request.CANCEL_BET_NUMBERS_BY_TICKET_TRIPLECHANCE, CancelTicketPrintHandler.class);
		addRequestHandler(Request.CLAIM_BET_NUMBERS_BY_TICKET_TC, TicketClaimHandlerTripleChance.class);

		/* :::::::::::::::::::::::::PLAYMART:::::::::::::::::::::::::::::::: */

		addRequestHandler(Request.DOUBLE_BET_PLAYMART, DoubleEventHandlerPlayMart.class);
		addRequestHandler(Request.LIVE_BETS_HANDLER_PLAYMART, LiveUpdateBetsHandlerPlayMart.class);
		addRequestHandler(Request.REBET_NUMBERS_PLAYMART, RebetHandlerClassPlayMart.class);
		addRequestHandler(Request.CLEARALL_PLAYMART, ClearAllHandlerPlayMart.class);
		addRequestHandler(Request.REMOVE_BET_PLAYMART_CUSTOMISE_REQUEST, BetRemoveCustomiseHandlerPlayMart.class);
		addRequestHandler(Request.USER_GAME_DETAILS_DAY_WISE__PLAYMART, UserGameDetails_PlayMart.class);
		addRequestHandler(Request.USER_GAME_DETAILS_DATE_WISE_PLAYMART, UserGameDetailsDateWise_PlayMart.class);
		addRequestHandler(Request.PRINT_BET_NUMBERS_PLAYMART, PlayMartBetPrintHandler.class);
		addRequestHandler(Request.GET_USERS_DAY_WISE_RESULT_PLAYMART, PlayMart_UsersDayWiseResult.class);
		addRequestHandler(Request.CANCEL_BET_NUMBERS_BY_TICKET_PLAYMART, CancelTicketPrintHandler.class);
		addRequestHandler(Request.CLAIM_BET_NUMBERS_BY_TICKET_PM, TicketClaimHandlerPlayMart.class);

	}

	@Override
	public void updateTasks() {
		SmartFoxServer tempSFS = SmartFoxServer.getInstance();
		// updateTask.startGameUpdate(tempSFS);
		updateTask_single_chance.startGameUpdate(tempSFS);
		// updateTask_double_nine.startGameUpdate(tempSFS);
		// updateTaskHandlerTripleNine.startGameUpdate(tempSFS);
		updateTaskHandlerPlayMart.startGameUpdate(tempSFS);
		// updateTask.startBotDataUpdate(tempSFS);
	}

	@Override
	public Object handleInternalMessage(String cmdName, Object params) {
		return supportTriggers.handleTriggers(cmdName, params);
	}

}