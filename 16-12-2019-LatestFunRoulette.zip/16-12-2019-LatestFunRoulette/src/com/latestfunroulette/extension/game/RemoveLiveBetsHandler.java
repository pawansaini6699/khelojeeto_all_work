package com.latestfunroulette.extension.game;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.game.common.GameEventMangaer;
import com.latestfunroulette.game.common.interfaces.IGameEventManager;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class RemoveLiveBetsHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User user, ISFSObject params) {
		// TODO Auto-generated method stub

		IGameEventManager gameEventManager = new GameEventMangaer();

		gameEventManager.onCancelSpecificBet(user, params, new CallBack() {

			@Override
			public void call(Object... values) {
				// TODO Auto-generated method stub

			}
		});

	}
}
