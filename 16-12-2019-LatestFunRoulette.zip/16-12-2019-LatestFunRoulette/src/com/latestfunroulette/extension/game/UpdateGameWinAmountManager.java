package com.latestfunroulette.extension.game;

import java.util.List;
import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.cache.beans.RouletteBetBeans;
import com.latestfunroulette.cache.beans.SessionBean;
import com.latestfunroulette.cache.beans.UserBetBean;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Events;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.TicketPrint;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.game.base.interfaces.BaseState;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.SFSExtension;

import scala.ref.WeakReference;

public class UpdateGameWinAmountManager {

	@SuppressWarnings("unused")
	private WeakReference<SFSExtension> ref_extension = null;

	public UpdateGameWinAmountManager(SFSExtension extension) {
		ref_extension = new WeakReference<SFSExtension>(extension);
	}

	public static void updateWinAmount(BaseState basestate, String pSession, String pWinnumber, Room roomname,
			int jackport, String ticketid) {

		new Thread() {
			@Override
			public void run() {

				Utils.Logger(GameMainExtension.extension, "UpdateGameWinAmountManager" + "sessionid" + pSession
						+ " winnnumber" + pWinnumber + "jackport:::::::::" + jackport);

				GameBean gameBean = basestate.getGameBean();
				Player player = GameMainExtension.cache.getPlayer().getValueByKey(gameBean.getUserid());
				SessionBean tempSession = GameMainExtension.cache.getGameSessionBySessionId().getValueByKey(pSession);
				Room tempRoom = GameMainExtension.extension.getParentZone().getRoomByName(gameBean.getRoomName());

				double winamount = 0;
				double tempWinnumberBetAmount = 0;
				String tempWinamount = "";
				int userexistStatus = 1;
				String winningnumber = "";

				if (tempSession != null) {

					List<UserBetBean> tempUserBetBeans = tempSession.getAllUserBets();
					if (tempUserBetBeans != null) {
						for (int u = 0; u < tempUserBetBeans.size(); u++) {
							UserBetBean tempUser = tempUserBetBeans.get(u);

							int gameId = tempUser.getGameId();

							User tempSFSUser = tempRoom.getUserByName(tempUser.getUserId());

							if (tempUser != null && tempUser.isBetStatus()) {

								List<String> tempStrings = TicketPrint.getTempRouletteBetBeans();

								System.out.println(
										"UpdateGameWinAmountManager:::::::::::::tempStrings:::::::::" + tempStrings);

								if (tempStrings.size() > 0) {

									for (String ticketno : tempStrings) {
										System.out.println("UpdateGameWinAmountManager:::::::::::::ticketno:::::::::"
												+ tempStrings);

										RouletteBetBeans tEMPBeans = TicketPrint
												.getRouletteBeanByWinningNumberandTicketId(ticketno,
														String.valueOf(pWinnumber));

										if (tEMPBeans != null) {

											tempWinnumberBetAmount = tEMPBeans.getBetAmount();
											Utils.Logger(GameMainExtension.extension,
													"UpdateGameWinAmountManager:::::::::::::::::::::tempWinnumberBetAmount::"
															+ tempWinnumberBetAmount + "jackport" + jackport);

											Utils.Logger(GameMainExtension.extension,
													"UpdateGameWinAmountManager:::::::::::::::::::::tempWinnumberBetAmount::"
															+ tempWinnumberBetAmount + "jackport" + jackport);

											winamount = tempWinnumberBetAmount * 9 * jackport;

											gameBean.setWinner(String.valueOf(winamount));

											// BigDecimal tempBigDecimal = new BigDecimal((tempWinnumberBetAmount *36));
											tempWinamount = String.valueOf(winamount);

											Utils.Logger(GameMainExtension.extension,
													"UpdateGameWinAmountManager::::::::" + "tempWinamount"
															+ tempWinamount);

											if (tempSFSUser != null) {
												Utils.Logger(GameMainExtension.extension,
														"---------- UpdateUserCreditsbeforeTakeHandler----------userexistStatus "
																+ userexistStatus);

												userexistStatus = 0;
											}

											gameBean.setTotalsessionwinamount(String.valueOf(winamount));
											GameMainExtension.cache.getGames().add(gameBean);

										}

										DBManager.updateUserWinAmountsql(tempUser.getUserId(), tempWinamount,
												winningnumber, pSession, jackport, ticketno, new CallBack() {

													@Override
													public void call(Object... callback) {

														{

															ISFSObject isfsObject = (ISFSObject) callback[0];

// isfsObject.putUtfString(Param.WINAMOUNT,
// String.valueOf(winamountuser));
															Utils.Logger(GameMainExtension.extension,
																	"---------- UpdateUserCreditsbeforeTakeHandler----------response "
																			+ isfsObject.getDump());
															GameMainExtension.extension.send(Events.UPDATEUSERCREDITS,
																	isfsObject, tempSFSUser);
														}

													}
												});

										DBManager.updateUserWinAmountmongo(tempUser.getUserId(), pSession, gameId,
												winningnumber, tempWinamount, userexistStatus, player.getChips());

										Utils.Logger(GameMainExtension.extension,
												"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
										Utils.Logger(GameMainExtension.extension,
												" :::: UpdateGameWinAmount :::: User Id :::: " + tempUser.getUserId()
														+ " :::: Win number :::: " + pWinnumber
														+ " ::: Win number bet amount :::: " + tempWinnumberBetAmount
														+ " :::: Win amount ::: " + tempWinamount);
										Utils.Logger(GameMainExtension.extension,
												"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");

									}
									Utils.Logger(GameMainExtension.extension,
											"::::::::: UpdateGameWinAmount :::::::::::::totalsessionbetamount"
													+ tempSession.getTotalBetAmount()
													+ "::::::::::: winamount ::::::::::::::::" + winamount);
									DBManager.updateLiveTimeData(tempSession.getTotalBetAmount(),
											String.valueOf(winamount), gameId, jackport);

								}

								else {

									winningnumber = (pWinnumber.equals("0") ? "00"
											: String.valueOf((Integer.parseInt(pWinnumber) - 1)));

									tempWinnumberBetAmount = tempUser.getUserBetPlaceAmount()
											.getValueByKey(String.valueOf(winningnumber)).getBetAmount();

									winamount = ((int) Math.round((tempWinnumberBetAmount * 36 * jackport)));

									gameBean.setWinner(String.valueOf(winamount));

// BigDecimal tempBigDecimal = new BigDecimal((tempWinnumberBetAmount *36));
									tempWinamount = String.valueOf(winamount);

									Utils.Logger(GameMainExtension.extension,
											"UpdateGameWinAmountManager::::::::" + "tempWinamount" + tempWinamount);

									if (tempSFSUser != null) {
										Utils.Logger(GameMainExtension.extension,
												"---------- UpdateUserCreditsbeforeTakeHandler----------userexistStatus "
														+ userexistStatus);

										userexistStatus = 0;
									}

									gameBean.setTotalsessionwinamount(String.valueOf(winamount));
									gameBean.setJackport(jackport);
									GameMainExtension.cache.getGames().add(gameBean);

// final int winamountuser=winamount;

									DBManager.updateUserWinAmountsql(tempUser.getUserId(), tempWinamount, winningnumber,
											pSession, jackport, ticketid, new CallBack() {

												@Override
												public void call(Object... callback) {

													{

														ISFSObject isfsObject = (ISFSObject) callback[0];

// isfsObject.putUtfString(Param.WINAMOUNT,
// String.valueOf(winamountuser));
														Utils.Logger(GameMainExtension.extension,
																"---------- UpdateUserCreditsbeforeTakeHandler----------response "
																		+ isfsObject.getDump());
														GameMainExtension.extension.send(Events.UPDATEUSERCREDITS,
																isfsObject, tempSFSUser);
													}

												}
											});

									DBManager.updateUserWinAmountmongo(tempUser.getUserId(), pSession, gameId,
											winningnumber, tempWinamount, userexistStatus, player.getChips());

									Utils.Logger(GameMainExtension.extension,
											"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
									Utils.Logger(GameMainExtension.extension,
											" :::: UpdateGameWinAmount :::: User Id :::: " + tempUser.getUserId()
													+ " :::: Win number :::: " + pWinnumber
													+ " ::: Win number bet amount :::: " + tempWinnumberBetAmount
													+ " :::: Win amount ::: " + tempWinamount);
									Utils.Logger(GameMainExtension.extension,
											"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
								}

								Utils.Logger(GameMainExtension.extension,
										"::::::::: UpdateGameWinAmount :::::::::::::totalsessionbetamount"
												+ tempSession.getTotalBetAmount()
												+ "::::::::::: winamount ::::::::::::::::" + winamount);
								DBManager.updateLiveTimeData(tempSession.getTotalBetAmount(), String.valueOf(winamount),
										gameId, jackport);

							}
						}
					}
				}
			}

		}.start();
	}
}