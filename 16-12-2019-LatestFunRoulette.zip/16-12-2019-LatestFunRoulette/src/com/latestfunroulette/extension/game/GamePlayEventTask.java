package com.latestfunroulette.extension.game;

import java.sql.ResultSet;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import com.latestfunroulette.common.GenerateWinPostion;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.SmartFoxServer;

public class GamePlayEventTask {
	ScheduledFuture<?> taskHandle, taskHandle2;
	int coinAmt;
	// Time t=new Time();
	static int time;

	static String start;
	// java.sql.Connection conn;
	// private CallableStatement callableStatement = null;
	ResultSet resultSet = null;
	int liveTime;
	// public static GameMainExtension gsfs;
	public static GenerateWinPostion generateWinPosition = null;
	public static GameMainExtension extension2 = null;
	// WeakReference<SFSExtension> ref_extension;

	private int count = 0;

	public GamePlayEventTask() {

	}

	public void gameplaytask() {
		extension2 = GameMainExtension.extension;

		SmartFoxServer sfs = SmartFoxServer.getInstance();
		Utils.Logger(extension2, "sfs extension " + sfs);
		generateWinPosition = GenerateWinPostion.getInstance(extension2);
		generateWinPosition.generateWinPostionList();
		taskHandle = sfs.getTaskScheduler().scheduleAtFixedRate(new RoulleteThread(), 15, 1, TimeUnit.SECONDS);

	}

	private class RoulleteThread implements Runnable {

		public RoulleteThread() {

		}

		public void run() {

			if (count > 60) {
				count = 0;

			}

			Utils.Logger(extension2, ":::::::::::::::::UpdateLiveTimePlay::::::::::::::::::::" + count);
			count++;

			// DBManager.UpdateLiveTimePlay(count);

		}

	}

	public String getCurrentRouletteTime() {
		return String.valueOf(count);
	}

	public int getAdminCurrentRouletteTime() {

		Utils.Logger(extension2, "timer::::::::::::::::::" + (60 - count));
		return (60 - count);
	}

}
