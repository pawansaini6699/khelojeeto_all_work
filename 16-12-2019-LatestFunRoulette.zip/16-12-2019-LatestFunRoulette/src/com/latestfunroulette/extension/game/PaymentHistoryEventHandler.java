package com.latestfunroulette.extension.game;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class PaymentHistoryEventHandler extends BaseClientRequestHandler{

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		new Thread() {
			@Override
			public void run() {
				Utils.Logger(GameMainExtension.extension,"PaymentHistoryEventHandler::::::::::::::CurrentThread" +Thread.currentThread().getName());
				print("Request :::: Player Name :::: " + pUser.getName());

				String userid = params.getUtfString(Param.USERID);
				DBManager.getSharePointDetailsByUserId(userid, new CallBack() {

					@Override
					public void call(Object... callback) {
						ISFSArray tempHistoryList = (ISFSArray) callback[0];
						ISFSObject tempSFSObj = new SFSObject();
						tempSFSObj.putSFSArray(Param.PAYMENT_HISTORY_LIST, tempHistoryList);
						print("Response ::getSharePointDetailsByUserId:: Prames ::: " + tempSFSObj.getDump());
					//	GameMainExtension.extension.send(Request.PAYMENT_HISTORY_REQUEST, tempSFSObj, pUser);
					}
				});
			}
		}.start();
	}

	private synchronized void print(String msg){
		Utils.Logger(GameMainExtension.extension, "PaymentHistoryEventHandler :::::: "+msg);
	}
}