package com.latestfunroulette.extension.game;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.game.common.GameEventMangaer;
import com.latestfunroulette.game.common.interfaces.IGameEventManager;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class CancelTicketPrintHandlerRoulette extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUsers, ISFSObject params) {

		new Thread() {

			@Override
			public void run() {

				Utils.Logger(getParentExtension(), "CancelTicketPrintHandlerRoulette :::: Request :::: User ::: "
						+ pUsers.getName() + " ::: Params :::: " + params.getDump());

				try {

					IGameEventManager tempEvents = new GameEventMangaer();

					tempEvents.onCancelTicketRoulette(pUsers, params, new CallBack() {

						@Override
						public void call(Object... values) {

						}
					});
				} catch (Exception e) {

				}

			}

		}.start();

	}

}
