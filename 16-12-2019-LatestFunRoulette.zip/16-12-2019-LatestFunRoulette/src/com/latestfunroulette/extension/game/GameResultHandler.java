package com.latestfunroulette.extension.game;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.game.common.GameEventMangaer;
import com.latestfunroulette.game.common.interfaces.IGameEventManager;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class GameResultHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User user, ISFSObject params) {

		new Thread() {
			@SuppressWarnings("null")
			@Override
			public void run() {
				synchronized (this) {

					Utils.Logger(getParentExtension(), "GameResultHandler :::: Request :::: User ::: " + user.getName()
							+ " ::: Params :::: " + params.getDump());

					try {

						IGameEventManager tempEvents = new GameEventMangaer();

						tempEvents.onGetWinningNumber(user, params, new CallBack() {

							@Override
							public void call(Object... callback) {

							}
						});
					} catch (Exception e) {

					}

				}
			}
		}.start();

	}

	public void insertSession(String session_id) {

		Utils.Logger(GameMainExtension.extension,
				"::::::RoulleteCroneExtension::::::::::::insertSession:::" + session_id);

	//	String new_session_id1 = randomString(10);

	}

	/*
	 * private String randomString(int len) { Random random = new Random();
	 * StringBuilder sb = new StringBuilder(len);
	 * 
	 * for (int i = 0; i < len; i++) {
	 * sb.append("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
	 * .charAt(random.nextInt(
	 * "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".length())));
	 * } return sb.toString(); }
	 */
}
