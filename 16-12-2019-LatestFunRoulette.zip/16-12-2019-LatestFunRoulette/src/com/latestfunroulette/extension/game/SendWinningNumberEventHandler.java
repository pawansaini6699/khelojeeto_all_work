package com.latestfunroulette.extension.game;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class SendWinningNumberEventHandler extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User user, ISFSObject params) {

		/*
		 * new Thread() {
		 * 
		 * @Override public void run() {
		 * 
		 * int gameTypeId = 1;
		 * 
		 * DBManager.get_winning_number(gameTypeId, new CallBack() {
		 * 
		 * @Override public void call(Object... callback) {
		 * 
		 * print("TimerExtension RunMethod :::: Extension :::get_winning_number " +
		 * gameTypeId);
		 * 
		 * ISFSObject isfsObject = (ISFSObject) callback[0];
		 * print("Response::::::::::::::: " + isfsObject.getDump());
		 * send("WinningNumberOfGame", isfsObject, new
		 * ArrayList<>(getParentExtension().getParentZone().getUserList()));
		 * 
		 * } });
		 * 
		 * } }.start();
		 */
	}

	public void print(String msg) {
		Utils.Logger(GameMainExtension.extension, "FetchWinningNumberOfGameHandler::::::::::" + msg);

	}
}