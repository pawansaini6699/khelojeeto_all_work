package com.latestfunroulette.extension.game;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.game.common.GameEventMangaer;
import com.latestfunroulette.game.common.interfaces.IGameEventManager;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class RebetHandlerClass extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {

		print(":::::::request:::::::::: User::::::::::::" + pUser.getDump() + ":::::::params:::::: "
				+ params.getDump());

		new Thread() {
			public void run() {

				IGameEventManager tempEvents = new GameEventMangaer();

				tempEvents.onRebet(pUser, params, new CallBack() {

					@Override
					public void call(Object... values) {
						// TODO Auto-generated method stub

					}
				});

			}
		}.start();
	}

	public synchronized void print(String msg) {

		Utils.Logger(GameMainExtension.extension, "::::::::::RebetHandlerClass::::::::::::" + msg);

	}

}
