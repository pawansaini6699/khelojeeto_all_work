package com.latestfunroulette.extension.game;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class FetchLastFiveDataHandler extends BaseClientRequestHandler {
	public FetchLastFiveDataHandler() {
	}

	public void handleClientRequest(User user, ISFSObject params) {
		//int gametypeid = params.getInt(Param.GAME_TYPE_ID).intValue();
		
		print("::::::::request:::::::::::::params " + params.getDump());
		/*new Thread() {
			@Override
			public void run() {
				DBManager.five_dataFor_Roullet(gametypeid, new CallBack() {
					@Override
					public void call(Object... callback) {
						ISFSObject isfsObject = (ISFSObject) callback[0];
						print(":::::::::::response:::::::::::::::params " + params.getDump());
						GameMainExtension.extension.send(Request.LAST_FIVE_GAME_WINNINGNUMBER, isfsObject, user);
					}
				});
			}
		}.start();
	}*/
	}
	void print(String msg) {
		Utils.Logger(GameMainExtension.extension, ":::::::::::::::FetchLastTenDataHandler::::::::::" + msg);

	}
}