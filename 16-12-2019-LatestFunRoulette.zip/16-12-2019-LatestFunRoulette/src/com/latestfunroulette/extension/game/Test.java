package com.latestfunroulette.extension.game;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.game.common.GameEventMangaer;
import com.latestfunroulette.game.common.interfaces.IGameEventManager;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;

class Test implements Runnable {

	boolean shouldStop;
	User user;
	ISFSObject params;

	public Test(boolean shouldStop) {
		this.shouldStop = shouldStop;
	}

	@Override
	public void run() {

		while (!shouldStop) {
			Utils.Logger(GameMainExtension.extension,"Thread is started");
			liveBetsData(user, params);
		}

		Utils.Logger(GameMainExtension.extension,"Thread has ended");

	}

	public void stop() {
		Thread.currentThread().interrupt();
		shouldStop = true;
	}

	public void liveBetsData(User user, ISFSObject params) {
		Utils.Logger(GameMainExtension.extension,
				"LiveUpdateBetsHandlerClass :::: Request :::: User ::: " + user.getName() + " ::: Params :::: "
						+ params.getDump() + " THREAD NAME::::::::" + Thread.currentThread().getName());

		try {

			IGameEventManager tempEvents = new GameEventMangaer();

			tempEvents.onLiveBet(user, params, new CallBack() {

				@Override
				public void call(Object... values) {

				}
			});

		} catch (Exception e) {

			Utils.Logger(GameMainExtension.extension,"LiveUpdateBetsHandlerClass:::::::::::::::::: error::::::" + e);
		}
		stop();

	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public ISFSObject getParams() {
		return params;
	}

	public void setParams(ISFSObject params) {
		this.params = params;
	}

}
