package com.latestfunroulette.extension.game;

import java.util.List;
import com.latestfunroulette.cache.beans.SessionBean;
import com.latestfunroulette.cache.beans.UserBetBean;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class SendServerLivetimer extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {

		new Thread() {
			@Override
			public void run() {
				synchronized (this) {

					try {

						Utils.Logger(getParentExtension(), "SendServerLivetimer ::: Params ::: " + params.getDump());

						String userid=params.getUtfString("userid");

							DBManager.sendSessionIdOfRullete(userid, new CallBack() {

								@Override
								public void call(Object... callback) {
									String session_id = (String) callback[0];
									Utils.Logger(getParentExtension(),
											"SendServerLiveTimer :::: SendSessionIdofRullete :::: Session Id :::: "
													+ session_id);
									SessionBean tempSessionBean = GameMainExtension.cache
											.getGameSessionBySessionId().getValueByKey(session_id);

									if (tempSessionBean != null) {
										List<UserBetBean> tempUsers = tempSessionBean.getAllUserBets();
										int userSize = tempUsers.size();

										Utils.Logger(getParentExtension(),
												"SendServerLiveTimer ::::: before User size :::: " + userSize);

										try {

											for (int u = 0; u < userSize; u++) {
												UserBetBean tempUserBetBean = tempUsers.get(u);
												if (tempUserBetBean != null && !tempUserBetBean.isBetStatus()) {
													tempSessionBean.cancelAllRouletteBet(tempUserBetBean.getUserId());
													--u;
													--userSize;
												}
											}

										} catch (Exception e) {
											Utils.ErrorLogger(getParentExtension(),
													"SendServerLiveTimer :::: Remove Loop Error :::: ", e);
										}

										try {
											tempUsers = tempSessionBean.getAllUserBets();
											userSize = tempUsers.size();

										} catch (Exception e) {
											Utils.ErrorLogger(getParentExtension(),
													"SendServerLiveTimer ::::: Upload data on loop server error ::::: ",
													e);
										}

										Utils.Logger(getParentExtension(),
												"SendServerLiveTimer ::::: after User size :::: " + userSize);

										try {

											for (int u = 0; u < userSize; u++) {
												UserBetBean tempUserBetBean = tempUsers.get(u);
												if (tempUserBetBean != null && tempUserBetBean.isBetStatus()) {

													try {

													
														String userid = tempUserBetBean.getUserId();
														Utils.Logger(getParentExtension(),
																"SendServerLiveTimer ::::: Update live_update_roulette_history user id :::: "
																		+ userid);
														Utils.Logger(getParentExtension(),
																"SendServerLiveTimer :::: User Id :::: " + userid
																		+ " :::: Session Id ::: " + session_id
																		+ " :::: Total Bet Amount :::  "
																		+ tempUserBetBean.getTotalBetAmount());
														
														//    DBManager.insertrouletteData(session_id, tempUserBetBean);
													      
													      // Accessing the database 
													     													      
													      
												//	DBManager.insertLiveRouletteBets(session_id, tempUserBetBean);

													} catch (Exception e) {
														Utils.ErrorLogger(getParentExtension(),
																"SendServerLiveTimer ::::: Upload data insertLiveRouletteBets in loop server error ::::: ",
																e);
													}

													/*
													 * try {
													 * 
													 * List<RouletteBetBeans> tempRBB = tempUserBetBean
													 * .getUserRouletteBets(); for (int b = 0; b < tempRBB.size(); b++)
													 * {
													 * 
													 * RouletteBetBeans tempUserRouletteBet = tempRBB.get(b);
													 * Utils.Logger(getParentExtension(),
													 * "databseprint data::::::::::::::");
													 * 
													 * try { if (tempUserRouletteBet != null) {
													 * DBManager.insertValues(tempUserBetBean.getUserId(),
													 * tempSessionBean.getSessionId(), tempUserRouletteBet.getBetNos(),
													 * tempUserRouletteBet.getBetAmount(), 0,
													 * tempUserRouletteBet.getSplitBetAmount(),
													 * tempUserBetBean.getTotalBetAmount(),
													 * tempUserRouletteBet.getBetCommands()); }
													 * 
													 * } catch (Exception e) { Utils.ErrorLogger(getParentExtension(),
													 * "SendServerLiveTimer ::::: Upload data inser data insertValues loop in loop server error error ::::: "
													 * , e); }
													 * 
													 * 
													 * }
													 * 
													 * } catch (Exception e) { Utils.ErrorLogger(getParentExtension(),
													 * "SendServerLiveTimer ::::: Upload data  insertValues loop in loop server error ::::: "
													 * , e); }
													 */

												}
											}

										} catch (Exception e) {
											Utils.ErrorLogger(getParentExtension(),
													"SendServerLiveTimer ::::: Upload data on loop server error ::::: ",
													e);
										}

									}
								}
							});

						
					} catch (Exception e) {
						Utils.ErrorLogger(getParentExtension(), "SendServerLivetimer :::: Error ::::: ", e);
					}
				}
			}
		}.start();

	}
}