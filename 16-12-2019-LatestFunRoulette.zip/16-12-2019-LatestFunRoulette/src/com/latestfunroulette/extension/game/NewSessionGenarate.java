package com.latestfunroulette.extension.game;

import com.latestfunroulette.cache.beans.SessionBean;
import com.latestfunroulette.cache.caching.interfaces.ISessionCache;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class NewSessionGenarate extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {

		print("Params ::: " + params.getDump());
		new Thread() {
			@Override
			public void run() {
				int time = params.getInt("serverTime");

				String resultwheel = params.getUtfString(Param.WINNINGNUMBER);
				String session_id = params.getUtfString(Param.SESSION_ID);

				ISFSObject isfsObject = new SFSObject();
				isfsObject.putUtfString(Param.CURRENTGAMESESSION, session_id);
				isfsObject.putUtfString(Param.RESULTWHEEL, resultwheel);
				isfsObject.putInt(Param.TIMER, time);
			
			//	GameMainExtension.cache.getSession().updateCurrentSession(session_id);

				print("RouletteGameExtension ::::51 New Session ::::: " + session_id);

				SessionBean tempsessionbean = new SessionBean();
				tempsessionbean.setSessionId(session_id);
				Utils.Logger(getParentExtension(),
						"RouletteGameExtension ::::51 New Session ::::: " + tempsessionbean.toString());

				ISessionCache<String, SessionBean> tempSessionCache = GameMainExtension.cache
						.getGameSessionBySessionId();

				if (tempSessionCache == null) {
					Utils.Logger(getParentExtension(), "RouletteGameExtension :::: Session Cache is null");
				} else {
					Utils.Logger(getParentExtension(), "RouletteGameExtension :::: Session Cache is not null");
					tempSessionCache.clearAllSession();
					tempSessionCache.add(tempsessionbean);
				}

			}
		}.start();
	}

	public void print(String msg) {

		Utils.Logger(GameMainExtension.extension, "NewSessionGenarate :::::::::::::" + msg);

	}
}
