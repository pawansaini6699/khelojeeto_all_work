package com.latestfunroulette.extension.game;

import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class LiveUpdateBetsHandlerClass extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User user, ISFSObject params) {

		Test test1 = new Test(false);
		test1.setParams(params);
		test1.setUser(user);
		Thread t = new Thread(test1);
		t.setName("mainthread");

		t.start();

	}
}
