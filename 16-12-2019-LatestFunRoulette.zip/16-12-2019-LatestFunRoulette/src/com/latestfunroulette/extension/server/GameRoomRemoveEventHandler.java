package com.latestfunroulette.extension.server;

import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.extensions.BaseServerEventHandler;

public class GameRoomRemoveEventHandler extends BaseServerEventHandler {

	@Override
	public void handleServerEvent(ISFSEvent params) throws SFSException {
		new Thread() {
			@Override
			public void run() {
				try {
					Utils.Logger(getParentExtension(),
							"GameRoomRemoveEventHandler :::: Request ::: Params :::: " + params.toString());
					Utils.SleepThread(3000);
					// CommonEvents.sendUpdateOnlineLobbyEvent();
				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(), " ::: " + this.getClass().getName() + " :: ERROR ::",
							e);
				}
			}
		}.start();
	}
}