package com.latestfunroulette.extension.server;

import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.StaticRoomManager;
import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.extensions.BaseServerEventHandler;

public class ServerReadyEventHandler extends BaseServerEventHandler {

	@Override
	public void handleServerEvent(ISFSEvent event) throws SFSException {

		try {
			Utils.Logger(getParentExtension(), "ServerReadyEventHandler ::::  ::: Params ::: " + event.toString());
			getAllAvatar();
			// createOnlineLobbyRoom();
			createPlayMartRoom();
			createZeroToNineLobbyRoom();
			// createTwoRouletteLobbyRoom();
			// createThreeRouletteLobbyRoom();

		} catch (Exception e) {
			Utils.ErrorLogger(getParentExtension(), " ::: " + this.getClass().getName() + " :: ERROR ::", e);
		}
	}

	private void getAllAvatar() {

		new Thread() {

			@Override
			public void run() {
				DBManager.getAllAvatars();
			}
		}.start();

	}

	private void createZeroToNineLobbyRoom() {

		new Thread() {

			@Override
			public void run() {
				StaticRoomManager.createZeroToNineLobbyRoom();

			}
		}.start();

	}

	/*
	 * private void createOnlineLobbyRoom() { new Thread() {
	 * 
	 * @Override public void run() {
	 * 
	 * StaticRoomManager.createOnlineLobbyRoom(); // DBManager.machineTime();
	 * 
	 * } }.start();
	 * 
	 * }
	 */

	private void createPlayMartRoom()

	{
		new Thread() {

			@Override
			public void run() {
				StaticRoomManager.createPlayMartLobbyRoom();

			}
		}.start();

	}

	/*
	 * private void createTwoRouletteLobbyRoom() {
	 * 
	 * new Thread() {
	 * 
	 * @Override public void run() { StaticRoomManager.createTwoRouletteLobbyRoom();
	 * } }.start(); }
	 */

	/*
	 * private void createThreeRouletteLobbyRoom() { new Thread() {
	 * 
	 * @Override public void run() {
	 * StaticRoomManager.createThreeRouletteLobbyRoom(); } }.start(); }
	 */

}
