package com.latestfunroulette.extension.server;

import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.Constants.StaticRooms;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.extensions.BaseServerEventHandler;

public class UserLeaveRoomEventHandler extends BaseServerEventHandler {

	@Override
	public void handleServerEvent(ISFSEvent params) throws SFSException {
		new Thread() {
			@Override
			public void run() {
				try {
					User tempuser = (User) params.getParameter(SFSEventParam.USER);
					Room temproom = (Room) params.getParameter(SFSEventParam.ROOM);
					Zone tempzone = (Zone) params.getParameter(SFSEventParam.ZONE);

					print("Request ::::: User ::::: " + tempuser.getName() + " ::::: Room :::: " + temproom.getName()
							+ " ::: Zone ::: " + tempzone.getName());

					
					
					GameBean tempGameBean = GameMainExtension.cache.getGames().getValueByKey(temproom.getName());
					
					
					if (temproom.getName().equalsIgnoreCase(StaticRooms.SINGLE_ROULETTE_ROOM)) {

						// String temproomid=temproom.getName();

						Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(tempuser.getName());

						Utils.Logger(getParentExtension(), "tempPlayer " + tempPlayer.toString());

					

						Utils.Logger(getParentExtension(),
								"UserLeaveRoomEventHandler:::::::::::Join ::::  SINGLE_ROULETTE_ROOM::::: User :::: " + tempuser.getName());

						
						tempGameBean.getGameMachine().onLeave(tempuser.getName());
						
					}
					/*
					 * print(" :::: PLAYER_CHIPS :::: " +
					 * GameMainExtension.cache.getPlayer().getValueByKey(tempuser.getName()).
					 * getChips());
					 */		//		 CommonEvents.sendUpdateOnlineLobbyEvent();
				} catch (Exception e) {
					Utils.ErrorLogger(getParentExtension(), " ::: " + this.getClass().getName() + " :: ERROR ::",
							e);
				}
			}
		}.start();
	}

	private void print(String msg) {
		Utils.Logger(getParentExtension(), "UserLeaveRoomEventHandler :::: " + msg);
	}
}