package com.latestfunroulette.extension.server;

import com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean;
import com.latestfunroulette.ZerotoNineRoulette.machine.interfaces.IStateMachine;
import com.latestfunroulette.ZerotoNineRoulette.machine.machineclass.Machine;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.StaticRooms;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.extensions.BaseServerEventHandler;

public class RoomAddEventHandler extends BaseServerEventHandler {

	@Override
	public void handleServerEvent(ISFSEvent params) throws SFSException {

		new Thread() {
			@Override
			public void run() {

				Room temproom = (Room) params.getParameter(SFSEventParam.ROOM);
				Zone tempzone = (Zone) params.getParameter(SFSEventParam.ZONE);

				Utils.Logger(getParentExtension(), "RoomAddEventHandler:::::::::::::::temproom ::: "
						+ temproom.getName() + "  tempzone :::: " + tempzone.getName());

				if (temproom.getName().equalsIgnoreCase(StaticRooms.ZERO_TO_NINE_LOBBY_ROOM)) {
					Utils.Logger(getParentExtension(),
							"RoomAddEventHandler:::::::ZERO_TO_NINE_LOBBY_ROOM::::::::temproom ::: "
									+ temproom.getName());

					GameBean tempGameBean = new GameBean();

					tempGameBean.setSfsRoom(temproom);

					tempGameBean.setRoomName(temproom.getName());
					tempGameBean.setGameTurnTime(0);
					tempGameBean.setGameState(GameState.INITIAL);

					
					IStateMachine<GameBean> getGame = new Machine();
					tempGameBean.setGameMachine(getGame);
					getGame.onStart(tempGameBean);
					
					GameMainExtension.gameCacheZeroToNine.getGames().add(tempGameBean);
					
					Utils.Logger(GameMainExtension.extension,"room addevent :::::::::::::::zerotonine::::::::"+tempGameBean);
					
					
				

				}
				else if (temproom.getName().equalsIgnoreCase(StaticRooms.SINGLE_ROULETTE_ROOM)) {

					Utils.Logger(getParentExtension(),
							"RoomAddEventHandler:::::::::SINGLE_ROULETTE_ROOM::::::temproom ::: " + temproom.getName());
					com.latestfunroulette.cache.beans.GameBean tempGameBean = new com.latestfunroulette.cache.beans.GameBean();

					tempGameBean.setSfsRoom(temproom);

					tempGameBean.setRoomName(temproom.getName());
					tempGameBean.setGameTurnTime(0);
					tempGameBean.setGameState(GameState.INITIAL);

					com.latestfunroulette.game.machine.interfaces.IStateMachine<com.latestfunroulette.cache.beans.GameBean> getGame = new com.latestfunroulette.game.machine.machineclass.Machine();
					tempGameBean.setGameMachine(getGame);
					getGame.onStart(tempGameBean);
					GameMainExtension.cache.getGames().add(tempGameBean);

					Utils.Logger(GameMainExtension.extension,"RoomAddEventHandler:::::::::::::::::::::gamebean::::::::::::::" + tempGameBean);
				}
				else if (temproom.getName().equalsIgnoreCase(StaticRooms.DOUBLE_CHANCE_ROOM)) {

					Utils.Logger(getParentExtension(),
							"RoomAddEventHandler:::::::::DOUBLE_CHANCE_ROOM::::::temproom ::: " + temproom.getName());
					com.latestfunroulette.dubliRoulette.cache.beans.GameBean tempGameBean = new com.latestfunroulette.dubliRoulette.cache.beans.GameBean();

					tempGameBean.setSfsRoom(temproom);

					tempGameBean.setRoomName(temproom.getName());
					tempGameBean.setGameTurnTime(0);
					tempGameBean.setGameState(GameState.INITIAL);

					com.latestfunroulette.dubliRoulette.machine.interfaces.IStateMachine<com.latestfunroulette.dubliRoulette.cache.beans.GameBean> getGame = new com.latestfunroulette.dubliRoulette.machine.machineclass.Machine();
					tempGameBean.setGameMachine(getGame);
					getGame.onStart(tempGameBean);
					GameMainExtension.gameCacheDoubleRoulette.getGames().add(tempGameBean);
				}
				else if(temproom.getName().equalsIgnoreCase(StaticRooms.PLAY_MART_ROOM)) {
					

					Utils.Logger(getParentExtension(),
							"RoomAddEventHandler::::::::::PLAY_MART_ROOM:::::temproom ::: " + temproom.getName());
					com.latestfunroulette.playMart.cache.beans.GameBean tempGameBean = new com.latestfunroulette.playMart.cache.beans.GameBean();

					tempGameBean.setSfsRoom(temproom);

					tempGameBean.setRoomName(temproom.getName());
					tempGameBean.setGameTurnTime(0);
					tempGameBean.setGameState(GameState.INITIAL);

					com.latestfunroulette.playMart.machine.interfaces.IStateMachine<com.latestfunroulette.playMart.cache.beans.GameBean> getGame = new com.latestfunroulette.playMart.machine.Machine();
					tempGameBean.setGameMachine(getGame);
					getGame.onStart(tempGameBean);
					GameMainExtension.gamecachePlayMart.getGames().add(tempGameBean);
					
				}

				else {
					Utils.Logger(getParentExtension(),
							"RoomAddEventHandler:::::::::THREE_ROULETTE_ROOM::::::temproom ::: " + temproom.getName());
					com.latestfunroulette.TripleRoulette.cache.beans.GameBean tempGameBean = new com.latestfunroulette.TripleRoulette.cache.beans.GameBean();

					tempGameBean.setSfsRoom(temproom);

					tempGameBean.setRoomName(temproom.getName());
					tempGameBean.setGameTurnTime(0);
					tempGameBean.setGameState(GameState.INITIAL);

					com.latestfunroulette.TripleRoulette.machine.interfaces.IStateMachine<com.latestfunroulette.TripleRoulette.cache.beans.GameBean> getGame = new com.latestfunroulette.TripleRoulette.machine.machineclass.Machine();
					tempGameBean.setGameMachine(getGame);
					getGame.onStart(tempGameBean);
					GameMainExtension.gameCacheTripleRoulette.getGames().add(tempGameBean);

				}

			}
		}.start();

	}

}
