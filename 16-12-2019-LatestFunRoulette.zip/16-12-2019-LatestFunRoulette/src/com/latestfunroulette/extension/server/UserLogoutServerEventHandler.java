package com.latestfunroulette.extension.server;

import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.extensions.BaseServerEventHandler;

public class UserLogoutServerEventHandler extends BaseServerEventHandler {

	@Override
	public void handleServerEvent(ISFSEvent params) throws SFSException {
		Utils.Logger(getParentExtension(), "UserLogoutServerEventHandler ::::  ::: Params ::: " + params.toString());
		new Thread() {
			@Override
			public void run() {
				synchronized (this) {
					try {
						User pUser = (User) params.getParameter(SFSEventParam.USER);
						Utils.Logger(getParentExtension(),
								"UserLogoutServerEventHandler ::: User :::: " + pUser.getName());
						DBManager.logout(pUser.getName());
						GameMainExtension.cache.getPlayer().delete(pUser.getName());
				//		CommonEvents.sendUpdateOnlineLobbyEvent();
					} catch (Exception e) {
						Utils.ErrorLogger(getParentExtension(), e.getMessage());
						e.printStackTrace();
					}
				}
			}
		}.start();
	}
}