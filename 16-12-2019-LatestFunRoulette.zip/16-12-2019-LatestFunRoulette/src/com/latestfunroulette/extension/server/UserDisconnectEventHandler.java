package com.latestfunroulette.extension.server;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.cache.beans.SessionBean;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.UserConnectionStatus;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.extensions.BaseServerEventHandler;

public class UserDisconnectEventHandler extends BaseServerEventHandler {

	@Override
	public void handleServerEvent(ISFSEvent params) throws SFSException {

		try {

			// Room room = (Room) params.getParameter(SFSEventParam.ROOM);
			User user = (User) params.getParameter(SFSEventParam.USER);
			String tempUserName = user.getName();

			Utils.Logger(getParentExtension(), "UserDisconnectEventHandler::::::::::::::::::::::::user" + user);

			if (user != null) {

				Utils.Logger(getParentExtension(),
						":::::::::::::::Server is disceconnect::::::::: " + tempUserName + "User" + user
								+ "::::::::::SERVEREVENTHANDLER:::::::" + getParentExtension().getParentZone().getName()
								+ " ::: User :::::" + user.getName());
				User tempUser = SmartFoxServer.getInstance().getZoneManager().getZoneByName("RouletteGame")
						.getExtension().getParentZone().getUserByName(user.getName());

				if (tempUser == null || !tempUser.isConnected()) {

					Utils.Logger(getParentExtension(),
							" ServerEVentHandler ::: Disconnect :::::::::::SERVEREVENTHANDLER:::::::::RulletZone:::::"
									+ getParentExtension().getParentZone().getName() + " ::: User :::::"
									+ user.getName());

					Player player = GameMainExtension.cache.getPlayer().getValueByKey(user.getName());
					player.setConnectionStatus(UserConnectionStatus.DISCONNECTED);

					DBManager.logoutConnection(user.getName());
					tempUserName = user.getName();
					String zoneName = getParentExtension().getParentZone().getName();
					if (zoneName.equalsIgnoreCase("RouletteGame")) {
						DBManager.sendSessionIdOfRullete(user.getName(), new CallBack() {
							@Override
							public void call(Object... callback) {
								String session_id = (String) callback[0];
								String tempUserName = user.getName();
								SessionBean tempSessionBean = GameMainExtension.cache.getGameSessionBySessionId()
										.getValueByKey(session_id);

								// if(player!=null) {

								if (tempSessionBean != null) {
									tempSessionBean.cancelAllRouletteBet(tempUserName);
									Utils.Logger(GameMainExtension.extension,"servereventhandler:::::::::" + tempSessionBean.toString());
								}

								// }
							}
						});
					}
				}

			}
		} catch (Exception e) {
			Utils.Logger(getParentExtension(), "***** USER_DISCONNECT *****   error   " + e);

		}
	}
}

/*
 * private void print(String msg) { Utils.Logger(getParentExtension(),
 * "UserDisconnectEventHandler :::: " + msg); }
 */
