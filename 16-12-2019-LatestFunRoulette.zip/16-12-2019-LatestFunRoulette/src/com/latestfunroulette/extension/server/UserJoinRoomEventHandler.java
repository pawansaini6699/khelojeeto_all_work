package com.latestfunroulette.extension.server;

import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.Constants.StaticRooms;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.extensions.BaseServerEventHandler;

public class UserJoinRoomEventHandler extends BaseServerEventHandler {

	@Override
	public void handleServerEvent(ISFSEvent params) throws SFSException {
		new Thread() {
			@Override
			public void run() {
				synchronized (params) {
					try {
						User tempUser = (User) params.getParameter(SFSEventParam.USER);
						Room temproom = (Room) params.getParameter(SFSEventParam.ROOM);
						Zone tempzone = (Zone) params.getParameter(SFSEventParam.ZONE);
						String tempLoginId = tempUser.getName();

						Utils.Logger(getParentExtension(),
								" >>>>>>>>>>>>>>>>>>>>>>>>  USERJOINROOMEVENTHANDLER:::::::::::Request :::jkhkjhkjhkj: User ::: "
										+ tempUser.getDump() + " :::: Zone :::: " + tempzone.getName()
										+ " :::: Room ::: " + temproom.getName());

						if (temproom.getName().equalsIgnoreCase(StaticRooms.SINGLE_ROULETTE_ROOM)) {

							GameBean tempGameBean = GameMainExtension.cache.getGames()
									.getValueByKey(temproom.getName());
							Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(tempLoginId);

							Utils.Logger(getParentExtension(), "tempPlayer " + tempPlayer.toString());

							Utils.Logger(getParentExtension(),
									"USERJOINROOMEVENTHANDLER:::::::::::Join ::::  SINGLE_ROULETTE_ROOM::::: User :::: "
											+ tempUser.getName());

							tempGameBean.getGameMachine().onJoin(tempUser.getName());

						} else if (temproom.getName().equalsIgnoreCase(StaticRooms.ZERO_TO_NINE_LOBBY_ROOM)) {
							com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean tempGameBean = GameMainExtension.gameCacheZeroToNine
									.getGames().getValueByKey(temproom.getName());
							Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(tempLoginId);

							Utils.Logger(getParentExtension(), "tempPlayer " + tempPlayer.toString());

							Utils.Logger(getParentExtension(),
									"USERJOINROOMEVENTHANDLER:::::::::::Join ::::  ZERO_TO_NINE_LOBBY_ROOM::::: User :::: "
											+ tempUser.getName());

							tempGameBean.getGameMachine().onJoin(tempLoginId);

						}

						else if (temproom.getName().equalsIgnoreCase(StaticRooms.DOUBLE_CHANCE_ROOM)) {

							com.latestfunroulette.dubliRoulette.cache.beans.GameBean tempGameBean = GameMainExtension.gameCacheDoubleRoulette
									.getGames().getValueByKey(temproom.getName());

							Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(tempLoginId);

							Utils.Logger(getParentExtension(), "tempPlayer " + tempPlayer.toString());

							Utils.Logger(getParentExtension(),
									"USERJOINROOMEVENTHANDLER:::::::::::Join ::::  doublechance room ::::: User :::: "
											+ tempUser.getName());

							tempGameBean.getGameMachine().onJoin(tempLoginId);

							// CommonEvents.sendDoubleRouletteLobbyEvent(tempUser);

						} else if (temproom.getName().equalsIgnoreCase(StaticRooms.PLAY_MART_ROOM)) {

							com.latestfunroulette.playMart.cache.beans.GameBean   tempGameBean = GameMainExtension.gamecachePlayMart
									.getGames().getValueByKey(temproom.getName());

							Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(tempLoginId);

							Utils.Logger(getParentExtension(), "tempPlayer " + tempPlayer.toString());

							Utils.Logger(getParentExtension(),
									"USERJOINROOMEVENTHANDLER:::::::::::Join ::::  PLAT_MART_ROOM ::::: User :::: "
											+ tempUser.getName());

							tempGameBean.getGameMachine().onJoin(tempLoginId);
						}

						else {

							com.latestfunroulette.TripleRoulette.cache.beans.GameBean tempGameBean = GameMainExtension.gameCacheTripleRoulette
									.getGames().getValueByKey(temproom.getName());

							Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(tempLoginId);

							Utils.Logger(getParentExtension(),
									"USERJOINROOMEVENTHANDLER::::::::  THREEROULETTEGAME:::::::tempPlayer::::chips :::"
											+ tempPlayer.getChips() + "::::loginstatus:::  "
											+ tempPlayer.getLoginStatus() + " block status::::: "
											+ tempPlayer.getUserBlockStatus());

							Utils.Logger(getParentExtension(),
									"::::::USERJOINROOMEVENTHANDLER::::::::::::::::::Join ::::  THREE_ROULETTE_LOBBY_ROOM::::: User :::: "
											+ tempUser.getName());

							tempGameBean.getGameMachine().onJoin(tempLoginId);

							// CommonEvents.sendThreeRouletteLobbyEvent(tempUser);

						}

					} catch (Exception e) {
						Utils.ErrorLogger(GameMainExtension.extension,
								" ::: " + this.getClass().getName() + " :: ERROR ::", e);
					}
				}
			}
		}.start();
	}

}
