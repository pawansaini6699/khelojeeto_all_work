package com.latestfunroulette.extension.server;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.UserConnectionStatus;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.bitswarm.sessions.ISession;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSErrorCode;
import com.smartfoxserver.v2.exceptions.SFSErrorData;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.exceptions.SFSLoginException;
import com.smartfoxserver.v2.extensions.BaseServerEventHandler;

public class UserLoginEventHandler extends BaseServerEventHandler {

	@Override
	public void handleServerEvent(ISFSEvent params) throws SFSException {
		print("UserLoginEventHandler ::::  ::: Params ::: " + params.toString());

		String username = (String) params.getParameter(SFSEventParam.LOGIN_NAME);

		print("Login user name = " + username);

		User tempUser = getParentExtension().getParentZone().getUserByName(username);
		if (username != null && !Utils.isGuestUser(username)) {
			if (GameMainExtension.cache.getPlayer().getValueByKey(username) == null) {

				Utils.Logger(getParentExtension(), "UserLoginEventHandler::::::::::::::::::player"
						+ GameMainExtension.cache.getPlayer().getValueByKey(username));
				DBManager.getUserDetailByLoginId(username, tempUser, new CallBack() {
					@Override
					public void call(Object... callback) {
					}
				});
			}

			// Utils.Logger(getParentExtension(),
			// "UuserLoginEventHandler:::::::::::::::::::::::tempPlayer::::::"+tempPlayer.toString());

			if (GameMainExtension.cache.getPlayer().getValueByKey(username) != null) {

				Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(username);
				print("User Login Done cache is = " + tempPlayer.toSFS().getDump());
				print("User Login user_id"
						+ getParentExtension().getParentZone().getUserByName(tempPlayer.getUserid()));

				if (tempPlayer.getConnectionStatus() == UserConnectionStatus.CONNECTED) {

					Utils.Logger(getParentExtension(),
							"UuserLoginEventHandler:::::::::::::::::::::::connected::::::" + tempUser.isConnected());

					/*
					 * User previousUser = getParentExtension().getParentZone()
					 * .getUserByName(tempPlayer.getName());
					 */
					if (getParentExtension().getParentZone().getUserByName(tempPlayer.getUserid()) != null) {
						SFSErrorData data = new SFSErrorData(SFSErrorCode.LOGIN_ALREADY_LOGGED);
						data.addParameter(String.format(Param.ALREADY_LOGIN_USER, tempPlayer.getName()));
						throw new SFSLoginException("Nice try...", data);
					}

					/*
					 * else {
					 * 
					 * DBManager.customSfsLogin(tempPlayer, new CallBack() {
					 * 
					 * @Override public void call(Object... values) { String status = (String)
					 * values[0]; String message = (String) values[1];
					 * 
					 * ISFSObject tempSFSObj = new SFSObject();
					 * tempSFSObj.putUtfString(Param.STATUS, status);
					 * tempSFSObj.putUtfString(Param.MESSAGE, message); if
					 * (status.equalsIgnoreCase("true")) { tempUser.setName(tempPlayer.getUserid());
					 * tempPlayer.getChips(); tempPlayer.getLoginStatus();
					 * tempPlayer.getUserBlockStatus(); tempPlayer.setUser(tempUser);
					 * 
					 * Utils.Logger(getParentExtension(), "tempplayer:::::::::::::::" +
					 * tempPlayer.toString()); GameMainExtension.cache.getPlayer().add(tempPlayer);
					 * 
					 * tempSFSObj.putUtfString(Param.USER_LOGIN_ID, tempPlayer.getUserid()); } else
					 * {
					 * 
					 * tempSFSObj.putNull(Param.USER_LOGIN_ID); }
					 * 
					 * print("Response :::: User ::: " + tempUser.getName() + " ::: Params ::: " +
					 * tempSFSObj.getDump()); send(Request.CUSTOM_LOGIN_REQUEST, tempSFSObj,
					 * tempUser);
					 * 
					 * if (status.equalsIgnoreCase("true")) CommonEvents.sendUserDetails(tempPlayer,
					 * tempUser); status = null; message = null; tempSFSObj = null; } });
					 * 
					 * }
					 */

					// getParentExtension().getApi().kickUser(previousUser, null, "", 1);
				} else {

					ISession tempSession = (ISession) params.getParameter(SFSEventParam.SESSION);

					tempPlayer.setConnectionStatus(UserConnectionStatus.CONNECTED);
					tempPlayer.setIpaddress(tempSession.getAddress());
					tempPlayer.setLoginStatus(1);

					DBManager.updateUserLoginStatus(tempPlayer);
				}
			}
		} else {
			print(" :::: GUEST USER :::: ");
		}

	}

	private void print(String msg) {
		Utils.Logger(GameMainExtension.extension,"UserLoginEventHandler :::: " + msg);
	}

}