package com.latestfunroulette.extension.server;

import com.latestfunroulette.common.Utils;
import com.smartfoxserver.v2.core.ISFSEvent;
import com.smartfoxserver.v2.core.SFSEventParam;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSException;
import com.smartfoxserver.v2.extensions.BaseServerEventHandler;

public class UserJoinZoneEventHandler extends BaseServerEventHandler {

	@Override
	public void handleServerEvent(ISFSEvent event) throws SFSException {
		new Thread() {
			@Override
			public void run() {
				synchronized (this) {
					try {
						User tempUser = (User) event.getParameter(SFSEventParam.USER);
						String tempLoginId = tempUser.getName();
						print("UserJoinZoneEventHandler @@ :::: User ::: " + tempLoginId);

						print("Join :::: Online Lobby Rooom ::::: User :::: " + tempUser.getName());

						// Player tempPlayer =
						// GameMainExtension.cache.getPlayer().getValueByKey(tempLoginId);

						Utils.Logger(getParentExtension(), "UserJoinZoneEventHandler :::: User ::: " + tempLoginId);

						if (tempUser != null && !Utils.isGuestUser(tempLoginId)) {
							/*
							 * DBManager.getUserDetailByLoginId(tempLoginId, new CallBack() {
							 * 
							 * @Override public void call(Object... values) { // TODO Auto-generated method
							 * stub
							 * 
							 * } });
							 */
						}

					} catch (Exception e) {
						Utils.ErrorLogger(getParentExtension(), " ::: " + this.getClass().getName() + " :: ERROR ::",
								e);
					}
				}
			}
		}.start();
	}

	private void print(String msg) {
		Utils.Logger(getParentExtension(), "UserJoinZoneEventHandler :::: " + msg);
	}
}