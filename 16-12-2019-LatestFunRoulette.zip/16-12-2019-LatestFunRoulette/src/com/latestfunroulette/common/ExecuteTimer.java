package com.latestfunroulette.common;

import java.util.Timer;

public class ExecuteTimer {

	public static void init() {

		TimerExample te1 = new TimerExample("Task1");
		Timer t = new Timer();
		t.schedule(te1, 60*60*24*1*1000);

	}
}