package com.latestfunroulette.common;

import java.math.BigDecimal;
import java.math.RoundingMode;

import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.cache.beans.SessionBean;
import com.smartfoxserver.v2.entities.User;

public class RemoveBetNumber {
	static long winAmountFactor = 0;

	public RemoveBetNumber(User user, String sessionId, double coins, int betnumbers) {
		String[] totalbetnumber = BetNumbersConstant.getValuesByKey(betnumbers);
		double splitAmount = 0;
		double totalsplitamount = 0;
		double winAmount = 0;

		Utils.Logger(GameMainExtension.extension,
				"playmart::::::::::::::BetNumbers::::::::::::::: betno::::::::::: " + betnumbers);

		SessionBean tempGameSessionBean = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
				.getValueByKey(sessionId);

		if (12 > betnumbers) {
			totalsplitamount = coins;
			winAmount = coins * 10;

		} else if (betnumbers > 11 && 16 > betnumbers) {

			splitAmount = (((double) coins) / 3);
			totalsplitamount = BigDecimal.valueOf(splitAmount).setScale(2, RoundingMode.HALF_UP).doubleValue();
			System.out.println("totalsplitamount   three digit:::::::::::::::::::" + totalsplitamount);
			winAmount = totalsplitamount * 10;

		} else {
			splitAmount = (((double) coins) / 4);
			totalsplitamount = BigDecimal.valueOf(splitAmount).setScale(2, RoundingMode.HALF_UP).doubleValue();
			System.out.println("totalsplitamount   four digit:::::::::::::::::::" + totalsplitamount);
			winAmount = totalsplitamount * 10;
		}

		Utils.Logger(GameMainExtension.extension,
				"playmart::::::::::::::::::::::::::::::::: winAmount:::::::::::::::::::::::::::::" + winAmount);

		StringBuilder tempSelectedNumbers = new StringBuilder();

		for (int i = 0; i < totalbetnumber.length; i++) {

			if (totalbetnumber.length == 1) {

				tempSelectedNumbers.append(totalbetnumber[i]);

			} else {

				tempSelectedNumbers.append(totalbetnumber[i] + ",");
			}
		}
		if (tempGameSessionBean == null) {

			Utils.Logger(GameMainExtension.extension,
					"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    ");

		} else {

			Utils.Logger(GameMainExtension.extension,
					"BetNumbers:::::::playmart :::::::::::::::tempGameSessionBean: is not null::::::::::    "
							+ tempGameSessionBean.toString() + "tempGameSessionBean"
							+ tempGameSessionBean.getTotalBetAmount());

			tempGameSessionBean.cancelSpecifiChooseAdmin(tempSelectedNumbers.toString(), user.getName(),coins, totalsplitamount);

		}

	}

}
