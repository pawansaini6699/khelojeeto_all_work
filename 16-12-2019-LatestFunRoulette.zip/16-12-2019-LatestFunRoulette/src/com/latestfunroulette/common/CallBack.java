package com.latestfunroulette.common;

public interface CallBack {
	void call(Object... values);
}