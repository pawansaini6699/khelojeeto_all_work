package com.latestfunroulette.common;

import java.lang.ref.WeakReference;
import java.util.Collection;
import java.util.List;

import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.Events;
import com.latestfunroulette.common.Constants.Message;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.StaticRooms;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.game.base.interfaces.BaseState;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class CommonEvents {

	private static WeakReference<SFSExtension> ref_extension = null;

	public CommonEvents(SFSExtension extension) {
		ref_extension = new WeakReference<SFSExtension>(extension);
	}

	public static void sendUserIsBlockedEvent(Player pPlayer, User pUser) {
		new Thread() {
			@Override
			public void run() {

				if (pUser == null || !pUser.isConnected())
					return;

				ISFSObject tempSFSObj = pPlayer.toSFS();
				tempSFSObj.putUtfString(Param.IS_USER_BLOCK,
						(pPlayer.getUserBlockStatus() == 1 ? EnableStatus.TRUE : EnableStatus.FALSE));
				tempSFSObj.putUtfString(Param.MESSAGE, Message.USER_IS_BLOCKED);
				Utils.Logger(ref_extension.get(), "CommonEvents ::: sendUserIsBlockedEvent ::: Response :::: User ::: "
						+ pUser.getName() + " :::: Params ::: " + tempSFSObj.getDump());
				// ref_extension.get().send(Event.USER_BLOCKED_EVENT, tempSFSObj, pUser);
			}
		}.start();
	}

	public static void sendUserDetails(Player pPlayer, User pUser) {
		new Thread() {
			@Override
			public void run() {

				if (pUser == null || !pUser.isConnected())
					return;
				
				ISFSObject tempSFSObj = pPlayer.toSFS();
				int avatarId = DBManager.getAvatarId(pPlayer.getUserid());
				tempSFSObj.putUtfString(Param.AVATAR_ID, String.valueOf(avatarId));
				tempSFSObj.putUtfString(Param.STATUS, EnableStatus.TRUE);
				tempSFSObj.putUtfString(Param.MESSAGE, Message.SUCCESSFULLY);

				Utils.Logger(ref_extension.get(), "CommonEvents ::: SendUserDetails ::: Response :::: User ::: "
						+ pUser.getName() + " :::: Params ::: " + tempSFSObj.getDump());
				ref_extension.get().send(Events.USER_PROFILE_EVENT, tempSFSObj, pUser);
			}
		}.start();
	}

	public static void sendSingleRouletteLobbyEvent(User pUser) {

		Utils.Logger(GameMainExtension.extension, "User:::::name:::::::" + pUser.getName());

	//	String loginuser = pUser.getName();

		new Thread() {
			@Override
			public void run() {

				if (pUser == null || !pUser.isConnected())
					return;

				DBManager.getLastFiveNumber(pUser.getName(),new CallBack() {

					@Override
					public void call(Object... callback) {
						Room tempRoom = ref_extension.get().getParentZone()
								.getRoomByName(StaticRooms.SINGLE_ROULETTE_ROOM);

						GameBean gameBean = GameMainExtension.cache.getGames().getValueByKey(tempRoom.getName());
						// GameBean gameBean =
						// GameMainExtension.cache.getGames().getValueByKey(loginuser);

						Utils.Logger(GameMainExtension.extension,
								"sendSingleRouletteLobbyEvent::::::::::gamebean" + gameBean.toString());
					//	Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(loginuser);
						ISFSObject isfsObject = (ISFSObject) callback[0];
						Utils.Logger(GameMainExtension.extension, "ROOM NAME" + tempRoom.getName());
						List<User> tempUsers = tempRoom.getUserList();
						int onlineplayerscount = tempUsers.size();

						isfsObject.putUtfString(Param.ONLINE_PLAYER_COUNT, String.valueOf(onlineplayerscount));
						isfsObject.putUtfString(Param.ROOM_NAME, "SINGLE_ROULETTE_ROOM");
					//	isfsObject.putUtfString(Param.CREDITS, tempPlayer.getChips());
						Utils.Logger(GameMainExtension.extension,
								"CommonEvents::::::::::::::::::sendSingleRouletteLobbyEvent::::::::Response:::::::isfsobject "
										+ isfsObject.getDump());

					//	ref_extension.get().send(Request.SINGLE_ROULETTE_LOBBY_REQUEST, isfsObject, pUser);

					}
				});

				/*
				 * tempSFSObj.putUtfString(Param.ONLINE_PLAYER_COUNT,
				 * String.valueOf(onlineplayerscount));
				 * 
				 * try {
				 * 
				 * IGameEventManager tempEvents = new GameEventMangaer();
				 * 
				 * tempEvents.sendLiveTime(this, params, new CallBack() {
				 * 
				 * @Override public void call(Object... values) {
				 * 
				 * } }); } catch (Exception e) {
				 * 
				 * }
				 */

			}
		}.start();
	}

	public static void sendDoubleRouletteLobbyEvent(User pUser) {

		Utils.Logger(GameMainExtension.extension, "User:::::name:::::::" + pUser.getName());

		// String loginuser = pUser.getName();

		new Thread() {
			@Override
			public void run() {

				if (pUser == null || !pUser.isConnected())
					return;

				DBManager.userStatus(pUser.getName(), new CallBack() {
					@Override
					public void call(Object... callback) {
						ISFSObject tempSFSObj = (ISFSObject) callback[0];

						GameBean gameBean = GameMainExtension.cache.getGames().getValueByKey(pUser.getName());

						Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());
						List<User> tempUsers = tempRoom.getUserList();
						int onlineplayerscount = tempUsers.size();

						Utils.Logger(ref_extension.get(),
								"game bean room name" + gameBean.getRoomName() + " gamebean time  " + gameBean.getTime()
										+ " fivewinning number " + gameBean.getLastfivenumber()
										+ "winning number :::::: " + gameBean.getWinningnumber());

						tempSFSObj.putUtfString(Param.ONLINE_PLAYER_COUNT, String.valueOf(onlineplayerscount));
						tempSFSObj.putUtfString(Param.TIMER,
								String.valueOf(new BaseState().getTimer().getElapsedTime()));
						tempSFSObj.putUtfString(Param.LASTFIVENUMBER, gameBean.getLastfivenumber());
						tempSFSObj.putUtfString(Param.WINNINGNUMBER, gameBean.getWinningnumber());

						Utils.Logger(GameMainExtension.extension,
								"CommonEvents::::::::::::::::::sendDoubleRouletteLobbyEvent::::::::Response:::::::isfsobject "
										+ tempSFSObj.getDump());

						ref_extension.get().send(Events.TWO_ROULETTE_LOBBY_EVENT, tempSFSObj, tempUsers);

					}
				});

			}
		}.start();
	}

	public static void sendThreeRouletteLobbyEvent(User pUser) {

		Utils.Logger(GameMainExtension.extension, "User:::::name:::::::" + pUser.getName());

		String loginuser = pUser.getName();

		new Thread() {
			@Override
			public void run() {

				if (pUser == null || !pUser.isConnected())
					return;

				DBManager.userStatus(pUser.getName(), new CallBack() {
					@Override
					public void call(Object... callback) {
						ISFSObject tempSFSObj = (ISFSObject) callback[0];

						GameBean gameBean = GameMainExtension.cache.getGames().getValueByKey(loginuser);

						Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());
						List<User> tempUsers = tempRoom.getUserList();
						int onlineplayerscount = tempUsers.size();

						Utils.Logger(ref_extension.get(),
								"game bean room name" + gameBean.getRoomName() + " gamebean time  " + gameBean.getTime()
										+ " fivewinning number " + gameBean.getLastfivenumber()
										+ "winning number :::::: " + gameBean.getWinningnumber());

						tempSFSObj.putUtfString(Param.ONLINE_PLAYER_COUNT, String.valueOf(onlineplayerscount));
						tempSFSObj.putUtfString(Param.TIMER, gameBean.getTime());
						tempSFSObj.putUtfString(Param.LASTFIVENUMBER, gameBean.getLastfivenumber());
						tempSFSObj.putUtfString(Param.WINNINGNUMBER, gameBean.getWinningnumber());

						Utils.Logger(GameMainExtension.extension,
								"CommonEvents::::::::::::::::::sendThreeRouletteLobbyEvent::::::::Response:::::::isfsobject "
										+ tempSFSObj.getDump());

						ref_extension.get().send(Events.THREE_ROULETTE_LOBBY_EVENT, tempSFSObj, tempUsers);

					}
				});

			}
		}.start();
	}

	public static void sendUserChips(Player pPlayer) {
		new Thread() {
			@Override
			public void run() {

				Collection<User> userList = GameMainExtension.extension.getParentZone().getUserList();
				User pUser = null;
				for (User user : userList) {
					if (user.getName().equals(pPlayer.getUserid())) {
						pUser = user;
						Utils.Logger(GameMainExtension.extension,
								" :::: USER getParentZone().getUserList() :::: " + pUser);
						break;
					}
				}
				if (pUser != null && pUser.isConnected()) {
					ISFSObject tempSFSObj = pPlayer.updateChips();
					tempSFSObj.putUtfString(Param.STATUS, EnableStatus.TRUE);
					tempSFSObj.putUtfString(Param.MESSAGE, Message.SUCCESSFULLY);
					Utils.Logger(ref_extension.get(), ":::: SFSOBJECT :::" + tempSFSObj.getDump());
					Utils.Logger(ref_extension.get(), "CommonEvents ::: SendUserChips ::: Response :::: User ::: "
							+ pUser.getName() + " :::: Params ::: " + tempSFSObj.getDump());
					// ref_extension.get().send(Event.UPDATE_USER_CHIPS, tempSFSObj, pUser);
				} else {
					Utils.Logger(ref_extension.get(), "CommonEvents ::: SendUserChips ::: USER == null :::: ");
				}
			}
		}.start();
	}

	public static void sendUserDetailsAfterProfileUpdate(Player pPlayer, User pUser) {
		new Thread() {
			@Override
			public void run() {

				if (pUser == null || !pUser.isConnected())
					return;

				ISFSObject tempSFSObj = pPlayer.toSFS();
				tempSFSObj.putUtfString(Param.STATUS, EnableStatus.TRUE);
				tempSFSObj.putUtfString(Param.MESSAGE, Message.SUCCESSFULLY);
				Utils.Logger(ref_extension.get(),
						"CommonEvents ::: sendUserDetailsAfterProfileUpdate ::: Response :::: User :::"
								+ pUser.getName() + " :::: Params ::: " + tempSFSObj.getDump());
				// ref_extension.get().send(Event.USER_PROFILE_IMAGE_UPDATE_EVENT, tempSFSObj,
				// pUser);
			}
		}.start();
	}

}