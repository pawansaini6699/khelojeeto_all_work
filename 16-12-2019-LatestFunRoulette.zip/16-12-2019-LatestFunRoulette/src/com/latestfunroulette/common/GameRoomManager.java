package com.latestfunroulette.common;

import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.common.Constants.GameFormat;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.exceptions.SFSCreateRoomException;

public class GameRoomManager {

	public static void createRoom(User pUser, GameBean tempGameBean, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				GameMainExtension extension = GameMainExtension.extension;
				Utils.Logger(extension, "GameRoomManager :::: CreateRoom()");
				try {

					if (pUser != null && pUser.isConnected()) {
						String roomname = GameMainExtension.globlaId.getNextId(GameFormat.ROOM_NAME);
						Utils.Logger(extension, "GameRoomManager::::::::::"+ roomname);
						tempGameBean.setRoomName(roomname);
						// tempGameBean.setGameTableName(roomname);
						int maxPlayer = 100;

						CreateRoomSettings tempRoomSetting = new CreateRoomSettings();
						tempRoomSetting.setGroupId(tempGameBean.getGameType());
						tempRoomSetting.setName(roomname);
						tempRoomSetting.setMaxUsers(maxPlayer);
						tempRoomSetting.setGame(true);
					//	tempRoomSetting.setAutoRemoveMode(SFSRoomRemoveMode.DEFAULT);
						if (tempGameBean.isPassword()) {
							tempRoomSetting.setPassword(tempGameBean.getPassword());
						}

						Room tempRoom = extension.getApi().createRoom(extension.getParentZone(), tempRoomSetting, null,
								false, null, true, true);

						// tempRoom.setProperty(Param.GAME_NAME, tempGameBean.getGameTableName());
						tempRoom.setProperty(Param.GAME_TYPE, tempGameBean.getGameType());

						tempRoom.setActive(true);
						tempGameBean.setSfsRoom(tempRoom);

						Utils.Logger(extension, "GameRoomManager ::::: CreateRoom :::: " + tempRoom.getDump());
						/*
						 * DBManager.createOnlineGame(tempGameBean, new CallBack() {
						 * 
						 * @Override public void call(Object... values) { String status = (String)
						 * values[0]; Utils.Logger(extension,
						 * "GameRoomManager ::::: CreateRoom ::: CreateOnlineGame :::: () :::: Status :::; "
						 * + status); GameMainExtension.cache.getGames().add(tempGameBean); //
						 * joinRoom(pUser, tempGameBean, pCallBack); } });
						 */
					} else {
						pCallBack.call(false, "", null);
					}
				} catch (SFSCreateRoomException e) {
					pCallBack.call(false, "", null);
					Utils.ErrorLogger(extension, "GameRoomManager :::::  CreateRoom ::::: Error :::: ", e);
				}
			}
		}.start();
	}

	/*
	 * public static synchronized void joinRoom(User pUser, GameBean tempGameBean,
	 * CallBack pCallBack) { Utils.Logger(GameMainExtension.extension,
	 * "GameRoomManager :::: JoinRoom()");
	 * 
	 * if (pUser != null && pUser.isConnected()) { Player tempPlayer =
	 * GameMainExtension.cache.getPlayer().getValueByKey(pUser.getName());
	 * Utils.Logger(GameMainExtension.extension,
	 * "GameRoomManager :::: JoinRoom() BLOCK_STATUS " +
	 * tempPlayer.getUserBlockStatus()); if (tempPlayer.getUserBlockStatus() == 0) {
	 * tempGameBean.addPlayers(pUser, tempPlayer.getLoginid(),tempGameBean, new
	 * CallBack() {
	 * 
	 * @Override public void call(Object... values) { boolean dbstatus = (boolean)
	 * values[0]; if (dbstatus) { CommonEvents.sendUserDetails(tempPlayer, pUser);
	 * joinSFSRoom(pUser, tempGameBean, pCallBack);
	 * Utils.addGameInPlayerList(tempGameBean, pUser);
	 * Utils.Logger(GameMainExtension.extension, "GameRoomManager :::: JoinRoom() "
	 * + tempGameBean.getPlayers()); Utils.setPlayersRank(tempGameBean); } else
	 * pCallBack.call(dbstatus); } }); } else {
	 * CommonEvents.sendUserIsBlockedEvent(tempPlayer, pUser);
	 * pCallBack.call(EnableStatus.DISABLE); } } else {
	 * pCallBack.call(EnableStatus.DISABLE); } }
	 */
	/*
	 * private static synchronized void joinSFSRoom(User pUser, GameBean
	 * tempGameBean, CallBack pCallBack) { Utils.Logger(GameMainExtension.extension,
	 * "GameRoomManager :::: JoinSFSRoom()"); try { if (pUser != null &&
	 * pUser.isConnected()) { Utils.Logger(GameMainExtension.extension,
	 * "GameRoomManager :::: JoinSFSRoom() - 1 "); Room tempRoom =
	 * tempGameBean.getSfsRoom(); if (!pUser.isJoinedInRoom(tempRoom) &&
	 * tempRoom.getUserByName(pUser.getName()) == null) {
	 * Utils.Logger(GameMainExtension.extension,
	 * "GameRoomManager :::: JoinSFSRoom() - 2 "); if (tempGameBean.isPassword()) {
	 * GameMainExtension.extension.getApi().joinRoom(pUser, tempRoom,
	 * tempGameBean.getPassword(), false, null); } else {
	 * GameMainExtension.extension.getApi().joinRoom(pUser, tempRoom, null, false,
	 * null); Utils.ErrorLogger(GameMainExtension.extension,
	 * "GameRoomManager :::::  JoinSFSRoom @@@@ ::::: " + pUser.getDump()); }
	 * pCallBack.call(EnableStatus.ENABLE); } else { // Player pPlayer = //
	 * EstimationKingdomExtension.cache.getPlayer().getValueByKey(pUser.getName());
	 * // CommonEvents.sendUserIsBlockedEvent(pPlayer, pUser);
	 * pCallBack.call(EnableStatus.DISABLE); } } else {
	 * pCallBack.call(EnableStatus.DISABLE); } } catch (SFSJoinRoomException e) {
	 * pCallBack.call(EnableStatus.DISABLE);
	 * Utils.ErrorLogger(GameMainExtension.extension,
	 * "GameRoomManager :::::  JoinSFSRoom ::::: Error :::: ", e); } }
	 */
	
}