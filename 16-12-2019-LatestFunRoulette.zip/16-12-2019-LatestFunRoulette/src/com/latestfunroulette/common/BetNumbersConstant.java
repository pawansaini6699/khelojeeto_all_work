package com.latestfunroulette.common;

import java.util.HashMap;

import com.latestfunroulette.extension.GameMainExtension;

public class BetNumbersConstant {

	static HashMap<Integer, String[]> hashMapBetValues = new HashMap<Integer, String[]>();

	public static String[] getValuesByKey(int key) {
		try {

			return hashMapBetValues.get(key);

		} catch (Exception e) {

			Utils.Logger(GameMainExtension.extension, "error::::::::::::::::::::" + e);
			return null;
		}

	}

	public static HashMap<Integer, String[]> getAllList() {

		return hashMapBetValues;
	}

	private BetNumbersConstant() {

	}

	public static void init() {

		hashMapBetValues.put(0, new String[] { "0" });
		hashMapBetValues.put(1, new String[] { "1" });
		hashMapBetValues.put(2, new String[] { "2" });
		hashMapBetValues.put(3, new String[] { "3" });

		hashMapBetValues.put(4, new String[] { "4" });
		hashMapBetValues.put(5, new String[] { "5" });
		hashMapBetValues.put(6, new String[] { "6" });

		hashMapBetValues.put(7, new String[] { "7" });
		hashMapBetValues.put(8, new String[] { "8" });
		hashMapBetValues.put(9, new String[] { "9" });
		hashMapBetValues.put(10, new String[] { "10" });
		hashMapBetValues.put(11, new String[] { "11" });

		hashMapBetValues.put(12, new String[] { "0", "4", "8" });
		hashMapBetValues.put(13, new String[] { "1", "5", "9" });
		hashMapBetValues.put(14, new String[] { "2", "6", "10" });
		hashMapBetValues.put(15, new String[] { "3", "7", "11" });

		hashMapBetValues.put(16, new String[] { "0", "1", "2", "3" });
		hashMapBetValues.put(17, new String[] { "4", "5", "6", "7" });
		hashMapBetValues.put(18, new String[] { "8", "9", "10", "11" });

		/*
		 * ::::::::::::::::::::::::::::::::::::::::DoubleNine::::::::::::::::::::::
		 */
		hashMapBetValues.put(101, new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" });
		hashMapBetValues.put(102, new String[] { "10", "11", "12", "13", "14", "15", "16", "17", "18", "19" });
		hashMapBetValues.put(103, new String[] { "20", "21", "22", "23", "24", "25", "26", "27", "28", "29" });
		hashMapBetValues.put(104, new String[] { "30", "31", "32", "33", "34", "35", "36", "37", "38", "39" });
		hashMapBetValues.put(105, new String[] { "40", "41", "42", "43", "44", "45", "46", "47", "48", "49" });
		hashMapBetValues.put(106, new String[] { "50", "51", "52", "53", "54", "55", "56", "57", "58", "59" });
		hashMapBetValues.put(107, new String[] { "60", "61", "62", "63", "64", "65", "66", "67", "68", "69" });
		hashMapBetValues.put(108, new String[] { "70", "71", "72", "73", "74", "75", "76", "77", "78", "79" });
		hashMapBetValues.put(109, new String[] { "80", "81", "82", "83", "84", "85", "86", "87", "88", "89" });
		hashMapBetValues.put(110, new String[] { "90", "91", "92", "93", "94", "95", "96", "97", "98", "99" });
		hashMapBetValues.put(111, new String[] { "0", "10", "20", "30", "40", "50", "60", "70", "80", "90" });
		hashMapBetValues.put(112, new String[] { "1", "11", "21", "31", "41", "51", "61", "71", "81", "91" });
		hashMapBetValues.put(113, new String[] { "2", "12", "22", "32", "42", "52", "62", "72", "82", "92" });
		hashMapBetValues.put(114, new String[] { "3", "13", "23", "33", "43", "53", "63", "73", "83", "93" });
		hashMapBetValues.put(115, new String[] { "4", "14", "24", "34", "44", "54", "64", "74", "84", "94" });
		hashMapBetValues.put(116, new String[] { "5", "15", "25", "35", "45", "55", "65", "75", "85", "95" });
		hashMapBetValues.put(117, new String[] { "6", "16", "26", "36", "46", "56", "66", "76", "86", "96" });
		hashMapBetValues.put(118, new String[] { "7", "17", "27", "37", "47", "57", "67", "77", "87", "97" });
		hashMapBetValues.put(119, new String[] { "8", "18", "28", "38", "48", "58", "68", "78", "88", "98" });
		hashMapBetValues.put(120, new String[] { "9", "19", "29", "39", "49", "59", "69", "79", "89", "99" });

		/*
		 * :::::::::::::::::::::::::::::::::::::::::: Triple
		 * Roulette::::::::::::::::::::::::::::::::::::::::::
		 */

		hashMapBetValues.put(201,
				new String[] { "000", "001", "002", "003", "004", "005", "006", "007", "008", "009" });
		hashMapBetValues.put(202,
				new String[] { "010", "011", "012", "013", "014", "015", "016", "017", "018", "019" });
		hashMapBetValues.put(203,
				new String[] { "020", "021", "022", "023", "024", "025", "026", "027", "028", "029" });
		hashMapBetValues.put(204,
				new String[] { "030", "031", "032", "033", "034", "035", "036", "037", "038", "039" });
		hashMapBetValues.put(205,
				new String[] { "040", "041", "042", "043", "044", "045", "046", "047", "048", "049" });
		hashMapBetValues.put(206,
				new String[] { "050", "051", "052", "053", "054", "055", "056", "057", "058", "059" });
		hashMapBetValues.put(207,
				new String[] { "060", "061", "062", "063", "064", "065", "066", "067", "068", "069" });
		hashMapBetValues.put(208,
				new String[] { "070", "071", "072", "073", "074", "075", "076", "077", "078", "079" });
		hashMapBetValues.put(209,
				new String[] { "080", "081", "082", "083", "084", "085", "086", "087", "088", "089" });
		hashMapBetValues.put(210,
				new String[] { "090", "091", "092", "093", "094", "095", "096", "097", "098", "099" });

		hashMapBetValues.put(211,
				new String[] { "100", "101", "102", "103", "104", "105", "106", "107", "108", "109" });
		hashMapBetValues.put(212,
				new String[] { "110", "111", "112", "113", "114", "115", "116", "117", "118", "119" });
		hashMapBetValues.put(213,
				new String[] { "120", "121", "122", "123", "124", "125", "126", "127", "128", "129" });
		hashMapBetValues.put(214,
				new String[] { "130", "131", "132", "133", "134", "135", "136", "137", "138", "139" });
		hashMapBetValues.put(215,
				new String[] { "140", "141", "142", "143", "144", "145", "146", "147", "148", "149" });
		hashMapBetValues.put(216,
				new String[] { "150", "151", "152", "153", "154", "155", "156", "157", "158", "159" });
		hashMapBetValues.put(217,
				new String[] { "160", "161", "162", "163", "164", "165", "166", "167", "168", "169" });
		hashMapBetValues.put(218,
				new String[] { "170", "171", "172", "173", "174", "175", "176", "177", "178", "179" });
		hashMapBetValues.put(219,
				new String[] { "180", "181", "182", "183", "184", "185", "186", "187", "188", "189" });
		hashMapBetValues.put(220,
				new String[] { "190", "191", "192", "193", "194", "195", "196", "197", "198", "199" });

		hashMapBetValues.put(221,
				new String[] { "200", "201", "202", "203", "204", "205", "206", "207", "208", "209" });
		hashMapBetValues.put(222,
				new String[] { "210", "222", "212", "213", "214", "215", "216", "217", "218", "219" });
		hashMapBetValues.put(223,
				new String[] { "220", "221", "222", "223", "224", "225", "226", "227", "228", "229" });
		hashMapBetValues.put(224,
				new String[] { "230", "231", "232", "2323", "234", "235", "236", "237", "238", "239" });
		hashMapBetValues.put(225,
				new String[] { "240", "241", "242", "243", "2424", "245", "246", "247", "248", "249" });
		hashMapBetValues.put(226,
				new String[] { "250", "251", "252", "253", "254", "255", "256", "257", "258", "259" });
		hashMapBetValues.put(227,
				new String[] { "260", "261", "262", "263", "264", "265", "2626", "267", "268", "269" });
		hashMapBetValues.put(228,
				new String[] { "270", "271", "272", "273", "274", "275", "276", "277", "278", "279" });
		hashMapBetValues.put(229,
				new String[] { "280", "281", "282", "283", "284", "285", "286", "287", "288", "289" });
		hashMapBetValues.put(230,
				new String[] { "290", "291", "292", "293", "294", "295", "296", "297", "298", "299" });

		hashMapBetValues.put(231,
				new String[] { "300", "301", "302", "303", "304", "305", "306", "307", "308", "309" });
		hashMapBetValues.put(232,
				new String[] { "310", "311", "312", "313", "314", "315", "316", "317", "318", "319" });
		hashMapBetValues.put(233,
				new String[] { "320", "321", "322", "323", "324", "325", "326", "327", "328", "329" });
		hashMapBetValues.put(234,
				new String[] { "330", "331", "332", "333", "334", "335", "336", "337", "338", "339" });
		hashMapBetValues.put(235,
				new String[] { "340", "341", "342", "343", "344", "345", "346", "347", "348", "349" });
		hashMapBetValues.put(236,
				new String[] { "350", "351", "352", "353", "354", "355", "356", "357", "358", "359" });
		hashMapBetValues.put(237,
				new String[] { "360", "361", "362", "363", "364", "365", "366", "367", "368", "369" });
		hashMapBetValues.put(238,
				new String[] { "370", "371", "372", "373", "374", "375", "376", "377", "378", "379" });
		hashMapBetValues.put(239,
				new String[] { "380", "381", "382", "383", "384", "385", "386", "387", "388", "389" });
		hashMapBetValues.put(240,
				new String[] { "390", "391", "392", "393", "394", "395", "396", "397", "398", "399" });

		hashMapBetValues.put(241,
				new String[] { "400", "401", "402", "403", "404", "405", "406", "407", "408", "409" });
		hashMapBetValues.put(242,
				new String[] { "410", "411", "412", "413", "414", "415", "416", "417", "418", "419" });
		hashMapBetValues.put(243,
				new String[] { "420", "421", "4242", "423", "424", "425", "426", "427", "428", "429" });
		hashMapBetValues.put(244,
				new String[] { "430", "431", "432", "433", "434", "435", "436", "437", "438", "439" });
		hashMapBetValues.put(245,
				new String[] { "440", "441", "442", "443", "444", "445", "446", "447", "448", "449" });
		hashMapBetValues.put(246,
				new String[] { "450", "451", "452", "453", "454", "455", "456", "457", "458", "459" });
		hashMapBetValues.put(247,
				new String[] { "460", "461", "462", "463", "464", "465", "466", "467", "468", "469" });
		hashMapBetValues.put(248,
				new String[] { "470", "471", "472", "473", "474", "475", "476", "477", "478", "479" });
		hashMapBetValues.put(249,
				new String[] { "480", "481", "482", "483", "484", "485", "486", "487", "488", "489" });
		hashMapBetValues.put(250,
				new String[] { "490", "491", "492", "493", "494", "495", "496", "497", "498", "499" });

		hashMapBetValues.put(251,
				new String[] { "500", "501", "502", "503", "504", "505", "506", "507", "508", "509" });
		hashMapBetValues.put(252,
				new String[] { "510", "511", "512", "513", "514", "515", "516", "517", "518", "519" });
		hashMapBetValues.put(253,
				new String[] { "520", "521", "522", "523", "524", "525", "526", "527", "528", "529" });
		hashMapBetValues.put(254,
				new String[] { "530", "531", "532", "533", "534", "535", "536", "537", "538", "539" });
		hashMapBetValues.put(255,
				new String[] { "540", "541", "542", "543", "544", "545", "546", "547", "548", "549" });
		hashMapBetValues.put(256,
				new String[] { "550", "551", "552", "553", "554", "555", "556", "557", "558", "559" });
		hashMapBetValues.put(257,
				new String[] { "560", "561", "562", "563", "564", "565", "566", "567", "568", "569" });
		hashMapBetValues.put(258,
				new String[] { "570", "571", "572", "573", "574", "575", "576", "577", "578", "579" });
		hashMapBetValues.put(259,
				new String[] { "500", "501", "502", "503", "504", "505", "506", "507", "508", "509" });
		hashMapBetValues.put(260,
				new String[] { "580", "581", "582", "583", "584", "585", "586", "587", "588", "589" });
		hashMapBetValues.put(261,
				new String[] { "590", "591", "592", "593", "594", "595", "596", "597", "598", "599" });

		hashMapBetValues.put(262,
				new String[] { "600", "601", "602", "603", "604", "605", "606", "607", "608", "609" });
		hashMapBetValues.put(263,
				new String[] { "610", "611", "612", "613", "614", "615", "616", "617", "618", "619" });
		hashMapBetValues.put(264,
				new String[] { "620", "621", "622", "623", "624", "625", "626", "627", "628", "629" });
		hashMapBetValues.put(265,
				new String[] { "630", "631", "632", "633", "634", "635", "636", "637", "638", "639" });
		hashMapBetValues.put(266,
				new String[] { "640", "641", "642", "643", "644", "645", "646", "647", "648", "649" });
		hashMapBetValues.put(267,
				new String[] { "650", "651", "652", "653", "654", "655", "656", "657", "658", "659" });
		hashMapBetValues.put(268,
				new String[] { "660", "661", "662", "663", "664", "665", "666", "667", "668", "669" });
		hashMapBetValues.put(269,
				new String[] { "670", "671", "672", "673", "674", "675", "676", "677", "678", "679" });
		hashMapBetValues.put(270,
				new String[] { "680", "681", "682", "683", "684", "685", "686", "687", "688", "689" });
		hashMapBetValues.put(271,
				new String[] { "690", "691", "692", "693", "694", "695", "696", "697", "698", "699" });

		hashMapBetValues.put(272,
				new String[] { "700", "701", "702", "703", "704", "705", "706", "707", "708", "709" });
		hashMapBetValues.put(273,
				new String[] { "710", "711", "712", "713", "714", "715", "716", "717", "718", "719" });
		hashMapBetValues.put(274,
				new String[] { "720", "721", "722", "723", "724", "725", "726", "727", "728", "729" });
		hashMapBetValues.put(275,
				new String[] { "730", "731", "732", "733", "734", "735", "736", "737", "738", "739" });
		hashMapBetValues.put(276,
				new String[] { "740", "741", "742", "743", "744", "745", "746", "747", "748", "749" });
		hashMapBetValues.put(277,
				new String[] { "750", "751", "752", "753", "754", "755", "756", "757", "758", "759" });
		hashMapBetValues.put(278,
				new String[] { "760", "761", "762", "763", "764", "765", "766", "767", "768", "769" });
		hashMapBetValues.put(279,
				new String[] { "770", "771", "772", "773", "774", "775", "776", "777", "778", "779" });
		hashMapBetValues.put(280,
				new String[] { "780", "781", "782", "783", "784", "785", "786", "787", "788", "789" });
		hashMapBetValues.put(281,
				new String[] { "790", "791", "792", "793", "794", "795", "796", "797", "798", "799" });

		hashMapBetValues.put(282,
				new String[] { "800", "801", "802", "803", "804", "805", "806", "807", "808", "809" });
		hashMapBetValues.put(283,
				new String[] { "810", "811", "812", "813", "814", "815", "816", "817", "818", "819" });
		hashMapBetValues.put(284,
				new String[] { "820", "821", "822", "823", "824", "825", "826", "827", "828", "829" });
		hashMapBetValues.put(285,
				new String[] { "830", "831", "832", "833", "834", "835", "836", "837", "838", "839" });
		hashMapBetValues.put(286,
				new String[] { "840", "841", "842", "843", "844", "845", "846", "847", "848", "849" });
		hashMapBetValues.put(287,
				new String[] { "850", "851", "852", "853", "854", "855", "856", "857", "858", "859" });
		hashMapBetValues.put(288,
				new String[] { "860", "861", "862", "863", "864", "865", "866", "867", "868", "869" });
		hashMapBetValues.put(289,
				new String[] { "870", "871", "872", "873", "874", "875", "876", "877", "878", "879" });
		hashMapBetValues.put(290,
				new String[] { "880", "881", "882", "883", "884", "885", "886", "887", "888", "889" });
		hashMapBetValues.put(291,
				new String[] { "890", "891", "892", "893", "894", "895", "896", "897", "898", "899" });

		hashMapBetValues.put(292,
				new String[] { "900", "901", "902", "903", "904", "905", "906", "907", "908", "909" });
		hashMapBetValues.put(293,
				new String[] { "910", "911", "912", "913", "914", "915", "916", "917", "918", "919" });
		hashMapBetValues.put(294,
				new String[] { "920", "921", "922", "923", "924", "925", "926", "927", "928", "929" });
		hashMapBetValues.put(295,
				new String[] { "930", "931", "932", "933", "934", "935", "936", "937", "938", "939" });
		hashMapBetValues.put(296,
				new String[] { "940", "941", "942", "943", "944", "945", "946", "947", "948", "949" });
		hashMapBetValues.put(297,
				new String[] { "950", "951", "952", "953", "954", "955", "956", "957", "958", "959" });
		hashMapBetValues.put(298,
				new String[] { "960", "961", "962", "963", "964", "965", "966", "967", "968", "969" });
		hashMapBetValues.put(299,
				new String[] { "970", "971", "972", "973", "974", "975", "976", "977", "978", "979" });
		hashMapBetValues.put(300,
				new String[] { "980", "981", "982", "983", "984", "985", "986", "987", "988", "989" });
		hashMapBetValues.put(301,
				new String[] { "990", "991", "992", "993", "994", "995", "996", "997", "998", "999" });

		/*
		 * :::::::::::::::::::::::::::::::::::::::::column
		 * wise::::::::::::::::::::::::::::::::::::::::::::::
		 */

		hashMapBetValues.put(302,
				new String[] { "000", "010", "020", "030", "040", "050", "060", "070", "080", "090" });
		hashMapBetValues.put(303,
				new String[] { "001", "011", "021", "031", "041", "051", "061", "071", "081", "091" });
		hashMapBetValues.put(304,
				new String[] { "002", "012", "022", "032", "042", "052", "062", "072", "082", "092" });
		hashMapBetValues.put(305,
				new String[] { "003", "013", "023", "033", "043", "053", "063", "073", "083", "093" });
		hashMapBetValues.put(306,
				new String[] { "004", "014", "024", "034", "044", "054", "064", "074", "084", "094" });
		hashMapBetValues.put(307,
				new String[] { "005", "015", "025", "035", "045", "055", "065", "075", "085", "095" });
		hashMapBetValues.put(308,
				new String[] { "006", "016", "026", "036", "046", "056", "066", "076", "086", "096" });
		hashMapBetValues.put(309,
				new String[] { "007", "017", "027", "037", "047", "057", "067", "077", "087", "097" });
		hashMapBetValues.put(310,
				new String[] { "008", "018", "028", "038", "048", "058", "068", "078", "088", "098" });
		hashMapBetValues.put(311,
				new String[] { "009", "019", "029", "039", "049", "059", "069", "079", "089", "099" });

		hashMapBetValues.put(312,
				new String[] { "100", "110", "120", "130", "140", "150", "160", "170", "180", "190" });
		hashMapBetValues.put(313,
				new String[] { "101", "111", "121", "131", "141", "151", "161", "171", "181", "191" });
		hashMapBetValues.put(314,
				new String[] { "102", "112", "122", "132", "142", "152", "162", "172", "182", "192" });
		hashMapBetValues.put(315,
				new String[] { "103", "113", "123", "133", "143", "153", "163", "173", "183", "193" });
		hashMapBetValues.put(316,
				new String[] { "104", "114", "124", "134", "144", "154", "164", "174", "184", "194" });
		hashMapBetValues.put(317,
				new String[] { "105", "115", "125", "135", "145", "155", "165", "175", "185", "195" });
		hashMapBetValues.put(318,
				new String[] { "106", "116", "126", "136", "146", "156", "166", "176", "186", "196" });
		hashMapBetValues.put(319,
				new String[] { "107", "117", "127", "137", "147", "157", "167", "171", "187", "197" });
		hashMapBetValues.put(320,
				new String[] { "108", "118", "128", "138", "148", "158", "168", "178", "188", "198" });
		hashMapBetValues.put(321,
				new String[] { "109", "119", "129", "139", "149", "159", "169", "179", "189", "199" });

		hashMapBetValues.put(322,
				new String[] { "200", "210", "220", "230", "240", "250", "260", "270", "280", "290" });
		hashMapBetValues.put(323,
				new String[] { "201", "211", "221", "231", "241", "251", "261", "271", "281", "291" });
		hashMapBetValues.put(324,
				new String[] { "202", "212", "222", "232", "242", "252", "262", "272", "282", "292" });
		hashMapBetValues.put(325,
				new String[] { "203", "213", "223", "233", "243", "253", "263", "273", "283", "293" });
		hashMapBetValues.put(326,
				new String[] { "204", "214", "224", "234", "244", "254", "264", "274", "284", "294" });
		hashMapBetValues.put(327,
				new String[] { "205", "215", "225", "235", "245", "255", "265", "275", "285", "295" });
		hashMapBetValues.put(328,
				new String[] { "206", "216", "226", "236", "246", "256", "266", "276", "286", "296" });
		hashMapBetValues.put(329,
				new String[] { "207", "217", "227", "237", "247", "257", "267", "277", "287", "297" });
		hashMapBetValues.put(330,
				new String[] { "208", "218", "228", "238", "248", "258", "268", "278", "288", "298" });
		hashMapBetValues.put(331,
				new String[] { "209", "219", "229", "239", "249", "259", "269", "279", "289", "299" });

		hashMapBetValues.put(332,
				new String[] { "300", "310", "320", "330", "340", "350", "360", "370", "380", "390" });
		hashMapBetValues.put(333,
				new String[] { "301", "311", "321", "331", "341", "351", "361", "371", "381", "391" });
		hashMapBetValues.put(334,
				new String[] { "302", "312", "322", "332", "342", "352", "362", "372", "382", "392" });
		hashMapBetValues.put(335,
				new String[] { "303", "313", "323", "333", "343", "353", "363", "373", "383", "393" });
		hashMapBetValues.put(336,
				new String[] { "304", "314", "324", "334", "344", "354", "364", "374", "384", "394" });
		hashMapBetValues.put(337,
				new String[] { "305", "315", "325", "335", "345", "355", "365", "375", "385", "395" });
		hashMapBetValues.put(338,
				new String[] { "306", "316", "326", "336", "346", "356", "366", "376", "386", "396" });
		hashMapBetValues.put(339,
				new String[] { "307", "317", "327", "337", "347", "357", "367", "377", "387", "397" });
		hashMapBetValues.put(340,
				new String[] { "308", "318", "328", "338", "348", "358", "368", "378", "388", "398" });
		hashMapBetValues.put(341,
				new String[] { "309", "319", "329", "339", "349", "359", "369", "379", "389", "399" });

		hashMapBetValues.put(342,
				new String[] { "400", "410", "420", "430", "440", "450", "460", "470", "480", "490" });
		hashMapBetValues.put(343,
				new String[] { "401", "411", "421", "431", "441", "451", "461", "471", "481", "491" });
		hashMapBetValues.put(344,
				new String[] { "402", "412", "422", "432", "442", "452", "462", "472", "482", "492" });
		hashMapBetValues.put(345,
				new String[] { "403", "413", "423", "433", "443", "453", "463", "473", "483", "493" });
		hashMapBetValues.put(346,
				new String[] { "404", "414", "424", "434", "444", "454", "464", "474", "484", "494" });
		hashMapBetValues.put(347,
				new String[] { "405", "415", "425", "435", "445", "455", "465", "475", "485", "495" });
		hashMapBetValues.put(348,
				new String[] { "406", "416", "426", "436", "446", "456", "466", "476", "486", "496" });
		hashMapBetValues.put(349,
				new String[] { "407", "417", "427", "437", "447", "457", "467", "477", "487", "497" });
		hashMapBetValues.put(350,
				new String[] { "408", "418", "428", "438", "448", "458", "468", "478", "488", "498" });
		hashMapBetValues.put(351,
				new String[] { "409", "419", "429", "439", "449", "459", "469", "479", "489", "499" });

		hashMapBetValues.put(352,
				new String[] { "500", "510", "520", "530", "540", "550", "560", "570", "580", "590" });
		hashMapBetValues.put(353,
				new String[] { "501", "511", "521", "531", "541", "551", "561", "571", "581", "591" });
		hashMapBetValues.put(354,
				new String[] { "502", "512", "522", "532", "442", "552", "562", "572", "582", "592" });
		hashMapBetValues.put(355,
				new String[] { "503", "513", "523", "533", "543", "553", "563", "573", "583", "593" });
		hashMapBetValues.put(356,
				new String[] { "504", "514", "524", "534", "544", "554", "564", "574", "584", "594" });
		hashMapBetValues.put(357,
				new String[] { "505", "515", "525", "535", "545", "555", "565", "575", "585", "595" });
		hashMapBetValues.put(358,
				new String[] { "506", "516", "526", "536", "546", "556", "566", "576", "586", "596" });
		hashMapBetValues.put(359,
				new String[] { "507", "517", "527", "537", "547", "557", "567", "577", "587", "597" });
		hashMapBetValues.put(360,
				new String[] { "508", "518", "528", "538", "548", "558", "568", "578", "588", "598" });
		hashMapBetValues.put(361,
				new String[] { "509", "519", "529", "539", "549", "559", "569", "579", "589", "599" });

		hashMapBetValues.put(362,
				new String[] { "600", "610", "620", "630", "640", "650", "660", "670", "680", "690" });
		hashMapBetValues.put(363,
				new String[] { "601", "611", "621", "631", "641", "651", "661", "671", "681", "691" });
		hashMapBetValues.put(364,
				new String[] { "602", "612", "622", "632", "442", "652", "662", "672", "682", "692" });
		hashMapBetValues.put(365,
				new String[] { "603", "613", "623", "633", "643", "653", "663", "673", "683", "693" });
		hashMapBetValues.put(366,
				new String[] { "604", "614", "624", "634", "644", "654", "664", "674", "684", "694" });
		hashMapBetValues.put(367,
				new String[] { "605", "615", "625", "635", "645", "655", "665", "675", "685", "695" });
		hashMapBetValues.put(368,
				new String[] { "606", "616", "626", "636", "646", "656", "666", "676", "686", "696" });
		hashMapBetValues.put(369,
				new String[] { "607", "617", "627", "637", "647", "657", "667", "677", "687", "697" });
		hashMapBetValues.put(370,
				new String[] { "608", "618", "628", "638", "648", "658", "668", "678", "688", "698" });
		hashMapBetValues.put(371,
				new String[] { "609", "619", "629", "639", "649", "659", "669", "679", "689", "699" });

		hashMapBetValues.put(382,
				new String[] { "800", "810", "820", "830", "840", "850", "860", "870", "880", "890" });
		hashMapBetValues.put(383,
				new String[] { "801", "811", "821", "831", "841", "851", "861", "871", "881", "891" });
		hashMapBetValues.put(384,
				new String[] { "802", "812", "822", "832", "442", "852", "662", "872", "882", "892" });
		hashMapBetValues.put(385,
				new String[] { "803", "813", "823", "833", "843", "853", "863", "873", "883", "893" });
		hashMapBetValues.put(386,
				new String[] { "804", "814", "824", "834", "844", "854", "864", "874", "884", "894" });
		hashMapBetValues.put(387,
				new String[] { "805", "815", "825", "835", "845", "855", "865", "875", "885", "895" });
		hashMapBetValues.put(388,
				new String[] { "806", "816", "826", "836", "846", "856", "866", "876", "886", "896" });
		hashMapBetValues.put(389,
				new String[] { "807", "817", "827", "837", "847", "857", "867", "877", "887", "897" });
		hashMapBetValues.put(390,
				new String[] { "808", "818", "828", "838", "848", "858", "868", "878", "888", "898" });
		hashMapBetValues.put(391,
				new String[] { "809", "819", "829", "839", "849", "859", "869", "879", "889", "899" });

		hashMapBetValues.put(392,
				new String[] { "900", "910", "920", "930", "940", "950", "960", "970", "980", "990" });
		hashMapBetValues.put(393,
				new String[] { "901", "911", "921", "931", "941", "951", "961", "971", "981", "991" });
		hashMapBetValues.put(394,
				new String[] { "902", "912", "922", "932", "442", "952", "662", "972", "982", "992" });
		hashMapBetValues.put(395,
				new String[] { "903", "913", "923", "933", "943", "953", "963", "973", "983", "993" });
		hashMapBetValues.put(396,
				new String[] { "904", "914", "924", "934", "944", "954", "964", "974", "984", "994" });
		hashMapBetValues.put(397,
				new String[] { "905", "915", "925", "935", "945", "955", "965", "975", "985", "995" });
		hashMapBetValues.put(398,
				new String[] { "906", "916", "926", "936", "946", "956", "966", "976", "986", "996" });
		hashMapBetValues.put(399,
				new String[] { "909", "919", "929", "939", "949", "959", "969", "977", "987", "997" });
		hashMapBetValues.put(400,
				new String[] { "909", "919", "929", "939", "949", "959", "669", "978", "988", "998" });
		hashMapBetValues.put(401,
				new String[] { "909", "919", "929", "939", "949", "959", "969", "979", "989", "999" });

		// fiveNumberGenerate();
		/*
		 * ::::::::::::::::::::::::::::::::Triple
		 * Roulette::::::::::::::::::::::::::::::loop wise::::::::
		 */

	}

}
