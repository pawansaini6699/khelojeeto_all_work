package com.latestfunroulette.common;

import com.latestfunroulette.TripleRoulette.cache.beans.SessionBean;
import com.latestfunroulette.extension.GameMainExtension;

public class BetNumbersTripleRoulette {

	static double winAmountFactor = 90;
	static double betSplitFactor = 0;
	static String command;

	static double winAmountFactorsingle = 9;
	static double betSplitFactorsingle = 0;

	static double winAmountFactorTriple = 900;
	static double betSplitFactorTriple = 0;

	public static void TripleRoulette(String userId, String sessionId, double coins, int betnumbers, String tabletype,
			int gameid) {

		if (tabletype.equalsIgnoreCase("SINGLE")) {

			double winAmount = coins * winAmountFactorsingle;
			Utils.Logger(GameMainExtension.extension,
					"BetNumbersTripleRoulette:::::::::::::::: winAmount:::::::::::::::::::::::::::::" + winAmount);

			SessionBean tempGameSessionBean = GameMainExtension.gameCacheTripleRoulette.getGameSessionBySessionId()
					.getValueByKey(sessionId);

			if (tempGameSessionBean == null) {

				Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    ");

			} else {

				Utils.Logger(GameMainExtension.extension,    "    BetNumbersTripleRoulette   ::     tempGameSessionBean    :  is not null::::::::::    "
						+ tempGameSessionBean.toString() + "tempGameSessionBean"
						+ tempGameSessionBean.getTotalBetAmount());

				tempGameSessionBean.addUserBet(userId, sessionId, coins, String.valueOf(betnumbers), winAmount,
						tabletype, gameid);

			}
		}

		else if (tabletype.equalsIgnoreCase("DOUBLE")) {

			totalbetnumbers(betnumbers, coins, sessionId, userId, tabletype, gameid);

		} else {

			String[] dayString = BetNumbersConstant.getValuesByKey(betnumbers);
			if (dayString != null) {

				double winAmount = coins * winAmountFactorTriple;

				Utils.Logger(GameMainExtension.extension,"BetNumbers::::::::::::::: betno::::::::::: " + dayString.toString());

				SessionBean tempGameSessionBean = GameMainExtension.gameCacheTripleRoulette.getGameSessionBySessionId()
						.getValueByKey(sessionId);

				for (int i = 0; i < dayString.length; i++) {

					Utils.Logger(GameMainExtension.extension,"dayString:::::::::::::" + dayString[i]);

					Utils.Logger(GameMainExtension.extension,dayString[i]);
					Utils.Logger(GameMainExtension.extension,sessionId);

					if (tempGameSessionBean == null) {

						Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    ");

					} else {

						tempGameSessionBean.addUserBet(userId, sessionId, coins, String.valueOf(dayString[i]),
								winAmount, tabletype, gameid);
					}

				}

			}

			else {

				double winAmount = coins * winAmountFactor;
				Utils.Logger(GameMainExtension.extension,
						"BetNumbersTripleRoulette:::::::::::::::: winAmount:::::::::::::::::::::::::::::" + winAmount);

				SessionBean tempGameSessionBean = GameMainExtension.gameCacheTripleRoulette.getGameSessionBySessionId()
						.getValueByKey(sessionId);

				if (tempGameSessionBean == null) {

					Utils.Logger(GameMainExtension.extension,"BetNumbersTripleRoulette:::::::tempGameSessionBean::::is null" + ":::::::    ");

				}

				else {

					Utils.Logger(GameMainExtension.extension,
							"BetNumbers:::::::Triple chance:::::::::::::::tempGameSessionBean: is not null::::::::::    "
									+ tempGameSessionBean.toString() + "tempGameSessionBean"
									+ tempGameSessionBean.getTotalBetAmount());

					tempGameSessionBean.addUserBet(userId, sessionId, coins, String.valueOf(betnumbers), winAmount,
							tabletype, gameid);

				}
			}
		}

	}

	public static void totalbetnumbers(int betNumbers, double coins, String sessionId, String userId, String tableType,
			int gameId) {

		Utils.Logger(GameMainExtension.extension,"totalbetnumbers::::::::::::::::::::::::::::::::betNumbers+++" + betNumbers);

		String[] dayString = BetNumbersConstant.getValuesByKey(betNumbers);
		if (dayString != null) {
			double winAmount = coins * winAmountFactor;

			Utils.Logger(GameMainExtension.extension,"BetNumbersTripleRoulette::::::::::::::: betno::::::::::: " + dayString.toString());
			SessionBean tempGameSessionBean = GameMainExtension.gameCacheTripleRoulette.getGameSessionBySessionId()
					.getValueByKey(sessionId);

			for (int i = 0; i < dayString.length; i++) {

				Utils.Logger(GameMainExtension.extension,"dayString:::::::::::::" + dayString[i]);

				Utils.Logger(GameMainExtension.extension,dayString[i]);
				Utils.Logger(GameMainExtension.extension,sessionId);

				if (tempGameSessionBean == null) {

					Utils.Logger(GameMainExtension.extension,"BetNumbersTripleRoulette:::::::tempGameSessionBean::::is null" + ":::::::    ");

				} else {

					tempGameSessionBean.addUserBet(userId, sessionId, coins, String.valueOf(dayString[i]), winAmount,
							tableType, gameId);
				}

			}

		} else {
			double winAmount = coins * winAmountFactor;
			Utils.Logger(GameMainExtension.extension,
					"BetNumbersTripleRoulette:::::::::::::::: winAmount:::::::::::::::::::::::::::::" + winAmount);

			SessionBean tempGameSessionBean = GameMainExtension.gameCacheTripleRoulette.getGameSessionBySessionId()
					.getValueByKey(sessionId);

			if (tempGameSessionBean == null) {

				Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    ");

			} else {

				Utils.Logger(GameMainExtension.extension,
						"BetNumbersTripleRoulette:::::::::::::::tempGameSessionBean: is not null::::::::::    "
								+ tempGameSessionBean.toString() + "tempGameSessionBean"
								+ tempGameSessionBean.getTotalBetAmount());

				tempGameSessionBean.addUserBet(userId, sessionId, coins, String.valueOf(betNumbers), winAmount,
						tableType, gameId);

			}

		}

	}

}
