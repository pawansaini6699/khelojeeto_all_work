package com.latestfunroulette.common;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;

public class RejoinManager {

	public void rejoin(User pUser, Player tempPlayer) {
		new Thread() {
			@Override
			public void run() {
				print("RejoinManager ::: Rejoin ::: Player Name :: " + pUser.getName());

				DBManager.getSessionId(new CallBack() {

					@Override
					public void call(Object... call) {
					//	String sessionid=(String)call[0];
						
					//	GameMainExtension.cache

					}
				});

			}

		}.start();
	}

	private void print(String msg) {
		Utils.Logger(GameMainExtension.extension, "RejoinManager :::: " + msg);
	}
}