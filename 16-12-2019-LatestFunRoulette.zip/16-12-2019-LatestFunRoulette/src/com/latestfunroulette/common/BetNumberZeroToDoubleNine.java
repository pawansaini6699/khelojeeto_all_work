package com.latestfunroulette.common;

import com.latestfunroulette.dubliRoulette.cache.beans.SessionBean;
import com.latestfunroulette.extension.GameMainExtension;

public class BetNumberZeroToDoubleNine {

	static double winAmountFactor = 90;
	static double betSplitFactor = 0;
	static String command;

	static double winAmountFactorsingle = 9;
	static double betSplitFactorsingle = 0;

	public static void doubleRoulette(String userId, String sessionId, double coins, int betnumbers, String tabletype,
			int gameid) {

		if (tabletype.equalsIgnoreCase("SINGLE")) {

			double winAmount = coins * winAmountFactorsingle;
			Utils.Logger(GameMainExtension.extension,
					"BetNumbersZeroToNine:::::::::::::::: winAmount:::::::::::::::::::::::::::::" + winAmount);

			SessionBean tempGameSessionBean = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
					.getValueByKey(sessionId);

			if (tempGameSessionBean == null) {

				Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    ");

			} else {

				Utils.Logger(GameMainExtension.extension,"BetNumbers:::::SINGLE CHANCE::tempGameSessionBean: is not null::::::::::    "
						+ tempGameSessionBean.toString() + "tempGameSessionBean"
						+ tempGameSessionBean.getTotalBetAmount());

				tempGameSessionBean.addUserBet(userId, sessionId, coins, String.valueOf(betnumbers), winAmount,
						tabletype, gameid);

			}
		}

		else {
			totalbetnumbers(betnumbers, coins, sessionId, userId, tabletype, gameid);
		}

	}

	public static void totalbetnumbers(int betNumbers, double coins, String sessionId, String userId, String tableType,
			int gameId) {

		/*
		 * Utils.Logger(GameMainExtension.extension,
		 * "totalbetnumbers::::::::::::::::::::::::::::::::betNumbers+++" + betNumbers);
		 * if (betNumbers > 100) { switch (betNumbers) { case 101: dayString = new
		 * String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" }; command =
		 * "firstrow"; winAmountFactor = 10; betSplitFactor = 10; break; case 102:
		 * dayString = new String[] { "10", "11", "12", "13", "14", "15", "16", "17",
		 * "18", "19" }; command = "secondrow"; winAmountFactor = 10; betSplitFactor =
		 * 10; break;
		 * 
		 * case 103: dayString = new String[] { "20", "21", "22", "23", "24", "25",
		 * "26", "27", "28", "29" }; command = "thirdrow"; winAmountFactor = 10;
		 * betSplitFactor = 10; break;
		 * 
		 * case 104: dayString = new String[] { "30", "31", "32", "33", "34", "35",
		 * "36", "37", "38", "39" }; command = "fourrow"; winAmountFactor = 10;
		 * betSplitFactor = 10; break;
		 * 
		 * case 105: dayString = new String[] { "40", "41", "42", "43", "44", "45",
		 * "46", "47", "48", "49" }; command = "fiverow"; winAmountFactor = 10;
		 * betSplitFactor = 10; break;
		 * 
		 * case 106: dayString = new String[] { "50", "51", "52", "53", "54", "55",
		 * "56", "57", "58", "59" }; command = "sixrow"; winAmountFactor = 10;
		 * betSplitFactor = 10; break;
		 * 
		 * case 107: dayString = new String[] { "60", "61", "62", "63", "64", "65",
		 * "66", "67", "68", "69" }; command = "sevenrow"; winAmountFactor = 10;
		 * betSplitFactor = 10; break;
		 * 
		 * case 108: dayString = new String[] { "70", "71", "72", "73", "74", "75",
		 * "76", "77", "78", "79" }; command = "eightrow"; winAmountFactor = 10;
		 * betSplitFactor = 10; break;
		 * 
		 * case 109: dayString = new String[] { "80", "81", "82", "83", "84", "85",
		 * "86", "87", "88", "89" }; command = "ninerow"; winAmountFactor = 10;
		 * betSplitFactor = 10; break;
		 * 
		 * case 110: dayString = new String[] { "90", "91", "92", "93", "94", "95",
		 * "96", "97", "98", "99" }; command = "tenrow"; winAmountFactor = 10;
		 * betSplitFactor = 10; break;
		 * 
		 * case 111: dayString = new String[] { "0", "10", "20", "30", "40", "50", "60",
		 * "70", "80", "90" }; command = "firstcolumn"; winAmountFactor = 10;
		 * betSplitFactor = 10; break;
		 * 
		 * case 112: dayString = new String[] { "1", "11", "21", "31", "41", "51", "61",
		 * "71", "81", "91" }; command = "secondcolumn"; winAmountFactor = 10;
		 * betSplitFactor = 10; break; case 113: dayString = new String[] { "2", "12",
		 * "22", "32", "42", "52", "62", "72", "82", "92" }; command = "thirdcolumn";
		 * winAmountFactor = 10; betSplitFactor = 10; break; case 114: dayString = new
		 * String[] { "3", "13", "23", "33", "43", "53", "63", "73", "83", "93" };
		 * command = "fourthcolumn"; winAmountFactor = 10; betSplitFactor = 10; break;
		 * case 115: dayString = new String[] { "4", "14", "24", "34", "44", "54", "64",
		 * "74", "84", "94" }; command = "fifthcolumn"; winAmountFactor = 10;
		 * betSplitFactor = 10; break; case 116: dayString = new String[] { "5", "15",
		 * "25", "35", "45", "55", "65", "75", "85", "95" }; command = "sixcolumn";
		 * winAmountFactor = 10; betSplitFactor = 10; break; case 117: dayString = new
		 * String[] { "6", "16", "26", "36", "46", "56", "66", "76", "86", "96" };
		 * command = "sevencolumn"; winAmountFactor = 10; betSplitFactor = 10; break;
		 * case 118: dayString = new String[] { "7", "17", "27", "37", "47", "57", "67",
		 * "77", "87", "97" }; command = "eightcolumn"; winAmountFactor = 10;
		 * betSplitFactor = 10; break; case 119: dayString = new String[] { "8", "18",
		 * "28", "38", "48", "58", "68", "78", "88", "98" }; command = "ninecolumn";
		 * winAmountFactor = 10; betSplitFactor = 10; break;
		 * 
		 * case 120: dayString = new String[] { "9", "19", "29", "39", "49", "59", "69",
		 * "79", "89", "99" }; command = "tenclolumn"; winAmountFactor = 10;
		 * betSplitFactor = 10; break;
		 * 
		 * } }
		 */

		String[] dayString = BetNumbersConstant.getValuesByKey(betNumbers);
		if (dayString != null) {

			double winAmount = coins * winAmountFactor;

			Utils.Logger(GameMainExtension.extension,"BetNumbers::::::::::::::: betno::::::::::: " + dayString.toString());
			SessionBean tempGameSessionBean = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
					.getValueByKey(sessionId);

			for (int i = 0; i < dayString.length; i++) {

				Utils.Logger(GameMainExtension.extension,"dayString:::::::::::::" + dayString[i]);

				Utils.Logger(GameMainExtension.extension,dayString[i]);
				Utils.Logger(GameMainExtension.extension,sessionId);

				if (tempGameSessionBean == null) {

					Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    ");

				} else {

					tempGameSessionBean.addUserBet(userId, sessionId, coins, String.valueOf(dayString[i]), winAmount,
							tableType, gameId);
				}

			}

		} else {
			double winAmount = coins * winAmountFactor;
			Utils.Logger(GameMainExtension.extension,
					"BetNumbersZeroToNine:::::::::::::::: winAmount:::::::::::::::::::::::::::::" + winAmount);

			SessionBean tempGameSessionBean = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
					.getValueByKey(sessionId);

			if (tempGameSessionBean == null) {

				Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    ");

			} else {

				Utils.Logger(GameMainExtension.extension,
						"BetNumbers:::::::Double CHANCE:::::::::::::::tempGameSessionBean: is not null::::::::::    "
								+ tempGameSessionBean.toString() + "tempGameSessionBean"
								+ tempGameSessionBean.getTotalBetAmount());

				tempGameSessionBean.addUserBet(userId, sessionId, coins, String.valueOf(betNumbers), winAmount,
						tableType, gameId);

			}

		}

	}

}
