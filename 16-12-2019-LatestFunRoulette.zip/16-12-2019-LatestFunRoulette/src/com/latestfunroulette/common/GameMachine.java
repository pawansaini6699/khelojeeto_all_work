package com.latestfunroulette.common;

import java.io.Serializable;

import com.latestfunroulette.extension.GameMainExtension;

public class GameMachine implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int betplaceamountstate;
	private int gameresultwaitingstate;
	private int resultstate;
	private String description;
	private int Status;
	private int TotalGameTime;

	public int getBetplaceamountstate() {
		Utils.Logger(GameMainExtension.extension,"zerotonine:::::::::::::::::::::"+betplaceamountstate);
		return betplaceamountstate;
	}

	public void setBetplaceamountstate(int betplaceamountstate) {
		this.betplaceamountstate = betplaceamountstate;
	}

	public int getGameresultwaitingstate() {
		return gameresultwaitingstate;
	}

	public void setGameresultwaitingstate(int gameresultwaitingstate) {
		this.gameresultwaitingstate = gameresultwaitingstate;
	}

	public int getResultstate() {
		return resultstate;
	}

	public void setResultstate(int resultstate) {
		this.resultstate = resultstate;
	}

	/*
	 * public String getRoomName() { return RoomName; } public void
	 * setRoomName(String roomName) { RoomName = roomName; }
	 */

	public int getStatus() {
		return Status;
	}

	public void setStatus(int status) {
		this.Status = status;
	}

	public int getTotalGameTime() {
		return TotalGameTime;
	}

	public void setTotalGameTime(int TotalGameTime) {
		this.TotalGameTime = TotalGameTime;
	}

	@Override
	public String toString() {
		return "GameMachine [betplaceamountstate=" + betplaceamountstate + ", gameresultwaitingstate="
				+ gameresultwaitingstate + ", resultstate=" + resultstate + ", description=" + description + ", Status="
				+ Status + ", TotalGameTime=" + TotalGameTime + "]";
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
