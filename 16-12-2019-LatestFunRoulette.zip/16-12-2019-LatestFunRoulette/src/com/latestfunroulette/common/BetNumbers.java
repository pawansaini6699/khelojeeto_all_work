package com.latestfunroulette.common;

import com.latestfunroulette.cache.beans.SessionBean;
import com.latestfunroulette.extension.GameMainExtension;

public class BetNumbers {

	static int winAmountFactor = 0;
	static double betSplitFactor = 0;
	static String command;

	/*
	 * public static void main(String args[]) {
	 * 
	 * splitBetNumbers("gk00300009", "1234", 102, 130, 1);
	 * 
	 * }
	 */

	@SuppressWarnings("null")
	public static void splitBetNumbers(String userId, String sessionId, int coins, int betnumbers, int gameid) {
		String[] dayString = {};

		switch (betnumbers) {
		case 1:
			dayString = new String[] { "0", "1" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 2:
			dayString = new String[] { "0", "2" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 3:
			dayString = new String[] { "0", "3" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 4:
			dayString = new String[] { "1", "2" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 5:
			dayString = new String[] { "2", "3" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 6:
			dayString = new String[] { "4", "5" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 7:
			dayString = new String[] { "5", "6" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 8:
			dayString = new String[] { "7", "8" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 9:
			dayString = new String[] { "8", "9" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 10:
			dayString = new String[] { "10", "11" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 11:
			dayString = new String[] { "11", "12" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 12:
			dayString = new String[] { "13", " 14" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 13:
			dayString = new String[] { " 14", " 15" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 14:
			dayString = new String[] { "16", "17" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 15:
			dayString = new String[] { "17", " 18" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 16:
			dayString = new String[] { "19", " 20" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 17:
			dayString = new String[] { "20", " 21 " };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 18:
			dayString = new String[] { " 22", "23 " };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 19:
			dayString = new String[] { " 23", " 24" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 20:
			dayString = new String[] { "25", "26" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 21:
			dayString = new String[] { "26", " 27 " };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 22:
			dayString = new String[] { " 28", " 29" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 23:
			dayString = new String[] { "29", " 30 " };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 24:
			dayString = new String[] { "31", " 32" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 25:
			dayString = new String[] { " 32", "33" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 26:
			dayString = new String[] { " 34", "35" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 27:
			dayString = new String[] { "35", "36 " };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 28:
			dayString = new String[] { "1", "4" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 29:
			dayString = new String[] { "2", "5" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 30:
			dayString = new String[] { "3", "6" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 31:
			dayString = new String[] { "4", "7" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 32:
			dayString = new String[] { "5", "8" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 33:
			dayString = new String[] { "6", "9" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 34:
			dayString = new String[] { "7", "10" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 35:
			dayString = new String[] { "8", "11" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 36:
			dayString = new String[] { "9", "12" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 37:
			dayString = new String[] { "10", "13" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 38:
			dayString = new String[] { "11", "14" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 39:
			dayString = new String[] { "12", "15" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 40:
			dayString = new String[] { "13", "16" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 41:
			dayString = new String[] { "14", "17" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 42:
			dayString = new String[] { "15", "18" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 43:
			dayString = new String[] { "16", "19" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 44:
			dayString = new String[] { "17", "20" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 45:
			dayString = new String[] { "18", "21" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 46:
			dayString = new String[] { "19", "22" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 47:
			dayString = new String[] { "20", "23" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 48:
			dayString = new String[] { "21", "24" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 49:
			dayString = new String[] { "22", "25" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 50:
			dayString = new String[] { "23", "26" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 51:
			dayString = new String[] { "24", "27" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 52:
			dayString = new String[] { "25", "28" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 53:
			dayString = new String[] { "26", "29" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 54:
			dayString = new String[] { "27", "30" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 55:
			dayString = new String[] { "28", "31" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 56:
			dayString = new String[] { "29", "32" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 57:
			dayString = new String[] { "30", "33" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 58:
			dayString = new String[] { "31", "34" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 59:
			dayString = new String[] { "32", "35" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 60:
			dayString = new String[] { "00", "3" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 61:
			dayString = new String[] { "00", "2" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;
		case 62:
			dayString = new String[] { "00", "3", "2" };
			command = "STREET";
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 2;
			break;

		case 63:
			dayString = new String[] { "00", "0", "2" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 2;
			break;

		case 64:
			dayString = new String[] { "0", "00" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 65:
			dayString = new String[] { "33", "36" };
			command = "SPLIT";
			winAmountFactor = 18;
			betSplitFactor = 2;
			break;

		case 66:
			dayString = new String[] { "0", "1", "2" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 67:
			dayString = new String[] { "0", "2", "3" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;

		case 68:
			dayString = new String[] { "1", "2", "3" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 69:
			dayString = new String[] { "4", "5", "6" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 70:
			dayString = new String[] { "7", "8", "9" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 71:
			dayString = new String[] { "10", "11", "12" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 72:
			dayString = new String[] { "13", "14", "15" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 73:
			dayString = new String[] { "16", "17", "18" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 74:
			dayString = new String[] { "19", "20", "21" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 75:
			dayString = new String[] { "22", "23", "24" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 76:
			dayString = new String[] { "25", "26", "27" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 77:
			dayString = new String[] { "28", "29", "30" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;
		case 78:
			dayString = new String[] { "31", "32", "33" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;

		case 79:
			dayString = new String[] { "34", "35", "36" };
			command = "STREET";
			winAmountFactor = 12;
			betSplitFactor = 3;
			break;

		case 80:
			dayString = new String[] { "1", "2", "4", "5" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 81:
			dayString = new String[] { "2", "3", "5", "6" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 82:
			dayString = new String[] { "4", "5", "7", "8" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 83:
			dayString = new String[] { "5", "6", "8", "9" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 84:
			dayString = new String[] { "7", "8", "10", "11" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 85:
			dayString = new String[] { "8", "9", "11", "12" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 86:
			dayString = new String[] { "10", "11", "13", "14" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 87:
			dayString = new String[] { "11", "12", "14", "15" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 88:
			dayString = new String[] { "13", "14", "16", "17" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 89:
			dayString = new String[] { "14", "15", "17", "18" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 90:
			dayString = new String[] { "16", "17", "19", "20" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 91:
			dayString = new String[] { "17", "18", "20", "21" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 92:
			dayString = new String[] { "19", "20", "22", "23" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 93:
			dayString = new String[] { "20", "21", "23", "24" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 94:
			dayString = new String[] { "22", "23", "25", "26" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 95:
			dayString = new String[] { "23", "24", "26", "27" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 96:
			dayString = new String[] { "25", "26", "28", "29" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 97:
			dayString = new String[] { "26", "27", "29", "30" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 98:
			dayString = new String[] { "28", "29", "31", "32" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 99:
			dayString = new String[] { "29", "30", "32", "33" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 100:
			dayString = new String[] { "31", "32", "34", "35" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 101:
			dayString = new String[] { "32", "33", "35", "36" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;
		case 102:
			dayString = new String[] { "1", "2", "3", "4", "5", "6" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;
			break;
		case 103:
			dayString = new String[] { "4", "5", "6", "7", "8", "9" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;
			break;
		case 104:
			dayString = new String[] { "7", "8", "9", "10", "11", "12" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;
			break;
		case 105:
			dayString = new String[] { "10", "11", "12", "13", "14", "15" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;

			break;
		case 106:
			dayString = new String[] { "13", "14", "15", "16", "17", "18" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;
			break;
		case 107:
			dayString = new String[] { "16", "17", "18", "19", "20", "21" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;
			break;
		case 108:
			dayString = new String[] { "19", "20", "21", "22", "23", "24" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;
			break;
		case 109:
			dayString = new String[] { "22", "23", "24", "25", "26", "27" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;
			break;

		case 110:
			dayString = new String[] { "25", "26", "27", "28", "29", "30" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;
			break;
		case 111:
			dayString = new String[] { "28", "29", "30", "31", "32", "33" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;
			break;
		case 112:
			dayString = new String[] { "31", "32", "33", "34", "35", "36" };
			command = "GROUP_6";
			winAmountFactor = 6;
			betSplitFactor = 6;
			break;
		case 113:
			dayString = new String[] { "2", "4", "6", "8", "10", "12", "14", "16", "18", "20", "22", "24", "26", "28",
					"30", "32", "34", "36" };
			command = "EVEN_NUMBER";
			winAmountFactor = 2;
			betSplitFactor = 18;
			break;
		case 114:
			dayString = new String[] { "1", "3", "5", "7", "9", "11", "13", "15", "17", "19", "21", "23", "25", "27",
					"29", "31", "33", "35" };
			command = "ODD_NUMBER";
			winAmountFactor = 2;
			betSplitFactor = 18;
			break;
		case 115:
			dayString = new String[] { "2", "4", "6", "8", "10", "11", "13", "15", "17", "20", "22", "24", "26", "28",
					"29", "31", "33", "35" };
			command = "BLACK_NUMBER";
			winAmountFactor = 2;
			betSplitFactor = 18;
			break;
		case 116:
			dayString = new String[] { "1", "3", "5", "7", "9", "12", "14", "16", "18", "19", "21", "23", "25", "27",
					"30", "32", "36", "34" };
			command = "RED_NUMBER";
			winAmountFactor = 2;
			betSplitFactor = 18;
			break;
		case 117:
			dayString = new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" };
			command = "FIRST_12";
			winAmountFactor = 3;
			betSplitFactor = 12;
			break;
		case 118:
			dayString = new String[] { "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24" };
			command = "SECOND_12";
			winAmountFactor = 3;
			betSplitFactor = 12;
			break;
		case 119:
			dayString = new String[] { "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36" };
			command = "THIRD_12";
			winAmountFactor = 3;
			betSplitFactor = 12;
			break;
		case 120:
			dayString = new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15",
					"16", "17", "18" };
			command = "FIRST_18";
			winAmountFactor = 2;
			betSplitFactor = 18;
			break;
		case 121:
			dayString = new String[] { "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31",
					"32", "33", "34", "35", "36" };
			command = "SECOND_18";
			winAmountFactor = 2;
			betSplitFactor = 18;
			break;
		case 122:
			dayString = new String[] { "3", "6", "9", "12", "15", "18", "21", "24", "27", "30", "33", "36" };
			command = "THIRD_ROW";
			winAmountFactor = 3;
			betSplitFactor = 12;
			break;
		case 123:
			dayString = new String[] { "2", "5", "8", "11", "14", "17", "20", "23", "26", "29", "32", "35" };
			command = "SECOND_ROW";
			winAmountFactor = 3;
			betSplitFactor = 12;
			break;
		case 124:
			dayString = new String[] { "1", "4", "7", "10", "13", "16", "19", "22", "25", "28", "31", "34" };
			command = "FIRST_ROW";
			winAmountFactor = 3;
			betSplitFactor = 12;
			break;

		case 125:
			dayString = new String[] { "00" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;

		case 126:
			dayString = new String[] { "0" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 127:
			dayString = new String[] { "1" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 128:
			dayString = new String[] { "2" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 129:
			dayString = new String[] { "3" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 130:
			dayString = new String[] { "4" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 131:
			dayString = new String[] { "5" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 132:
			dayString = new String[] { "6" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 133:
			dayString = new String[] { "7" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 134:
			dayString = new String[] { "8" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 135:
			dayString = new String[] { "9" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 136:
			dayString = new String[] { "10" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 137:
			dayString = new String[] { "11" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 138:
			dayString = new String[] { "12" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;

		case 139:
			dayString = new String[] { "13" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 140:
			dayString = new String[] { "14" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 141:
			dayString = new String[] { "15" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 142:
			dayString = new String[] { "16" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 143:
			dayString = new String[] { "17" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 144:
			dayString = new String[] { "18" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 145:
			dayString = new String[] { "19" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 146:
			dayString = new String[] { "20" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 147:
			dayString = new String[] { "21" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 148:
			dayString = new String[] { "22" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 149:
			dayString = new String[] { "23" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 150:
			dayString = new String[] { "24" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 151:
			dayString = new String[] { "25" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 152:
			dayString = new String[] { "26" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;

		case 153:
			dayString = new String[] { "27" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 154:
			dayString = new String[] { "28" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 155:
			dayString = new String[] { "29" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 156:
			dayString = new String[] { "30" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 157:
			dayString = new String[] { "31" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 158:
			dayString = new String[] { "32" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 159:
			dayString = new String[] { "33" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 160:
			dayString = new String[] { "34" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 161:
			dayString = new String[] { "35" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 162:
			dayString = new String[] { "36" };
			command = "STRAIGHT UP";
			winAmountFactor = 36;
			betSplitFactor = 1;
			break;
		case 163:
			dayString = new String[] { "00", "0", "2", "3" };
			command = "CORNER";
			winAmountFactor = 9;
			betSplitFactor = 4;
			break;

		default:

			// dayString = new int[] { 0 };

			break;
		}

		int winAmount = (int) coins * winAmountFactor;

		// BigDecimal tempcoins = new BigDecimal(coins);
		// BigDecimal tempBetSplictFactor = new BigDecimal(betSplitFactor);

		// double splitAmount =tempcoins.divide(tempBetSplictFactor).doubleValue();

		double splitAmount = (((double) coins) / betSplitFactor);

		StringBuilder tempSelectedNumbers = new StringBuilder();
		Utils.Logger(GameMainExtension.extension,"BetNumbers::::::::::::::::winAmount" + winAmount + "::::::::::::::splitamount:::::::::::"
				+ splitAmount + " betno::::::::::: " + dayString.toString());

		for (int i = 0; i < dayString.length; i++) {

			Utils.Logger(GameMainExtension.extension,"dayString:::::::::::::" + dayString[i]);
			if (dayString[i].equalsIgnoreCase("00")) {

				tempSelectedNumbers.append("00" + ",");
				tempSelectedNumbers.setLength(tempSelectedNumbers.length());
				Utils.Logger(GameMainExtension.extension,"tempSelectedNumbers:::::::::::" + tempSelectedNumbers.toString());
			} else {

				Utils.Logger(GameMainExtension.extension,dayString[i]);

				if (i == dayString.length - 1) {
					tempSelectedNumbers.append(dayString[i]);
					// tempSelectedNumbers.setLength(tempSelectedNumbers.length() - 1);
				} else {
					tempSelectedNumbers.append(dayString[i] + ",");
				}
			}

		}
		// tempSelectedNumbers.setLength(tempSelectedNumbers.length() - 1);
		Utils.Logger(GameMainExtension.extension,"length::::::::::::::tempSelectedNumbers" + tempSelectedNumbers.toString());

		Utils.Logger(GameMainExtension.extension,sessionId);

		SessionBean tempGameSessionBean = GameMainExtension.cache.getGameSessionBySessionId().getValueByKey(sessionId);

		if (tempGameSessionBean == null) {

			Utils.Logger(GameMainExtension.extension,
					"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    " + tempGameSessionBean.toString());

		} else {

		
			
			Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean: is not null::::::::::  betamount  "
			+tempGameSessionBean.getTotalBetAmount());

			tempGameSessionBean.addUserBet(userId, sessionId, coins, tempSelectedNumbers.toString(), winAmountFactor,
					splitAmount, winAmount, gameid, command);

			tempGameSessionBean.addUserBetWithoutSplit(userId, sessionId, coins, tempSelectedNumbers.toString(),
					winAmount, gameid, command);

		}
	}
}
