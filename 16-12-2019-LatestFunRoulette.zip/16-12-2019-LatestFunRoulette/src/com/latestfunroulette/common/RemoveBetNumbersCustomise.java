package com.latestfunroulette.common;

import com.latestfunroulette.cache.beans.SessionBean;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;


public class RemoveBetNumbersCustomise {



		static int winAmountFactor = 0;
		static double betSplitFactor = 0;

		public static void main(String args[]) {

			//splitBetNumbersRemove("1234", 102, );

		}

		@SuppressWarnings("null")
		public static void splitBetNumbersRemove( String sessionId, int betnumbers,User user,double coins) {
			String[] dayString = {  };

			switch (betnumbers) {
			case 1:
				dayString = new String[] { "0", "1" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 2:
				dayString = new String[] { "0", "2"};
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 3:
				dayString = new String[] { "0", "3" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 4:
				dayString = new String[] { "1", "2" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 5:
				dayString = new String[] { "2", "3" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 6:
				dayString = new String[] { "4", "5" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 7:
				dayString = new String[] { "5", "6" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 8:
				dayString = new String[] { "7", "8" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 9:
				dayString = new String[] { "8", "9" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 10:
				dayString = new String[] { "10", "11" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 11:
				dayString = new String[] { "11", "12" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 12:
				dayString = new String[] { "13"," 14" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 13:
				dayString = new String[] {" 14"," 15" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 14:
				dayString = new String[] { "16", "17" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 15:
				dayString = new String[] { "17"," 18" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 16:
				dayString = new String[] { "19"," 20" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 17:
				dayString = new String[] { "20"," 21 "};
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 18:
				dayString = new String[] {" 22", "23 "};
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 19:
				dayString = new String[] {" 23"," 24" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 20:
				dayString = new String[] { "25", "26" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 21:
				dayString = new String[] { "26"," 27 "};
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 22:
				dayString = new String[] {" 28"," 29" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 23:
				dayString = new String[] { "29"," 30 "};
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 24:
				dayString = new String[] { "31"," 32" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 25:
				dayString = new String[] {" 32", "33" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 26:
				dayString = new String[] {" 34", "35" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 27:
				dayString = new String[] { "35", "36 "};
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 28:
				dayString = new String[] { "1", "4" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 29:
				dayString = new String[] { "2", "5" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 30:
				dayString = new String[] { "3", "6" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 31:
				dayString = new String[] { "4", "7" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 32:
				dayString = new String[] { "5", "8" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 33:
				dayString = new String[] { "6", "9" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 34:
				dayString = new String[] { "7", "10" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 35:
				dayString = new String[] { "8", "11" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 36:
				dayString = new String[] { "9", "12" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 37:
				dayString = new String[] { "10", "13" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 38:
				dayString = new String[] { "11", "14" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 39:
				dayString = new String[] { "12", "15" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 40:
				dayString = new String[] { "13", "16" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 41:
				dayString = new String[] { "14", "17" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 42:
				dayString = new String[] { "15", "18" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 43:
				dayString = new String[] { "16", "19" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 44:
				dayString = new String[] { "17", "20" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 45:
				dayString = new String[] { "18", "21" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 46:
				dayString = new String[] { "19", "22" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 47:
				dayString = new String[] { "20", "23" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 48:
				dayString = new String[] { "21", "24" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 49:
				dayString = new String[] { "22", "25" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 50:
				dayString = new String[] { "23", "26" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 51:
				dayString = new String[] { "24", "27" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 52:
				dayString = new String[] { "25", "28" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 53:
				dayString = new String[] { "26", "29" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 54:
				dayString = new String[] { "27", "30" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 55:
				dayString = new String[] { "28", "31" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 56:
				dayString = new String[] { "29", "32" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 57:
				dayString = new String[] { "30", "33" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 58:
				dayString = new String[] { "31", "34" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 59:
				dayString = new String[] { "32", "35" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 60:
				dayString = new String[] { "00", "3" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 61:
				dayString = new String[] { "00", "2" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;
			case 62:
				dayString = new String[] { "00", "3", "2" };
				winAmountFactor = 12;
				betSplitFactor = 2;
				break;

			case 63:
				dayString = new String[] { "00", "0", "2" };
				winAmountFactor = 12;
				betSplitFactor = 2;
				break;

			case 64:
				dayString = new String[] { "0", "00" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 65:
				dayString = new String[] { "33", "36" };
				winAmountFactor = 18;
				betSplitFactor = 2;
				break;

			case 66:
				dayString = new String[] { "0", "1", "2" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 67:
				dayString = new String[] { "0", "2", "3" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;

			case 68:
				dayString = new String[] { "1", "2", "3" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 69:
				dayString = new String[] { "4", "5", "6" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 70:
				dayString = new String[] { "7", "8", "9" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 71:
				dayString = new String[] { "10", "11", "12" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 72:
				dayString = new String[] { "13", "14", "15" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 73:
				dayString = new String[] { "16", "17", "18" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 74:
				dayString = new String[] { "19", "20", "21" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 75:
				dayString = new String[] { "22", "23", "24" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 76:
				dayString = new String[] { "25", "26", "27" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 77:
				dayString = new String[] { "28", "29", "30" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;
			case 78:
				dayString = new String[] { "31", "32", "33" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;

			case 79:
				dayString = new String[] { "34", "35", "36" };
				winAmountFactor = 12;
				betSplitFactor = 3;
				break;

			case 80:
				dayString = new String[] { "1","2", "4", "5" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 81:
				dayString = new String[] { "2", "3", "5", "6" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 82:
				dayString = new String[] { "4", "5", "7", "8" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 83:
				dayString = new String[] { "5", "6", "8", "9" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 84:
				dayString = new String[] { "7", "8", "10", "11" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 85:
				dayString = new String[] { "8", "9", "11", "12" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 86:
				dayString = new String[] { "10", "11", "13", "14" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 87:
				dayString = new String[] { "11", "12", "14", "15" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 88:
				dayString = new String[] { "13", "14", "16", "17" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 89:
				dayString = new String[] { "14", "15", "17", "18" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 90:
				dayString = new String[] { "16", "17", "19", "20" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 91:
				dayString = new String[] { "17", "18", "20", "21" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 92:
				dayString = new String[] { "19", "20", "22", "23" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 93:
				dayString = new String[] { "20", "21", "23", "24" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 94:
				dayString = new String[] { "22", "23", "25", "26" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 95:
				dayString = new String[] { "23", "24", "26", "27" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 96:
				dayString = new String[] { "25", "26", "28", "29" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 97:
				dayString = new String[] { "26", "27", "29", "30" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 98:
				dayString = new String[] { "28", "29", "31", "32" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 99:
				dayString = new String[] { "29", "30", "32", "33" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 100:
				dayString = new String[] { "31", "32", "34", "35" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 101:
				dayString = new String[] { "32", "33", "35", "36" };
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;
			case 102:
				dayString = new String[] { "1", "2", "3", "4", "5", "6" };
				winAmountFactor = 6;
				betSplitFactor = 6;
				break;
			case 103:
				dayString = new String[] { "4", "5", "6", "7", "8", "9" };
				winAmountFactor = 6;
				betSplitFactor = 6;
				break;
			case 104:
				dayString = new String[] { "7", "8", "9", "10", "11", "12" };
				winAmountFactor = 6;
				betSplitFactor = 6;
				break;
			case 105:
				dayString = new String[] { "10", "11", "12", "13", "14", "15" };
				winAmountFactor = 6;
				betSplitFactor = 6;

				break;
			case 106:
				dayString = new String[] { "13", "14", "15", "16", "17", "18" };
				winAmountFactor = 6;
				betSplitFactor = 6;
				break;
			case 107:
				dayString = new String[] { "16", "17", "18", "19", "20", "21" };
				winAmountFactor = 6;
				betSplitFactor = 6;
				break;
			case 108:
				dayString = new String[] { "19", "20", "21", "22", "23", "24" };
				winAmountFactor = 6;
				betSplitFactor = 6;
				break;
			case 109:
				dayString = new String[] { "22", "23", "24", "25", "26", "27" };
				winAmountFactor = 6;
				betSplitFactor = 6;
				break;

			case 110:
				dayString = new String[] { "25", "26", "27", "28", "29", "30" };
				winAmountFactor = 6;
				betSplitFactor = 6;
				break;
			case 111:
				dayString = new String[] { "28", "29", "30", "31", "32", "33" };
				winAmountFactor = 6;
				betSplitFactor = 6;
				break;
			case 112:
				dayString = new String[] { "31", "32", "33", "34", "35", "36" };
				winAmountFactor = 6;
				betSplitFactor = 6;
				break;
			case 113:
				dayString = new String[] { "2", "4", "6", "8", "10", "12", "14", "16", "18", "20", "22", "24", "26", "28", "30", "32", "34", "36" };
				winAmountFactor = 2;
				betSplitFactor = 18;
				break;
			case 114:
				dayString = new String[] { "1", "3", "5", "7", "9", "11", "13", "15", "17", "19", "21", "23", "25", "27", "29", "31", "33", "35" };
				winAmountFactor = 2;
				betSplitFactor = 18;
				break;
			case 115:
				dayString = new String[] { "2", "4", "6", "8", "10", "11", "13", "15", "17", "20", "22", "24", "26", "28", "29", "31", "33", "35" };
				winAmountFactor = 2;
				betSplitFactor = 18;
				break;
			case 116:
				dayString = new String[] { "1", "3", "5", "7", "9", "12", "14", "16", "18", "19", "21", "23", "25", "27", "30", "32", "36", "34" };
				winAmountFactor = 2;
				betSplitFactor = 18;
				break;
			case 117:
				dayString = new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" };
				winAmountFactor = 3;
				betSplitFactor = 12;
				break;
			case 118:
				dayString = new String[] { "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24" };
				winAmountFactor = 3;
				betSplitFactor = 12;
				break;
			case 119:
				dayString = new String[] { "25","26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36" };
				winAmountFactor = 3;
				betSplitFactor = 12;
				break;
			case 120:
				dayString = new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18" };
				winAmountFactor = 2;
				betSplitFactor = 18;
				break;
			case 121:
				dayString = new String[] { "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36" };
				winAmountFactor = 2;
				betSplitFactor = 18;
				break;
			case 122:
				dayString = new String[] { "3", "6", "9", "12", "15", "18", "21", "24", "27", "30", "33", "36" };
				winAmountFactor = 3;
				betSplitFactor = 12;
				break;
			case 123:
				dayString = new String[] { "2", "5", "8", "11", "14", "17", "20", "23", "26", "29", "32", "35" };
				winAmountFactor = 3;
				betSplitFactor = 12;
				break;
			case 124:
				dayString = new String[] { "1", "4", "7", "10", "13", "16", "19", "22", "25", "28", "31", "34" };
				winAmountFactor = 3;
				betSplitFactor = 12;
				break;

			case 125:		
				dayString = new String[] { "00" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
					
			case 126:		
				dayString = new String[] { "0" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 127:		
				dayString = new String[] { "1" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 128:		
				dayString = new String[] { "2" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 129:		
				dayString = new String[] { "3" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 130:		
				dayString = new String[] { "4" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 131:		
				dayString = new String[] { "5" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 132:		
				dayString = new String[] { "6" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 133:		
				dayString = new String[] { "7" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 134:		
				dayString = new String[] { "8"};
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 135:		
				dayString = new String[] { "9" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 136:		
				dayString = new String[] { "10" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 137:		
				dayString = new String[] { "11" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 138:		
				dayString = new String[] { "12" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
					
			case 139:		
				dayString = new String[] { "13" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 140:		
				dayString = new String[] { "14" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 141:		
				dayString = new String[] { "15" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 142:		
				dayString = new String[] { "16" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 143:		
				dayString = new String[] { "17" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 144:		
				dayString = new String[] { "18" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 145:		
				dayString = new String[] { "19" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 146:		
				dayString = new String[] { "20" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 147:		
				dayString = new String[] { "21" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 148:		
				dayString = new String[] { "22" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 149:		
				dayString = new String[] { "23" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 150:		
				dayString = new String[] { "24" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 151:		
				dayString = new String[] { "25" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 152:		
				dayString = new String[] { "26" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
					
			case 153:		
				dayString = new String[] { "27" };
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 154:		
				dayString = new String[] { "28" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 155:		
				dayString = new String[] { "29" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 156:		
				dayString = new String[] { "30" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 157:		
				dayString = new String[] { "31" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 158:		
				dayString = new String[] { "32" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 159:		
				dayString = new String[] { "33" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 160:		
				dayString = new String[] { "34" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 161:		
				dayString = new String[] { "35" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 162:		
				dayString = new String[] { "36" };	
				winAmountFactor = 36;	
				betSplitFactor = 1;	
				break;	
			case 163:	
				dayString = new String[] { "00", "0", "2","3" }; 
				winAmountFactor = 9;
				betSplitFactor = 4;
				break;	
				
			default:

			//	dayString = new int[] { 0 };

				break;
			}

		
			StringBuilder tempSelectedNumbers = new StringBuilder();
		
			for (int i = 0; i < dayString.length; i++) {

				Utils.Logger(GameMainExtension.extension,"dayString:::::::::::::"+dayString[i]);
				
				if (dayString[i].equalsIgnoreCase("00")) {

					tempSelectedNumbers.append("00" +",");
					tempSelectedNumbers.setLength(tempSelectedNumbers.length());
					Utils.Logger(GameMainExtension.extension,"tempSelectedNumbers:::::::::::" + tempSelectedNumbers.toString());
				} else {

					Utils.Logger(GameMainExtension.extension,dayString[i]);

					tempSelectedNumbers.append(dayString[i] + ",");
					//tempSelectedNumbers.setLength(tempSelectedNumbers.length() - 1);

				}

			}
			// tempSelectedNumbers.setLength(tempSelectedNumbers.length() - 1);
			Utils.Logger(GameMainExtension.extension,"length::::::::::::::tempSelectedNumbers" + tempSelectedNumbers.toString());

			Utils.Logger(GameMainExtension.extension,sessionId);

			SessionBean tempGameSessionBean = GameMainExtension.cache.getGameSessionBySessionId().getValueByKey(sessionId);

			if (tempGameSessionBean == null) {

				Utils.Logger(GameMainExtension.extension,
						"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    " + tempGameSessionBean.toString());

			} else {

				Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean: is not null::::::::::    "
						+ tempGameSessionBean.toString() + "tempGameSessionBean" + tempGameSessionBean.getTotalBetAmount());

				tempGameSessionBean.cancelSpecifiChooseAdmin(tempSelectedNumbers.toString(),user.getName(),coins);

			}
		}
	}

	

