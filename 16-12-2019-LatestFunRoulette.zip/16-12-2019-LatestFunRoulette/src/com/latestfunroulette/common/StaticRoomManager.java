package com.latestfunroulette.common;

import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.Constants.StaticRooms;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.api.CreateRoomSettings;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.exceptions.SFSCreateRoomException;
import com.smartfoxserver.v2.exceptions.SFSJoinRoomException;

public class StaticRoomManager {

	public static synchronized void createOnlineLobbyRoom() {
		// GameMainExtension extension = GameMainExtension.extension; // User
		// pUser=null; // CallBack
		try {
			Utils.Logger(GameMainExtension.extension, "SingleRouletteLobbyRoom");
			GameBean tempGameBean = new GameBean();
			CreateRoomSettings tempRoomSetting = new CreateRoomSettings();
			tempRoomSetting.setGroupId(StaticRooms.SINGLE_ROULETTE_ROOM);
			tempRoomSetting.setName(StaticRooms.SINGLE_ROULETTE_ROOM);
			Utils.Logger(GameMainExtension.extension,
					"createOnlineLobbyRoom::::::::::::::::zone" + GameMainExtension.extension.getParentZone()
							+ "tempRoomSetting" + tempRoomSetting.getName() + tempRoomSetting.getGroupId());

			Room tempRoom = GameMainExtension.extension.getApi().createRoom(GameMainExtension.extension.getParentZone(),
					tempRoomSetting, null, false, null, true, true);

			Utils.Logger(GameMainExtension.extension, "createOnlineLobbyRoom::::::::::::::::room" + tempRoom);

			tempRoom.setProperty(Param.GAME_TYPE, StaticRooms.SINGLE_ROULETTE_ROOM);
			tempRoom.setActive(true);
			tempGameBean.setSfsRoom(tempRoom);

			Utils.Logger(GameMainExtension.extension,"tempGameBean:::::::::::::::::" + tempGameBean);

			// new AllMachineManager().OnInitialState(tempRoom, tempGameBean);

			// GameMainExtension.cache.getGames().add(tempGameBean);
			// joinRoom(pUser, tempGameBean, pCallBack);

		} catch (SFSCreateRoomException e) {
			Utils.ErrorLogger(GameMainExtension.extension,
					"StaticRoomManager ::::: CreateOnlineLobbyRoom :::: Error :::: ", e);
			e.printStackTrace();
		}
	}

	public static synchronized void createZeroToNineLobbyRoom() {
		GameMainExtension extension = GameMainExtension.extension;
		try {
			GameBean tempGameBean = new GameBean();
			CreateRoomSettings tempRoomSetting = new CreateRoomSettings();
			tempRoomSetting.setGroupId(StaticRooms.ZERO_TO_NINE_LOBBY_ROOM);
			tempRoomSetting.setName(StaticRooms.ZERO_TO_NINE_LOBBY_ROOM);

			// tempGameBean.setRoomName(StaticRooms.TWO_ROULETTE_LOBBY_ROOM);

			Room tempRoom = extension.getApi().createRoom(extension.getParentZone(), tempRoomSetting, null, false, null,
					true, true);

			tempRoom.setProperty(Param.GAME_TYPE, StaticRooms.ZERO_TO_NINE_LOBBY_ROOM);
			tempRoom.setActive(true);
			tempGameBean.setSfsRoom(tempRoom);
			// new AllMachineManager().OnInitialState(tempRoom, tempGameBean);
			// GameMainExtension.cache.getGames().add(tempGameBean);

		} catch (SFSCreateRoomException e) {
			Utils.ErrorLogger(extension, "StaticRoomManager ::::: createZeroToNineLobbyRoom :::: Error :::: ", e);
			e.printStackTrace();
		}
	}

	public static synchronized void createTwoRouletteLobbyRoom() {
		GameMainExtension extension = GameMainExtension.extension;
		try {
			GameBean tempGameBean = new GameBean();
			CreateRoomSettings tempRoomSetting = new CreateRoomSettings();
			tempRoomSetting.setGroupId(StaticRooms.DOUBLE_CHANCE_ROOM);
			tempRoomSetting.setName(StaticRooms.DOUBLE_CHANCE_ROOM);

			// tempGameBean.setRoomName(StaticRooms.TWO_ROULETTE_LOBBY_ROOM);

			Room tempRoom = extension.getApi().createRoom(extension.getParentZone(), tempRoomSetting, null, false, null,
					true, true);

			tempRoom.setProperty(Param.GAME_TYPE, StaticRooms.DOUBLE_CHANCE_ROOM);
			tempRoom.setActive(true);
			tempGameBean.setSfsRoom(tempRoom);
			// new AllMachineManager().OnInitialState(tempRoom, tempGameBean);
			// GameMainExtension.cache.getGames().add(tempGameBean);

		} catch (SFSCreateRoomException e) {
			Utils.ErrorLogger(extension, "StaticRoomManager ::::: createTwoRouletteLobbyRoom :::: Error :::: ", e);
			e.printStackTrace();
		}
	}

	public static synchronized void createThreeRouletteLobbyRoom() {
		GameMainExtension extension = GameMainExtension.extension;
		try {

			GameBean tempGameBean = new GameBean();
			CreateRoomSettings tempRoomSetting = new CreateRoomSettings();
			tempRoomSetting.setGroupId(StaticRooms.TRIPLE_CHANCE_ROOM);
			tempRoomSetting.setName(StaticRooms.TRIPLE_CHANCE_ROOM);

			// tempGameBean.setRoomName(StaticRooms.THREE_ROULETTE_LOBBY_ROOM);

			Room tempRoom = extension.getApi().createRoom(extension.getParentZone(), tempRoomSetting, null, false, null,
					true, true);

			tempRoom.setProperty(Param.GAME_TYPE, StaticRooms.TRIPLE_CHANCE_ROOM);
			tempRoom.setActive(true);
			tempGameBean.setSfsRoom(tempRoom);

			// GameMainExtension.cache.getGames().add(tempGameBean);

		} catch (SFSCreateRoomException e) {
			Utils.ErrorLogger(extension, "StaticRoomManager ::::: createThreeRouletteLobbyRoom :::: Error :::: ", e);
			e.printStackTrace();
		}
	}
	
	
	public static synchronized void createPlayMartLobbyRoom() {
		GameMainExtension extension = GameMainExtension.extension;
		try {
			GameBean tempGameBean = new GameBean();
			CreateRoomSettings tempRoomSetting = new CreateRoomSettings();
			tempRoomSetting.setGroupId(StaticRooms.PLAY_MART_ROOM);
			tempRoomSetting.setName(StaticRooms.PLAY_MART_ROOM);

			// tempGameBean.setRoomName(StaticRooms.TWO_ROULETTE_LOBBY_ROOM);

			Room tempRoom = extension.getApi().createRoom(extension.getParentZone(), tempRoomSetting, null, false, null,
					true, true);

			tempRoom.setProperty(Param.GAME_TYPE, StaticRooms.PLAY_MART_ROOM);
			tempRoom.setActive(true);
			tempGameBean.setSfsRoom(tempRoom);
			// new AllMachineManager().OnInitialState(tempRoom, tempGameBean);
			// GameMainExtension.cache.getGames().add(tempGameBean);

		} catch (SFSCreateRoomException e) {
			Utils.ErrorLogger(extension, "StaticRoomManager ::::: createPlayMartLobbyRoom :::: Error :::: ", e);
			e.printStackTrace();
		}
	}


	public static synchronized void joinOnlineLobbyRoom(User pUser) {
		GameMainExtension extension = GameMainExtension.extension;
		Utils.Logger(extension, "StaticRoomManager :::: JoinOnlineLobbyRoom :::: User :::: " + pUser.getName());
		try {
			Room tempRoom = extension.getParentZone().getRoomByName(StaticRooms.SINGLE_ROULETTE_ROOM);
			if (pUser.isJoinedInRoom(tempRoom) == false)
				extension.getApi().joinRoom(pUser, tempRoom, null, false, null);
		} catch (SFSJoinRoomException e) {
			Utils.ErrorLogger(extension, "StaticRoomManager ::::: JoinOnlineLobbyRoom :::: Error :::: ", e);
			e.printStackTrace();
		}
	}

	public static synchronized void unJoinOnlineLobbyRoom(User pUser) {
		GameMainExtension extension = GameMainExtension.extension;
		Utils.Logger(extension, "StaticRoomManager :::: UnJoinOnlineLobbyRoom :::: User :::: " + pUser.getName());

		Room tempRoom = extension.getParentZone().getRoomByName(StaticRooms.SINGLE_ROULETTE_ROOM);
		ISFSObject isfsObject = new SFSObject();

		isfsObject.putUtfString(Param.MESSAGE, "Room Leave Successfully");
		isfsObject.putUtfString(Param.STATUS, "true");

		extension.getApi().leaveRoom(pUser, tempRoom, false, true);

		extension.send(Request.LEAVE_SINGLE_ROULETTE_LOBBY_REQUEST, isfsObject, pUser);
	}

	public static synchronized void joinZeroToNineLobbyRoom(User pUser) {
		GameMainExtension extension = GameMainExtension.extension;
		Utils.Logger(extension, "StaticRoomManager :::: joinZeroToNineLobbyRoom :::: User :::: " + pUser.getName());
		try {
			Room tempRoom = extension.getParentZone().getRoomByName(StaticRooms.ZERO_TO_NINE_LOBBY_ROOM);
			if (pUser.isJoinedInRoom(tempRoom) == false)
				extension.getApi().joinRoom(pUser, tempRoom, null, false, null);
		} catch (SFSJoinRoomException e) {
			Utils.ErrorLogger(extension, "StaticRoomManager ::::: joinZeroToNineLobbyRoom :::: Error :::: ", e);
			e.printStackTrace();
		}
	}

	public static synchronized void unjoinZeroToNineLobbyRoom(User pUser) {
		GameMainExtension extension = GameMainExtension.extension;
		Utils.Logger(extension, "StaticRoomManager :::: UnJoinOnlineLobbyRoom :::: User :::: " + pUser.getName());

		Room tempRoom = extension.getParentZone().getRoomByName(StaticRooms.ZERO_TO_NINE_LOBBY_ROOM);
		ISFSObject isfsObject = new SFSObject();

		isfsObject.putUtfString(Param.MESSAGE, "Room Leave Successfully");
		isfsObject.putUtfString(Param.STATUS, "true");

		extension.getApi().leaveRoom(pUser, tempRoom, false, true);

		extension.send(Request.LEAVE_ZERO_TO_NINE_ROULETTE_LOBBY_REQUEST, isfsObject, pUser);
	}

	/* TWO_ROULETTE_LOBBY_ROOM JOIN METHOD */

	public static synchronized void joinTwoRouletteLobbyRoom(User pUser) {
		GameMainExtension extension = GameMainExtension.extension;
		Utils.Logger(extension,
				" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> StaticRoomManager :::: joinTwoRouletteOnlineLobbyRoom :::: User :::: "
						+ pUser.getName());
		try {
			Room tempRoom = extension.getParentZone().getRoomByName(StaticRooms.DOUBLE_CHANCE_ROOM);
			if (pUser.isJoinedInRoom(tempRoom) == false)
				extension.getApi().joinRoom(pUser, tempRoom, null, false, null);
		} catch (SFSJoinRoomException e) {
			Utils.ErrorLogger(extension,
					" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  StaticRoomManager ::::: joinTwoRouletteOnlineLobbyRoom :::: Error :::: ",
					e);
			e.printStackTrace();
		}
	}

	public static synchronized void unJoinTwoRouletteLobbyRoom(User pUser) {
		GameMainExtension extension = GameMainExtension.extension;
		Utils.Logger(extension, "StaticRoomManager :::: unJoinTwoRouletteLobbyRoom :::: User :::: " + pUser.getName());

		Room tempRoom = extension.getParentZone().getRoomByName(StaticRooms.DOUBLE_CHANCE_ROOM);
		ISFSObject isfsObject = new SFSObject();

		isfsObject.putUtfString(Param.MESSAGE, "Room Leave Successfully");
		isfsObject.putUtfString(Param.STATUS, "true");
		extension.getApi().leaveRoom(pUser, tempRoom, false, true);
		extension.send(Request.LEAVE_DOUBLE_CHANCE_LOBBY_REQUEST, isfsObject, pUser);

	}

	/* THREE_ROULETTE_LOBBY_ROOM JOIN METHOD */

	public static synchronized void joinThreeRouletteOnlineLobbyRoom(User pUser) {
		GameMainExtension extension = GameMainExtension.extension;
		Utils.Logger(extension,
				"StaticRoomManager :::: joinThreeRouletteOnlineLobbyRoom :::: User :::: " + pUser.getName());
		try {
			Room tempRoom = extension.getParentZone().getRoomByName(StaticRooms.TRIPLE_CHANCE_ROOM);
			if (pUser.isJoinedInRoom(tempRoom) == false)
				extension.getApi().joinRoom(pUser, tempRoom, null, false, null);
		} catch (SFSJoinRoomException e) {
			Utils.ErrorLogger(extension, "StaticRoomManager ::::: joinThreeRouletteOnlineLobbyRoom :::: Error :::: ",
					e);
			e.printStackTrace();
		}
	}

	public static synchronized void unJoinThreeRouletteLobbyRoom(User pUser) {
		GameMainExtension extension = GameMainExtension.extension;
		Utils.Logger(extension,
				"StaticRoomManager :::: joinThreeRouletteOnlineLobbyRoom :::: User :::: " + pUser.getName());

		Room tempRoom = extension.getParentZone().getRoomByName(StaticRooms.TRIPLE_CHANCE_ROOM);
		ISFSObject isfsObject = new SFSObject();

		isfsObject.putUtfString(Param.MESSAGE, "Room Leave Successfully");
		isfsObject.putUtfString(Param.STATUS, "true");
		extension.getApi().leaveRoom(pUser, tempRoom, false, true);
		extension.send(Request.LEAVE_TRIPLE_CHANCE_LOBBY_REQUEST, isfsObject, pUser);
	}
	
	
	public static synchronized void joinPlayMartRoom(User pUser) {
		GameMainExtension extension = GameMainExtension.extension;
		Utils.Logger(extension,
				"StaticRoomManager :::: joinPlayMartRoom :::: User :::: " + pUser.getName());
		try {
			Room tempRoom = extension.getParentZone().getRoomByName(StaticRooms.PLAY_MART_ROOM);
			if (pUser.isJoinedInRoom(tempRoom) == false)
				extension.getApi().joinRoom(pUser, tempRoom, null, false, null);
		} catch (SFSJoinRoomException e) {
			Utils.ErrorLogger(extension, "StaticRoomManager ::::: joinPlayMartRoom :::: Error :::: ",
					e);
			e.printStackTrace();
		}
	}

	public static synchronized void unJoinPlayMartRoom(User pUser) {
		GameMainExtension extension = GameMainExtension.extension;
		Utils.Logger(extension,
				"StaticRoomManager :::: unJoinPlayMartRoom :::: User :::: " + pUser.getName());

		Room tempRoom = extension.getParentZone().getRoomByName(StaticRooms.PLAY_MART_ROOM);
		ISFSObject isfsObject = new SFSObject();

		isfsObject.putUtfString(Param.MESSAGE, "Room Leave Successfully");
		isfsObject.putUtfString(Param.STATUS, "true");
		extension.getApi().leaveRoom(pUser, tempRoom, false, true);
		extension.send(Request.LEAVE_PLAY_MART_LOBBY_REQUEST, isfsObject, pUser);
	}

	public static synchronized void joinRoom(User pUser, GameBean tempGameBean, CallBack pCallBack) {
		Utils.Logger(GameMainExtension.extension, "GameRoomManager :::: JoinRoom()");

		if (pUser != null && pUser.isConnected()) {
			Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(pUser.getName());
			Utils.Logger(GameMainExtension.extension,
					"GameRoomManager :::: JoinRoom() BLOCK_STATUS " + tempPlayer.getUserBlockStatus());
			if (tempPlayer.getUserBlockStatus() == 0) {
				/*
				 * tempGameBean.addPlayers(pUser, tempPlayer.getLoginid(),tempGameBean, new
				 * CallBack() {
				 * 
				 * @Override public void call(Object... values) { boolean dbstatus = (boolean)
				 * values[0]; if (dbstatus) { CommonEvents.sendUserDetails(tempPlayer, pUser);
				 * joinSFSRoom(pUser, tempGameBean, pCallBack);
				 * Utils.addGameInPlayerList(tempGameBean, pUser);
				 * Utils.Logger(GameMainExtension.extension, "GameRoomManager :::: JoinRoom() "
				 * + tempGameBean.getPlayers()); Utils.setPlayersRank(tempGameBean); } else
				 * pCallBack.call(dbstatus); } });
				 */
			} else {
				CommonEvents.sendUserIsBlockedEvent(tempPlayer, pUser);
				pCallBack.call(EnableStatus.DISABLE);
			}
		} else {
			pCallBack.call(EnableStatus.DISABLE);
		}
	}

}