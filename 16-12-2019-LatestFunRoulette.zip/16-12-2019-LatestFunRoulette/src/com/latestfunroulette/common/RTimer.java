package com.latestfunroulette.common;

public class RTimer {

	long startTime = 0;

	/**
	 * reset start-time to current-time
	 */
	public void resetTimer() {
		startTime = System.currentTimeMillis();
	}

	/**
	 * 
	 * @return return start time
	 */
	public long getStartTime() {
		return startTime;
	}

	/**
	 * get elapsed-time in seconds
	 * 
	 * @return return elapsed-time in seconds
	 */
	public long getElapsedTime() {
		long endTime = System.currentTimeMillis();
		long elapsedTime = (endTime - startTime) / 1000;

		return elapsedTime;

	}

}