package com.latestfunroulette.common;

public class Constants {

	public static class Param {

		public static final String USER_NAME = "USER_NAME";
		public static final String PASSWORD = "PASSWORD";
		public static final String NAME = "NAME";
		// public static final String EMAIL_ID = "EMAIL_ID";
		public static final String DEVICE_ID = "DEVICE_ID";
		public static final String MOBILE_NO = "MOBILE_NO";
		public static final String DEVICE_TYPE = "DEVICE_TYPE";
		public static final String USER_TYPE = "USER_TYPE";

		public static final String STATUS = "STATUS";
		public static final String USERID = "USERID";
		public static final String SESSIONID = "SESSIONID";
		public static final String MESSAGE = "MESSAGE";
		public static final String TICKETID = "TICKETID";
		public static final String DEVICETYPE = "DEVICETYPE";
		public static final String GAMETYPE = "GAMETYPE";
		
		public static final String DRAWTIME = "DRAWTIME";
		public static final String TICKETTIMER = "TICKETTIMER";
	
		
		
		

		public static final String BETAMOUNT = "BETAMOUNT";
		public static final String JACKPORT = "JACKPORT";

		public static final String GAME_TYPE_ID = "gameTypeId";
		public static final String USER_GAME_LIST = "USER_GAME_LIST";
		public static final String BET_LIST = "BET_LIST";
		public static final String TABLE_TYPE = "TABLE_TYPE";
		public static final String TABLE_NUMBERS = "TABLE_NUMBERS";
		public static final String GAME_ID = "GAME_ID";
		public static final String BETSARRAY = "BETSARRAY";

		// public static final String USER_LOGIN_ID = "USER_LOGIN_ID";
		public static final String SOCIAL_ID = "SOCIAL_ID";

		public static final String USER_IMAGE = "USER_IMAGE";
		public static final String EMAILID = "EMAILID";

		public static final String CHIPS = "CHIPS";
		public static final String WIN_CHIPS = "WIN_CHIPS";
		public static final String DESIGNATE = "DESIGNATE";
		public static final String LOSS_CHIPS = "LOSS_CHIPS";

		public static final String ROUND_WIN_COUNTS = "ROUND_WIN_COUNTS";
		public static final String ROUND_LOSS_COUNTS = "ROUND_LOSS_COUNTS";
		public static final String LEVEL_RANK = "LEVEL_RANK";

		public static final String GENDER = "GENDER";
		public static final String USER_NATIONALITY = "USER_NATIONALITY";
		public static final String USER_LIVING_COUNTRY = "USER_LIVING_COUNTRY";

		public static final String AVATAR_ID = "AVATAR_ID";
		public static final String AVATAR_URL = "AVATAR_URL";
		public static final String AVATAR_LIST = "AVATAR_LIST";

		public static final String CARD_SUIT = "CARD_SUIT";
		public static final String CARD_VALUE = "CARD_VALUE";
		public static final String CARD_RESOURCE_VALUE = "CARD_RESOURCE_VALUE";
		public static final String CARD_DISPLAY_VALUE = "CARD_DISPLAY_VALUE";
		public static final String SELECTED_CARD_CUT_FOR_SEAT = "SELECTED_CARD_CUT_FOR_SEAT";
		public static final String CARD_LIST_CUT_FOR_SEAT = "CARD_LIST_CUT_FOR_SEAT";
		public static final String CARD_INDEX = "CARD_INDEX";
		public static final String CARD_DRAW_TYPE = "CARD_DRAW_TYPE";
		public static final String PICKED_CARD = "PICKED_CARD";
		public static final String DISCARDED_CARD = "DISCARDED_CARD";
		public static final String IS_CARD_ABLE_TO_PICK = "IS_CARD_ABLE_TO_PICK";
		public static final String CLOSE_DECK_CARD_SIZE = "CLOSE_DECK_CARD_SIZE";

		public static final String LEVEL = "LEVEL";
		public static final String LEVEL_COUNT = "LEVEL_COUNT";
		public static final String TOTAL_GAME = "TOTAL_GAME";
		public static final String KING = "KING";
		public static final String KOUZ = "KOUZ";
		public static final String DASH_CALL = "DASH_CALL";
		public static final String EIGHT_CALL = "EIGHT_CALL";

		public static final String GAME_CHIPS = "GAME_CHIPS";
		public static final String GAME_TYPE = "GAME_TYPE";
		public static final String GAME_PASSWORD = "GAME_PASSWORD";
		public static final String GAME_PASSWORD_STATUS = "GAME_PASSWORD_STATUS";
		public static final String GAME_TURN_TIME = "GAME_TURN_TIME";
		public static final String GAME_CHAT_STATUS = "GAME_CHAT_STATUS";
		public static final String GAME_LEVEL = "GAME_LEVEL";

		public static final String FILL_SLOT = "FILL_SLOT";
		public static final String BLANK_SLOT = "BLANK_SLOT";
		public static final String ROUND = "ROUND";

		public static final String GAME_NAME = "GAME_NAME";
		public static final String GAME_TABLE_NAME = "GAME_TABLE_NAME";
		public static final String ROOM_NAME = "ROOM_NAME";

		public static final String ONLINE_PLAYER_COUNT = "ONLINE_PLAYER_COUNT";
		public static final String ONLINE_GAME_LIST = "ONLINE_GAME_LIST";

		public static final String TIMER = "TIMER";
		public static final String STATE = "STATE";

		public static final String OLD_PASSWORD = "OLD_PASSWORD";
		public static final String NEW_PASSWORD = "NEW_PASSWORD";

		public static final String CURRENT_SCORE = "CURRENT_SCORE";
		public static final String CURRENT_TAG = "CURRENT_TAG";
		public static final String ESTIMATED_HANDS = "ESTIMATED_HANDS";
		public static final String ESTIMATED_SUIT = "ESTIMATED_SUIT";
		public static final String BIG_ESTIMATED_VALUE_HANDS = "BIG_ESTIMATED_VALUE_HANDS";
		public static final String BIG_ESTIMATED_SUIT_HANDS = "BIG_ESTIMATED_SUIT_HANDS";
		public static final String TOTAL_ESTIMATED_HANDS = "TOTAL_ESTIMATED_HANDS";

		public static final String CURRENT_HANDS = "CURRENT_HANDS";
		public static final String GAME_RANK = "GAME_RANK";
		public static final String SEAT_NO = "SEAT_NO";
		public static final String CURRENT_ROUND = "CURRENT_ROUND";

		public static final String PLAYER_CARDS = "PLAYER_CARDS";
		public static final String STARTING_BID = "STARTING_BID";
		public static final String STARTING_SUIT = "STARTING_SUIT";
		public static final String WITH_END_BID = "WITH_END_BID";
		public static final String BID_ACTION = "BID_ACTION";

		public static final String DASH_CALL_STATUS = "DASH_CALL_STATUS";

		public static final String BID = "BID";
		public static final String BID_NO = "BID_NO";
		public static final String BID_STATUS = "BID_STATUS";
		public static final String BOT_STATUS = "BOT_STATUS";
		public static final String CURRENT_TIME = "CURRENT_TIME";
		public static final String STATE_TIME = "STATE_TIME";
		public static final String TURN_TIME = "TURN_TIME";
		public static final String LAST_PLAYER_STATUS = "LAST_PLAYER_STATUS";

		public static final String PLAYER_LIST = "PLAYER_LIST";

		public static final String DOMINANT_SUIT = "DOMINANT_SUIT";
		public static final String CARD_TURN_SUIT = "CARD_TURN_SUIT";

		public static final String WIN_TURN_SEAT_NO = "WIN_TURN_SEAT_NO";
		public static final String WIN_TURN_LOGIN_ID = "WIN_TURN_LOGIN_ID";

		public static final String TURN_TRICKS = "TURN_TRICKS";

		public static final String ROUND_RESULT_STATUS = "ROUND_RESULT_STATUS";
		public static final String ROUND_ID = "ROUND_ID";
		public static final String ROUND_SCORE = "ROUND_SCORE";
		public static final String TOTAL_SCORE = "TOTAL_SCORE";

		public static final String BIGGEST_BID_PLAYER_LOGIN_ID = "BIGGEST_BID_PLAYER_LOGIN_ID";
		public static final String BIGGEST_BID_PLAYER_SEAT_NO = "BIGGEST_BID_PLAYER_SEAT_NO";

		public static final String ROUND_RESULT_PLAYES = "ROUND_RESULT_PLAYES";
		public static final String ROUND_RESULT_LIST = "ROUND_RESULT_LIST";

		public static final String RISK_STATUS = "RISK_STATUS";
		public static final String DASH_STATUS = "DASH_STATUS";
		public static final String CARD_AVOID_STATUS = "CARD_AVOID_STATUS";

		public static final String NEW_GAME_STATUS = "NEW_GAME_STATUS";
		public static final String CHAT_MESSAGE_SENDER = "CHAT_MESSAGE_SENDER";
		public static final String CHAT_MESSAGE = "CHAT_MESSAGE";
		public static final String CHAT_TIME = "CHAT_TIME";
		public static final String COLOR_ROUND_STATUS = "COLOR_ROUND_STATUS";

		// User Types
		public static final String CUSTOM = "Custom";
		public static final String FACEBOOK = "Facebook";
		public static final String GOOGLE = "Google";
		public static final String GUEST = "Guest";
		public static final String STATIC_COUNTRY = "Egypt";
		public static final String IS_BOT_JOINING_IN_ROOM = "IS_BOT_JOINING_IN_ROOM";
		public static final String IS_ROUND_RESTART = "IS_ROUND_RESTART";
		public static final String CARD_TURN_COUNT = "CARD_TURN_COUNT";
		public static final String CURRENT_STATE = "CURRENT_STATE";
		public static final String PLAYER_REMAINING_CARDS = "PLAYER_REMAINING_CARDS";
		public static final String DELAY_TIME = "DELAY_TIME";
		public static final String GAME_CHAT_BLOCK_STATUS = "GAME_CHAT_BLOCK_STATUS";

		// Banner
		public static final String BANNER_TITLE = "BANNER_TITLE";
		public static final String BANNER_IMAGE = "BANNER_IMAGE";
		public static final String BANNER_PAGE = "BANNER_PAGE";
		public static final String BANNER_STATUS = "BANNER_STATUS";
		public static final String BANNER_LINK = "BANNER_LINK";
		public static final String IS_USER_BLOCK = "IS_USER_BLOCK";
		public static final String USER_VARIABLE = "USER_VARIABLE";

		public static final String ASSIGNED_GAMES = "ASSIGNED_GAMES";
		public static final String USER_GAME_TYPES = "USER_GAME_TYPES";

		public static final String ALREADY_LOGIN_USER = " %s is already logged.";
		public static final String ACTIVE_ALL_GAMES = "ACTIVE_ALL_GAMES";
		public static final String KING_PERCENT = "KING_PERCENT";
		public static final String KOUZ_PERCENT = "KOUZ_PERCENT";
		public static final String SCORE_MULTIPLIER = "SCORE_MULTIPLIER";
		public static final String PLAYER_RANK = "PLAYER_RANK";
		public static final String ALL_PLAYERS_CARD_AVOID_STATUS = "ALL_PLAYERS_CARD_AVOID_STATUS";
		public static final String INVITED_BY = "INVITED_BY";
		public static final String INVITED_TO = "INVITED_TO";

		public static final String FILE_UPLOAD_ID = "FILE_UPLOAD_ID";
		public static final String PROFILE_IMAGE = "PROFILE_IMAGE";
		public static final String IMAGE_URL = "IMAGE_URL";
		public static final String AUTO_DISCARD = "AUTO_DISCARD";
		public static final String WITH_STATUS = "WITH_STATUS";
		public static final String CURRENT_TURN_TRICKS = "CURRENT_TURN_TRICKS";
		public static final String LAST_TURN_TRICKS = "LAST_TURN_TRICKS";
		public static final String CURRENT_TURN_SEAT_NO = "CURRENT_TURN_SEAT_NO";

		public static final String CREDITS = "CREDITS";
		public static final String BETS = "BETS";
		public static final String SESSION_ID = "SESSION_ID";
		public static final String WINNER = "WINNER";
		public static final String WINNINGNUMBER = "WINNINGNUMBER";
		public static final String TOTALBETAMT = "TOTALBETAMT";
		public static final String LASTFIVENUMBER = "LASTFIVENUMBER";
		public static final String CURRENTGAMESESSION = "CURRENTGAMESESSION";
		public static final String RESULTWHEEL = "RESULTWHEEL";
		public static final String PAYMENT_HISTORY_LIST = "PAYMENT_HISTORY_LIST";
		public static final String BETPLACETIME = "BETPLACETIME";
		public static final String WINAMOUNT = "WINAMOUNT";
		public static final String SINGLE = "SINGLE";
		public static final String DOUBLE = "DOUBLE";
		public static final String TRIPLE = "TRIPLE";
		public static final String COINS = "COINS";
		public static final String COMMANDNAME = "COMMANDNAME";
		public static final String BETNO = "BETNO";
		public static final String ROOMNAME = "ROOMNAME";
		public static final String COMMAND_QUIT = "COMMAND_QUIT";
		public static final String TOTALBET = "TOTALBET";
		public static final String ID = "ID";
		public static final String GAMEID = "GAMEID";
		public static final String MININNER = "MININNER";
		public static final String MAXINNER = "MAXINNER";
		public static final String MINOUTER = "MINOUTER";
		public static final String MAXOUTER = "MAXOUTER";
		public static final String STARTDATE = "STARTDATE";
		public static final String ENDDATE = "ENDDATE";

	}

	public static class Request {

		public static final String CUSTOM_REGISTRATION_REQUEST = "CUSTOM_REGISTRATION_REQUEST";
		public static final String CUSTOM_LOGIN_REQUEST = "CUSTOM_LOGIN_REQUEST";
		public static final String GUEST_LOGIN_REQUEST = "GUEST_LOGIN_REQUEST";
		public static final String SOCIAL_LOGIN_REQUEST = "SOCIAL_LOGIN_REQUEST";
		public static final String CONVERT_PERMANENT_REQUEST = "CONVERT_PERMANENT_REQUEST";

		public static final String PING_PONG_REQUEST = "PING_PONG_REQUEST";
		public static final String FORGOT_PASSWORD_REQUEST = "FORGOT_PASSWORD_REQUEST";

		public static final String AVATAR_LIST_REQUEST = "AVATAR_LIST_REQUEST";
		public static final String UPDATE_AVATAR_REQUEST = "UPDATE_AVATAR_REQUEST";
		public static final String PROFILE_REQUEST = "PROFILE_REQUEST";
		public static final String UPDATE_PROFILE_REQUEST = "UPDATE_PROFILE_REQUEST";
		public static final String RESET_PASSWORD_REQUEST = "RESET_PASSWORD_REQUEST";

		public static final String LAST_FIVE_GAME_WINNINGNUMBER = "LAST_FIVE_GAME_WINNINGNUMBER";
		public static final String SEND_WINNING_NUMBER = "SEND_WINNING_NUMBER";

		public static final String NEWSESSIONGENERATE = "NEWSESSIONGENERATE";

		public static final String LIVEBETSHANDLER = "LIVEBETSHANDLER";
		public static final String REMOVELIVEBETREQUEST = "REMOVELIVEBETREQUEST";
		public static final String CLEARALL = "CLEARALL";
		public static final String GETLIVERSERVERTIME = "GETLIVERSERVERTIME";
		public static final String CURRENTTIME = "CURRENTTIME";
		public static final String REBET_NUMBERS = "REBET_NUMBERS";
		public static final String BETOK = "BETOK";
		public static final String PAYMENT_HISTORY_REQUEST = "PAYMENT_HISTORY_REQUEST";
		public static final String USERBLOCKEDEVENT = "USERBLOCKEDEVENT";
		public static final String GAMERESULTWAITINGSTATE = "GAMERESULTWAITINGSTATE";
		public static final String LOGOUTREQUEST = "LOGOUTREQUEST";
		public static final String BETREMOVECUSTOMISE = "BETREMOVECUSTOMISE";
		public static final String DOUBLEBETROULETTE = "DOUBLEBETROULETTE";

		public static final String SINGLE_ROULETTE_LOBBY_REQUEST = "SINGLE_ROULETTE_LOBBY_REQUEST";
		public static final String LEAVE_SINGLE_ROULETTE_LOBBY_REQUEST = "LEAVE_SINGLE_ROULETTE_LOBBY_REQUEST";

		public static final String DOUBLE_CHANCE_LOBBY_REQUEST = "DOUBLE_CHANCE_LOBBY_REQUEST";
		public static final String LEAVE_DOUBLE_CHANCE_LOBBY_REQUEST = "LEAVE_DOUBLE_CHANCE_LOBBY_REQUEST";

		public static final String TRIPLE_CHANCE_LOBBY_REQUEST = "TRIPLE_CHANCE_LOBBY_REQUEST";
		public static final String LEAVE_TRIPLE_CHANCE_LOBBY_REQUEST = "LEAVE_TRIPLE_CHANCE_LOBBY_REQUEST";

		public static final String ZERO_TO_NINE_ROULETTE_LOBBY_REQUEST = "ZERO_TO_NINE_ROULETTE_LOBBY_REQUEST";
		public static final String LEAVE_ZERO_TO_NINE_ROULETTE_LOBBY_REQUEST = "LEAVE_ZERO_TO_NINE_ROULETTE_LOBBY_REQUEST";

		public static final String PLAY_MART_LOBBY_REQUEST = "PLAY_MART_LOBBY_REQUEST";
		public static final String LEAVE_PLAY_MART_LOBBY_REQUEST = "LEAVE_PLAY_MART_LOBBY_REQUEST";
		public static final String USER_GAME_DETAILS_DAY_WISE = "USER_GAME_DETAILS_DAY_WISE";
		public static final String USER_GAME_DETAILS_DATE_WISE = "USER_GAME_DETAILS_DATE_WISE";
		public static final String GET_USERS_DAY_WISE_RESULT_ROULETTE = "GET_USERS_DAY_WISE_RESULT_ROULETTE";
		public static final String CANCEL_BET_NUMBERS_BY_TICKET_ROULETTE = "CANCEL_BET_NUMBERS_BY_TICKET_ROULETTE";
		public static final String CLAIM_BET_NUMBERS_BY_TICKET_ROULETTE = "CLAIM_BET_NUMBERS_BY_TICKET_ROULETTE";

		/*
		 * :::::::::::::::::::::::::::::::::::SINGLECHANCE::::::::::::::::::::::::::::::
		 */

		public static final String DOUBLE_BET_SINGLECHANCE = "DOUBLE_BET_SINGLECHANCE";
		public static final String LIVE_BETS_HANDLER_SINGLECHANCE = "LIVE_BETS_HANDLER_SINGLECHANCE";
		public static final String CLEARALL_SINGLECHANCE = "CLEARALL_SINGLECHANCE";
		public static final String REBET_NUMBERS_SINGLECHANCE = "REBET_NUMBERS_SINGLECHANCE";
		public static final String BETREMOVECUSTOMISEZEROTONINE = "BETREMOVECUSTOMISEZEROTONINE";
		public static final String USER_GAME_DETAILS_DAY_WISE_SINGLECHANCE = "USER_GAME_DETAILS_DAY_WISE_SINGLECHANCE";
		public static final String USER_GAME_DETAILS_DATE_WISE_SINGLECHANCE = "USER_GAME_DETAILS_DATE_WISE_SINGLECHANCE";
		public static final String CANCEL_BET_NUMBERS_BY_TICKET_SINGLECHANCE = "CANCEL_BET_NUMBERS_BY_TICKET_SINGLECHANCE";
		public static final String PRINT_BET_NUMBERS = "PRINT_BET_NUMBERS";
		public static final String GET_USERS_DAY_WISE_RESULT_SINGLECHANCE = "GET_USERS_DAY_WISE_RESULT_SINGLECHANCE";
		public static final String CLAIM_BET_NUMBERS_BY_TICKET_SC = "CLAIM_BET_NUMBERS_BY_TICKET_SC";
		public static final String GET_BET_ALL_DETAILS_SC = "GET_BET_ALL_DETAILS_SC";

		/*
		 * :::::::::::::::::::::::::::::::::::DOUBLECHANCE::::::::::::::::::::::::::::::
		 */

		public static final String DOUBLE_BET_DOUBLE_CHANCE = "DOUBLE_BET_DOUBLE_CHANCE";
		public static final String LIVE_BETS_HANDLER_DOUBLE_CHANCE = "LIVE_BETS_HANDLER_DOUBLE_CHANCE";
		public static final String CLEARALL_DOUBLE_CHANCE = "CLEARALL_DOUBLE_CHANCE";
		public static final String REBET_NUMBERS_DOUBLE_CHANCE = "REBET_NUMBERS_DOUBLE_CHANCE";
		public static final String BET_REMOVE_CUSTOMISE_DOUBLE_CHANCE = "BET_REMOVE_CUSTOMISE_DOUBLE_CHANCE";
		public static final String USER_GAME_DETAILS_DAY_WISE_DOUBLE_CHANCE = "USER_GAME_DETAILS_DAY_WISE_DOUBLE_CHANCE";
		public static final String USER_GAME_DETAILS_DATE_WISE_DOUBLE_CHANCE = "USER_GAME_DETAILS_DATE_WISE_DOUBLE_CHANCE";
		public static final String REMOVE_BET_CUSTOMISE_REQUEST = "REMOVE_BET_CUSTOMISE_REQUEST";
		public static final String PRINT_BET_NUMBERS_DOUBLECHANCE = "PRINT_BET_NUMBERS_DOUBLECHANCE";
		public static final String USERS_DAY_WISE_RESULT_DOUBLECHANCE = "USERS_DAY_WISE_RESULT_DOUBLECHANCE";
		public static final String CANCEL_BET_NUMBERS_BY_TICKET_DOUBLECHANCE = "CANCEL_BET_NUMBERS_BY_TICKET_DOUBLECHANCE";
		public static final String CLAIM_BET_NUMBERS_BY_TICKET_DC = "CLAIM_BET_NUMBERS_BY_TICKET_DC";

		/*
		 * :::::::::::::::::::::::::::::::::::TRIPLECHANCE::::::::::::::::::::::::::::::
		 */

		public static final String DOUBLE_BET_TRIPLE_CHANCE = "DOUBLE_BET_TRIPLE_CHANCE";
		public static final String LIVE_BETS_HANDLER_TRIPLE_CHANCE = "LIVE_BETS_HANDLER_TRIPLE_CHANCE";
		public static final String CLEARALL_TRIPLE_CHANCE = "CLEARALL_TRIPLE_CHANCE";
		public static final String REBET_NUMBERS_TRIPLE_CHANCE = "REBET_NUMBERS_TRIPLE_CHANCE";
		public static final String BET_REMOVE_CUSTOMISE_TRIPLE_CHANCE = "BET_REMOVE_CUSTOMISE_TRIPLE_CHANCE";
		public static final String USER_GAME_DETAILS_DAY_WISE__TRIPLE_CHANCE = "USER_GAME_DETAILS_DAY_WISE__TRIPLE_CHANCE";
		public static final String USER_GAME_DETAILS_DATE_WISE_TRIPLE_CHANCE = "USER_GAME_DETAILS_DATE_WISE_TRIPLE_CHANCE";
		public static final String REMOVE_BET_TRIPLE_CHANCE_CUSTOMISE_REQUEST = "REMOVE_BET_TRIPLE_CHANCE_CUSTOMISE_REQUEST";
		public static final String USER_BETS_TABLE = "USER_BETS_TABLE";
		public static final String USER_BETS_TABLE_DOUBLE = "USER_BETS_TABLE_DOUBLE";
		public static final String PRINT_BET_NUMBERS_TRIPLECHANCE = "PRINT_BET_NUMBERS_TRIPLECHANCE";
		public static final String CANCEL_BET_NUMBERS_BY_TICKET_TRIPLECHANCE = "CANCEL_BET_NUMBERS_BY_TICKET_TRIPLECHANCE";

		public static final String CLAIM_BET_NUMBERS_BY_TICKET_TC = "CLAIM_BET_NUMBERS_BY_TICKET_TC";
		public static final String GET_USERS_DAY_WISE_RESULT_TRIPLECHANCE = "GET_USERS_DAY_WISE_RESULT_TRIPLECHANCE";

		/*
		 * :::::::::::::::::::::::::::::::::::Play Mart::::::::::::::::::::::::::::::
		 */

		public static final String DOUBLE_BET_PLAYMART = "DOUBLE_BET_PLAYMART";
		public static final String LIVE_BETS_HANDLER_PLAYMART = "LIVE_BETS_HANDLER_PLAYMART";
		public static final String CLEARALL_PLAYMART = "CLEARALL_PLAYMART";
		public static final String REBET_NUMBERS_PLAYMART = "REBET_NUMBERS_PLAYMART";
		public static final String BET_REMOVE_CUSTOMISE_PLAYMART = "BET_REMOVE_CUSTOMISE_PLAYMART";
		public static final String USER_GAME_DETAILS_DAY_WISE__PLAYMART = "USER_GAME_DETAILS_DAY_WISE__PLAYMART";
		public static final String USER_GAME_DETAILS_DATE_WISE_PLAYMART = "USER_GAME_DETAILS_DATE_WISE_PLAYMART";
		public static final String REMOVE_BET_PLAYMART_CUSTOMISE_REQUEST = "REMOVE_BET_PLAYMART_CUSTOMISE_REQUEST";
		public static final String PRINT_BET_NUMBERS_PLAYMART = "PRINT_BET_NUMBERS_PLAYMART";
		public static final String PRINT_BET_NUMBERS_ROULETTE = "PRINT_BET_NUMBERS_ROULETTE";
		public static final String CANCEL_BET_NUMBERS_BY_TICKET_PLAYMART = "CANCEL_BET_NUMBERS_BY_TICKET_PLAYMART";
		public static final String GET_USERS_DAY_WISE_RESULT_PLAYMART = "GET_USERS_DAY_WISE_RESULT_PLAYMART";
		public static final String CLAIM_BET_NUMBERS_BY_TICKET_PM = "CLAIM_BET_NUMBERS_BY_TICKET_PM";

		
	}

	public static class Message {

		public static final String SUCCESSFULLY = "Successfully!";
		public static final String USER_NOT_FOUND = "User is not found.";
		public static final String USER_IS_BLOCKED = "User is block.";

		public static final String TRY_AGAIN = "Please try again!";
		public static final String GAME_NOT_EXIST = "Game is not exist. Please try again!";
		public static final String ALREADY_JOIN_GAME = "You have joined already in the game.";
		public static final String GAME_FULL = "Game is full. Please try again!";

		public static final String TRIGGER_ERROR_MESSAGE = "Please send proper data.";
		public static final String TRIGGER_MESSAGE = "Message is receive successfully";

		public static final String AVATAR_NOT_EXIST = "Avatar image not exist!";

		public static final String INSUFFICIENT_AMOUNT = "you don't have sufficient chips! please check your balance. ";
		public static final String CHECKED_PASSWORD = "please check your entered password!";

		public static final String TABLE_CREATE_SUCCESSFULLY = "Your table create successfully.";
		public static final String TABLE_JOIN_SUCCESSFULLY = "You have joined table successfully.";

		public static final String YOU_CAN_NOT_ENTRY_OLD_PASSWORD = "You can not enter old password.";

		public static final String PLAYER_WAITING_STATUS = "You have joined the game successfully!";
		public static final String CARD_DISTRIBUTE_STATUS = "Card distribution!";
		public static final String DASH_CALL_STATUS = "Dash call!";
		public static final String CALL_BID = "Call Bid!";
		public static final String ESTIMATION_HAND = "Estimation hand!";
		public static final String PLAY_TRUN = "Play trun!";
		public static final String CALL_DASH_CALL_STATUS = "Dash call status update successfully!";
		public static final String START_THE_GAME_WITH_COMPUTER = "Start the game with computer?";
		public static final String TABLE_NOT_FOUND = "Game is not found.";
		public static final String USER_LEAVE_GAME_SUCCESSFUL = "user leave game successfully.";
		public static final String USER_LEAVE_GAME_UNSUCCESSFUL = "user leave game unsuccessful.";
		public static final String DISCARD_CARD_SUCCESS = "discard card successfully.";
		public static final String ALL_PLAYERS_WANTS_TO_RESTART_ROUND = "all players wants to restart round.";
		public static final String WANTS_TO_RESTART_ROUND = "do you want to restart round?";
		public static final String PLAYER_WANTS_TO_RESTART_ROUND = "player wants to restart round!";
		public static final String WIN_RESPONSE = "player win response!";
		public static final String PLAYER_DISCONNECT = "Player disconnect!";
		public static final String PLEASE_TRY_AGAIN = "PLEASE_TRY_AGAIN";
		public static final String FILE_UPLOAD_SUCCESSFULL = "FILE_UPLOAD_SUCCESSFULL";
	}

	public class UserType {
		public static final String NONE_USER = "NONE_USER";
		public static final String SPECTATOR_USER = "SPECTATOR_USER";
		public static final String BOT = "BOT";
		public static final String USR = "USR";
	}

	public static class GameTypes {
		public static final String SINGLE = "SINGLE_ROULETTE_GAME";
		public static final String DOUBLE = "TWO_ROULETTE_GAME";
		public static final String THRIPPLE = "THREE_ROULETTE_GAME";

	}

	public static class GameStateTime {
		public static int INITIAL_TIME = 2;
		public static int BET_PLACE_TIME = 49;
		public static int GAME_WAIT_TIME = 54;
		public static int GAME_RESULT_TIME = 59;
		public static int TotalGameTime;
		public static int status;

	}

	public static class GameStateZeroToNineTime {
		public static final int INITIAL_TIME = 2;
		public static int BET_PLACE_TIME = 50;
		public static int GAME_WAIT_TIME = 55;
		public static int GAME_RESULT_TIME = 60;
		public static int TotalGameTime;
		public static int status;

	}

	public static class GameStateZeroToDoubleNineTime {
		public static final int INITIAL_TIME = 2; // some time change 2 to 14
		public static int BET_PLACE_TIME = 49;
		public static int GAME_WAIT_TIME = 54;
		public static int GAME_RESULT_TIME = 59;
		public static int TotalGameTime;
		public static int status;

	}

	public static class GameStateZeroToTripleNineTime {
		public static final int INITIAL_TIME = 2;
		public static int BET_PLACE_TIME = 49;
		public static int GAME_WAIT_TIME = 54;
		public static int GAME_RESULT_TIME = 59;
		public static int TotalGameTime;
		public static int status;

	}

	public static class gameStatePlatMart {

		public static final int INITIAL_TIME = 2;
		public static final int BET_PLACE_TIME = 49;
		public static final int GAME_WAIT_TIME = 54;
		public static final int GAME_RESULT_TIME = 59;
		public static int TotalGameTime;
		public static int status;

	}

	public static class Urls {
		/** live **/
		public static final String BASE_URL = "http://192.168.1.191:8080/";
		/** testing **/
		// public static final String BASE_URL = "http://192.168.1.189:8080/";
		/** developer **/
		// public static final String BASE_URL = "http://192.168.1.189:8090/";
		public static final String PROFILE_IMAGE = BASE_URL + "profile_image";
		public static final String ADMIN_PANEL_URL = "http://205.147.102.6/g/sites/estimationkingdom/admin";
		public static final String ADMIN_IMAGE_URL = "http://205.147.102.6/g/sites/estimationkingdom/uploads/user_images/";
	}

	public static class Events {
		public static final String USER_PROFILE_EVENT = "USER_PROFILE_EVENT";
		public static final String ONLINE_LOBBY_EVENT = "ONLINE_LOBBY_EVENT";
		public static final String TWO_ROULETTE_LOBBY_EVENT = "TWO_ROULETTE_LOBBY_EVENT";
		public static final String THREE_ROULETTE_LOBBY_EVENT = "THREE_ROULETTE_LOBBY_EVENT";
		public static final String SINGLE_ROULETTE_LOBBY_REQUEST = "SINGLE_ROULETTE_LOBBY_REQUEST";
		public static final String DOUBLE_CHANCE_LOBBY_REQUEST = "DOUBLE_CHANCE_LOBBY_REQUEST";

		public static final String ZERO_TO_NINE_ROULETTE_LOBBY_REQUEST = "ZERO_TO_NINE_ROULETTE_LOBBY_REQUEST";

		public static final String LIVETIME = "LIVETIME";
		public static final String LAST_FIVE_GAME_WINNINGNUMBER = "LAST_FIVE_GAME_WINNINGNUMBER";

		public static final String CLEARALL = "CLEARALL";

		public static final String WINNINGNUMBEROFGAME = "WINNINGNUMBEROFGAME";
		public static final String REBET_NUMBERS = "REBET_NUMBERS";
		public static final String GAMERESULTWAITINGSTATE = "GAMERESULTWAITINGSTATE";
		public static final String STATEHANDLER = "STATEHANDLER";
		public static final String SPECIFICCLEAR = "SPECIFICCLEAR";
		public static final String UPDATEUSERCREDITS = "UPDATEUSERCREDITS";
		public static final String REBET_NUMBERS_SINGLECHANCE = "REBET_NUMBERS_SINGLECHANCE";
		public static final String REBET_NUMBERS_PLAYMART = "REBET_NUMBERS_PLAYMART";
		public static final String CLEARALL_SINGLECHANCE = "CLEARALL_SINGLECHANCE";

		public static final String CLEARALL_TRIPLE_CHANCE = "CLEARALL_TRIPLE_CHANCE";
		public static final String REBET_NUMBERS_TRIPLE_CHANCE = "REBET_NUMBERS_TRIPLE_CHANCE";
		public static final String TRIPLE_CHANCE_LOBBY_REQUEST = "TRIPLE_CHANCE_LOBBY_REQUEST";
		public static final String BET_REMOVE_CUSTOMISE_TRIPLE_CHANCE = "BET_REMOVE_CUSTOMISE_TRIPLE_CHANCE";
		public static final String PLAY_MART_LOBBY_REQUEST = "PLAY_MART_LOBBY_REQUEST";

	}

	public static class StaticRooms {

		public static final String ROULETTE_LOBBY = "ROULETTE_LOBBY";
		public static final String ROULETTE_ROOM = "ROULETTE_ROOM";

		public static final String ZERO_TO_NINE_LOBBY_ROOM = "ZERO_TO_NINE_LOBBY_ROOM";

		public static final String SINGLE_ROULETTE_ROOM = "SINGLE_ROULETTE_ROOM";

		public static final String DOUBLE_CHANCE_ROOM = "DOUBLE_CHANCE_ROOM";

		public static final String TRIPLE_CHANCE_ROOM = "TRIPLE_CHANCE_ROOM";

		public static final String PLAY_MART_ROOM = "PLAY_MART_ROOM";

	}

	public static class GameState {
		public static final String INITIAL = "0";
		public static final String BETPLACESTATE = "1";

		public static final String RESULTWAIT = "2";
		public static final String RESULT = "3";
		public static final String EXIT = "4";

	}

	/*
	 * public static class GameStateZeroToNine { public static final String INITIAL
	 * = "0"; public static final String BETPLACESTATE = "1";
	 * 
	 * public static final String RESULTWAIT = "2"; public static final String
	 * RESULT = "3"; public static final String EXIT = "4";
	 * 
	 * }
	 */

	public class OPCode {
		public static final String NONE = "";
		public static final String SUCCESSFULL = "200";
		public static final String LOGIN_ERROR = "201";
		public static final String LOGIN_USER_NAME = "202";
		public static final String LOGIN_USER_PASSWORD = "203";
		public static final String WRONG_PASSWORD = "204";

		public static final String TRIGGER_ERROR = "305";
	}

	public class UserConnectionStatus {
		public static final int NONE = 0;
		public static final int CONNECTED = 1;
		public static final int DISCONNECTED = 2;
		public static final int LEVAED = 3;
	}

	public class DefaultValue {
		public static final String ZERO = "0";
		public static final String NONE = "NONE";
		public static final String BEGINNER_LEVEL = "Beginner";

		public static final int INITIAL = 0;

		public static final String HIGHEST = "highest";
		public static final String LOWEST = "lowest";
	}

	public class LoginStatus {
		public static final int NONE = -1;
		public static final int LOGIN = 1;
		public static final int LOGOUT = 0;
	}

	public class EnableStatus {
		public static final boolean ENABLE = true;
		public static final boolean DISABLE = false;
		public static final String TRUE = "true";
		public static final String FALSE = "false";
	}

	public static class CommandsKey {

		public static final String COMMAND_KEY = "COMMAND_KEY";
		public static final String COMMAND_SINGLE_NUMBER = "COMMAND_SINGLE_NUMBER";
		public static final String COMMAND_EVEN_NUMBER = "COMMAND_EVEN_NUMBER";
		public static final String COMMAND_ODD_NUMBER = "COMMAND_ODD_NUMBER";
		public static final String COMMAND_BLACK_NUMBER = "COMMAND_BLACK_NUMBER";
		public static final String COMMAND_RED_NUMBER = "COMMAND_RED_NUMBER";
		public static final String COMMAND_FIRST_12 = "COMMAND_FIRST_12";
		public static final String COMMAND_SECOND_12 = "COMMAND_SECOND_12";
		public static final String COMMAND_THIRD_12 = "COMMAND_THIRD_12";
		public static final String COMMAND_FIRST_18 = "COMMAND_FIRST_18";
		public static final String COMMAND_SECOND_18 = "COMMAND_SECOND_18";
		public static final String COMMAND_FIRST_ROW = "COMMAND_FIRST_ROW";
		public static final String COMMAND_SECOND_ROW = "COMMAND_SECOND_ROW";
		public static final String COMMAND_THIRD_ROW = "COMMAND_THIRD_ROW";
		public static final String COMMAND_GROUP_2 = "COMMAND_GROUP_2";
		public static final String COMMAND_GROUP_3 = "COMMAND_GROUP_3";
		public static final String COMMAND_GROUP_4 = "COMMAND_GROUP_4";
		public static final String COMMAND_GROUP_6 = "COMMAND_GROUP_6";
		public static final String COMMAND_QUIT = "COMMAND_QUIT";
		public static final String COMMAND_1 = "STRAIGHT UP";
		public static final String BET_NO = "betno";
		public static final String COMMAND_2 = "SPLIT";
		public static final String COMMAND_3 = "STREET";
		public static final String COMMAND_4 = "CORNER";

		public static final int[] _0 = { 0, 1 };
		public static final int[] _00 = { 0, 2 };
		public static final int[] _1 = { 0, 3 };
		public static final int[] _2 = { 1, 2 };
		public static final int[] _3 = { 2, 3 };
		public static final int[] _4 = { 1, 4 };
		public static final int[] _5 = { 2, 5 };
		public static final int[] _6 = { 3, 6 };
		public static final int[] _7 = { 4, 7 };
		public static final int[] _8 = { 5, 8 };
		public static final int[] _9 = { 6, 9 };
		public static final int[] _10 = { 7, 10 };
		public static final int[] _11 = { 8, 11 };
		public static final int[] _12 = { 9, 12 };
		public static final int[] _13 = { 10, 13 };
		public static final int[] _14 = { 11, 14 };
		public static final int[] _15 = { 12, 15 };
		public static final int[] _16 = { 13, 16 };
		public static final int[] _17 = { 14, 17 };
		public static final int[] _18 = { 15, 18 };
		public static final int[] _19 = { 16, 19 };
		public static final int[] _20 = { 17, 20 };
		public static final int[] _21 = { 18, 21 };
		public static final int[] _22 = { 19, 22 };
		public static final int[] _23 = { 20, 23 };
		public static final int[] _24 = { 21, 24 };
		public static final int[] _25 = { 22, 25 };
		public static final int[] _26 = { 23, 26 };
		public static final int[] _27 = { 24, 27 };
		public static final int[] _28 = { 25, 28 };
		public static final int[] _29 = { 26, 29 };
		public static final int[] _30 = { 27, 30 };
		public static final int[] _31 = { 28, 31 };
		public static final int[] _32 = { 29, 32 };
		public static final int[] _33 = { 30, 33 };
		public static final int[] _34 = { 31, 34 };
		public static final int[] _35 = { 32, 35 };
		public static final int[] _36 = { 33, 36 };
		public static final int[] _37 = { 1, 2, 4, 5 };
		public static final int[] _38 = { 2, 3, 5, 6 };
		public static final int[] _39 = { 4, 5, 7, 8 };
		public static final int[] _40 = { 5, 6, 8, 9 };
		public static final int[] _41 = { 7, 8, 10, 11 };
		public static final int[] _42 = { 8, 9, 11, 12 };
		public static final int[] _43 = { 10, 11, 13, 14 };
		public static final int[] _44 = { 11, 12, 14, 15 };
		public static final int[] _45 = { 13, 14, 16, 17 };
		public static final int[] _46 = { 14, 15, 17, 18 };
		public static final int[] _47 = { 16, 17, 19, 20 };
		public static final int[] _48 = { 17, 18, 20, 21 };
		public static final int[] _49 = { 19, 20, 22, 23 };
		public static final int[] _50 = { 20, 21, 23, 24 };
		public static final int[] _51 = { 22, 23, 25, 26 };
		public static final int[] _52 = { 23, 24, 26, 27 };
		public static final int[] _53 = { 25, 26, 28, 29 };
		public static final int[] _54 = { 26, 27, 29, 30 };
		public static final int[] _55 = { 28, 29, 31, 32 };
		public static final int[] _56 = { 29, 30, 32, 33 };
		public static final int[] _57 = { 31, 32, 34, 35 };
		public static final int[] _58 = { 32, 33, 35, 36 };
		public static final int[] _59 = { 1, 2, 3, 4, 5, 6 };
		public static final int[] _60 = { 4, 5, 6, 7, 8, 9 };
		public static final int[] _61 = { 7, 8, 9, 10, 11, 12 };
		public static final int[] _62 = { 10, 11, 12, 13, 14, 15 };
		public static final int[] _63 = { 13, 14, 15, 16, 17, 18 };
		public static final int[] _64 = { 16, 17, 18, 19, 20, 21 };
		public static final int[] _65 = { 19, 20, 21, 22, 23, 24 };
		public static final int[] _66 = { 22, 23, 24, 25, 26, 27 };
		public static final int[] _67 = { 25, 26, 27, 28, 29, 30 };
		public static final int[] _68 = { 25, 26, 27, 28, 29, 30 };
		public static final int[] _69 = { 28, 29, 30, 31, 32, 33 };
		public static final int[] _70 = { 31, 32, 33, 34, 35, 36 };
		public static final int[] _71 = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36 };
		public static final int[] _72 = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35 };
		public static final int[] _73 = { 2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35 };
		public static final int[] _74 = { 1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 36, 34 };
		public static final int[] _75 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
		public static final int[] _76 = { 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 };
		public static final int[] _77 = { 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36 };
		public static final int[] _78 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
		public static final int[] _79 = { 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36 };
		public static final int[] _80 = { 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36 };
		public static final int[] _81 = { 2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35 };
		public static final int[] _82 = { 1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34 };

		public static final String STRING_EVEN_NUMBER = "2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,34,36";
		public static final String STRING_ODD_NUMBER = "1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35";
		public static final String STRING_BLACK_NUMBER = "2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35";
		public static final String STRING_RED_NUMBER = "1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,36,34";
		public static final String STRING_FIRST_12 = "1,2,3,4,5,6,7,8,9,10,11,12";
		public static final String STRING_SECOND_12 = "13,14,15,16,17,18,19,20,21,22,23,24";
		public static final String STRING_THIRD_12 = "25,26,27,28,29,30,31,32,33,34,35,36";
		public static final String STRING_FIRST_18 = "1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18";
		public static final String STRING_SECOND_18 = "19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36";
		public static final String STRING_FIRST_ROW = "3,6,9,12,15,18,21,24,27,30,33,36";
		public static final String STRING_SECOND_ROW = "2,5,8,11,14,17,20,23,26,29,32,35";
		public static final String STRING_THIRD_ROW = "1,4,7,10,13,16,19,22,25,28,31,34";
		public static final String STRING_ZERO_ONE = "0,1";
		public static final String STRING_ZERO_TWO = "0,2";
		public static final String STRING_ZERO_THREE = "0,3";
		public static final String STRING_ONE_TWO = "1,2";
		public static final String STRING_TWO_THREE = "2,3";
		public static final String STRING_ONE_FOUR = "1,4";
		public static final String STRING_TWO_FIVE = "2,5";
		public static final String STRING_THREE_SIX = "3,6";
		public static final String STRING_FOUR_SEVEN = "4,7";
		public static final String STRING_FIVE_EIGHT = "5,8";
		public static final String STRING_SIX_NINE = "6,9";
		public static final String STRING_SEVEN_TEN = "7,10";
		public static final String STRING_EIGHT_ELEVEN = "8,11";
		public static final String STRING_NINE_TWELEVE = "9,12";
		public static final String STRING_TEN_THIRTTEN = "10,13";
		public static final String STRING_ELEVEN_FOURTEEN = "11,14";
		public static final String STRING_TWELEVE_FIFTEEN = "12,15";
		public static final String STRING_THIRDTEEN_SIXTEEN = "13,16";
		public static final String STRING_FOURTEEN_SEVENTEEN = "14,17";
		public static final String STRING_FIFTEEN_EIGHTEEN = "15,18";
		public static final String STRING_SIXTEEN_NINETEEN = "16,19";
		public static final String STRING_SEVENTEEN_TWENTY = "17,20";
		public static final String STRING_EIGHTEEN_TWENTYONE = "18,21";
		public static final String STRING_NINETEEN_TWENTYTWO = "19,22";
		public static final String STRING_TWENTY_TWENTYTHREE = "20,23";
		public static final String STRING_TWENTYONE_TWENTYFOUR = "21,24";
		public static final String STRING_TWENTYTWO_TWENTYFIVE = "22,25";
		public static final String STRING_TWENTYTHREE_TWENTYSIX = "23,26";
		public static final String STRING_TWENTYFOUR_TWENTYSEVEN = "24,27";
		public static final String STRING_TWENTYFIVE_TWENTYEIGHT = "25,28";
		public static final String STRING_TWENTYSIX_TWENTYNINE = "26,29";
		public static final String STRING_TWENTYSEVEN_THIRDTY = "27,30";
		public static final String TWENTYEIGHT_THIRDTYONE = "28,31";
		public static final String STRING_TWENTYNINE_THIRDTYTWO = "29,32";
		public static final String STRING_THIRDTY_THIRDTYTHREE = "30,33";
		public static final String STRING_THIRDTYONE_THIRDTYFOUR = "31,34";
		public static final String STRING_THIRDTYTWO__THIRDTYFIVE = "32,35";
		public static final String STRING_THIRDTYTHREE_THIRDTYSIX = "33,36";
		public static final String STRING_ONE_TWO_FOUR_FIVE = "1,2,4,5";
		public static final String STRING_TWO_THREE_FIVE_SIX = "2,3,5,6";
		public static final String STRING_FOUR_FIVE_SEVEN_EIGHT = "4,5,7,8";
		public static final String STRING_FIVE_SIX_EIGHT_NINE = "5,6,8,9";
		public static final String STRING_SEVEN_EIGHT_TEN_ELEVEN = "7,8,10,11";
		public static final String STRING_EIGHT_ELEVEN_NINE_TWELEVE = "8,9,11,12";
		public static final String STRING_TEN_ELEVEN_THIRDEEN_FOURTEEN = "10,11,13,14";
		public static final String STRING_ELEVEN_TEVELVE_FOURTEEN_FIFTEEN = "11,12,14,15";
		public static final String STRING_THIRDEEN_FOURTEEN_SIXTEEN_SEVENTEEN = "13,14,16,17";
		public static final String STRING_FOURTEEN_FIFTEEN_SEVENTEEN_EIGHTEEN = "14,15,17,18";
		public static final String SIXTEEN_SEVENTEEN_NINETEEN_TWENTY = "16,17,19,20";
		public static final String STRING_SEVENTEEN_EIGHTEEN_TWENTY_TWENTYONE = "17,18,20,21";
		public static final String STRING_NINETEEN_TWENTY_TWENTYTWO_TWENTYTHREE = "19,20,22,23";
		public static final String STRING_TWENTY_TWENTYONE_TWENTYTHREE_TWENTYFOUR = "20,21,23,24";
		public static final String STRING_TWENTYTWO_TWENTYTHREE_TWENTYFIVE_TWENTYSIX = "22,23,25,26";
		public static final String STRING_TWENTYTHREE_TWENTYFOUR_TWENTYSIX_TWENTYSEVEN = "23,24,26,27";
		public static final String STRING_TWENTYFIVE_TWENTYSIX_TWENTYEIGHT_TWENTYNINE = "25,26,28,29";
		public static final String STRING_TWENTYSIX_TWENTYSEVEN_TWENTYNINE_THIRDTY = "26,27,29,30";
		public static final String STRING_TWENTYEIGHT_TWENTYNINE_THIRDTYONE_THIRDTYTWO = "28,29,31,32";
		public static final String STRING_TWENTYNINE_THIRDTY_THIRDTYTWO_THIRDTYTHREE = "29,30,32,33";
		public static final String STRING_THIRDTYONE_THIRDTYTWO_THIRDTYFOUR_THIRDTYFIVE = "31,32,34,35";
		public static final String STRING_THIRDTYTWO_THIRDTYTHREE_THIRDTYFIVE_THIRDTYSIX = "32,33,35,36";

	}

	public static class GameFormat {

		public static final String ROOM_NAME = "EK%05d";

		public static final String ROUND_1 = "RO1%05d";
		public static final String ROUND_2 = "RO2%05d";
		public static final String ROUND_3 = "RO3%05d";
		public static final String ROUND_4 = "RO4%05d";
		public static final String ROUND_5 = "RO5%05d";
		public static final String ROUND_6 = "RO6%05d";
		public static final String ROUND_7 = "RO7%05d";
		public static final String ROUND_8 = "RO8%05d";
		public static final String ROUND_9 = "RO9%05d";
		public static final String ROUND_10 = "RO10%05d";
		public static final String ROUND_11 = "RO11%05d";
		public static final String ROUND_12 = "RO12%05d";
		public static final String ROUND_13 = "RO13%05d";
		public static final String ROUND_14 = "RO14%05d";
		public static final String ROUND_15 = "RO15%05d";
		public static final String ROUND_16 = "RO16%05d";
		public static final String ROUND_17 = "RO17%05d";
		public static final String ROUND_18 = "RO18%05d";

	}

	public static class Trigger {
		public static final String ID = "ID";
		public static final String NAME = "NAME";
		public static final String RESULT = "RESULT";
		public static final String OPCODE = "OPCODE";
		public static final String MESSAGE = "MESSAGE";
		public static final String USER_ADD = "USER_ADD";
		public static final String DATA = "DATA";
		public static final String ADD_USER_CHIPS = "ADD_USER_CHIPS";
		public static final String USER_BLOCKED = "USER_BLOCKED";
		public static final String UPDATE_STATUS_SHAREPOINT = "UPDATE_STATUS_SHAREPOINT";
		public static final String UPDATE_TIMER = "UPDATE_TIMER";
		public static final String CURRENTTIME = "CURRENTTIME";
		public static final String CURRENT_SESSION_DATA = "CURRENT_SESSION_DATA";
		public static final String CURRENT_USER_ID = "CURRENT_USER_ID";
		public static final String UPDATE_MACHINE_STATUS = "UPDATE_MACHINE_STATUS";
		public static final String ZERO_TO_NINE_CURRENT_SESSION_DATA = "ZERO_TO_NINE_CURRENT_SESSION_DATA";
		public static final String ZERO_TO_DOUBLE_NINE_CURRENT_SESSION_DATA = "ZERO_TO_DOUBLE_NINE_CURRENT_SESSION_DATA";
		public static final String ZERO_TO_TRIPLE_NINE_CURRENT_SESSION_DATA = "ZERO_TO_TRIPLE_NINE_CURRENT_SESSION_DATA";

	}

}