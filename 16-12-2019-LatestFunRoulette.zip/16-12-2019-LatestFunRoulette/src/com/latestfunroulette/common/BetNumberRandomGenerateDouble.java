package com.latestfunroulette.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.dubliRoulette.cache.beans.SessionBean;
import com.latestfunroulette.extension.GameMainExtension;

public class BetNumberRandomGenerateDouble {

	static HashMap<Integer, String[]> hashMapBetValues = new HashMap<Integer, String[]>();

	static List<String> numberList = new ArrayList<String>();
	static HashMap<Integer, HashMap<Integer, String[]>> hashmapkey = new HashMap<Integer, HashMap<Integer, String[]>>();

	static double winAmountFactorDouble = 90;
	static double winAmountFactorTriple = 900;

	private BetNumberRandomGenerateDouble() {

	}

	public static void init() {

		for (int i = 0; i <= 99; i++) {

			if (i < 10) {
				numberList.add("0" + String.valueOf(i));
			} else {
				numberList.add(String.valueOf(i));
			}

		}
	}

	public static String[] fiveNumberGenerate(String userid, String sessionId, double coins, int limit, int tablenumber,
			String tabletype, int gameid) {

		try {
			Collections.shuffle(numberList);

			ArrayList<String> list = new ArrayList<String>();

			for (int i = 0; i < limit; i++) {
				// Random rand = new Random();

				String totalnumber = numberList.get(i);
				list.add(totalnumber);
				Utils.Logger(GameMainExtension.extension,"totalnumber::::::::::::::::::::::" + totalnumber);

				double winAmount = coins * winAmountFactorDouble;

				SessionBean tempGameSessionBean = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
						.getValueByKey(sessionId);

				if (tempGameSessionBean == null) {

					Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    ");

				} else {

					Utils.Logger(GameMainExtension.extension,
							"BetNumbers:::::DOUBLE ROULETTE::::::::::::::::::::::::::::::::::::::::::Double Chance::tempGameSessionBean: is not null::::::::::    "
									+ tempGameSessionBean.getTotalBetAmount());

					tempGameSessionBean.addUserBet(userid, sessionId, coins, totalnumber, winAmount, tabletype, gameid);

				}
			}

			hashMapBetValues.put(limit, list.stream().toArray(String[]::new));

		} catch (Exception e) {
			Utils.Logger(GameMainExtension.extension,
					"Triple chance ::::::::::::::::::fiveNumberGenerate::::::::::error" + e);
		}

		return hashMapBetValues.get(limit);
	}

}
