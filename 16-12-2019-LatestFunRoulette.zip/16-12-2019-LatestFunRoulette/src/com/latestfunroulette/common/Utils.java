package com.latestfunroulette.common;

import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class Utils {

	public static void Logger(SFSExtension pExtension, Object pMessage) {

		pExtension.trace(new Object[] { "\n\n KHELO JEETO = " + pMessage + "\n\n" });
	}

	public static void ErrorLogger(SFSExtension pExtension, Object pMessage) {
		pExtension.trace(new Object[] { "\n\n KHELO JEETO ERROR = " + pMessage + "\n\n" });
	}

	public static void ErrorLogger(SFSExtension pExtension, String pMessage, Exception pException) {
		try {
			String error = pMessage + " \t " + pException.getMessage() + " \t " + pException.getClass().getName()
					+ "\n";
			for (StackTraceElement ste : pException.getStackTrace()) {
				error += ste.toString() + "\n";
			}
			pExtension.trace(new Object[] { "\n\n KHELO JEETO ERROR = " + error + "\n\n" });
		} catch (Exception e2) {
			Utils.ErrorLogger(pExtension, "IBaseCommon PrintError :::: " + e2.toString());
		}
	}

	public static boolean isGuestUser(String pUserName) {
		synchronized (pUserName) {
			if (pUserName.isEmpty() || pUserName.toLowerCase().contains("trial")
					|| pUserName.toLowerCase().contains("guest")) {
				return true;
			}
			return false;
		}
	}

	public static void SleepThread(long pTime) {
		try {
			Thread.sleep(pTime);
		} catch (InterruptedException e) {
			Utils.ErrorLogger(GameMainExtension.extension, "Utils :::: SleepThread :::: ", e);
		}
	}

}
