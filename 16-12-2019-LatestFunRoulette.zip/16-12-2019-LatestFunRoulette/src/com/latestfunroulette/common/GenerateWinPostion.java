package com.latestfunroulette.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.extensions.SFSExtension;

/**
 * @author Akasy
 *
 */
public class GenerateWinPostion {

	private static GenerateWinPostion instance = null;
	//private WeakReference<SFSExtension> ref_extension = null;
	private static List<String> winPositionList = new ArrayList<>();
	private static String currentWinPosition = "0";
	
	public GenerateWinPostion(SFSExtension extension) {
		//ref_extension = new WeakReference<SFSExtension>(extension);
	}
	
	public static GenerateWinPostion getInstance(SFSExtension extension) {
		if (instance == null) {
			instance = new GenerateWinPostion(extension);
		}
		return instance;
	}
	
	public void generateWinPostionList() {
		for (int i = 0; i < 38; i++) {
			if(i==0) {
				winPositionList.add("00");
			}
			else {
				winPositionList.add(String.valueOf(i-1));
			}
			
		}
		print("GenerateWinPositionList  ::: List :::: "+winPositionList.toString());
	}
	
	public synchronized String generateWinPosition() {
		
		List<String> currentWinPositionList = new ArrayList<>();
		currentWinPositionList.addAll(winPositionList);
		Collections.shuffle(currentWinPositionList);

		/*
		 * List<String> getLastFiveWinPosition = DBManager.getLastFiveWinPosition();
		 * print("GenerateWinPositionList  ::: List :::: "+winPositionList.toString());
		 * print("GenerateWinPosition :::: LastFiveWinPosition ::::: List :::: "
		 * +getLastFiveWinPosition.toString());
		 * 
		 * for (int i = 0; i < getLastFiveWinPosition.size(); i++) { String number =
		 * getLastFiveWinPosition.get(i); int index =
		 * currentWinPositionList.indexOf(number);
		 * print(" GetCurrentWinPosition :::: "+currentWinPositionList.indexOf(number));
		 * if (index != -1) currentWinPositionList.remove(index);
		 * 
		 * 
		 * 
		 * }
		 */
		currentWinPosition = currentWinPositionList.get(0);

		print(" RouletteCroneExtention::::::::: GenerateWinPosition ::::: WinPosition ::: "+currentWinPosition);
		
		return currentWinPosition;
	}
	
	public String getCurrentWinPosition() {
		print(" GetCurrentWinPosition :::: "+currentWinPosition);
		return currentWinPosition;
	}
	
	
	public void print(String msg) {
		Utils.Logger(GameMainExtension.extension, "GenerateWinPosition :::::::: "+msg);
	}
	
}
