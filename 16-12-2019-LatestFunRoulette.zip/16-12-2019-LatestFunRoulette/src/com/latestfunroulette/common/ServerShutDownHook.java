package com.latestfunroulette.common;


import com.smartfoxserver.v2.extensions.SFSExtension;

public class ServerShutDownHook {

	public ServerShutDownHook(SFSExtension pExtension) {
		ShutdownHookThread tempThread = new ShutdownHookThread();
		Runtime.getRuntime().addShutdownHook(tempThread);
	}

	class ShutdownHookThread extends Thread {

		public ShutdownHookThread() {
		}

		public void run() {

			DBManager.logoutAllUsersOnServerShutDown(new CallBack() {
				@Override
				public void call(Object... values) {

				}
			});

			//DBManager.updateGlobalId(GameMainExtension.globlaId.getCurrentId());

		}
	}
}