
package com.latestfunroulette.common;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

import org.apache.http.util.TextUtils;
import org.apache.log4j.PropertyConfigurator;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.latestfunroulette.cache.beans.AvatarBean;
import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.cache.beans.RouletteBetBeans;
import com.latestfunroulette.cache.beans.UserBetBean;
import com.latestfunroulette.common.Constants.GameStateTime;
import com.latestfunroulette.common.Constants.GameStateZeroToDoubleNineTime;
import com.latestfunroulette.common.Constants.GameStateZeroToNineTime;
import com.latestfunroulette.common.Constants.GameStateZeroToTripleNineTime;
import com.latestfunroulette.common.Constants.Message;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.Constants.Urls;
import com.latestfunroulette.common.Constants.UserConnectionStatus;
import com.latestfunroulette.extension.GameMainExtension;
import com.mongodb.BasicDBObject;
import com.mongodb.BasicDBObjectBuilder;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class DBManager {

	private static Connection tempconnection;
	static GameBean gameBean = new GameBean();
	private static SFSExtension extension;
	private static Zone zone;

	public static void DBInit(SFSExtension tempextension, Zone tempzone) {
		if (extension == null || zone == null) {
			extension = tempextension;
			zone = tempzone;
		}
	}

	public static void updateExtension(SFSExtension tempextension) {
		if (extension != null) {
			extension = tempextension;
		}
	}

	public static void updateZone(Zone tempzone) {
		if (zone != null) {
			zone = tempzone;
		}
	}

	public static void closeConnection() {
		try {
			getConnection().close();
			Utils.Logger(extension, " Database Connection Close ");
		} catch (SQLException e) {
			Utils.ErrorLogger(extension, e);
		}
	}

	private static Connection getConnection() {

		if (extension == null || zone == null)
			return null;

		try {
			if (tempconnection == null || tempconnection.isClosed()) {
				tempconnection = extension.getParentZone().getDBManager().getConnection();
				Utils.Logger(extension, tempconnection);
			}
		} catch (SQLException e) {
			Utils.ErrorLogger(extension, " Database Connection Error = ", e);
		}

		return tempconnection;
	}

	private static MongoClient getMongoConnection() {

		MongoClient mongo = new MongoClient("172.105.52.243", 27017);

		MongoCredential credential = MongoCredential.createCredential("kuser", "khelojeeto",
				"3tYsbRN!5GH".toCharArray());

		// MongoDatabase database = mongo.getDatabase("khelojeeto");
		Utils.Logger(extension, "Connected to the database successfully:::::::::::" + "credential" + credential);

		return mongo;

	}

	@SuppressWarnings("deprecation")
	private static DB getMongoDB() {
		return getMongoConnection().getDB("khelojeeto");
	}

	private static void closeMongoDb() {

		getMongoConnection().close();
	}

	private static void CloseResult_And_Statement(ResultSet pResultSet, CallableStatement pStatement) {

		new Thread() {
			@Override
			public void run() {
				try {
					if (pResultSet != null)
						pResultSet.close();
					if (pStatement != null)
						pStatement.close();
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "CloseResult_And_Statement Error = ", e);
				}
			}
		}.start();
	}

	public static int getAvatarId(String loginid) {
		int avatarId = 0;
		ResultSet tempresultset = null;
		CallableStatement tempstatement = null;
		try {
			String getAvatarId = "{call getAvatarId(?)}";
			tempstatement = getConnection().prepareCall(getAvatarId);
			tempstatement.setString(1, loginid);
			tempresultset = tempstatement.executeQuery();
			if (tempresultset != null) {
				while (tempresultset.next()) {
					avatarId = tempresultset.getInt("avatarId");
				}
			}

		} catch (SQLException e) {
			Utils.ErrorLogger(extension, "DBManager getAvatarId Error = " + e);
		} finally {
			CloseResult_And_Statement(tempresultset, tempstatement);

		}
		return avatarId;
	}

	public static void getAllAvatars() {

		new Thread() {
			@Override
			public void run() {
				ResultSet tempresultset = null;
				CallableStatement tempstatement = null;
				try {
					String allusers = "{call getAllAvatars()}";
					tempstatement = getConnection().prepareCall(allusers);
					tempresultset = tempstatement.executeQuery();
					if (tempresultset != null) {
						while (tempresultset.next()) {

							int avatarid = tempresultset.getInt("avatarid");
							String avatarurl = tempresultset.getString("avatarurl");
							boolean status = tempresultset.getBoolean("status");

							AvatarBean tempavatarbean = new AvatarBean();
							tempavatarbean.setAvatarid(String.valueOf(avatarid));
							tempavatarbean.setAvatar_url(avatarurl);
							tempavatarbean.setEnable(status);

							GameMainExtension.cache.getAvatar().add(tempavatarbean);
						}
					}
					Utils.Logger(extension, " :::: DBManager Get All Avatars :::: ");
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager Get All Avatars Error = ", e);
				} finally {
					CloseResult_And_Statement(tempresultset, tempstatement);

				}

			}
		}.start();

	}

	public static void customRegistration(Player pPlayer, CallBack pCallBack) {

		Utils.Logger(extension, "customRegistration::::::::::::" + pPlayer.toString());

		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {

					String customregistartion = "{call registration(?,?,?,?,?,?,?,?,?)}";
					tempStatement = getConnection().prepareCall(customregistartion);
					tempStatement.setString(1, pPlayer.getName());
					tempStatement.setString(2, pPlayer.getUsername());
					tempStatement.setString(3, pPlayer.getEmailid());
					tempStatement.setString(4, pPlayer.getPassword());
					tempStatement.setString(5, pPlayer.getUserType());
					tempStatement.setString(6, pPlayer.getDeviceId());
					tempStatement.setString(7, pPlayer.getDeviceType());
					tempStatement.setString(8, pPlayer.getMobileno());
					tempStatement.setString(9, pPlayer.getIpaddress());

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						String status = tempResultSet.getString("status");
						String message = tempResultSet.getString("message");

						if (status.equalsIgnoreCase("true")) {
							String userid = tempResultSet.getString("userid");
							String image = tempResultSet.getString("avatarurl") != null
									? tempResultSet.getString("avatarurl")
									: "";
							String chips = tempResultSet.getString("credits");
							String mobileno = tempResultSet.getString("phone");

							pPlayer.setUserid(userid);
							pPlayer.setImage(image);
							pPlayer.setChips(chips);
							pPlayer.setMobileno(mobileno);

							GameMainExtension.cache.getPlayer().add(pPlayer);

						}
						pCallBack.call(status, message);
					}

				} catch (SQLException e) {
					pCallBack.call("false", Message.TRY_AGAIN);
					Utils.ErrorLogger(extension, "DBManager ::::: CustomRegistartion :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void customLogin(Player pPlayer, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {
					String customlogin = "{call customlogin1(?,?,?,?,?)}";
					tempStatement = getConnection().prepareCall(customlogin);
					tempStatement.setString(1, pPlayer.getEmailid());
					tempStatement.setString(2, pPlayer.getPassword());
					tempStatement.setString(3, pPlayer.getDeviceId());
					tempStatement.setString(4, pPlayer.getDeviceType());
					tempStatement.setString(5, pPlayer.getIpaddress());

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						String status = tempResultSet.getString("status");
						String message = tempResultSet.getString("message");

						if (status.equalsIgnoreCase("true")) {
							String userid = tempResultSet.getString("userid");
							String name = tempResultSet.getString("name");
							String userType = tempResultSet.getString("usertype");
							String image = tempResultSet.getString("avatarurl");

							String chips = tempResultSet.getString("credits");
							String mobileno = tempResultSet.getString("phone");
							int login_status = tempResultSet.getInt("login");

							int blockStatus = tempResultSet.getInt("block_status");
							String userGameType = tempResultSet.getString("userGameType");
							String assignedGames = tempResultSet.getString("assignedGames");

							pPlayer.setUserid(userid);
							pPlayer.setChips(chips);
							pPlayer.setUserBlockStatus(blockStatus);
							pPlayer.setName(name);
							pPlayer.setLoginStatus(login_status);

							pPlayer.setUserType(userType);
							pPlayer.setImage(image);

							pPlayer.setChips(chips);
							pPlayer.setMobileno(mobileno);

							// pPlayer.setLossChips(losschips);

							pPlayer.setConnectionStatus(UserConnectionStatus.CONNECTED);
							pPlayer.setUserBlockStatus(blockStatus);
							pPlayer.setUserGameType(userGameType);
							pPlayer.setAssignedgames(assignedGames);

							GameMainExtension.cache.getPlayer().add(pPlayer);
						}
						pCallBack.call(status, message);
					}

				} catch (SQLException e) {
					pCallBack.call("false", Message.TRY_AGAIN);
					Utils.ErrorLogger(extension, "DBManager :::: CustomLogin1 :::: Error :::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void customSfsLogin(Player pPlayer, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String customlogin = "{call customsfslogin(?)}";
					tempStatement = getConnection().prepareCall(customlogin);
					tempStatement.setString(1, pPlayer.getEmailid());
					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						String status = tempResultSet.getString("status");
						String message = tempResultSet.getString("message");

						if (status.equalsIgnoreCase("true")) {
							String userid = tempResultSet.getString("userid");
							String name = tempResultSet.getString("name");
							String userType = tempResultSet.getString("usertype");
							String image = tempResultSet.getString("avatarurl");

							String chips = tempResultSet.getString("credits");
							String mobileno = tempResultSet.getString("phone");
							int login_status = tempResultSet.getInt("login");

							int blockStatus = tempResultSet.getInt("block_status");

							pPlayer.setUserid(userid);
							pPlayer.setChips(chips);
							pPlayer.setUserBlockStatus(blockStatus);
							pPlayer.setName(name);
							pPlayer.setLoginStatus(login_status);

							pPlayer.setUserType(userType);

							/*
							 * if (userType.equalsIgnoreCase(UserType.BOT)) {
							 * pPlayer.setBot(EnableStatus.ENABLE); }
							 */
							pPlayer.setImage(image);

							pPlayer.setChips(chips);
							pPlayer.setMobileno(mobileno);

							// pPlayer.setLossChips(losschips);

							pPlayer.setConnectionStatus(UserConnectionStatus.CONNECTED);
							pPlayer.setUserBlockStatus(blockStatus);

							GameMainExtension.cache.getPlayer().add(pPlayer);
						}
						pCallBack.call(status, message);
					}

				} catch (SQLException e) {
					pCallBack.call("false", Message.TRY_AGAIN);
					Utils.ErrorLogger(extension, "DBManager :::: CustomLogin :::: Error :::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void guestUserLogin(Player pPlayer, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String guestlogin = "{call guestlogin(?,?,?,?)}";
					tempStatement = getConnection().prepareCall(guestlogin);
					tempStatement.setString(1, pPlayer.getUserType());
					tempStatement.setString(2, pPlayer.getDeviceId());
					tempStatement.setString(3, pPlayer.getDeviceType());
					tempStatement.setString(4, pPlayer.getIpaddress());

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {

						String status = tempResultSet.getString("status");
						String message = tempResultSet.getString("message");

						if (status.equalsIgnoreCase("true")) {
							String userid = tempResultSet.getString("userid");
							String name = tempResultSet.getString("name");

							String image = tempResultSet.getString("avatarurl");
							String chips = tempResultSet.getString("credits");
							String mobileno = tempResultSet.getString("phone");

							int blockStatus = tempResultSet.getInt("block_status");

							pPlayer.setUserid(userid);
							pPlayer.setName(name);
							pPlayer.setUsername("");
							pPlayer.setImage(image);
							pPlayer.setChips(chips);
							pPlayer.setMobileno(mobileno);
							pPlayer.setUserBlockStatus(blockStatus);

							GameMainExtension.cache.getPlayer().add(pPlayer);
						}
						pCallBack.call(status, message);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::: GuestUserLogin ::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();
	}

	public static void updateguestlogin(Player pPlayer, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String sociallogin = "{call updateguestlogin(?,?,?,?,?,?,?,?,?,?,?)}";
					tempStatement = getConnection().prepareCall(sociallogin);
					tempStatement.setString(1, pPlayer.getUserid());
					tempStatement.setString(2, pPlayer.getName());
					tempStatement.setString(3, pPlayer.getUsername());
					tempStatement.setString(4, pPlayer.getEmailid());
					tempStatement.setString(5, pPlayer.getMobileno());
					tempStatement.setString(6, pPlayer.getSocialId());
					tempStatement.setString(7, pPlayer.getUserType());
					tempStatement.setString(8, pPlayer.getDeviceId());
					tempStatement.setString(9, pPlayer.getDeviceType());
					tempStatement.setString(10, pPlayer.getImage());
					tempStatement.setString(11, pPlayer.getIpaddress());

					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						String status = tempResultSet.getString("status");
						String message = tempResultSet.getString("message");

						if (status.equalsIgnoreCase("true")) {
							String userid = tempResultSet.getString("userid");
							// String name = tempResultSet.getString("name");
							String name = tempResultSet.getString("name") != null ? tempResultSet.getString("name")
									: "";
							String username = tempResultSet.getString("username");
							String socialid = tempResultSet.getString("social_id");
							String image = tempResultSet.getString("image");
							String chips = tempResultSet.getString("credits");
							String mobileno = tempResultSet.getString("phone");
							int blockStatus = tempResultSet.getInt("block_status");

							if (image.contains("profile_image")) {
								image = Urls.BASE_URL + image;
							}

							pPlayer.setUserid(userid);
							pPlayer.setName(name);
							pPlayer.setUsername(username);
							pPlayer.setSocialId(socialid);
							pPlayer.setImage(image);
							pPlayer.setChips(chips);
							pPlayer.setMobileno(mobileno);
							pPlayer.setUserBlockStatus(blockStatus);

							GameMainExtension.cache.getPlayer().add(pPlayer);
						}
						pCallBack.call(status, message);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::: updateguestlogin ::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void socialLogin(Player pPlayer, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String sociallogin = "{call sociallogin(?,?,?,?,?,?,?,?,?,?)}";
					tempStatement = getConnection().prepareCall(sociallogin);

					tempStatement.setString(1, pPlayer.getName());
					tempStatement.setString(2, pPlayer.getUsername());
					tempStatement.setString(3, pPlayer.getEmailid());
					tempStatement.setString(4, pPlayer.getMobileno());
					tempStatement.setString(5, pPlayer.getSocialId());
					tempStatement.setString(6, pPlayer.getUserType());
					tempStatement.setString(7, pPlayer.getDeviceId());
					tempStatement.setString(8, pPlayer.getDeviceType());
					tempStatement.setString(9, pPlayer.getImage());
					tempStatement.setString(10, pPlayer.getIpaddress());

					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						String status = tempResultSet.getString("status");
						String message = tempResultSet.getString("message");

						if (status.equalsIgnoreCase("true")) {
							String userid = tempResultSet.getString("userid");
							// String name = tempResultSet.getString("name");
							String name = tempResultSet.getString("name") != null ? tempResultSet.getString("name")
									: "";
							String username = tempResultSet.getString("username");
							String socialid = tempResultSet.getString("social_id");
							String image = tempResultSet.getString("image");
							String chips = tempResultSet.getString("credits");
							String mobileno = tempResultSet.getString("phone");
							int blockStatus = tempResultSet.getInt("block_status");

							if (image.contains("profile_image")) {
								image = Urls.BASE_URL + image;
							}

							pPlayer.setUserid(userid);
							pPlayer.setName(name);
							pPlayer.setUsername(username);
							pPlayer.setSocialId(socialid);
							pPlayer.setImage(image);
							pPlayer.setChips(chips);
							pPlayer.setMobileno(mobileno);
							pPlayer.setUserBlockStatus(blockStatus);

							GameMainExtension.cache.getPlayer().add(pPlayer);
						}
						pCallBack.call(status, message);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::: SocialLogin ::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void getUserDetailByLoginId(String userid, User user, CallBack callBack) {

		Utils.Logger(extension, "DbManager:::::::::::::::getUserDetailByLoginId::::::::::::::::::useird" + userid);
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String userdetailbyloginid = "{call getuserdetailbyloginid(?)}";
					tempStatement = getConnection().prepareCall(userdetailbyloginid);
					tempStatement.setString(1, userid);

					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {

						String status = tempResultSet.getString("status");
						String message = tempResultSet.getString("message");

						ISFSObject tempSFSObj = null;

						if (status.equalsIgnoreCase("true")) {
							Player tempPlay = null;
							if ((tempPlay = GameMainExtension.cache.getPlayer().getValueByKey(userid)) == null) {
								tempPlay = new Player();
								tempPlay.setUserid(userid);
								GameMainExtension.cache.getPlayer().add(tempPlay);
							}

							String usertype = tempResultSet.getString("usertype");
							String userid = tempResultSet.getString("userid");
							String name = tempResultSet.getString("name");

							String chips = tempResultSet.getString("credits");
							String image = tempResultSet.getString("avatarurl");
							String mobileno = tempResultSet.getString("phone");
							String deviceid = tempResultSet.getString("device_id");
							String devicetype = tempResultSet.getString("devicetype");
							int blockStatus = tempResultSet.getInt("block_status");

							tempPlay.setUserType(usertype);
							tempPlay.setUserid(userid);
							tempPlay.setName(name);
							tempPlay.setChips(chips);

							tempPlay.setMobileno(mobileno);
							tempPlay.setDeviceId(deviceid);
							tempPlay.setDeviceType(devicetype);
							tempPlay.setUser(user);

							tempPlay.setUserBlockStatus(blockStatus);

							if (usertype.equalsIgnoreCase(Param.CUSTOM)) {

							} else if (usertype.equalsIgnoreCase(Param.FACEBOOK)) {
								String socialid = tempResultSet.getString("social_id");
								tempPlay.setSocialId(socialid);
								if (image.contains("profile_image"))
									image = Urls.BASE_URL + image;
							} else if (usertype.equalsIgnoreCase(Param.GOOGLE)) {
								String socialid = tempResultSet.getString("social_id");
								tempPlay.setSocialId(socialid);
								if (image.contains("profile_image"))
									image = Urls.BASE_URL + image;
							}

							tempPlay.setImage(image);

							tempSFSObj = tempPlay.toSFS();
							tempSFSObj.putUtfString(Param.STATUS, status);
							tempSFSObj.putUtfString(Param.MESSAGE, message);
							callBack.call(tempPlay);
							Utils.Logger(extension, tempPlay.toProfileSFS().getDump());
							CommonEvents.sendUserDetails(tempPlay, extension.getApi().getUserByName(userid));
						} else {
							tempSFSObj = new SFSObject();
							tempSFSObj.putUtfString(Param.STATUS, status);
							tempSFSObj.putUtfString(Param.MESSAGE, message);
						}
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::: GetUserDetailByLoginId ::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();
	}

	public static void userLogout(String userId, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				String logoutQuery = "{call logout(?)}";

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					tempStatement = getConnection().prepareCall(logoutQuery);
					tempStatement.setString(1, userId);
					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						String login = tempResultSet.getString("status");

						String logoutMessage = tempResultSet.getString("msg");
						ISFSObject obj = new SFSObject();
						obj.putUtfString(Param.STATUS, login);
						obj.putUtfString(Param.MESSAGE, logoutMessage);

						pCallBack.call(obj);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::userLogout  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::userLogout  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void updateUserLoginStatus(Player pPlayer) {

		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String allusers = "{call updateLoginStatus(?,?)}";
					Connection tempconnection = DBManager.getConnection();
					tempStatement = tempconnection.prepareCall(allusers);
					tempStatement.setString(1, pPlayer.getUserid());
					if (pPlayer.getConnectionStatus() == UserConnectionStatus.CONNECTED) {
						tempStatement.setString(2, "1");
					} else if (pPlayer.getConnectionStatus() == UserConnectionStatus.DISCONNECTED) {
						tempStatement.setString(2, "0");
					}

					ResultSet tempresultset = tempStatement.executeQuery();
					if (tempresultset != null) {
						while (tempresultset.next()) {

						}
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager updateUserLoginStatus Error = " + e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public synchronized static void logout(String pUserLoginId) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {
					String logout = "{call logout(?)}";
					tempStatement = getConnection().prepareCall(logout);
					tempStatement.setString(1, pUserLoginId);
					tempStatement.executeQuery();
					CloseResult_And_Statement(null, tempStatement);
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager :::: Logout :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public synchronized static void updateGlobalId(int id) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String logout = "{call updateGlobalId(?)}";
					tempStatement = getConnection().prepareCall(logout);
					tempStatement.setInt(1, id);
					tempStatement.executeQuery();
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager :::: updateGlobalId :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public synchronized static void logoutAllUsersOnServerShutDown(CallBack callBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					Utils.Logger(extension, "DBManager :::: logoutAllUsersOnServerShutDown :::: ");
					String logout = "{call logoutAllUsersOnServerShutDown()}";
					tempStatement = getConnection().prepareCall(logout);
					ResultSet rs = tempStatement.executeQuery();
					rs.next();
					String result = rs.getString("result");
					callBack.call(result);
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager :::: logoutAllUsersOnServerShutDown :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void existEmail(String emailid, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					if (emailid != null) {
						if (!emailid.isEmpty()) {
							String existemailid = "{call checkemailid(?)}";
							tempStatement = getConnection().prepareCall(existemailid);
							tempStatement.setString(1, emailid);
							String pwd = null;
							tempResultSet = tempStatement.executeQuery();
							if (tempResultSet != null && tempResultSet.next()) {
								String status = tempResultSet.getString("status");
								String message = tempResultSet.getString("message");
								if (status.equalsIgnoreCase("true")) {

									pwd = tempResultSet.getString("password");
									String playerName = tempResultSet.getString("name");

									Utils.Logger(extension, "New Generated Password IS::" + pwd);
									new EmailHandler().send(emailid, pwd, playerName);
								}
								pCallBack.call(status, message);
							}
						}
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::: ExistEmail ::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void updateUserAvatar(String loginId, String avatarId, User pUser, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String updateavatar = "{call updateavatar(?,?)}";
					tempStatement = getConnection().prepareCall(updateavatar);
					tempStatement.setString(1, loginId);
					tempStatement.setString(2, avatarId);
					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						String status = tempResultSet.getString("status");
						String message = tempResultSet.getString("message");
						if (status.equalsIgnoreCase("true")) {
							String imageUrl = tempResultSet.getString("profile_image");

							Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(loginId);
							if (tempPlayer.getUserBlockStatus() == 0) {
								if (tempPlayer.getUserType().equalsIgnoreCase(Param.GOOGLE)
										|| tempPlayer.getUserType().equalsIgnoreCase(Param.FACEBOOK)) {
									imageUrl = Urls.BASE_URL + imageUrl;
								}
								tempPlayer.setImage(imageUrl);

							} else {
								status = "false";
								message = "You are blocked. You can't update avatar !";
								CommonEvents.sendUserIsBlockedEvent(tempPlayer, pUser);
							}
							CommonEvents.sendUserDetails(tempPlayer, extension.getApi().getUserByName(loginId));
						}
						pCallBack.call(status, message);
					}
				} catch (SQLException e) {
					pCallBack.call("false", Message.TRY_AGAIN);
					Utils.ErrorLogger(extension, "DBManager :::: UpdateUserAvatar ::::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void updateProfile(User pUser, String name, CallBack pCallback) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String updateprofile = "{call updateprofile(?,?)}";
					tempStatement = getConnection().prepareCall(updateprofile);
					tempStatement.setString(1, pUser.getName());
					tempStatement.setString(2, name);

					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {

						String status = tempResultSet.getString("status");
						String message = tempResultSet.getString("message");

						if (status.equalsIgnoreCase("true")) {
							String tempname = tempResultSet.getString("name");
							String temppassword = tempResultSet.getString("password");

							Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(pUser.getName());
							if (tempPlayer.getUserBlockStatus() == 0) {
								tempPlayer.setName(tempname);
								tempPlayer.setPassword(temppassword);

								CommonEvents.sendUserDetails(tempPlayer, pUser);
							} else {
								status = "false";
								message = "You are blocked. You can't update profile !";
								CommonEvents.sendUserIsBlockedEvent(tempPlayer, pUser);
							}
						}

						pCallback.call(status, message);
					}

				} catch (SQLException e) {
					pCallback.call("false", Message.TRY_AGAIN);
					Utils.ErrorLogger(extension, "DBManager :::: UpdateProfile ::::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();
	}

	public static void resetPassword(String loginid, String oldpassword, String newpassword, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {
					String resetpwd = "{call resetpassword(?,?,?)}";
					tempStatement = getConnection().prepareCall(resetpwd);
					tempStatement.setString(1, loginid);
					tempStatement.setString(2, oldpassword);
					tempStatement.setString(3, newpassword);

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						String status = tempResultSet.getString("status");
						String message = tempResultSet.getString("message");
						String update_pwd = null;
						if (status.equalsIgnoreCase("true")) {
							update_pwd = tempResultSet.getString("update_pwd");
							Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(loginid);
							if (tempPlayer.getUserBlockStatus() == 0) {
								tempPlayer.setPassword(update_pwd);
							} else {

							}
						}
						pCallBack.call(status, message, update_pwd);
					}
				} catch (SQLException e) {
					pCallBack.call("false", Message.TRY_AGAIN);
					Utils.ErrorLogger(extension, "DBManager :::::  ResetPassword ::: Error :: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void userStatus(String userId, CallBack pCallBack) {
		new Thread() {

			@Override
			public void run() {

				// ISFSObject obj = new SFSObject();
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String playerGameInfoQuery = "call fetch_play_game_info(?)";
					tempStatement = getConnection().prepareCall(playerGameInfoQuery);
					tempStatement.setString(1, userId);
					tempResultSet = tempStatement.executeQuery();
					ISFSObject tempSFSObj = null;

					GameBean gameBean = new GameBean();
					if (tempResultSet.next()) {

						String result = tempResultSet.getString("result");
						if (result.equalsIgnoreCase("true")) {
							String credits = tempResultSet.getString("credits");
							String session_id = tempResultSet.getString("gamesessionid");

							gameBean.setCredits(credits);
							gameBean.setSession_id(session_id);

							tempSFSObj = gameBean.toSFS();
							tempSFSObj.putUtfString(Param.STATUS, result);

							GameMainExtension.cache.getGames().add(gameBean);

							Utils.Logger(extension, "fetchplaygmaeinfo::::::::::::" + gameBean);
							pCallBack.call(tempSFSObj);

						}
					}
					pCallBack.call(tempSFSObj);
				}

				catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::userStatus  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::userStatus  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();

	}

	public static void getGlobalId(CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				synchronized (this) {
					ResultSet tempResultSet = null;
					CallableStatement tempStatement = null;
					try {
						String globalid = "{call getglobalid()}";
						tempStatement = getConnection().prepareCall(globalid);
						tempResultSet = tempStatement.executeQuery();
						if (tempResultSet != null && tempResultSet.next()) {
							int tempGlobalid = tempResultSet.getInt("id");
							pCallBack.call(tempGlobalid);
						} else {
							pCallBack.call(1);
						}
					} catch (SQLException e) {
						pCallBack.call(1);
						Utils.ErrorLogger(extension, "DBManager :::::  getGlobalId ::: Error :: ", e);
					} catch (Exception e) {
						pCallBack.call(1);
						Utils.ErrorLogger(extension, "DBManager :::::  getGlobalId ::: Error :: ", e);
					} finally {
						CloseResult_And_Statement(tempResultSet, tempStatement);

					}
				}
			}
		}.start();
	}

	public static void getGlobalIdDoubleChance(CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				synchronized (this) {
					ResultSet tempResultSet = null;
					CallableStatement tempStatement = null;
					try {
						String globalid = "{call getglobalidDoubleChance()}";
						tempStatement = getConnection().prepareCall(globalid);
						tempResultSet = tempStatement.executeQuery();
						if (tempResultSet != null && tempResultSet.next()) {
							int tempGlobalid = tempResultSet.getInt("id");
							pCallBack.call(tempGlobalid);
						} else {
							pCallBack.call(1);
						}
					} catch (SQLException e) {
						pCallBack.call(1);
						Utils.ErrorLogger(extension, "DBManager :::::  getGlobalId ::: Error :: ", e);
					} catch (Exception e) {
						pCallBack.call(1);
						Utils.ErrorLogger(extension, "DBManager :::::  getGlobalId ::: Error :: ", e);
					} finally {
						CloseResult_And_Statement(tempResultSet, tempStatement);

					}
				}
			}
		}.start();
	}

	public static void getGlobalIdTripleChance(CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				synchronized (this) {
					ResultSet tempResultSet = null;
					CallableStatement tempStatement = null;
					try {
						String globalid = "{call getglobalidTripleChance()}";
						tempStatement = getConnection().prepareCall(globalid);
						tempResultSet = tempStatement.executeQuery();
						if (tempResultSet != null && tempResultSet.next()) {
							int tempGlobalid = tempResultSet.getInt("id");
							pCallBack.call(tempGlobalid);
						} else {
							pCallBack.call(1);
						}
					} catch (SQLException e) {
						pCallBack.call(1);
						Utils.ErrorLogger(extension, "DBManager :::::  getGlobalId ::: Error :: ", e);
					} catch (Exception e) {
						pCallBack.call(1);
						Utils.ErrorLogger(extension, "DBManager :::::  getGlobalId ::: Error :: ", e);
					} finally {
						CloseResult_And_Statement(tempResultSet, tempStatement);

					}
				}
			}
		}.start();
	}

	public static void UpdateLiveTimePlay(int currentSessionid, int wheelno, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String UpdateAllRecords = "{call UpdateLiveTimePlay(?,?)}";
					tempStatement = getConnection().prepareCall(UpdateAllRecords);
					tempStatement.setInt(1, currentSessionid);
					tempStatement.setInt(2, wheelno);

					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						int oldsessionid = tempResultSet.getInt("oldsessionid");
						int jackport = tempResultSet.getInt("jackport");
						pCallBack.call(oldsessionid, jackport);

					}
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager :::::::: UpdateLiveTimePlay :::: Error :::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void UpdateLiveTimePlayDoubleChance(int currentsession, String wheelno, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String UpdateAllRecords = "{call UpdateLiveTimePlayDoubleChance(?,?)}";
					tempStatement = getConnection().prepareCall(UpdateAllRecords);
					tempStatement.setInt(1, currentsession);
					tempStatement.setString(2, wheelno);

					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						int oldsessionid = tempResultSet.getInt("oldsessionid");
						int jackport = tempResultSet.getInt("jackport");
						pCallBack.call(oldsessionid, jackport);

					}
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager :::::::: UpdateLiveTimePlayDoubleChance :::: Error :::: ",
							e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void UpdateLiveTimePlayTripleChance(int currentsession, String wheelno, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String UpdateAllRecords = "{call UpdateLiveTimePlayTripleChance(?,?)}";
					tempStatement = getConnection().prepareCall(UpdateAllRecords);
					tempStatement.setInt(1, currentsession);
					tempStatement.setString(2, wheelno);

					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						int oldsessionid = tempResultSet.getInt("oldsessionid");
						int jackport = tempResultSet.getInt("jackport");
						pCallBack.call(oldsessionid, jackport);

					}
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager :::::::: UpdateLiveTimePlayTripleChance :::: Error :::: ",
							e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void UpdateLiveTimePlayPlayMart(int currentsession, String wheelno, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String UpdateAllRecords = "{call UpdateLiveTimePlayPlayMart(?,?)}";
					tempStatement = getConnection().prepareCall(UpdateAllRecords);
					tempStatement.setInt(1, currentsession);
					tempStatement.setString(2, wheelno);

					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						int oldsessionid = tempResultSet.getInt("oldsessionid");
						int jackport = tempResultSet.getInt("jackport");
						pCallBack.call(oldsessionid, jackport);

					}
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager :::::::: UpdateLiveTimePlayPlayMart :::: Error :::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void sendSessionIdOfRullete(String userid, CallBack pCallBack) {
		new Thread() {

			@Override
			public void run() {

				ResultSet rst = null;
				CallableStatement tempStatement = null;
				try {
					String lastfivewinningnumber = "";
					String jackport = "";

					String fetchSessionIdQuery = "call sendSessionIdOfRullete(?)";
					tempStatement = getConnection().prepareCall(fetchSessionIdQuery);
					tempStatement.setString(1, userid);
					rst = tempStatement.executeQuery();
					if (rst != null && rst.next()) {
						String session_id = rst.getString("sessionid");
						String status = rst.getString("result");
						String resultwheel = rst.getString("presultwheel");
						String credits = (rst.getString("currentcredits") == null ? "0"
								: rst.getString("currentcredits"));

						Utils.Logger(extension, "credits::::::::::::::" + credits);

						lastfivewinningnumber = rst.getString("winPosition");
						Utils.Logger(extension, "DBManager :::::: SendSessionIdOfRullete :::::::: Session :::: "
								+ session_id + "wheel" + resultwheel);
						String oldsessionid = rst.getString("oldsessionid");
						jackport = rst.getString("jackport");

						Utils.Logger(extension, "getLastFiveWinPosition" + "currentsessionid" + session_id
								+ "winningnumber" + resultwheel + "oldsessionid" + oldsessionid);

						while (rst.next()) {

							lastfivewinningnumber = lastfivewinningnumber + "," + rst.getString("winPosition");
							jackport = jackport + "," + rst.getString("jackport");

							Utils.Logger(extension,
									"getLastFiveWinPosition::::::::::::resultant Last 5 data" + lastfivewinningnumber);

						}

						pCallBack.call(session_id, status, resultwheel, credits, lastfivewinningnumber, oldsessionid,
								jackport);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::sendSessionIdOfRullete :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::sendSessionIdOfRullete :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(rst, tempStatement);
				}
			}
		}.start();
	}

	public static void insertLiveRouletteBets(String pSession, UserBetBean pUserBets, GameBean tempgamebBean) {

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String insertliveroulettebets = "call insertliveroulettebets1(?,?,?,?)";
					tempStatement = getConnection().prepareCall(insertliveroulettebets);

					tempStatement.setString(1, pUserBets.getUserId());
					tempStatement.setString(2, pSession);
					tempStatement.setString(3, pUserBets.getTotalBetAmount().toString());
					tempStatement.setInt(4, pUserBets.getGameId());

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						String updatedbalance = tempResultSet.getString("credits");
						String ticketid = tempResultSet.getString("ticketid");
						String drawtime = tempResultSet.getString("drawtime");
						String tickettimer = tempResultSet.getString("tickettimer");
						int gameid = tempResultSet.getInt("pgameid");

						ISFSObject isfsObject = new SFSObject();
						isfsObject.putUtfString(Param.CURRENT_SCORE, updatedbalance);

						tempgamebBean.setCredits(updatedbalance);
						tempgamebBean.setTicketid(ticketid);
						tempgamebBean.setDrawtime(drawtime);
						tempgamebBean.setTickettimer(tickettimer);
						tempgamebBean.setGameid(gameid);

						insertrouletteDataMongo(pSession, pUserBets, updatedbalance);
						dataInsertMongoWithoutSplit(pSession, pUserBets);

						Utils.Logger(extension, "DBManager:::::::::::::::insertLiveRouletteBets:::::::::isfsobject"
								+ isfsObject.getDump());
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: insertLiveRouletteBets() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void insertZeroToNineRoulettesql(String pSession,
			com.latestfunroulette.ZerotoNineRoulette.cache.beans.UserBetBean pUserBets, int isclaim,
			com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean tempBean) {

		String betamount = pUserBets.getTotalBetAmount();
		Utils.Logger(extension, "DBManager :::: insertZeroToNineRoulettesql() :::: Session Id :::  " + pSession
				+ "totalbetamount:::::::::::" + betamount);

		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {

			String insertliveroulettebets = "call insertliveroulettebetsZeroToNine(?,?,?,?,?,?)";
			tempStatement = getConnection().prepareCall(insertliveroulettebets);

			tempStatement.setString(1, pUserBets.getUserId());
			tempStatement.setString(2, pSession);
			tempStatement.setString(3, betamount);
			tempStatement.setInt(4, pUserBets.getGameId());
			tempStatement.setInt(5, isclaim);
			tempStatement.setInt(6, tempBean.getJackport());

			tempResultSet = tempStatement.executeQuery();

			if (tempResultSet != null && tempResultSet.next()) {

				String updatedbalance = tempResultSet.getString("credits");
				String ticketid = tempResultSet.getString("ticketid");
				String drawtime = tempResultSet.getString("drawtime");
				String tickettimer = tempResultSet.getString("tickettimer");
				int gameid = tempResultSet.getInt("pgameid");

				ISFSObject isfsObject = new SFSObject();
				isfsObject.putUtfString(Param.CURRENT_SCORE, updatedbalance);
				isfsObject.putUtfString(Param.TICKETID, ticketid);
				tempBean.setCredits(updatedbalance);
				tempBean.setTicketid(ticketid);
				tempBean.setDrawtime(drawtime);
				tempBean.setTickettimer(tickettimer);
				tempBean.setGameid(gameid);

				// GameMainExtension.gameCacheZeroToNine.getGames().add(tempBean);

				// insertZeroToNineRoulettemongo(pSession, pUserBets, updatedbalance, tempBean);
				dataInsertMongoWithoutSplitZeroToNine(pSession, pUserBets, tempBean);

				Utils.Logger(extension, "DBManager:::::::::::::::insertliveroulettebetsZeroToNine:::::::::isfsobject"
						+ isfsObject.getDump() + " tempgamebean::::::::::::::" + tempBean.toString());
			}
		} catch (SQLException e) {
			Utils.ErrorLogger(extension, "DBManager ::::: insertliveroulettebetsZeroToNine() :::: Error :::  ", e);
		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

		}

	}

	/*
	 * public static void insertZeroToNineRoulettePrintDataSql(String pSession,
	 * com.latestfunroulette.ZerotoNineRoulette.cache.beans.UserBetBean pUserBets,
	 * int isclaim, String ticket_id) {
	 * 
	 * Utils.Logger(extension,
	 * "DBManager :::: insertZeroToNineRoulettesql() :::: Session Id :::  " +
	 * pSession);
	 * 
	 * // Room tempRoom = extension.getParentZone().getRoomByName(roomname);
	 * 
	 * new Thread() {
	 * 
	 * @Override public void run() {
	 * 
	 * ResultSet tempResultSet = null; CallableStatement tempStatement = null;
	 * String updatedbalance = ""; try {
	 * 
	 * String insertliveroulettebets =
	 * "call insertliveroulettebetsZeroToNine(?,?,?,?,?,?)"; tempStatement =
	 * getConnection().prepareCall(insertliveroulettebets);
	 * 
	 * tempStatement.setString(1, pUserBets.getUserId()); tempStatement.setString(2,
	 * pSession); tempStatement.setString(3, pUserBets.getTotalBetAmount());
	 * tempStatement.setInt(4, pUserBets.getGameId()); tempStatement.setInt(5,
	 * isclaim); tempStatement.setString(6, ticket_id);
	 * 
	 * tempResultSet = tempStatement.executeQuery();
	 * 
	 * if (tempResultSet != null && tempResultSet.next()) { updatedbalance =
	 * tempResultSet.getString("credits"); ISFSObject isfsObject = new SFSObject();
	 * isfsObject.putUtfString(Param.CURRENT_SCORE, updatedbalance);
	 * 
	 * insertZeroToNineRoulettemongo(pSession, pUserBets, updatedbalance);
	 * 
	 * Utils.Logger(extension,
	 * "dbmanager :::::::::::::::::::::::::insertZeroToNineRoulettePrintDataSql::::::::::::gameBean"
	 * + gameBean.toString());
	 * 
	 * Utils.Logger(extension,
	 * "DBManager:::::::::::::::insertLiveRouletteBets:::::::::isfsobject" +
	 * isfsObject.getDump() + "gamebean::::::::::::::::::::" + gameBean.toString());
	 * }
	 * 
	 * } catch (SQLException e) { Utils.ErrorLogger(extension,
	 * "DBManager ::::: insertZeroToNineRoulettesql() :::: Error :::  ", e); }
	 * finally { CloseResult_And_Statement(tempResultSet, tempStatement);
	 * 
	 * }
	 * 
	 * } }.start();
	 * 
	 * }
	 */

	public static void insertTripleNineRoulettesql(String pSession,
			com.latestfunroulette.TripleRoulette.cache.beans.UserBetBean pUserBets) {

		Utils.Logger(extension, "DBManager :::: insertTripleNineRoulettesql() :::: Session Id :::  " + pSession);

		new Thread() {
			@Override
			public void run() {

				ResultSet rs = null;
				CallableStatement tempStatement = null;
				try {
					Utils.Logger(extension,
							"DBManager :::: insertTripleNineRoulettesql() ::::::::Userbetbean" + pUserBets.toString());

					String insertliveroulettebets = "call insertliveroulettebets1(?,?,?)";
					tempStatement = getConnection().prepareCall(insertliveroulettebets);

					tempStatement.setString(1, pUserBets.getUserId());
					tempStatement.setString(2, pSession);
					tempStatement.setString(3, pUserBets.getTotalBetAmount());

					rs = tempStatement.executeQuery();

					if (rs != null && rs.next()) {
						String updatedbalance = rs.getString("credits");
						ISFSObject isfsObject = new SFSObject();
						isfsObject.putUtfString(Param.CURRENT_SCORE, updatedbalance);

						gameBean.setCredits(updatedbalance);

						Utils.Logger(extension, "DBManager:::::::::::::::insertTripleNineRoulettesql:::::::::isfsobject"
								+ isfsObject.getDump());
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: insertTripleNineRoulettesql() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(rs, tempStatement);
				}

			}
		}.start();

	}

	public static void insertPlayMartsql(String pSession,
			com.latestfunroulette.playMart.cache.beans.UserBetBean pUserBets, int claims,
			com.latestfunroulette.playMart.cache.beans.GameBean tempgameBean) {

		Utils.Logger(extension, "DBManager :::: insertPlayMartsql() :::: Session Id :::  " + pSession);

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String insertliveroulettebets = "call insertliveroulettebetsplaymart(?,?,?,?,?)";
					tempStatement = getConnection().prepareCall(insertliveroulettebets);

					tempStatement.setString(1, pUserBets.getUserId());
					tempStatement.setString(2, pSession);
					tempStatement.setString(3, pUserBets.getTotalBetAmount());
					tempStatement.setInt(4, pUserBets.getGameId());
					tempStatement.setInt(5, tempgameBean.getJackport());

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						String updatedbalance = tempResultSet.getString("credits");
						String ticketid = tempResultSet.getString("ticketid");
						ISFSObject isfsObject = new SFSObject();
						isfsObject.putUtfString(Param.CURRENT_SCORE, updatedbalance);
						isfsObject.putUtfString(Param.TICKETID, ticketid);

						tempgameBean.setCredits(updatedbalance);
						tempgameBean.setTicketid(ticketid);

						insertPlayMartmongo(pSession, pUserBets, updatedbalance);

						Utils.Logger(extension,
								"DBManager:::::::::::::::insertPlayMartsql:::::::::isfsobject" + isfsObject.getDump());
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: insertPlayMartsql() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void newInsertSession(String userId, String SessionId, CallBack pCallBack) {
		Utils.Logger(extension, "DBManager :::: rebetInsertliveupdateHistory :::: User Id :::: " + userId
				+ " session_id  " + SessionId);

		new Thread() {
			@Override
			public void run() {
				ISFSObject isfsObject = new SFSObject();
				ResultSet rs = null;
				CallableStatement tempStatement = null;
				try {

					String fetchquery = "call rebetInsertBet(?,?)";
					tempStatement = getConnection().prepareCall(fetchquery);
					tempStatement.setString(1, userId);
					tempStatement.setString(2, SessionId);
					rs = tempStatement.executeQuery();
					if (rs != null && rs.next()) {
						String result = rs.getString("result");
						String dbresult = rs.getString("dbresult");

						isfsObject.putUtfString("result", result);
						isfsObject.putUtfString("dbresult", dbresult);

						pCallBack.call(isfsObject);
					}
				} catch (Exception e) {
					pCallBack.call(isfsObject);
					Utils.ErrorLogger(extension, "DBManager :::: rebetInsertliveupdateHistory :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(rs, tempStatement);
				}
			}
		}.start();
	}

	public static int winningNumber() {

		int wheel = -1;
		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {

			List<Integer> list = new ArrayList<>();

			String winminnumber = "{call getminbetnumber()}";

			tempStatement = getConnection().prepareCall(winminnumber);
			// tempStatement.setString(1, String.valueOf(sessionid));

			tempResultSet = tempStatement.executeQuery();
			if (tempResultSet != null && tempResultSet.next()) {

				String status = tempResultSet.getString("status");

				Utils.Logger(extension, "winningNumber::::::::::::::::status" + status);

				if (status.equalsIgnoreCase("true")) {

					String winnumber = (tempResultSet.getString("win_number"));
					wheel = (tempResultSet.getInt("win_number"));
					Utils.Logger(extension, "DBManager::::::::::wheel" + wheel);
					if (winnumber.equals("00")) {
						list.add(0);
					} else {
						list.add((wheel) + 1);
					}

					Collections.shuffle(list);
					Utils.Logger(extension, "DBManager:::::winningNumber::::list" + list.toString());

					if (list.get(0) == 0) {
						wheel = (list.get(0));
					} else {
						wheel = (list.get(0));
					}

					Utils.Logger(extension, "getWinMinNumber" + wheel);
				} else {

					for (int i = 0; i < 38; i++) {

						if (i == 0) {
							list.add((i));
						} else {
							list.add((i - 1));
						}

					}
				}
				Utils.Logger(extension, "RouletteCroneExtension:::::updateAvgAmount::::list" + list.toString());

				Utils.Logger(extension, "DBManager:::::winningNumber:::::::::list" + list.toString());

				Collections.shuffle(list);
				Utils.Logger(extension, ":::::DBManager:::::winningNumber::::list" + list);
				if (list.get(0) == 0) {
					wheel = (list.get(0));
				} else {
					wheel = (list.get(0));
				}
				Utils.Logger(extension, ":::::DBManager:::::winningNumber::::win_number" + wheel);

			}

		} catch (Exception e) {
			Utils.ErrorLogger(extension, ":::::::::::error:::::" + e);
		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

			;
		}

		return wheel;

	}

	public static int winningNumberZeroToNine() {

		Utils.Logger(extension,
				"DBmanager :::::::::::::::::winningNumberZeroToNine:::::::::::::::::::winningNumber::::::::::::::::sessionid");

		int wheel = -1;
		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {

			List<Integer> list = new ArrayList<>();

			String winminnumber = "{call getminbetnumber()}";

			tempStatement = getConnection().prepareCall(winminnumber);

			tempResultSet = tempStatement.executeQuery();
			if (tempResultSet != null && tempResultSet.next()) {

				String status = tempResultSet.getString("status");

				Utils.Logger(extension,
						"DBmanager :::::::::::::::::winningNumberZeroToNine::::::::::::::::::::winningNumber::::::::::::::::status"
								+ status);

				if (status.equalsIgnoreCase("true")) {

					// String winnumber = (tempResultSet.getString("win_number"));
					wheel = (tempResultSet.getInt("win_number"));
					Utils.Logger(extension, "DBManager::::::::::wheel" + wheel);

					list.add((wheel) + 1);

					Collections.shuffle(list);
					Utils.Logger(extension, "DBManager:::::winningNumber::::list" + list.toString());

					if (list.get(0) == 0) {
						wheel = (list.get(0));
					} else {
						wheel = (list.get(0));
					}

					Utils.Logger(extension, "getWinMinNumber" + wheel);
				} else {

					for (int i = 0; i < 10; i++) {

						list.add((i));
					}

				}
			}
			Utils.Logger(extension, "RouletteCroneExtension:::::updateAvgAmount::::list" + list.toString());

			Utils.Logger(extension, "DBManager:::::winningNumber:::::::::list" + list.toString());

			Collections.shuffle(list);
			Utils.Logger(extension, ":::::DBManager:::::winningNumber::::list" + list);

			wheel = (list.get(0));

			Utils.Logger(extension, ":::::DBManager:::::winningNumber::::win_number" + wheel);

		} catch (Exception e) {
			Utils.ErrorLogger(extension, ":::::::::::error:::::" + e);
		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

			;
		}

		return wheel;

	}

	public static String winningNumberDoubleChance() {

		String wheel = "-1";
		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {

			List<String> list = new ArrayList<>();

			String winminnumber = "{call getminbetnumber()}";

			tempStatement = getConnection().prepareCall(winminnumber);
			// tempStatement.setString(1, String.valueOf(sessionid));

			tempResultSet = tempStatement.executeQuery();
			if (tempResultSet != null && tempResultSet.next()) {

				String status = tempResultSet.getString("status");

				Utils.Logger(extension,
						"DBmanager :::::::::::::::::winningNumberZeroToNine::::::::::::::::::::winningNumber::::::::::::::::status"
								+ status);

				if (status.equalsIgnoreCase("true")) {

					// String winnumber = (tempResultSet.getString("win_number"));
					wheel = (tempResultSet.getString("win_number"));
					Utils.Logger(extension, "DBManager::::::::::wheel" + wheel);

					list.add(String.valueOf((wheel) + 1));

					Collections.shuffle(list);
					Utils.Logger(extension, "DBManager:::::winningNumber::::list" + list.toString());

					if (list.get(0).equalsIgnoreCase("0")) {
						wheel = (list.get(0));
					} else {
						wheel = (list.get(0));
					}

					Utils.Logger(extension, "getWinMinNumber" + wheel);
				} else {

					Random rand = new Random();

					// Generate random integers in range 0 to 999
					int rand_int1 = rand.nextInt(9);
					int rand_int2 = rand.nextInt(9);

					list.add(String.valueOf(String.valueOf(rand_int1) + String.valueOf(rand_int2)));

				}

			}

			Utils.Logger(extension, "RouletteCroneExtension:::::updateAvgAmount::::list" + list.toString());

			Utils.Logger(extension, "DBManager:::::winningNumber:::::::::list" + list.toString());

			Collections.shuffle(list);
			Utils.Logger(extension, ":::::DBManager:::::winningNumber::::list" + list);

			wheel = (list.get(0));

			Utils.Logger(extension, ":::::DBManager:::::winningNumber::::win_number" + wheel);
		} catch (Exception e) {
			Utils.ErrorLogger(extension, ":::::::::::error:::::" + e);
		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

			;
		}

		return wheel;

	}

	public static String ThreeRoulettewinningNumber() {

		String wheel = "-1";
		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {

			List<String> list = new ArrayList<>();

			String winminnumber = "{call getminbetnumber()}";

			tempStatement = getConnection().prepareCall(winminnumber);
			// tempStatement.setString(1, String.valueOf(sessionid));

			tempResultSet = tempStatement.executeQuery();
			if (tempResultSet != null && tempResultSet.next()) {

				String status = tempResultSet.getString("status");

				Utils.Logger(extension,
						"DBmanager :::::::::::::::::winningNumberZeroToNine::::::::::::::::::::winningNumber::::::::::::::::status"
								+ status);

				if (status.equalsIgnoreCase("true")) {

					// String winnumber = (tempResultSet.getString("win_number"));
					wheel = (tempResultSet.getString("win_number"));
					Utils.Logger(extension, "DBManager::::::::::wheel" + wheel);

					list.add(String.valueOf((wheel) + 1));

					Collections.shuffle(list);
					Utils.Logger(extension, "DBManager:::::winningNumber::::list" + list.toString());

					if (list.get(0).equalsIgnoreCase("0")) {
						wheel = (list.get(0));
					} else {
						wheel = (list.get(0));
					}

					Utils.Logger(extension, "getWinMinNumber" + wheel);
				} else {

					Random rand = new Random();

					// Generate random integers in range 0 to 999
					int rand_int1 = rand.nextInt(9);
					int rand_int2 = rand.nextInt(9);
					int rand_int3 = rand.nextInt(9);

					String totalwinningnumber = (String.valueOf(rand_int1) + String.valueOf(rand_int2)
							+ String.valueOf(rand_int3));

					list.add((totalwinningnumber));

				}

				Utils.Logger(extension, "DBManager:::::winningNumber:::::::::list" + list.toString());

				Collections.shuffle(list);
				Utils.Logger(extension, ":::::DBManager:::::winningNumber::::list" + list);
				if (list.get(0).equals("0")) {
					wheel = (list.get(0));
				} else {
					wheel = (list.get(0));
				}
				Utils.Logger(extension, ":::::DBManager:::::winningNumber::::win_number" + wheel);

			}

		} catch (Exception e) {
			Utils.ErrorLogger(extension, ":::::::::::error:::::" + e);
		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

			;
		}

		return wheel;

	}

	public static int winningNumberPlayMart() {

		int wheel = -1;
		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {

			List<Integer> list = new ArrayList<>();

			String winminnumber = "{call getminbetnumber()}";

			tempStatement = getConnection().prepareCall(winminnumber);
			// tempStatement.setString(1, String.valueOf(sessionid));

			tempResultSet = tempStatement.executeQuery();
			if (tempResultSet != null && tempResultSet.next()) {

				String status = tempResultSet.getString("status");

				Utils.Logger(extension,
						"DBmanager :::::::::::::::::winningNumberPlayMart::::::::::::::::::::winningNumber::::::::::::::::status"
								+ status);

				if (status.equalsIgnoreCase("true")) {

					// String winnumber = (tempResultSet.getString("win_number"));
					wheel = (tempResultSet.getInt("win_number"));
					Utils.Logger(extension, "DBManager::::::::::wheel" + wheel);

					list.add((wheel) + 1);

					Collections.shuffle(list);
					Utils.Logger(extension, "DBManager:::::winningNumber::::list" + list.toString());

					if (list.get(0) == 0) {
						wheel = (list.get(0));
					} else {
						wheel = (list.get(0));
					}

					Utils.Logger(extension, "getWinMinNumber" + wheel);
				} else {

					for (int i = 0; i < 12; i++) {

						list.add((i));
					}

				}
			}
			Utils.Logger(extension, "RouletteCroneExtension:::::updateAvgAmount::::list" + list.toString());

			Utils.Logger(extension, "DBManager:::::winningNumber:::::::::list" + list.toString());

			Collections.shuffle(list);
			Utils.Logger(extension, ":::::DBManager:::::winningNumber::::list" + list);

			wheel = (list.get(0));

			Utils.Logger(extension, ":::::DBManager:::::winningNumber::::win_number" + wheel);

		} catch (Exception e) {
			Utils.ErrorLogger(extension, ":::::::::::error:::::" + e);
		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

			;
		}

		return wheel;

	}

	public static void getLastFiveNumber(String loginid, CallBack pCallBack) {

		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {
			String lastfivewinningnumber = "";
			String jackport = "";

			String fiveWinPosition = "{call getLastFiveWinPosition(?)}";
			tempStatement = getConnection().prepareCall(fiveWinPosition);
			tempStatement.setString(1, loginid);
			tempResultSet = tempStatement.executeQuery();
			if (tempResultSet != null && tempResultSet.next()) {
				ISFSObject isfsObject = new SFSObject();

				String status = tempResultSet.getString("result");
				String credits = tempResultSet.getString("usercredits");
				String mininner = tempResultSet.getString("mininner");
				String maxinner = tempResultSet.getString("maxinner");
				String minouter = tempResultSet.getString("minouter");
				String maxouter = tempResultSet.getString("maxouter");

				if (status.equalsIgnoreCase("true")) {
					String currentsessionid = tempResultSet.getString("currentsessionid");
					String winningnumber = tempResultSet.getString("winnernum");
					// String livetime = tempResultSet.getString("livetime");
					lastfivewinningnumber = tempResultSet.getString("winPosition");
					jackport = tempResultSet.getString("jackport");

					Utils.Logger(extension, "getLastFiveWinPosition" + "currentsessionid" + currentsessionid
							+ "winningnumber" + winningnumber + "lastfivewinningnumber" + lastfivewinningnumber);

					while (tempResultSet.next()) {

						lastfivewinningnumber = lastfivewinningnumber + "," + tempResultSet.getString("winPosition");
						jackport = jackport + "," + tempResultSet.getString("jackport");

						Utils.Logger(extension,
								"getLastFiveWinPosition::::::::::::resultant Last 5 data" + lastfivewinningnumber);

						isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
						isfsObject.putUtfString(Param.JACKPORT, jackport);
					}

					isfsObject.putUtfString(Param.SESSION_ID, currentsessionid);
					isfsObject.putUtfString(Param.STATUS, status);

					isfsObject.putUtfString(Param.WINNINGNUMBER, winningnumber);
					isfsObject.putUtfString(Param.CREDITS, credits);
					isfsObject.putUtfString(Param.MININNER, mininner);
					isfsObject.putUtfString(Param.MAXINNER, maxinner);
					isfsObject.putUtfString(Param.MINOUTER, minouter);
					isfsObject.putUtfString(Param.MAXOUTER, maxouter);

					// isfsObject.putUtfString(Param.TIMER, livetime);

					Utils.Logger(extension, "isfsobject" + isfsObject.getDump());

					pCallBack.call(isfsObject);
				}

			}
		} catch (Exception e) {

			Utils.ErrorLogger(extension, "DBManager :::::::: getLastFiveWinPosition :::: Error :::: ", e);

		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

			;
		}
	}

	public static void getLastFiveNumberDoubleNine(String loginid, CallBack pCallBack) {

		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {
			String lastfivewinningnumber = "";
			String jackport = "";
			String fiveWinPosition = "{call getLastFiveWinPositionDoubleNine(?)}";
			tempStatement = getConnection().prepareCall(fiveWinPosition);
			tempStatement.setString(1, loginid);
			tempResultSet = tempStatement.executeQuery();
			if (tempResultSet != null && tempResultSet.next()) {
				ISFSObject isfsObject = new SFSObject();

				String status = tempResultSet.getString("result");
				String credits = tempResultSet.getString("usercredits");

				if (status.equalsIgnoreCase("true")) {
					String currentsessionid = tempResultSet.getString("currentsessionid");
					String winningnumber = tempResultSet.getString("winnernum");
					// String livetime = tempResultSet.getString("livetime");
					lastfivewinningnumber = tempResultSet.getString("winPosition");
					jackport = tempResultSet.getString("jackport");

					Utils.Logger(extension, "getLastFiveWinPosition" + "currentsessionid" + currentsessionid
							+ "winningnumber" + winningnumber + "lastfivewinningnumber" + lastfivewinningnumber);

					while (tempResultSet.next()) {

						lastfivewinningnumber = lastfivewinningnumber + "," + tempResultSet.getString("winPosition");
						jackport = jackport + "," + tempResultSet.getString("jackport");

						Utils.Logger(extension,
								"getLastFiveWinPosition::::::::::::resultant Last 5 data" + lastfivewinningnumber);

						isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
						isfsObject.putUtfString(Param.JACKPORT, jackport);
					}

					isfsObject.putUtfString(Param.SESSION_ID, currentsessionid);
					isfsObject.putUtfString(Param.STATUS, status);

					isfsObject.putUtfString(Param.WINNINGNUMBER, winningnumber);
					isfsObject.putUtfString(Param.CREDITS, credits);

					// isfsObject.putUtfString(Param.TIMER, livetime);

					Utils.Logger(extension, "isfsobject" + isfsObject.getDump());

					pCallBack.call(isfsObject);
				}
			}
		} catch (Exception e) {

			Utils.ErrorLogger(extension, "DBManager :::::::: getLastFiveWinPosition :::: Error :::: ", e);

		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

			;
		}
	}

	public static void getLastFiveNumberTripleNine(String loginid, CallBack pCallBack) {

		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {
			String lastfivewinningnumber = "";
			String jackport = "";

			String fiveWinPosition = "{call getLastFiveWinPositionTripleNine(?)}";
			tempStatement = getConnection().prepareCall(fiveWinPosition);
			tempStatement.setString(1, loginid);
			tempResultSet = tempStatement.executeQuery();
			if (tempResultSet != null && tempResultSet.next()) {
				ISFSObject isfsObject = new SFSObject();

				String status = tempResultSet.getString("result");
				String credits = tempResultSet.getString("usercredits");

				if (status.equalsIgnoreCase("true")) {
					String currentsessionid = tempResultSet.getString("currentsessionid");
					String winningnumber = tempResultSet.getString("winnernum");
					// String livetime = tempResultSet.getString("livetime");
					lastfivewinningnumber = tempResultSet.getString("winPosition");
					jackport = tempResultSet.getString("jackport");

					Utils.Logger(extension, "getLastFiveWinPosition" + "currentsessionid" + currentsessionid
							+ "winningnumber" + winningnumber + "lastfivewinningnumber" + lastfivewinningnumber);

					while (tempResultSet.next()) {

						lastfivewinningnumber = lastfivewinningnumber + "," + tempResultSet.getString("winPosition");
						jackport = jackport + "," + tempResultSet.getString("jackport");

						Utils.Logger(extension,
								"getLastFiveWinPosition::::::::::::resultant Last 5 data" + lastfivewinningnumber);

						isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
						isfsObject.putUtfString(Param.JACKPORT, jackport);
					}

					isfsObject.putUtfString(Param.SESSION_ID, currentsessionid);
					isfsObject.putUtfString(Param.STATUS, status);

					isfsObject.putUtfString(Param.WINNINGNUMBER, winningnumber);
					isfsObject.putUtfString(Param.CREDITS, credits);

					// isfsObject.putUtfString(Param.TIMER, livetime);

					Utils.Logger(extension, "isfsobject" + isfsObject.getDump());

					pCallBack.call(isfsObject);
				}
			}
		} catch (Exception e) {

			Utils.ErrorLogger(extension, "DBManager :::::::: getLastFiveWinPosition :::: Error :::: ", e);

		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

			;
		}
	}

	public static void getLastFiveNumberPlayMart(String loginid, CallBack pCallBack) {

		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {
			String lastfivewinningnumber = "";
			String jackport = "";

			String fiveWinPosition = "{call getLastFiveWinPositionPlayMart(?)}";
			tempStatement = getConnection().prepareCall(fiveWinPosition);
			tempStatement.setString(1, loginid);
			tempResultSet = tempStatement.executeQuery();
			if (tempResultSet != null && tempResultSet.next()) {
				ISFSObject isfsObject = new SFSObject();

				String status = tempResultSet.getString("result");
				String credits = tempResultSet.getString("usercredits");
				String mininner = tempResultSet.getString("mininner");
				String maxinner = tempResultSet.getString("maxinner");
				String minouter = tempResultSet.getString("minouter");
				String maxouter = tempResultSet.getString("maxouter");

				if (status.equalsIgnoreCase("true")) {
					String currentsessionid = tempResultSet.getString("currentsessionid");
					String winningnumber = tempResultSet.getString("winnernum");
					// String livetime = tempResultSet.getString("livetime");
					lastfivewinningnumber = tempResultSet.getString("winPosition");
					jackport = tempResultSet.getString("jackport");

					Utils.Logger(extension, "getLastFiveWinPosition" + "currentsessionid" + currentsessionid
							+ "winningnumber" + winningnumber + "lastfivewinningnumber" + lastfivewinningnumber);

					while (tempResultSet.next()) {

						lastfivewinningnumber = lastfivewinningnumber + "," + tempResultSet.getString("winPosition");
						jackport = jackport + "," + tempResultSet.getString("jackport");

						Utils.Logger(extension,
								"getLastFiveWinPosition::::::::::::resultant Last 5 data" + lastfivewinningnumber);

						isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
						isfsObject.putUtfString(Param.JACKPORT, jackport);
					}

					isfsObject.putUtfString(Param.SESSION_ID, currentsessionid);
					isfsObject.putUtfString(Param.STATUS, status);

					isfsObject.putUtfString(Param.WINNINGNUMBER, winningnumber);
					isfsObject.putUtfString(Param.CREDITS, credits);
					isfsObject.putUtfString(Param.MININNER, mininner);
					isfsObject.putUtfString(Param.MAXINNER, maxinner);
					isfsObject.putUtfString(Param.MINOUTER, minouter);
					isfsObject.putUtfString(Param.MAXOUTER, maxouter);

					// isfsObject.putUtfString(Param.TIMER, livetime);

					Utils.Logger(extension, "isfsobject" + isfsObject.getDump());

					pCallBack.call(isfsObject);
				}
			}
		} catch (Exception e) {

			Utils.ErrorLogger(extension, "DBManager :::::::: getLastFiveWinPosition :::: Error :::: ", e);

		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

			;
		}
	}

	public static void logoutConnection(String tempUserName) {
		Utils.Logger(extension, "DBManager :::: LogoutConnection " + " ::: tempUserName ::: " + tempUserName);
		new Thread() {

			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String query = "{call server_disconnect(?)}";
					tempStatement = getConnection().prepareCall(query);
					tempStatement.setString(1, tempUserName);
					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						String login = tempResultSet.getString("login");
						String userids = tempResultSet.getString("userids");
						Utils.Logger(extension, "DBManager :::: LogoutConnection :::: Login :::: " + login
								+ " ::: User Ids ::: " + userids);
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::logoutConnection  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager :::: logoutConnection :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void BetOkUpdateBalance(String userid, String totalbet, CallBack pCallBack) {
		Utils.Logger(extension, " DBMANAGER:::::::::::BetOkUpdateBalance::::::::::totalbet:::::::::::::::::: "
				+ totalbet + "USERID" + userid);

		new Thread() {
			@Override
			public void run() {

				double balance = 0.0;

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String query = "{call updatebalanceusers(?,?)}";
					tempStatement = getConnection().prepareCall(query);
					tempStatement.setString(1, userid);
					tempStatement.setString(2, totalbet);
					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {

						balance = tempResultSet.getDouble("balance");

						Utils.Logger(extension, "DBManager :::: BetOkUpdateBalance ::::  :::: balance" + balance);

						pCallBack.call(balance);
					}

					// pCallBack.call(isfsObject);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::BetOkUpdateBalance  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager :::: BetOkUpdateBalance :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void updatePlayerChips(String userid, CallBack callBack) {
		Utils.Logger(extension, "DBManager :::: UpdatePlayerCHips :::: User Id :::: " + userid);

		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String query = "{call  getprofiledetails(?)}";

					tempStatement = getConnection().prepareCall(query);
					tempStatement.setString(1, userid);
					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet.next()) {
						String status = tempResultSet.getString("status");
						if (status.equalsIgnoreCase("true")) {
							String credits = tempResultSet.getString("credits");
							ISFSObject tempReceiverAmount = new SFSObject();
							tempReceiverAmount.putUtfString("liveUpdateAmt", credits);
							User tempUser = extension.getParentZone().getUserByName(userid);

							if (tempUser != null) {
								extension.send("liveUpdateAmt", tempReceiverAmount, tempUser);
								// PaymentHistoryEventHandler tempPHEH = new PaymentHistoryEventHandler();
								// tempPHEH.handleClientRequest(tempUser, new SFSObject());
							}
						}
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager :::: UpdatePlayerChips :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager :::: UpdatePlayerChips :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void getSharePointDetailsByUserId(String userId, CallBack pCallBack) {

		new Thread() {
			@Override

			public void run() {
				ISFSArray tempSFSArr = new SFSArray();
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					// User tempUser = null;
					String paymenthistory = "{call getsharepointdetails(?)}";
					tempStatement = getConnection().prepareCall(paymenthistory);
					tempStatement.setString(1, userId);
					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null) {
						while (tempResultSet.next()) {
							String status = tempResultSet.getString("result");
							if (status.equalsIgnoreCase("true")) {
								String ids = tempResultSet.getString("ids");
								String id = tempResultSet.getString("id");
								String amount = tempResultSet.getString("amount");
								String type = tempResultSet.getString("type");
								ISFSObject tempSFSObj = new SFSObject();
								tempSFSObj.putUtfString("IDS", id);
								tempSFSObj.putUtfString("ID", ids);
								tempSFSObj.putUtfString("AMOUNT", amount);
								tempSFSObj.putUtfString("TYPE", type);
								tempSFSArr.addSFSObject(tempSFSObj);
								Utils.Logger(extension,
										"DBManager :::: getsharepointdetails ::::user  ::: " + tempSFSObj.getDump());

							}
						}

					}

					pCallBack.call(tempSFSArr);

				} catch (SQLException e) {
					pCallBack.call(tempSFSArr);
					Utils.ErrorLogger(extension, "DBManager :::: getSharePointDetailsByUserId :::: Error ::: ", e);
				} catch (Exception e) {
					pCallBack.call(tempSFSArr);
					Utils.ErrorLogger(extension, "DBManager :::: getSharePointDetailsByUserId :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void getUserBlockedStatus(String userid, CallBack callBack) {
		Utils.Logger(extension, "DBManager :::: getUserBlockedStatus :::: User Id :::: " + userid);

		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String query = "{call userblockstatus(?)}";

					tempStatement = getConnection().prepareCall(query);
					tempStatement.setString(1, userid);
					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet.next()) {
						String status = tempResultSet.getString("status");
						if (status.equalsIgnoreCase("true")) {
							ISFSObject tempReceiverAmount = new SFSObject();
							tempReceiverAmount.putUtfString("status", status);
							User user = extension.getParentZone().getUserByName(userid);
							if (user != null) {
								Utils.Logger(extension, "DBManager :::: getUserBlockedStatus ::::user  ::: " + user);
								extension.send(Request.USERBLOCKEDEVENT, tempReceiverAmount, user);
							}
						}
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager :::: getUserBlockedStatus :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager :::: getUserBlockedStatus :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void updateUserWinAmountsql(String userid, String winamount, String winningnumber, String sessionid,
			int jackport, String ticketId, CallBack pCallBack) {
		Utils.Logger(extension, "updateUserWinAmount:::::::::::::::::validateBeforeUserSession:::::::::::userid"
				+ userid + " GameTypeId " + jackport + "final_udated_bal" + winamount);
		new Thread() {

			@Override
			public void run() {
				ISFSObject obj = new SFSObject();
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call before_updateCreditsOnly_new(?, ?, ?, ?, ?, ?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);
					tempStatement.setInt(2, jackport);
					// callStmt1.setString(3, (winNumber.equalsIgnoreCase("0") ? "0" : winNumber));
					// callStmt1.setString(4, sessionId);

					tempStatement.setString(3, winamount);
					tempStatement.setString(4, winningnumber);
					tempStatement.setString(5, sessionid);
					tempStatement.setString(6, ticketId);

					// callStmt1.setInt(6, pTaksStatus);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");
					if (tempResultSet.next() && tempResultSet != null) {
						String status = tempResultSet.getString("result");
						String currentcredits = tempResultSet.getString("credits");
						String winningamount = tempResultSet.getString("winningamount");
						Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(userid);
						tempPlayer.setChips(currentcredits);

						GameMainExtension.cache.getPlayer().add(tempPlayer);

						Utils.Logger(extension, "DBMANAGER :::::::before_updateCreditsOnly_new:::::::status" + status);
						if (status.equalsIgnoreCase("true")) {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
						} else {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
						}
					}
					pCallBack.call(obj);
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void updateUserWinAmountmongo(String userid, String sessionId, int gameTypeId, String winNumber,
			String final_udated_bal, int pTaksStatus, String chips) {

		double currentchips = Double.parseDouble((chips));
		double totalbetamount = Double.parseDouble((final_udated_bal));
		double currentcredits = (currentchips + totalbetamount);

		// int currentcredits = Integer.parseInt(chips) +
		// Integer.parseInt(final_udated_bal);
		Utils.Logger(extension,
				"updateUserWinAmount:::::::::::::::::validateBeforeUserSession:::::::::::userid" + userid + "winNumber"
						+ winNumber + " sessionId " + sessionId + " GameTypeId " + gameTypeId + "final_udated_bal"
						+ final_udated_bal + "pTaksStatus " + pTaksStatus + "credits" + currentcredits);
		new Thread() {

			@Override
			public void run() {

				try {
					Properties prop = new Properties();
					prop.setProperty("log4j.rootLogger", "WARN");
					PropertyConfigurator.configure(prop);

					// Accessing the database
					DB database = getMongoDB();
					DBCollection collection = database.getCollection("RouletteGame");

					BasicDBObject newDocument = new BasicDBObject();
					newDocument.put("userid", userid);
					newDocument.put("sessionId", sessionId);

					BasicDBObject searchQuery = new BasicDBObject().append("currentcredits", winNumber)
							.append("winposition", final_udated_bal).append("winamount", final_udated_bal);

					collection.update(searchQuery, newDocument);

				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					closeMongoDb();
				}
			}
		}.start();
	}

	public static void insertrouletteDataMongo(String pSession, UserBetBean pUserBets, String credits) {

		try {

			double initialcredits = Double.parseDouble((credits));
			double totalbetamount = Double.parseDouble((pUserBets.getTotalBetAmount()));
			double aftercurrentcredits = (initialcredits - totalbetamount);

			Date date = new Date();
			// This method returns the time in millis
			long timeMilli = date.getTime();

			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			// Accessing the database
			DB database = getMongoDB();

			DBCollection collection = database.getCollection("RouletteGame");

			BasicDBObjectBuilder basicDBObjectBuilder = BasicDBObjectBuilder.start();
			basicDBObjectBuilder.append("sessionId", pSession).append("userid", pUserBets.getUserId())
					.append("00", pUserBets.getUserBetPlaceAmount().getValueByKey("00").getBetAmount())
					.append("0", pUserBets.getUserBetPlaceAmount().getValueByKey("0").getBetAmount())
					.append("1", pUserBets.getUserBetPlaceAmount().getValueByKey("1").getBetAmount())
					.append("2", pUserBets.getUserBetPlaceAmount().getValueByKey("2").getBetAmount())
					.append("3", pUserBets.getUserBetPlaceAmount().getValueByKey("3").getBetAmount())
					.append("4", pUserBets.getUserBetPlaceAmount().getValueByKey("4").getBetAmount())
					.append("5", pUserBets.getUserBetPlaceAmount().getValueByKey("5").getBetAmount())
					.append("6", pUserBets.getUserBetPlaceAmount().getValueByKey("6").getBetAmount())
					.append("7", pUserBets.getUserBetPlaceAmount().getValueByKey("7").getBetAmount())
					.append("8", pUserBets.getUserBetPlaceAmount().getValueByKey("8").getBetAmount())
					.append("9", pUserBets.getUserBetPlaceAmount().getValueByKey("9").getBetAmount())
					.append("10", pUserBets.getUserBetPlaceAmount().getValueByKey("10").getBetAmount())
					.append("11", pUserBets.getUserBetPlaceAmount().getValueByKey("11").getBetAmount())
					.append("12", pUserBets.getUserBetPlaceAmount().getValueByKey("12").getBetAmount())
					.append("13", pUserBets.getUserBetPlaceAmount().getValueByKey("13").getBetAmount())
					.append("14", pUserBets.getUserBetPlaceAmount().getValueByKey("14").getBetAmount())
					.append("15", pUserBets.getUserBetPlaceAmount().getValueByKey("15").getBetAmount())
					.append("16", pUserBets.getUserBetPlaceAmount().getValueByKey("16").getBetAmount())
					.append("17", pUserBets.getUserBetPlaceAmount().getValueByKey("17").getBetAmount())
					.append("18", pUserBets.getUserBetPlaceAmount().getValueByKey("18").getBetAmount())
					.append("19", pUserBets.getUserBetPlaceAmount().getValueByKey("19").getBetAmount())
					.append("20", pUserBets.getUserBetPlaceAmount().getValueByKey("20").getBetAmount())
					.append("21", pUserBets.getUserBetPlaceAmount().getValueByKey("21").getBetAmount())
					.append("22", pUserBets.getUserBetPlaceAmount().getValueByKey("22").getBetAmount())
					.append("23", pUserBets.getUserBetPlaceAmount().getValueByKey("23").getBetAmount())
					.append("24", pUserBets.getUserBetPlaceAmount().getValueByKey("24").getBetAmount())
					.append("25", pUserBets.getUserBetPlaceAmount().getValueByKey("25").getBetAmount())
					.append("26", pUserBets.getUserBetPlaceAmount().getValueByKey("26").getBetAmount())
					.append("27", pUserBets.getUserBetPlaceAmount().getValueByKey("27").getBetAmount())
					.append("28", pUserBets.getUserBetPlaceAmount().getValueByKey("28").getBetAmount())
					.append("29", pUserBets.getUserBetPlaceAmount().getValueByKey("29").getBetAmount())
					.append("30", pUserBets.getUserBetPlaceAmount().getValueByKey("30").getBetAmount())
					.append("31", pUserBets.getUserBetPlaceAmount().getValueByKey("31").getBetAmount())
					.append("32", pUserBets.getUserBetPlaceAmount().getValueByKey("32").getBetAmount())
					.append("33", pUserBets.getUserBetPlaceAmount().getValueByKey("33").getBetAmount())
					.append("34", pUserBets.getUserBetPlaceAmount().getValueByKey("34").getBetAmount())
					.append("35", pUserBets.getUserBetPlaceAmount().getValueByKey("35").getBetAmount())
					.append("36", pUserBets.getUserBetPlaceAmount().getValueByKey("36").getBetAmount())
					.append("initialcredits", initialcredits).append("aftercurrentcredits", aftercurrentcredits)
					.append("currentcredits", aftercurrentcredits).append("totalamount", pUserBets.getTotalBetAmount())
					.append("gameid", pUserBets.getGameId()).append("winposition", -1).append("winamount", 0)
					.append("currenttime", timeMilli);

			collection.insert(basicDBObjectBuilder.get());

		} catch (Exception e) {
			Utils.Logger(extension, "Dbmanager:::::::::::::::::::insertrouletteDataMongo:::::::::::::::::error" + e);

		} finally {
			closeMongoDb();
		}

	}

	public static void dataInsertMongoWithoutSplit(String pSession, UserBetBean pUserBets) {

		try {
			List<RouletteBetBeans> listdata = pUserBets.getUserRouletteBetsWithoutSplit();

			String str = new Gson().toJson(listdata);

			// Date date = new Date();
			// This method returns the time in millis
			// long timeMilli = date.getTime();

			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			DB database = getMongoDB();
			DBCollection collection = database.getCollection("RouletteGameWithoutSplit");

			BasicDBObjectBuilder basicDBObjectBuilder = BasicDBObjectBuilder.start();
			basicDBObjectBuilder.append("sessionId", pSession).append("userid", pUserBets.getUserId())
					.append("gameid", pUserBets.getGameId())

					.append("roulettedata", str);

			collection.insert(basicDBObjectBuilder.get());

		} catch (Exception e) {
			Utils.ErrorLogger(extension,
					"Dbmanager:::::::::::::::::::dataInsertMongoWithoutSplit:::::::::::::::::error" + e);
		} finally {
			closeMongoDb();
		}

	}

	public static void dataInsertMongoWithoutSplitZeroToNine(String pSession,
			com.latestfunroulette.ZerotoNineRoulette.cache.beans.UserBetBean pUserBets,
			com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean tempgamBean) {

		try {

			List<com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans> listdata = pUserBets
					.getUserRouletteBetsZeroToNine();

			List<com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanslist = new ArrayList<com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans>();

			HashMap<String, com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans> tempRouletteBetbeanstableMap = pUserBets
					.getUserRouletteBetsmap();

			if (tempRouletteBetbeanstableMap != null) {

				for (Map.Entry<String, com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanBetNo : tempRouletteBetbeanstableMap
						.entrySet()) {

					String betno = tempRouletteBetBeanBetNo.getKey();

					com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans rouletteBetBeans = tempRouletteBetbeanstableMap
							.get(betno);

					tempRouletteBetBeanslist.add(rouletteBetBeans);

				}

			}

			String strwithsplit = new Gson().toJson(tempRouletteBetBeanslist);

			String str = new Gson().toJson(listdata);

			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			// Accessing the database
			DB database = getMongoDB();
			DBCollection collection = database.getCollection("ZeroToNineWithoutSplit");

			BasicDBObjectBuilder basicDBObjectBuilder = BasicDBObjectBuilder.start();
			basicDBObjectBuilder.append("sessionId", pSession).append("userid", pUserBets.getUserId())
					.append("gameid", pUserBets.getGameId()).append("roulettedata", str)
					.append("ZeroToNinedata", strwithsplit).append("ticketid", tempgamBean.getTicketid());

			collection.insert(basicDBObjectBuilder.get());

		} catch (Exception e) {
			Utils.ErrorLogger(extension,
					"Dbmanager:::::::::::::::::::dataInsertMongoWithoutSplitZeroToNine:::::::::::::::::error" + e);
		} finally {
			closeMongoDb();
		}

	}

	/*
	 * public static void insertZeroToNineRoulettemongo(String pSession,
	 * com.latestfunroulette.ZerotoNineRoulette.cache.beans.UserBetBean pUserBets,
	 * String credits, com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean
	 * tempGameBean) {
	 * 
	 * Utils.ErrorLogger(extension, "UserBetBean::::::::::::::::: " +
	 * pUserBets.toString() + "credits::" + credits);
	 * 
	 * try { double initialcredits = Double.parseDouble((credits)); double
	 * totalbetamount = Double.parseDouble((pUserBets.getTotalBetAmount())); double
	 * aftercurrentcredits = (initialcredits - totalbetamount);
	 * 
	 * Properties prop = new Properties(); prop.setProperty("log4j.rootLogger",
	 * "WARN"); PropertyConfigurator.configure(prop);
	 * 
	 * DB database = getMongoDB();
	 * 
	 * DBCollection collection = database.getCollection("ZeroToNineRoulette");
	 * 
	 * List<com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans>
	 * tempRouletteBetBeanslist = new
	 * ArrayList<com.latestfunroulette.ZerotoNineRoulette.cache.beans.
	 * RouletteBetBeans>();
	 * 
	 * HashMap<String,
	 * com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans>
	 * tempRouletteBetbeanstableMap = pUserBets .getUserRouletteBetsmap();
	 * 
	 * if (tempRouletteBetbeanstableMap != null) {
	 * 
	 * for (Map.Entry<String,
	 * com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans>
	 * tempRouletteBetBeanBetNo : tempRouletteBetbeanstableMap .entrySet()) {
	 * 
	 * String betno = tempRouletteBetBeanBetNo.getKey();
	 * 
	 * com.latestfunroulette.ZerotoNineRoulette.cache.beans.RouletteBetBeans
	 * rouletteBetBeans = tempRouletteBetbeanstableMap .get(betno);
	 * 
	 * tempRouletteBetBeanslist.add(rouletteBetBeans);
	 * 
	 * }
	 * 
	 * }
	 * 
	 * String str = new Gson().toJson(tempRouletteBetBeanslist);
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * System.out.println("str:::::::::::::::::::" + str);
	 * 
	 * BasicDBObjectBuilder docBuilder = BasicDBObjectBuilder.start();
	 * 
	 * docBuilder.append("userid", pUserBets.getUserId()).append("ZeroToNinedata",
	 * str) .append("initialcredits", initialcredits).append("aftercurrentcredits",
	 * aftercurrentcredits) .append("currentcredits",
	 * aftercurrentcredits).append("totalamount", pUserBets.getTotalBetAmount())
	 * .append("winposition", -1).append("winamount", 0).append("ticketid",
	 * tempGameBean.getTicketid());
	 * 
	 * collection.insert(docBuilder.get());
	 * 
	 * } catch (Exception e) { Utils.ErrorLogger(extension,
	 * "Dbmanager:::::::::::::::::::insertZeroToNineRoulettemongo:::::::::::::::::error"
	 * + e); } finally { closeMongoDb();
	 * 
	 * }
	 * 
	 * }
	 */

	public static void insertPlayMartmongo(String pSession,
			com.latestfunroulette.playMart.cache.beans.UserBetBean pUserBets, String credits) {

		try {
			double initialcredits = Double.parseDouble((credits));
			double totalbetamount = Double.parseDouble((pUserBets.getTotalBetAmount()));
			double aftercurrentcredits = (initialcredits - totalbetamount);

			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			// Accessing the database
			DB database = getMongoDB();
			// database.createCollection("ZeroToNineRoulette");
			DBCollection collection = database.getCollection("PlayMart");

			List<com.latestfunroulette.playMart.cache.beans.RouletteBetBeans> tempRouletteBetBeanslist = new ArrayList<com.latestfunroulette.playMart.cache.beans.RouletteBetBeans>();

			HashMap<String, com.latestfunroulette.playMart.cache.beans.RouletteBetBeans> tempRouletteBetbeanstableMap = pUserBets
					.getUserRouletteBets();

			for (Map.Entry<String, com.latestfunroulette.playMart.cache.beans.RouletteBetBeans> tempRouletteBetBeanBetNo : tempRouletteBetbeanstableMap
					.entrySet()) {

				String betno = tempRouletteBetBeanBetNo.getKey();

				com.latestfunroulette.playMart.cache.beans.RouletteBetBeans rouletteBetBeans = tempRouletteBetbeanstableMap
						.get(betno);

				tempRouletteBetBeanslist.add(rouletteBetBeans);

			}

			String str = new Gson().toJson(tempRouletteBetBeanslist);

			BasicDBObjectBuilder docBuilder = BasicDBObjectBuilder.start();

			docBuilder.append("sessionId", pSession).append("userid", pUserBets.getUserId())
					.append("Roulettebetdata", str).append("initialcredits", initialcredits)
					.append("aftercurrentcredits", aftercurrentcredits).append("currentcredits", aftercurrentcredits)
					.append("totalamount", pUserBets.getTotalBetAmount()).append("winposition", -1)
					.append("winamount", 0);
			collection.insert(docBuilder.get());

		} catch (Exception e) {
			Utils.ErrorLogger(extension, "DBManager ::::: insertPlayMartmongo() :::: Error :::  ", e);
		} finally {
			closeMongoDb();
		}

	}

	public static void insertZeroToNinesql(String pSession,
			com.latestfunroulette.ZerotoNineRoulette.cache.beans.UserBetBean pUserBets) {
		Utils.Logger(extension, "DBManager :::: insertZeroToNinesql() :::: Session Id :::  " + pSession);

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					Utils.Logger(extension,
							"DBManager :::: insertZeroToNinesql() ::::::::Userbetbean" + pUserBets.toString());

					String insertliveroulettebets = "call insertliveroulettebets1(?,?,?)";
					tempStatement = getConnection().prepareCall(insertliveroulettebets);

					tempStatement.setString(1, pUserBets.getUserId());
					tempStatement.setString(2, pSession);
					tempStatement.setString(3, pUserBets.getTotalBetAmount());

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						String updatedbalance = tempResultSet.getString("credits");
						ISFSObject isfsObject = new SFSObject();
						isfsObject.putUtfString(Param.CURRENT_SCORE, updatedbalance);

						gameBean.setCredits(updatedbalance);

						Utils.Logger(extension, "DBManager:::::::::::::::insertZeroToNinesql:::::::::isfsobject"
								+ isfsObject.getDump());
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: insertZeroToNinesql() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void insertZeroToDoubleNinemongo(String pSession,
			com.latestfunroulette.dubliRoulette.cache.beans.UserBetBean pUserBets, String credits) {

		try {
			double initialcredits = Double.parseDouble((credits));
			double totalbetamount = Double.parseDouble((pUserBets.getTotalBetAmount()));
			double aftercurrentcredits = (initialcredits - totalbetamount);

			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			// Accessing the database
			DB database = getMongoDB();
			DBCollection collection = database.getCollection("ZeroToDoubleNineRoulette");

			// Document document = new Document("sessionId", pSession).append("userid",
			// pUserBets.getUserId())

			HashMap<String, com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans> tempHashMapdouble = pUserBets
					.getUserRouletteBetsTableType("DOUBLE");

			List<com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanslist = new ArrayList<com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans>();

			if (tempHashMapdouble != null) {

				for (Map.Entry<String, com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanBetNo : tempHashMapdouble
						.entrySet()) {

					String betno = tempRouletteBetBeanBetNo.getKey();

					com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans temprouletteBetBeanssingle = tempHashMapdouble
							.get(betno);
					tempRouletteBetBeanslist.add(temprouletteBetBeanssingle);

				}

				String str = new Gson().toJson(tempRouletteBetBeanslist);

				BasicDBObjectBuilder docBuilder = BasicDBObjectBuilder.start();

				docBuilder.append("sessionId", pSession).append("userid", pUserBets.getUserId())
						.append("Roulettebetdata", str).append("initialcredits", initialcredits)
						.append("aftercurrentcredits", aftercurrentcredits)
						.append("currentcredits", aftercurrentcredits)
						.append("totalamount", pUserBets.getTotalBetAmount()).append("winposition", -1)
						.append("winamount", 0);
				collection.insert(docBuilder.get());

			}
		} catch (Exception e) {
			Utils.ErrorLogger(extension, "DBManager ::::: insertZeroToDoubleNinemongo() :::: Error :::  ", e);
		} finally {
			closeMongoDb();
		}

	}

	public static void insertZeroToTripleNinemongo(String pSession,
			com.latestfunroulette.TripleRoulette.cache.beans.UserBetBean pUserBets, String credits) {

		try {

			double initialcredits = Double.parseDouble((credits));
			double totalbetamount = Double.parseDouble((pUserBets.getTotalBetAmount()));
			double aftercurrentcredits = (initialcredits - totalbetamount);

			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			// Accessing the database
			DB database = getMongoDB();
			DBCollection collection = database.getCollection("ZeroToTripleNineRoulette");

			// Document document = new Document("sessionId", pSession).append("userid",
			// pUserBets.getUserId())

			HashMap<String, com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans> tempHashMapdouble = pUserBets
					.getUserRouletteBetsTableType("TRIPLE");

			List<com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanslist = new ArrayList<com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans>();

			if (tempHashMapdouble != null) {

				for (Map.Entry<String, com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanBetNo : tempHashMapdouble
						.entrySet()) {

					String betno = tempRouletteBetBeanBetNo.getKey();

					com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans temprouletteBetBeanssingle = tempHashMapdouble
							.get(betno);
					tempRouletteBetBeanslist.add(temprouletteBetBeanssingle);

				}

				String str = new Gson().toJson(tempRouletteBetBeanslist);
				BasicDBObjectBuilder docBuilder = BasicDBObjectBuilder.start();

				docBuilder.append("sessionId", pSession).append("userid", pUserBets.getUserId())
						.append("Roulettebetdata", str).append("initialcredits", initialcredits)
						.append("aftercurrentcredits", aftercurrentcredits)
						.append("currentcredits", aftercurrentcredits)
						.append("totalamount", pUserBets.getTotalBetAmount()).append("winposition", -1)
						.append("winamount", 0);
				collection.insert(docBuilder.get());

			}
		} catch (Exception e) {
			Utils.ErrorLogger(extension, "DBManager ::::: insertZeroToTripleNinemongo() :::: Error :::  ", e);
		} finally {
			closeMongoDb();
		}
	}

	public static void insertDoubleChanceZeroToNineMongo(String pSession,
			com.latestfunroulette.dubliRoulette.cache.beans.UserBetBean pUserBets, String credits) {

		try {
			double initialcredits = Double.parseDouble((credits));
			double totalbetamount = Double.parseDouble((pUserBets.getTotalBetAmount()));
			double aftercurrentcredits = (initialcredits - totalbetamount);

			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			// Accessing the database
			DB database = getMongoDB();
			DBCollection collection = database.getCollection("DoubleChanceZeroToNine");

			// Document document = new Document("sessionId", pSession).append("userid",
			// pUserBets.getUserId())

			HashMap<String, com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans> tempHashMapsingle = pUserBets
					.getUserRouletteBetsTableType("SINGLE");

			List<com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanslist = new ArrayList<com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans>();

			for (Map.Entry<String, com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanBetNo : tempHashMapsingle
					.entrySet()) {

				String betno = tempRouletteBetBeanBetNo.getKey();

				com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans rouletteBetBeans = tempHashMapsingle
						.get(betno);

				tempRouletteBetBeanslist.add(rouletteBetBeans);

			}

			String str = new Gson().toJson(tempRouletteBetBeanslist);

			BasicDBObjectBuilder basicDBObject = BasicDBObjectBuilder.start();
			basicDBObject.append("sessionId", pSession).append("userid", pUserBets.getUserId())
					.append("Roulettebetdata", str).append("initialcredits", initialcredits)
					.append("aftercurrentcredits", aftercurrentcredits).append("currentcredits", aftercurrentcredits)
					.append("totalamount", pUserBets.getTotalBetAmount()).append("winposition", -1)
					.append("winamount", 0);
			collection.insert(basicDBObject.get());

		} catch (Exception e) {
			Utils.ErrorLogger(extension, "DBManager ::::: insertDoubleChanceZeroToNine() :::: Error :::  ", e);
		} finally {
			closeMongoDb();
		}
	}

	public static void insertTripleChanceZeroToNine(String pSession,
			com.latestfunroulette.TripleRoulette.cache.beans.UserBetBean pUserBets, String credits) {

		try {

			double initialcredits = Double.parseDouble((credits));
			double totalbetamount = Double.parseDouble((pUserBets.getTotalBetAmount()));
			double aftercurrentcredits = (initialcredits - totalbetamount);

			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			// Accessing the database
			DB database = getMongoDB();
			DBCollection collection = database.getCollection("TripleChanceZeroToNine");

			// Document document = new Document("sessionId", pSession).append("userid",
			// pUserBets.getUserId())

			HashMap<String, com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans> tempHashMapsingle = pUserBets
					.getUserRouletteBetsTableType("SINGLE");

			List<com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanslist = new ArrayList<com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans>();

			for (Map.Entry<String, com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanBetNo : tempHashMapsingle
					.entrySet()) {

				String betno = tempRouletteBetBeanBetNo.getKey();

				com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans rouletteBetBeans = tempHashMapsingle
						.get(betno);

				tempRouletteBetBeanslist.add(rouletteBetBeans);

			}

			String str = new Gson().toJson(tempRouletteBetBeanslist);
			BasicDBObjectBuilder basicDBObjectBuilder = BasicDBObjectBuilder.start();
			basicDBObjectBuilder.append("sessionId", pSession).append("userid", pUserBets.getUserId())
					.append("Roulettebetdata", str).append("initialcredits", initialcredits)
					.append("aftercurrentcredits", aftercurrentcredits).append("currentcredits", aftercurrentcredits)
					.append("totalamount", pUserBets.getTotalBetAmount()).append("winposition", -1)
					.append("winamount", 0);
			collection.insert(basicDBObjectBuilder.get());

		} catch (Exception e) {
			Utils.ErrorLogger(extension, "DBManager ::::: insertTripleChanceZeroToNine() :::: Error :::  ", e);
		} finally {
			closeMongoDb();
		}

	}

	public static void insertTripleChanceZeroToDoubleNine(String pSession,
			com.latestfunroulette.TripleRoulette.cache.beans.UserBetBean pUserBets, String credits) {

		try {

			double initialcredits = Double.parseDouble((credits));
			double totalbetamount = Double.parseDouble((pUserBets.getTotalBetAmount()));
			double aftercurrentcredits = (initialcredits - totalbetamount);

			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			// Accessing the database
			DB database = getMongoDB();
			DBCollection collection = database.getCollection("TripleChanceZeroToDoubleNine");

			// Document document = new Document("sessionId", pSession).append("userid",
			// pUserBets.getUserId())

			HashMap<String, com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans> tempHashMapsingle = pUserBets
					.getUserRouletteBetsTableType("DOUBLE");

			List<com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanslist = new ArrayList<com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans>();

			for (Map.Entry<String, com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans> tempRouletteBetBeanBetNo : tempHashMapsingle
					.entrySet()) {

				String betno = tempRouletteBetBeanBetNo.getKey();

				com.latestfunroulette.TripleRoulette.cache.beans.RouletteBetBeans rouletteBetBeans = tempHashMapsingle
						.get(betno);

				tempRouletteBetBeanslist.add(rouletteBetBeans);

			}

			String str = new Gson().toJson(tempRouletteBetBeanslist);
			BasicDBObjectBuilder basicDBObjectBuilder = BasicDBObjectBuilder.start();
			basicDBObjectBuilder.append("sessionId", pSession).append("userid", pUserBets.getUserId())
					.append("Roulettebetdata", str).append("initialcredits", initialcredits)
					.append("aftercurrentcredits", aftercurrentcredits).append("currentcredits", aftercurrentcredits)
					.append("totalamount", pUserBets.getTotalBetAmount()).append("winposition", -1)
					.append("winamount", 0);
			collection.insert(basicDBObjectBuilder.get());
		} catch (Exception e) {

			Utils.ErrorLogger(extension, "DBManager ::::: insertTripleChanceZeroToDoubleNine() :::: Error :::  ", e);
		} finally {
			closeMongoDb();
		}
	}

	public static void insertZeroToDoubleNinesql(String pSession,
			com.latestfunroulette.dubliRoulette.cache.beans.UserBetBean pUserBets, int gameid,
			com.latestfunroulette.dubliRoulette.cache.beans.GameBean tempGameBean) {
		Utils.Logger(extension, "DBManager :::: insertZeroToDoubleNinesql() :::: Session Id :::  " + pSession);

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String insertliveroulettebets = "call insertliveroulettebetsDoubleChance(?,?,?,?)";
					tempStatement = getConnection().prepareCall(insertliveroulettebets);

					tempStatement.setString(1, pUserBets.getUserId());
					tempStatement.setString(2, pSession);
					tempStatement.setString(3, pUserBets.getTotalBetAmount());
					tempStatement.setInt(4, gameid);

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						String updatedbalance = tempResultSet.getString("credits");
						String ticketid = tempResultSet.getString("ticketid");
						ISFSObject isfsObject = new SFSObject();
						isfsObject.putUtfString(Param.CURRENT_SCORE, updatedbalance);

						tempGameBean.setCredits(updatedbalance);
						tempGameBean.setTicketid(ticketid);

						try {
							insertZeroToDoubleNinemongo(pSession, pUserBets, updatedbalance);
						} catch (Exception e) {
							Utils.Logger(GameMainExtension.extension, "run time exception::::::::::::" + e);
						}
						try {
							insertDoubleChanceZeroToNineMongo(pSession, pUserBets, updatedbalance);
						} catch (Exception e) {
							Utils.Logger(GameMainExtension.extension, "run time exception::::::::::::" + e);
						}
						Utils.Logger(extension, "DBManager:::::::::::::::insertZeroToDoubleNinesql:::::::::isfsobject"
								+ isfsObject.getDump());
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: insertZeroToDoubleNinesql() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void insertZeroToTripleNineSql(String pSession,
			com.latestfunroulette.TripleRoulette.cache.beans.UserBetBean pUserBets, int gameid,
			com.latestfunroulette.TripleRoulette.cache.beans.GameBean tempgameBean) {
		Utils.Logger(extension, "DBManager :::: insertliveroulettebetsTripleChance() :::: Session Id :::  " + pSession);

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String insertliveroulettebets = "call insertliveroulettebetsTripleChance(?,?,?,?)";
					tempStatement = getConnection().prepareCall(insertliveroulettebets);
					tempStatement.setString(1, pUserBets.getUserId());
					tempStatement.setString(2, pSession);
					tempStatement.setString(3, pUserBets.getTotalBetAmount());
					tempStatement.setInt(4, gameid);

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						String updatedbalance = tempResultSet.getString("credits");
						String ticketid = tempResultSet.getString("ticketid");
						ISFSObject isfsObject = new SFSObject();
						isfsObject.putUtfString(Param.CURRENT_SCORE, updatedbalance);

						tempgameBean.setCredits(updatedbalance);
						tempgameBean.setTicketid(ticketid);

						try {
							insertZeroToTripleNinemongo(pSession, pUserBets, updatedbalance);

						} catch (Exception e) {
							System.out.println(
									"DbManager::::::::::::::::::::::insertZeroToTripleNinemongo:::::::::::::::::::error::::::::::::::::::::::::::::::e"
											+ e);
						}

						try {
							insertTripleChanceZeroToNine(pSession, pUserBets, updatedbalance);
						} catch (Exception e) {
							System.out.println(
									"DbManager::::::::::::::::::::::insertTripleChanceZeroToNine::::::error::::::::::::::::::::::::::::::e"
											+ e);
						}

						try {
							insertTripleChanceZeroToDoubleNine(pSession, pUserBets, updatedbalance);
						} catch (Exception e) {
							System.out.println(
									"DbManager::::::::::::::::::::::insertTripleChanceZeroToNine::::::error::::::::::::::::::::::::::::::e"
											+ e);
						}

						Utils.Logger(extension,
								"DBManager:::::::::::::::insertliveroulettebetsTripleChance:::::::::isfsobject"
										+ isfsObject.getDump());
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension,
							"DBManager ::::: insertliveroulettebetsTripleChance() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void insertLiveRouletteBetsExe(String pSession,
			com.latestfunroulette.exeRoulette.cache.beans.UserBetBean pUserBets) {

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String insertliveroulettebets = "call insertliveroulettebets1(?,?,?)";
					tempStatement = getConnection().prepareCall(insertliveroulettebets);

					tempStatement.setString(1, pUserBets.getUserId());
					tempStatement.setString(2, pSession);
					tempStatement.setString(3, pUserBets.getTotalBetAmount().toString());

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						String updatedbalance = tempResultSet.getString("credits");
						ISFSObject isfsObject = new SFSObject();
						isfsObject.putUtfString(Param.CURRENT_SCORE, updatedbalance);

						gameBean.setCredits(updatedbalance);

						Utils.Logger(extension, "DBManager:::::::::::::::insertLiveRouletteBetsExe:::::::::isfsobject"
								+ isfsObject.getDump());
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: insertLiveRouletteBetsExe() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void insertrouletteDataMongoexe(String pSession,
			com.latestfunroulette.exeRoulette.cache.beans.UserBetBean pUserBets, String credits) {

		Utils.Logger(extension, "credits:::::::::::" + credits);

		try {
			double initialcredits = Double.parseDouble((credits));
			double totalbetamount = Double.parseDouble((pUserBets.getTotalBetAmount()));
			double aftercurrentcredits = (initialcredits - totalbetamount);

			Date date = new Date();
			// This method returns the time in millis
			long timeMilli = date.getTime();

			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			// Accessing the database
			DB database = getMongoDB();
			DBCollection collection = database.getCollection("RouletteGame");

			BasicDBObjectBuilder basicDBObjectBuilder = BasicDBObjectBuilder.start();
			basicDBObjectBuilder.append("sessionId", pSession).append("userid", pUserBets.getUserId())
					.append("00", pUserBets.getUserBetPlaceAmount().getValueByKey("00").getBetAmount())
					.append("0", pUserBets.getUserBetPlaceAmount().getValueByKey("0").getBetAmount())
					.append("1", pUserBets.getUserBetPlaceAmount().getValueByKey("1").getBetAmount())
					.append("2", pUserBets.getUserBetPlaceAmount().getValueByKey("2").getBetAmount())
					.append("3", pUserBets.getUserBetPlaceAmount().getValueByKey("3").getBetAmount())
					.append("4", pUserBets.getUserBetPlaceAmount().getValueByKey("4").getBetAmount())
					.append("5", pUserBets.getUserBetPlaceAmount().getValueByKey("5").getBetAmount())
					.append("6", pUserBets.getUserBetPlaceAmount().getValueByKey("6").getBetAmount())
					.append("7", pUserBets.getUserBetPlaceAmount().getValueByKey("7").getBetAmount())
					.append("8", pUserBets.getUserBetPlaceAmount().getValueByKey("8").getBetAmount())
					.append("9", pUserBets.getUserBetPlaceAmount().getValueByKey("9").getBetAmount())
					.append("10", pUserBets.getUserBetPlaceAmount().getValueByKey("10").getBetAmount())
					.append("11", pUserBets.getUserBetPlaceAmount().getValueByKey("11").getBetAmount())
					.append("12", pUserBets.getUserBetPlaceAmount().getValueByKey("12").getBetAmount())
					.append("13", pUserBets.getUserBetPlaceAmount().getValueByKey("13").getBetAmount())
					.append("14", pUserBets.getUserBetPlaceAmount().getValueByKey("14").getBetAmount())
					.append("15", pUserBets.getUserBetPlaceAmount().getValueByKey("15").getBetAmount())
					.append("16", pUserBets.getUserBetPlaceAmount().getValueByKey("16").getBetAmount())
					.append("17", pUserBets.getUserBetPlaceAmount().getValueByKey("17").getBetAmount())
					.append("18", pUserBets.getUserBetPlaceAmount().getValueByKey("18").getBetAmount())
					.append("19", pUserBets.getUserBetPlaceAmount().getValueByKey("19").getBetAmount())
					.append("20", pUserBets.getUserBetPlaceAmount().getValueByKey("20").getBetAmount())
					.append("21", pUserBets.getUserBetPlaceAmount().getValueByKey("21").getBetAmount())
					.append("22", pUserBets.getUserBetPlaceAmount().getValueByKey("22").getBetAmount())
					.append("23", pUserBets.getUserBetPlaceAmount().getValueByKey("23").getBetAmount())
					.append("24", pUserBets.getUserBetPlaceAmount().getValueByKey("24").getBetAmount())
					.append("25", pUserBets.getUserBetPlaceAmount().getValueByKey("25").getBetAmount())
					.append("26", pUserBets.getUserBetPlaceAmount().getValueByKey("26").getBetAmount())
					.append("27", pUserBets.getUserBetPlaceAmount().getValueByKey("27").getBetAmount())
					.append("28", pUserBets.getUserBetPlaceAmount().getValueByKey("28").getBetAmount())
					.append("29", pUserBets.getUserBetPlaceAmount().getValueByKey("29").getBetAmount())
					.append("30", pUserBets.getUserBetPlaceAmount().getValueByKey("30").getBetAmount())
					.append("31", pUserBets.getUserBetPlaceAmount().getValueByKey("31").getBetAmount())
					.append("32", pUserBets.getUserBetPlaceAmount().getValueByKey("32").getBetAmount())
					.append("33", pUserBets.getUserBetPlaceAmount().getValueByKey("33").getBetAmount())
					.append("34", pUserBets.getUserBetPlaceAmount().getValueByKey("34").getBetAmount())
					.append("35", pUserBets.getUserBetPlaceAmount().getValueByKey("35").getBetAmount())
					.append("36", pUserBets.getUserBetPlaceAmount().getValueByKey("36").getBetAmount())
					.append("initialcredits", initialcredits).append("aftercurrentcredits", aftercurrentcredits)
					.append("currentcredits", aftercurrentcredits).append("totalamount", pUserBets.getTotalBetAmount())
					.append("winposition", -1).append("winamount", 0).append("currenttime", timeMilli);

			collection.insert(basicDBObjectBuilder.get());
		} catch (Exception e) {
			Utils.ErrorLogger(extension, "DBManager ::::: insertrouletteDataMongoexe() :::: Error :::  ", e);
		} finally {
			closeMongoDb();
		}

	}

	public static void getSessionId(CallBack callBack) {

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String sessionid = "";
					String querysessionid = "call getSessionId()";
					tempStatement = getConnection().prepareCall(querysessionid);

					tempResultSet = tempStatement.executeQuery();

					if (tempResultSet != null && tempResultSet.next()) {
						sessionid = tempResultSet.getString("sessionid");

					}
					callBack.call(sessionid);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: insertLiveRouletteBets() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void updateLiveTimeData(double totalsessionbetamount, String totalwinningamount, int gameID,
			int jackport) {

		String strjackport = String.valueOf(jackport) + "X";
		Utils.Logger(extension,
				"DbManager::::::::::::::::::::::::::::updateLiveTimeData:::::::::::totalsessionbetamount"
						+ totalsessionbetamount + "totalwinningamount:::::::::::::::" + totalwinningamount
						+ "strjackport:::::::::::" + strjackport);

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String querysessionid = "call updatedatalivetime(?,?,?,?)";
					tempStatement = getConnection().prepareCall(querysessionid);
					tempStatement.setDouble(1, totalsessionbetamount);
					tempStatement.setString(2, totalwinningamount);
					tempStatement.setInt(3, gameID);
					tempStatement.setString(4, strjackport);

					tempStatement.executeQuery();

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: insertLiveRouletteBets() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void updateLiveTimeDataZeroToNine(double totalsessionbetamount, String totalwinningamount, int gameid,
			int jackport) {

		String jackportstr = String.valueOf(jackport) + "X";

		Utils.Logger(extension,
				"DbManager::::::::::::::::::::::::::::updateLiveTimeData:::::::::::totalsessionbetamount"
						+ totalsessionbetamount + "totalwinningamount:::::::::::::::" + totalwinningamount);

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String querysessionid = "call updatedatalivetimeZeroToNine(?,?,?,?)";
					tempStatement = getConnection().prepareCall(querysessionid);
					tempStatement.setDouble(1, totalsessionbetamount);
					tempStatement.setString(2, totalwinningamount);
					tempStatement.setInt(3, gameid);
					tempStatement.setString(4, jackportstr);

					tempStatement.executeQuery();

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: insertLiveRouletteBets() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void updateLiveTimeDataPlayMart(double totalsessionbetamount, String totalwinningamount, int gameid,
			int jackport) {

		String strjackport = String.valueOf(jackport) + "X";
		Utils.Logger(extension,
				"DbManager::::::::::::::::::::::::::::updateLiveTimeData:::::::::::totalsessionbetamount"
						+ totalsessionbetamount + "totalwinningamount:::::::::::::::" + totalwinningamount
						+ "strjackport" + strjackport);

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String querysessionid = "call updatedatalivetimePlayMart(?,?,?,?)";
					tempStatement = getConnection().prepareCall(querysessionid);
					tempStatement.setDouble(1, totalsessionbetamount);
					tempStatement.setString(2, totalwinningamount);
					tempStatement.setInt(3, gameid);
					tempStatement.setString(4, strjackport);

					tempStatement.executeQuery();

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: updatedatalivetimePlayMart() :::: Error :::  ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void updateLiveTimeDataZeroToDoubleNine(double totalsessionbetamount, String totalwinningamount,
			int gameId, int jackport) {

		String jackportstr = String.valueOf(jackport) + "X";

		Utils.Logger(extension,
				"DbManager::::::::::::::::::::::::::::updateLiveTimeData:::::::::::totalsessionbetamount"
						+ totalsessionbetamount + "totalwinningamount:::::::::::::::" + totalwinningamount);

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String querysessionid = "call updatedatalivetimeDoubleChance(?,?,?,?)";
					tempStatement = getConnection().prepareCall(querysessionid);
					tempStatement.setDouble(1, totalsessionbetamount);
					tempStatement.setString(2, totalwinningamount);
					tempStatement.setInt(3, gameId);
					tempStatement.setString(4, jackportstr);

					tempStatement.executeQuery();

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: updatedatalivetimeDoubleChance() :::: Error :::  ",
							e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void updateLiveTimeDataZeroToTripleNine(double totalsessionbetamount, String totalwinningamount,
			int gameId, int jackport) {

		String jackportstr = String.valueOf(jackport) + "X";
		Utils.Logger(extension,
				"DbManager::::::::::::::::::::::::::::updateLiveTimeData:::::::::::totalsessionbetamount"
						+ totalsessionbetamount + "totalwinningamount:::::::::::::::" + totalwinningamount
						+ "jackportstr:::::::::::" + jackportstr);

		new Thread() {
			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String querysessionid = "call updatedatalivetimeTripleChance(?,?,?,?)";
					tempStatement = getConnection().prepareCall(querysessionid);
					tempStatement.setDouble(1, totalsessionbetamount);
					tempStatement.setString(2, totalwinningamount);
					tempStatement.setInt(3, gameId);
					tempStatement.setString(4, jackportstr);

					tempStatement.executeQuery();

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::: updatedatalivetimeTripleChance() :::: Error :::  ",
							e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();
	}

	/*
	 * ::::::::::::::::::::::::::::::::::::::::ZeroToNineRoulette:::::::::::::::::::
	 * :::::::::::::::::::::::::::
	 */

	public static void getLastFiveNumberZeroToNine(String loginid, CallBack pCallBack) {

		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;
		try {
			String lastfivewinningnumber = "";
			String jackport = "";
			String fiveWinPosition = "{call getLastFiveWinPositionZeroToNine(?)}";
			tempStatement = getConnection().prepareCall(fiveWinPosition);
			tempStatement.setString(1, loginid);
			tempResultSet = tempStatement.executeQuery();
			if (tempResultSet != null && tempResultSet.next()) {
				ISFSObject isfsObject = new SFSObject();

				String status = tempResultSet.getString("result");
				String credits = tempResultSet.getString("usercredits");

				if (status.equalsIgnoreCase("true")) {
					String currentsessionid = tempResultSet.getString("currentsessionid");
					String winningnumber = tempResultSet.getString("winnernum");
					// String livetime = tempResultSet.getString("livetime");
					lastfivewinningnumber = tempResultSet.getString("winPosition");
					jackport = tempResultSet.getString("jackport");

					Utils.Logger(extension, "getLastFiveWinPosition" + "currentsessionid" + currentsessionid
							+ "winningnumber" + winningnumber + "lastfivewinningnumber" + lastfivewinningnumber);

					while (tempResultSet.next()) {

						lastfivewinningnumber = lastfivewinningnumber + "," + tempResultSet.getString("winPosition");

						jackport = jackport + "," + tempResultSet.getString("jackport");
						Utils.Logger(extension,
								"getLastFiveWinPosition::::::::::::resultant Last 5 data" + lastfivewinningnumber);

						isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
					}

					isfsObject.putUtfString(Param.SESSION_ID, currentsessionid);
					isfsObject.putUtfString(Param.STATUS, status);

					isfsObject.putUtfString(Param.WINNINGNUMBER, winningnumber);
					isfsObject.putUtfString(Param.CREDITS, credits);
					isfsObject.putUtfString(Param.JACKPORT, jackport);

					// isfsObject.putUtfString(Param.TIMER, livetime);

					Utils.Logger(extension, "isfsobject" + isfsObject.getDump());

					pCallBack.call(isfsObject);
				}
			}
		} catch (Exception e) {

			Utils.ErrorLogger(extension, "DBManager :::::::: getLastFiveWinPosition :::: Error :::: ", e);

		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

			;
		}
	}

	public static void sendSessionIdOfRulleteZeroToNine(String userid,
			com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean tempgamBean, CallBack pCallBack) {
		new Thread() {

			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String jackport = "";
					String lastfivewinningnumber = "";
					String fetchSessionIdQuery = "call sendSessionIdOfRulleteZeroToNine(?)";
					tempStatement = getConnection().prepareCall(fetchSessionIdQuery);
					tempStatement.setString(1, userid);
					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						String session_id = tempResultSet.getString("sessionid");
						String status = tempResultSet.getString("result");
						String resultwheel = tempResultSet.getString("presultwheel");
						String credits = (tempResultSet.getString("currentcredits") == null ? "0"
								: tempResultSet.getString("currentcredits"));

						lastfivewinningnumber = tempResultSet.getString("winPosition");
						String oldsessionid = tempResultSet.getString("oldsessionid");
						jackport = tempResultSet.getString("jackport");

						tempgamBean.setJackport(Integer.parseInt(jackport));

						Utils.Logger(extension,
								"getLastFiveWinPosition" + "currentsessionid" + session_id + "winningnumber"
										+ resultwheel + "lastfivewinningnumber" + lastfivewinningnumber + "oldsessionid"
										+ oldsessionid);

						while (tempResultSet.next()) {

							lastfivewinningnumber = lastfivewinningnumber + ","
									+ tempResultSet.getString("winPosition");

							jackport = jackport + "," + tempResultSet.getString("jackport");

							// isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
						}

						pCallBack.call(session_id, status, resultwheel, credits, lastfivewinningnumber, oldsessionid,
								jackport);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::sendSessionIdOfRullete :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::sendSessionIdOfRullete :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void sendSessionIdOfRulleteDoubleChance(String userid, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String jackport;
					String lastfivewinningnumber = "";
					String fetchSessionIdQuery = "call sendSessionIdOfRulleteDoubleChance(?)";
					CallableStatement callStmt = getConnection().prepareCall(fetchSessionIdQuery);

					callStmt.setString(1, userid);
					ResultSet rst = callStmt.executeQuery();
					if (rst != null && rst.next()) {
						String session_id = rst.getString("sessionid");
						String status = rst.getString("result");
						String resultwheel = rst.getString("presultwheel");
						String credits = (rst.getString("currentcredits") == null ? "0"
								: rst.getString("currentcredits"));
						Utils.Logger(extension, "credits::::::::::::::" + credits);

						Utils.Logger(extension, "DBManager :::::: SendSessionIdOfRullete :::::::: Session :::: "
								+ session_id + "wheel" + resultwheel);
						lastfivewinningnumber = rst.getString("winPosition");
						String oldsessionid = rst.getString("oldsessionid");
						jackport = rst.getString("jackport");

						Utils.Logger(extension,
								"getLastFiveWinPosition" + "currentsessionid" + session_id + "winningnumber"
										+ resultwheel + "lastfivewinningnumber" + lastfivewinningnumber + "oldsessionid"
										+ oldsessionid);

						while (rst.next()) {

							lastfivewinningnumber = lastfivewinningnumber + "," + rst.getString("winPosition");

							jackport = jackport + "," + rst.getString("jackport");
							Utils.Logger(extension,
									"getLastFiveWinPosition::::::::::::resultant Last 5 data" + lastfivewinningnumber);

							// isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
						}

						pCallBack.call(session_id, status, resultwheel, credits, lastfivewinningnumber, oldsessionid,
								jackport);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::sendSessionIdOfRulleteDoubleChance :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::sendSessionIdOfRulleteDoubleChance :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void sendSessionIdOfRulleteTripleChance(String userid, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					String lastfivewinningnumber = "";
					String jackport = "";
					String fetchSessionIdQuery = "call sendSessionIdOfRulleteTripleChance(?)";
					CallableStatement callStmt = getConnection().prepareCall(fetchSessionIdQuery);

					callStmt.setString(1, userid);
					ResultSet rst = callStmt.executeQuery();
					if (rst != null && rst.next()) {
						String session_id = rst.getString("sessionid");
						String status = rst.getString("result");
						String resultwheel = rst.getString("presultwheel");
						String credits = (rst.getString("currentcredits") == null ? "0"
								: rst.getString("currentcredits"));
						Utils.Logger(extension, "credits::::::::::::::" + credits);

						Utils.Logger(extension,
								"DBManager :::::: sendSessionIdOfRulleteTripleChance :::::::: Session :::: "
										+ session_id + "wheel" + resultwheel);
						lastfivewinningnumber = rst.getString("winPosition");
						String oldsessionid = rst.getString("oldsessionid");
						jackport = rst.getString("jackport");

						Utils.Logger(extension,
								"getLastFiveWinPosition" + "currentsessionid" + session_id + "winningnumber"
										+ resultwheel + "lastfivewinningnumber" + lastfivewinningnumber + "oldsessionid"
										+ oldsessionid);

						while (rst.next()) {

							lastfivewinningnumber = lastfivewinningnumber + "," + rst.getString("winPosition");
							jackport = jackport + "," + rst.getString("jackport");

							Utils.Logger(extension,
									"getLastFiveWinPosition::::::::::::resultant Last 5 data" + lastfivewinningnumber);

							// isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
						}

						pCallBack.call(session_id, status, resultwheel, credits, lastfivewinningnumber, oldsessionid,
								jackport);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::sendSessionIdOfRulleteTripleChance :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::sendSessionIdOfRulleteTripleChance :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void sendSessionIdOfRulletePlayMart(String userid,
			com.latestfunroulette.playMart.cache.beans.GameBean tempGameBean, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ResultSet rst = null;
				CallableStatement callStmt = null;
				try {
					String lastfivewinningnumber = "";
					String jackport = "";
					String fetchSessionIdQuery = "call sendSessionIdOfRulletePlayMart(?)";
					callStmt = getConnection().prepareCall(fetchSessionIdQuery);

					callStmt.setString(1, userid);
					rst = callStmt.executeQuery();
					if (rst != null && rst.next()) {
						String session_id = rst.getString("sessionid");
						String status = rst.getString("result");
						String resultwheel = rst.getString("presultwheel");
						String credits = (rst.getString("currentcredits") == null ? "0"
								: rst.getString("currentcredits"));
						Utils.Logger(extension, "credits::::::::::::::" + credits);

						Utils.Logger(extension, "DBManager :::::: sendSessionIdOfRulletePlayMart :::::::: Session :::: "
								+ session_id + "wheel" + resultwheel);
						lastfivewinningnumber = rst.getString("winPosition");
						String oldsessionid = rst.getString("oldsessionid");
						jackport = rst.getString("jackport");

						tempGameBean.setJackport(Integer.parseInt(jackport));

						Utils.Logger(extension,
								"getLastFiveWinPosition" + "currentsessionid" + session_id + "winningnumber"
										+ resultwheel + "lastfivewinningnumber" + lastfivewinningnumber + "oldsessionid"
										+ oldsessionid);

						while (rst.next()) {

							jackport = jackport + "," + rst.getString("jackport");
							lastfivewinningnumber = lastfivewinningnumber + "," + rst.getString("winPosition");

							Utils.Logger(extension,
									"getLastFiveWinPosition::::::::::::resultant Last 5 data" + lastfivewinningnumber);

							// isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
						}

						pCallBack.call(session_id, status, resultwheel, credits, lastfivewinningnumber, oldsessionid,
								jackport);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::sendSessionIdOfRulletePlayMart :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::sendSessionIdOfRulletePlayMart :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(rst, callStmt);
				}
			}
		}.start();
	}

	public static void UpdateLiveTimePlayZeroToNine(int sessionid, int wheelno, CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String UpdateAllRecords = "{call UpdateLiveTimePlayZeroToNine(?,?)}";
					tempStatement = getConnection().prepareCall(UpdateAllRecords);
					tempStatement.setInt(1, sessionid);
					tempStatement.setInt(2, wheelno);

					tempResultSet = tempStatement.executeQuery();
					if (tempResultSet != null && tempResultSet.next()) {
						int oldsessionid = tempResultSet.getInt("oldsessionid");
						int jackport = tempResultSet.getInt("jackport");
						pCallBack.call(oldsessionid, jackport);

					}

				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager :::::::: UpdateLiveTimePlay :::: Error :::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void getGlobalIdZeroToNine(CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				synchronized (this) {
					ResultSet tempResultSet = null;
					CallableStatement tempStatement = null;
					try {
						String globalid = "{call getglobalidZeroToNine()}";
						tempStatement = getConnection().prepareCall(globalid);
						tempResultSet = tempStatement.executeQuery();
						if (tempResultSet != null && tempResultSet.next()) {
							int tempGlobalid = tempResultSet.getInt("id");
							pCallBack.call(tempGlobalid);
						} else {
							pCallBack.call(1);
						}
						DBManager.CloseResult_And_Statement(tempResultSet, tempStatement);

					} catch (SQLException e) {
						pCallBack.call(1);
						Utils.ErrorLogger(extension, "DBManager :::::  getGlobalId ::: Error :: ", e);
					} catch (Exception e) {
						pCallBack.call(1);
						Utils.ErrorLogger(extension, "DBManager :::::  getGlobalId ::: Error :: ", e);
					} finally {
						CloseResult_And_Statement(tempResultSet, tempStatement);

					}
				}
			}
		}.start();
	}

	public static void getGlobalIdPlayMart(CallBack pCallBack) {
		new Thread() {
			@Override
			public void run() {
				synchronized (this) {
					ResultSet tempResultSet = null;
					CallableStatement tempStatement = null;
					try {
						String globalid = "{call getglobalidPlayMart()}";
						tempStatement = getConnection().prepareCall(globalid);
						tempResultSet = tempStatement.executeQuery();
						if (tempResultSet != null && tempResultSet.next()) {
							int tempGlobalid = tempResultSet.getInt("id");
							pCallBack.call(tempGlobalid);
						} else {
							pCallBack.call(1);
						}

					} catch (SQLException e) {
						pCallBack.call(1);
						Utils.ErrorLogger(extension, "DBManager :::::  getGlobalId ::: Error :: ", e);
					} catch (Exception e) {
						pCallBack.call(1);
						Utils.ErrorLogger(extension, "DBManager :::::  getGlobalId ::: Error :: ", e);
					} finally {
						CloseResult_And_Statement(tempResultSet, tempStatement);

					}
				}
			}
		}.start();
	}

	public static void updateUserWinAmountsqlZeroToNine(String userid, int jackport, String winamount,
			int winningnumber, String sessionid, String ticketid, CallBack pCallBack) {
		Utils.Logger(extension, "updateUserWinAmount:::::::::::::::::validateBeforeUserSession:::::::::::userid"
				+ userid + " jackport " + jackport + "final_udated_bal" + winamount + "ticketid" + ticketid);
		new Thread() {

			@Override
			public void run() {
				ISFSObject obj = new SFSObject();
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call before_updateCreditsOnly_new_ZeroToNine(?,?,?,?,?,?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);
					tempStatement.setInt(2, jackport);
					// callStmt1.setString(3, (winNumber.equalsIgnoreCase("0") ? "0" : winNumber));
					// callStmt1.setString(4, sessionId);

					tempStatement.setString(3, winamount);
					tempStatement.setInt(4, winningnumber);
					tempStatement.setString(5, sessionid);
					tempStatement.setString(6, ticketid);

					// callStmt1.setInt(6, pTaksStatus);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");
					if (tempResultSet.next() && tempResultSet != null) {
						String status = tempResultSet.getString("result");
						String currentcredits = tempResultSet.getString("credits");
						String winningamount = tempResultSet.getString("winningamount");
						Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(userid);
						tempPlayer.setChips(currentcredits);

						GameMainExtension.cache.getPlayer().add(tempPlayer);

						Utils.Logger(extension,
								"DBMANAGER :::::::before_updateCreditsOnly_new_ZeroToNine:::::::status" + status);
						if (status.equalsIgnoreCase("true")) {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
						} else {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
						}
					}
					pCallBack.call(obj);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void updateUserWinAmountsqlZeroToNinePrint(String userid, int jackport, String winamount,
			int winningnumber, String sessionid, String ticketid) {
		Utils.Logger(extension, "updateUserWinAmount:::::::::::::::::validateBeforeUserSession:::::::::::userid"
				+ userid + " jackport " + jackport + "final_udated_bal" + winamount + "ticketid" + ticketid);
		new Thread() {

			@Override
			public void run() {
				ISFSObject obj = new SFSObject();
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call before_updateCreditsOnly_new_ZeroToNine(?,?,?,?,?,?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);
					tempStatement.setInt(2, jackport);
					// callStmt1.setString(3, (winNumber.equalsIgnoreCase("0") ? "0" : winNumber));
					// callStmt1.setString(4, sessionId);

					tempStatement.setString(3, winamount);
					tempStatement.setInt(4, winningnumber);
					tempStatement.setString(5, sessionid);
					tempStatement.setString(6, ticketid);

					// callStmt1.setInt(6, pTaksStatus);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");
					if (tempResultSet.next() && tempResultSet != null) {
						String status = tempResultSet.getString("result");
						String currentcredits = tempResultSet.getString("credits");
						String winningamount = tempResultSet.getString("winningamount");
						Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(userid);
						tempPlayer.setChips(currentcredits);

						GameMainExtension.cache.getPlayer().add(tempPlayer);

						Utils.Logger(extension, "DBMANAGER :::::::before_updateCreditsOnly_new:::::::status" + status);
						if (status.equalsIgnoreCase("true")) {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
						} else {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
						}
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void updateUserWinAmountsqlPlayMart(String userid, int jackport, String winamount, int winningnumber,
			String sessionid, String ticketId, CallBack pCallBack) {
		Utils.Logger(extension,
				"playmart::::::::::::::::::::updateUserWinAmountsqlPlayMart:::::::::::::::::validateBeforeUserSession:::::::::::userid"
						+ userid + " jackport " + jackport + "final_udated_bal" + winamount);
		new Thread() {

			@Override
			public void run() {
				ISFSObject obj = new SFSObject();
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call before_updateCreditsOnly_new_playmart(?,?,?,?,?,?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);
					tempStatement.setInt(2, jackport);
					// callStmt1.setString(3, (winNumber.equalsIgnoreCase("0") ? "0" : winNumber));
					// callStmt1.setString(4, sessionId);

					tempStatement.setString(3, winamount);
					tempStatement.setInt(4, winningnumber);
					tempStatement.setString(5, sessionid);
					tempStatement.setString(6, ticketId);

					// callStmt1.setInt(6, pTaksStatus);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");
					if (tempResultSet.next() && tempResultSet != null) {
						String status = tempResultSet.getString("result");
						String currentcredits = tempResultSet.getString("credits");
						String winningamount = tempResultSet.getString("winningamount");
						Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(userid);
						tempPlayer.setChips(currentcredits);

						GameMainExtension.cache.getPlayer().add(tempPlayer);

						Utils.Logger(extension,
								"DBMANAGER :::::::before_updateCreditsOnly_new_playmart:::::::status" + status);
						if (status.equalsIgnoreCase("true")) {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
						} else {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
						}
					}
					pCallBack.call(obj);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void updateUserWinAmountmongoZeroToNinne(String userid, String sessionId, int jackport, int winNumber,
			String final_udated_bal, int pTaksStatus, String chips) {

		double currentchips = Double.parseDouble((chips));
		double totalbetamount = Double.parseDouble((final_udated_bal));
		double currentcredits = (currentchips + totalbetamount);

		// int currentcredits = Integer.parseInt(chips) +
		// Integer.parseInt(final_udated_bal);
		Utils.Logger(extension,
				"DBMANAGER::::::::::::::::::::updateUserWinAmount::::::::::::::updateUserWinAmountmongoZeroToNinne:::::::::::::::validateBeforeUserSession:::::::::::userid"
						+ userid + "winNumber" + winNumber + " sessionId " + sessionId + " jackport " + jackport
						+ "final_udated_bal" + final_udated_bal + "pTaksStatus " + pTaksStatus + "credits"
						+ currentcredits);
		new Thread() {

			@Override
			public void run() {

				try {
					Properties prop = new Properties();
					prop.setProperty("log4j.rootLogger", "WARN");
					PropertyConfigurator.configure(prop);

					// Accessing the database
					DB database = getMongoDB();
					DBCollection collection = database.getCollection("ZeroToNineRoulette");

					BasicDBObject newDocument = new BasicDBObject();
					newDocument.put("userid", userid);
					newDocument.put("sessionId", sessionId);

					BasicDBObject searchQuery = new BasicDBObject().append("currentcredits", winNumber)
							.append("winposition", final_udated_bal).append("winamount", final_udated_bal);

					collection.update(searchQuery, newDocument);

				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					closeMongoDb();
				}
			}
		}.start();
	}

	public static void updateUserWinAmountMongoPlayMart(String userid, String sessionId, int jackport, int winNumber,
			String final_udated_bal, int pTaksStatus, String chips) {

		double currentchips = Double.parseDouble((chips));
		double totalbetamount = Double.parseDouble((final_udated_bal));
		double currentcredits = (currentchips + totalbetamount);

		// int currentcredits = Integer.parseInt(chips) +
		// Integer.parseInt(final_udated_bal);
		Utils.Logger(extension,
				"playmart::::::::::::::::::::updateUserWinAmountMongoPlayMart:::::::::::::::::validateBeforeUserSession:::::::::::userid"
						+ userid + "winNumber" + winNumber + " sessionId " + sessionId + " jackport " + jackport
						+ "final_udated_bal" + final_udated_bal + "pTaksStatus " + pTaksStatus + "credits"
						+ currentcredits);

		try {
			Properties prop = new Properties();
			prop.setProperty("log4j.rootLogger", "WARN");
			PropertyConfigurator.configure(prop);

			// Accessing the database
			DB database = getMongoDB();
			DBCollection collection = database.getCollection("PlayMart");

			BasicDBObject newDocument = new BasicDBObject();
			newDocument.put("userid", userid);
			newDocument.put("sessionId", sessionId);

			BasicDBObject searchQuery = new BasicDBObject().append("currentcredits", winNumber)
					.append("winposition", final_udated_bal).append("winamount", final_udated_bal);

			collection.update(searchQuery, newDocument);

		} catch (Exception e) {
			Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
		} finally {
			closeMongoDb();
		}

	}

	public static void updateUserWinAmountsqlZeroToDoubleNine(String userid, String winamount, String winningnumber,
			String sessionid, int singlewinamount, int doublewinamount, int jackport, String ticketno,
			CallBack pCallBack) {
		Utils.Logger(extension,
				"Doublechance::::::::::::::::::::updateUserWinAmount:::::::::::::::::validateBeforeUserSession:::::::::::userid"
						+ userid + " jackport " + jackport + "winamount" + winamount);
		new Thread() {

			@Override
			public void run() {
				ISFSObject obj = new SFSObject();
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call before_updateCreditsOnly_new_DoubleChance(?,?,?,?,?,?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);
					tempStatement.setInt(2, jackport);
					tempStatement.setString(3, winamount);
					tempStatement.setInt(4, Integer.parseInt(winningnumber));
					tempStatement.setString(5, sessionid);
					tempStatement.setString(6, ticketno);

					// callStmt1.setInt(6, pTaksStatus);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");
					if (tempResultSet.next() && tempResultSet != null) {
						String status = tempResultSet.getString("result");
						String currentcredits = tempResultSet.getString("credits");
						String winningamount = tempResultSet.getString("winningamount");
						Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(userid);
						tempPlayer.setChips(currentcredits);

						GameMainExtension.cache.getPlayer().add(tempPlayer);

						Utils.Logger(extension,
								"DBMANAGER :::::Doublechance::::::::::::::::::::::before_updateCreditsOnly_new:::::::status"
										+ status);
						if (status.equalsIgnoreCase("true")) {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
							obj.putUtfString(Param.SINGLE, String.valueOf(singlewinamount));
							obj.putUtfString(Param.DOUBLE, String.valueOf(doublewinamount));
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
						} else {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
							obj.putUtfString(Param.SINGLE, String.valueOf(singlewinamount));
							obj.putUtfString(Param.DOUBLE, String.valueOf(doublewinamount));

						}
					}
					pCallBack.call(obj);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void updateUserWinAmountsqlZeroToTripleNine(String userid, int jackport, String winamount,
			String winningnumber, String sessionid, int singlewinamount, int doublewinamount, int winamounttriple,
			String ticketId, CallBack pCallBack) {
		Utils.Logger(extension,
				"Doublechance::::::::::::::::::::updateUserWinAmount:::::::::::::::::validateBeforeUserSession:::::::::::userid"
						+ userid + " jackport " + jackport + "winamount" + winamount);
		new Thread() {

			@Override
			public void run() {
				ISFSObject obj = new SFSObject();
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call before_updateCreditsOnly_new_TripleChance(?,?,?,?,?,?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);
					tempStatement.setInt(2, jackport);
					tempStatement.setString(3, winamount);
					tempStatement.setString(4, (winningnumber));
					tempStatement.setString(5, sessionid);
					tempStatement.setString(6, ticketId);

					// callStmt1.setInt(6, pTaksStatus);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");
					if (tempResultSet.next() && tempResultSet != null) {
						String status = tempResultSet.getString("result");
						String currentcredits = tempResultSet.getString("credits");
						String winningamount = tempResultSet.getString("winningamount");
						Player tempPlayer = GameMainExtension.cache.getPlayer().getValueByKey(userid);
						tempPlayer.setChips(currentcredits);

						GameMainExtension.cache.getPlayer().add(tempPlayer);

						Utils.Logger(extension,
								"DBMANAGER :::::TripleChance::::::::::::::::::::::before_updateCreditsOnly_new:::::::status"
										+ status);
						if (status.equalsIgnoreCase("true")) {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
							obj.putUtfString(Param.SINGLE, String.valueOf(singlewinamount));
							obj.putUtfString(Param.DOUBLE, String.valueOf(doublewinamount));
							// obj.putUtfString(Param.TRIPLE, String.valueOf(doublewinamount));
							obj.putUtfString(Param.TRIPLE, String.valueOf(winamounttriple));
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
						} else {
							obj.putUtfString("dbResult", status);
							obj.putUtfString("updationMessage", tempResultSet.getString("message"));
							obj.putUtfString("loginstatus", tempResultSet.getString("loginstatus"));
							obj.putUtfString("credits", currentcredits);
							obj.putUtfString(Param.WINAMOUNT, winningamount);
							obj.putUtfString(Param.SINGLE, String.valueOf(singlewinamount));
							obj.putUtfString(Param.DOUBLE, String.valueOf(doublewinamount));

						}
					}
					pCallBack.call(obj);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}
			}
		}.start();
	}

	public static void updateUserWinAmountmongoZeroToTripleNine(String userid, String sessionId, int jackport,
			String winNumber, String final_udated_bal, int pTaksStatus, String chips) {

		double currentchips = Double.parseDouble((chips));
		double totalbetamount = Double.parseDouble((final_udated_bal));
		double currentcredits = (currentchips + totalbetamount);

		// int currentcredits = Integer.parseInt(chips) +
		// Integer.parseInt(final_udated_bal);
		Utils.Logger(extension,
				"Triplechance::::::::::::::::::::::::::::::updateUserWinAmountmongoZeroToTripleNine:::::::::::::::::validateBeforeUserSession:::::::::::userid"
						+ userid + "winNumber" + winNumber + " sessionId " + sessionId + " jackport " + jackport
						+ "final_udated_bal" + final_udated_bal + "pTaksStatus " + pTaksStatus + "credits"
						+ currentcredits);
		new Thread() {

			@Override
			public void run() {

				try {
					Properties prop = new Properties();
					prop.setProperty("log4j.rootLogger", "WARN");
					PropertyConfigurator.configure(prop);

					// Accessing the database
					DB database = getMongoDB();
					DBCollection collection = database.getCollection("ZeroToTripleNineRoulette");

					BasicDBObject newDocument = new BasicDBObject();
					newDocument.put("userid", userid);
					newDocument.put("sessionId", sessionId);

					BasicDBObject searchQuery = new BasicDBObject().append("currentcredits", winNumber)
							.append("winposition", final_udated_bal).append("winamount", final_udated_bal);

					collection.update(searchQuery, newDocument);

				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					closeMongoDb();
				}
			}
		}.start();
	}

	public static void updateUserWinAmountmongoZeroToDoubleNine(String userid, String sessionId, String winNumber,
			String final_udated_bal, int pTaksStatus, String chips, int jackport) {

		double currentchips = Double.parseDouble((chips));
		double totalbetamount = Double.parseDouble((final_udated_bal));
		double currentcredits = (currentchips + totalbetamount);

		// int currentcredits = Integer.parseInt(chips) +
		// Integer.parseInt(final_udated_bal);
		Utils.Logger(extension,
				"Doublechance::::::::::::::::::::::::::::::updateUserWinAmountmongoZeroToDoubleNine:::::::::::::::::validateBeforeUserSession:::::::::::userid"
						+ userid + "winNumber" + winNumber + " sessionId " + sessionId + " jackport " + jackport
						+ "final_udated_bal" + final_udated_bal + "pTaksStatus " + pTaksStatus + "credits"
						+ currentcredits);
		new Thread() {

			@Override
			public void run() {

				try {
					Properties prop = new Properties();
					prop.setProperty("log4j.rootLogger", "WARN");
					PropertyConfigurator.configure(prop);

					DB database = getMongoDB();
					DBCollection collection = database.getCollection("ZeroToDoubleNineRoulette");

					BasicDBObject newDocument = new BasicDBObject();
					newDocument.put("userid", userid);
					newDocument.put("sessionId", sessionId);

					BasicDBObject searchQuery = new BasicDBObject().append("winposition", winNumber).append("winamount",
							final_udated_bal);

					collection.update(searchQuery, newDocument);

				} catch (Exception e) {
					Utils.ErrorLogger(extension,
							"DBManager ::::::::::::::::::::::::::updateUserWinAmountmongoZeroToDoubleNine:::::::::::::::::::::::::::::::validateUserSession  :::: Error ::: ",
							e);
				} finally {
					closeMongoDb();
				}
			}
		}.start();
	}

	public static void updateUserWinAmountmongoDoubleChanceZeroToNine(String userid, String sessionId, String winNumber,
			String final_udated_bal, int pTaksStatus, String chips, int jackport) {

		double currentchips = Double.parseDouble((chips));
		double totalbetamount = Double.parseDouble((final_udated_bal));
		double currentcredits = (currentchips + totalbetamount);

		// int currentcredits = Integer.parseInt(chips) +
		// Integer.parseInt(final_udated_bal);
		Utils.Logger(extension,
				"updateUserWinAmount:::::::::::::::::validateBeforeUserSession:::::::::::userid" + userid + "winNumber"
						+ winNumber + " sessionId " + sessionId + " jackport " + jackport + "final_udated_bal"
						+ final_udated_bal + "pTaksStatus " + pTaksStatus + "credits" + currentcredits);
		new Thread() {

			@Override
			public void run() {

				try {
					Properties prop = new Properties();
					prop.setProperty("log4j.rootLogger", "WARN");
					PropertyConfigurator.configure(prop);

					// Accessing the database
					DB database = getMongoDB();
					DBCollection collection = database.getCollection("DoubleChanceZeroToNine");

					BasicDBObject newDocument = new BasicDBObject();
					newDocument.put("userid", userid);
					newDocument.put("sessionId", sessionId);

					BasicDBObject searchQuery = new BasicDBObject().append("winposition", winNumber).append("winamount",
							final_udated_bal);

					collection.update(searchQuery, newDocument);

				} catch (Exception e) {
					Utils.ErrorLogger(extension,
							"DBManager ::::::::::::::::::updateUserWinAmountmongoDoubleChanceZeroToNine:::::::::::::::::::::::::::::::::::validateUserSession  :::: Error ::: ",
							e);
				} finally {
					closeMongoDb();
				}
			}
		}.start();
	}

	public static void updateUserWinAmountmongoTripleChanceZeroToDoubleNine(String userid, String sessionId,
			int gameTypeId, String winNumber, String final_udated_bal, int pTaksStatus, String chips) {

		double currentchips = Double.parseDouble((chips));
		double totalbetamount = Double.parseDouble((final_udated_bal));
		double currentcredits = (currentchips + totalbetamount);

		// int currentcredits = Integer.parseInt(chips) +
		// Integer.parseInt(final_udated_bal);
		Utils.Logger(extension,
				"updateUserWinAmount:::::::::::::::::validateBeforeUserSession:::::::::::userid" + userid + "winNumber"
						+ winNumber + " sessionId " + sessionId + " GameTypeId " + gameTypeId + "final_udated_bal"
						+ final_udated_bal + "pTaksStatus " + pTaksStatus + "credits" + currentcredits);
		new Thread() {

			@Override
			public void run() {

				try {
					Properties prop = new Properties();
					prop.setProperty("log4j.rootLogger", "WARN");
					PropertyConfigurator.configure(prop);

					// Accessing the database
					DB database = getMongoDB();
					DBCollection collection = database.getCollection("TripleChanceZeroToDoubleNine");

					BasicDBObject newDocument = new BasicDBObject();
					newDocument.put("userid", userid);
					newDocument.put("sessionId", sessionId);

					BasicDBObject searchQuery = new BasicDBObject().append("currentcredits", currentcredits)
							.append("winposition", winNumber).append("winamount", final_udated_bal);

					collection.update(searchQuery, newDocument);

				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					closeMongoDb();
				}
			}
		}.start();
	}

	public static void updateUserWinAmountmongoTripleChanceZeroToNine(String userid, String sessionId, int gameTypeId,
			String winNumber, String final_udated_bal, int pTaksStatus, String chips) {

		double currentchips = Double.parseDouble((chips));
		double totalbetamount = Double.parseDouble((final_udated_bal));
		double currentcredits = (currentchips + totalbetamount);

		// int currentcredits = Integer.parseInt(chips) +
		// Integer.parseInt(final_udated_bal);
		Utils.Logger(extension,
				"updateUserWinAmount:::::::::::::::::validateBeforeUserSession:::::::::::userid" + userid + "winNumber"
						+ winNumber + " sessionId " + sessionId + " GameTypeId " + gameTypeId + "final_udated_bal"
						+ final_udated_bal + "pTaksStatus " + pTaksStatus + "credits" + currentcredits);
		new Thread() {

			@Override
			public void run() {

				try {
					Properties prop = new Properties();
					prop.setProperty("log4j.rootLogger", "WARN");
					PropertyConfigurator.configure(prop);

					// Accessing the database
					DB database = getMongoDB();
					DBCollection collection = database.getCollection("TripleChanceZeroToNine");

					BasicDBObject newDocument = new BasicDBObject();
					newDocument.put("userid", userid);
					newDocument.put("sessionId", sessionId);

					BasicDBObject searchQuery = new BasicDBObject().append("currentcredits", currentcredits)
							.append("winposition", winNumber).append("winamount", final_udated_bal);

					collection.update(searchQuery, newDocument);

				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					closeConnection();
				}
			}
		}.start();
	}

	public static void getUserGameDetail(String userid, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {
				ISFSObject isfsObject = new SFSObject();

				ISFSArray sFSArray = new SFSArray();

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call getusergamedetail(?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {
						long ticket_id = tempResultSet.getLong("Ticket_id");
						String Game_id = tempResultSet.getString("Game_id");
						String Play = tempResultSet.getString("Play");
						String Win = tempResultSet.getString("Win");
						String Result = tempResultSet.getString("Result");
						String isclaim = tempResultSet.getString("isclaim");
						String Draw_Time = tempResultSet.getString("Draw_Time");
						String Ticket_Time = tempResultSet.getString("Ticket_Time");

						isfsObject.putUtfString("Ticket_id", String.valueOf(ticket_id));
						isfsObject.putUtfString("Game_id", Game_id);
						isfsObject.putUtfString("Play", Play);
						isfsObject.putUtfString("Win", Win);
						isfsObject.putUtfString("Result", Result);
						isfsObject.putUtfString("isclaim", isclaim);
						isfsObject.putUtfString("Draw_Time", Draw_Time);
						isfsObject.putUtfString("Ticket_Time", Ticket_Time);
						sFSArray.addSFSObject(isfsObject);

						// listTicketPojos.add(tikPojo);

					}
					pCallBack.call(sFSArray);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();
	}

	public static String getTicketId() {

		String ticket_id = "";

		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;

		try {

			String updationQuery = "call getTicketId()";
			tempStatement = getConnection().prepareCall(updationQuery);

			tempResultSet = tempStatement.executeQuery();
			Utils.Logger(extension, "Resultset Getting Statement is here ");

			if (tempResultSet.next() && tempResultSet != null) {
				ticket_id = tempResultSet.getString("ticketid");

				// listTicketPojos.add(tikPojo);

			}

		} catch (SQLException e) {
			Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
		} catch (Exception e) {
			Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

		}

		return ticket_id;
	}

	public static void machineTime() {

		new Thread() {

			@Override
			public void run() {
				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {
					GameBean tempGameBeanSingleRoulette = new GameBean();
					com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean tempgamebeanZeroSingleChance = new com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean();
					com.latestfunroulette.dubliRoulette.cache.beans.GameBean tempgamebeandoubleroulette = new com.latestfunroulette.dubliRoulette.cache.beans.GameBean();
					com.latestfunroulette.TripleRoulette.cache.beans.GameBean tempgamebeanTripleroulette = new com.latestfunroulette.TripleRoulette.cache.beans.GameBean();

					List<GameBean> tempGamesListSingleRoulette = GameMainExtension.cache.getGames().getAllValue();

					Utils.Logger(extension,
							"DbManager::::::::::::::::machineTime::::::::::::::::::::::::::::Singleroulette:::::::::::::::::tempGames:::::::::::::::"
									+ tempGamesListSingleRoulette);

					List<com.latestfunroulette.ZerotoNineRoulette.cache.beans.GameBean> tempGameslistSingleChance = GameMainExtension.gameCacheZeroToNine
							.getGames().getAllValue();

					Utils.Logger(extension,
							"DbManager::::::::::::::::machineTime:::::::::::::::::::::::::single chance ::::::::::::::::::::::::::tempGameslistSingleChance"
									+ tempGameslistSingleChance);

					List<com.latestfunroulette.dubliRoulette.cache.beans.GameBean> tempGameListBeansDouble = GameMainExtension.gameCacheDoubleRoulette
							.getGames().getAllValue();

					Utils.Logger(extension,
							"DbManager::::::::::::::::machineTime:::::::::::::::::::::::::Double chance ::::::::::::::::::::::::::tempGameBeansDouble"
									+ tempGameListBeansDouble);

					List<com.latestfunroulette.TripleRoulette.cache.beans.GameBean> tempGameBeanslistTriple = GameMainExtension.gameCacheTripleRoulette
							.getGames().getAllValue();

					Utils.Logger(extension,
							"DbManager::::::::::::::::machineTime:::::::::::::::::::::::::TripleChance ::::::::::::::::::::::::::temp game"
									+ tempGameBeanslistTriple);

					List<GameMachine> list = new ArrayList<GameMachine>();

					int i = 0;

					Utils.Logger(extension,
							":::::::::::::::::dbmanager:::::::::::::::::MachineTime()::::::::::::::::::::");

					String machinetime = "{call machinetime()}";
					tempStatement = getConnection().prepareCall(machinetime);

					tempResultSet = tempStatement.executeQuery();
					int count = 0;
					while (tempResultSet.next()) {

						GameMachine gamemachine = new GameMachine();
						gamemachine.setBetplaceamountstate(tempResultSet.getInt("betplaceamountstate"));
						gamemachine.setGameresultwaitingstate(tempResultSet.getInt("gameresultwaitingstate"));
						gamemachine.setResultstate(tempResultSet.getInt("resultstate"));
						gamemachine.setStatus(tempResultSet.getInt("status"));
						gamemachine.setTotalGameTime(tempResultSet.getInt("TotalGameTime"));
						gamemachine.setDescription(tempResultSet.getString("description"));

						list.add(gamemachine);

						Utils.Logger(extension, "list data timming:::::::::::::::" + list);

						Utils.Logger(extension,
								"DBMANAGER::::::::::::::::::::::::::::::::::description:::::::::::::::::::::"
										+ list.get(count).getDescription() + "COUNT" + count);

						if (list.get(count).getDescription().equals("Roulette Game")) {
							if (list.get(count).getStatus() == 1) {

								Utils.Logger(extension, "Roulette Game:::::::::::::machine Start:::::::::::::::::::::"
										+ list.get(count).getStatus() + ":::::::::::::SingleRouletteRoom:::::::");

								boolean tempstatus = true;

								try {

									Utils.Logger(extension, "size++++++++++++" + tempGamesListSingleRoulette.size()
											+ "machine::::::::" + tempGamesListSingleRoulette.get(i).getGameMachine());
									if (tempGamesListSingleRoulette.size() != 0
											&& tempGamesListSingleRoulette.get(i).getGameMachine() != null) {

										tempstatus = tempGamesListSingleRoulette.get(i).getGameMachine()
												.setMachineStatusSingle(true);

										Utils.Logger(extension, "tempstatus" + tempstatus);
									}
								} catch (Exception e) {
									Utils.Logger(extension, "error:::::::::::::::::::::" + e);
								} //
								Utils.Logger(extension, "dbmanager status::::::::::::::" + tempstatus); //
								// tempGamesListSingleRoulette.get(i).getGameMachine().setMachineStatusSingle(true);

								tempGameBeanSingleRoulette.setStatus(tempstatus);

								Utils.Logger(extension, "betplaceamount state time ::::::::::::::::"
										+ list.get(0).getBetplaceamountstate());
								GameStateTime.BET_PLACE_TIME = list.get(count).getBetplaceamountstate();

								Utils.Logger(extension,
										" Gamse state time ::::::::::::::::::::" + GameStateTime.BET_PLACE_TIME);
								GameStateTime.GAME_WAIT_TIME = list.get(count).getGameresultwaitingstate();
								GameStateTime.GAME_RESULT_TIME = list.get(count).getResultstate();
								GameStateTime.TotalGameTime = list.get(count).getTotalGameTime();
								GameStateTime.status = list.get(count).getStatus();
							} else {

								boolean gamestatus = tempGamesListSingleRoulette.get(i).getGameMachine()
										.setMachineStatusSingle(false);

								tempGameBeanSingleRoulette.setStatus(gamestatus);

							}

						} else if (list.get(count).getDescription().equals("0 to 9 Single Chance Game")) {

							Utils.Logger(extension, "zerotonine::::::::::::::::::::::count::::::::::::::::::" + count);
							if (list.get(count).getStatus() == 1) {

								Utils.Logger(extension,
										"Roulette Game:::::::::::ZeroToNine:::::::::::::machine Start:::::::::::::::::::::"
												+ list.get(count).getStatus()
												+ ":::::::::::::::::::::ZeroToNineLobbyRoom:::::::");

								boolean tempstatus = true;
								try {
									if (tempGameslistSingleChance.size() != 0
											&& tempGameslistSingleChance.get(0).getGameMachine() != null) {

										Utils.Logger(extension,
												"size++++++++++++" + tempGameslistSingleChance.size()
														+ "machine::::::::"
														+ tempGameslistSingleChance.get(0).getGameMachine());

										tempstatus = tempGameslistSingleChance.get(0).getGameMachine()
												.setMachineStatusZeroToNine(true);
									}
								} catch (Exception e) {
									Utils.Logger(extension, "error:::::::::::::::::::::" + e);
								}
								Utils.Logger(extension, "dbmanager status::::::::::::::" + tempstatus);
								tempgamebeanZeroSingleChance.setStatus(tempstatus);

								Utils.Logger(extension, "counter:::::::::::::::::::::::" + count);

								GameStateZeroToNineTime.BET_PLACE_TIME = list.get(count).getBetplaceamountstate();
								GameStateZeroToNineTime.GAME_WAIT_TIME = list.get(count).getGameresultwaitingstate();
								GameStateZeroToNineTime.GAME_RESULT_TIME = list.get(count).getResultstate();
								GameStateZeroToNineTime.TotalGameTime = list.get(count).getTotalGameTime();
								GameStateZeroToNineTime.status = list.get(count).getStatus();

							} else {

								try {
									boolean gamestatus = tempGameslistSingleChance.get(0).getGameMachine()
											.setMachineStatusZeroToNine(false);

									tempgamebeanZeroSingleChance.setStatus(gamestatus);
								} catch (Exception e) {
									Utils.Logger(extension, "error:::::::::::::::::::::" + e);
								}
							}

						}

						if (list.get(count).getDescription().equals("00 to 99 Double Chance Game")) {

							Utils.Logger(extension,
									"DoubleRoulette::::::::::::::::::::::count::::::::::::::::::" + count);
							if (list.get(count).getStatus() == 1) {

								Utils.Logger(extension,
										"Roulette Game:::::::::::DoubleRoulette:::::::::::::machine Start:::::::::::::::::::::"
												+ list.get(count).getStatus()
												+ ":::::::::::::::::::::zeroToDoubleNineLobbyRoom:::::::");

								boolean tempstatus = true;
								try {
									if (tempGameListBeansDouble.size() != 0
											&& tempGameListBeansDouble.get(0).getGameMachine() != null) {

										Utils.Logger(extension, "size++++++++++++" + tempGameListBeansDouble.size()
												+ "machine::::::::" + tempGameListBeansDouble.get(0).getGameMachine());

										tempstatus = tempGameListBeansDouble.get(0).getGameMachine()
												.setMachineStatusDouble(true);
									}
								} catch (Exception e) {
									Utils.Logger(extension, "error:::::::::::::::::::::" + e);
								}
								Utils.Logger(extension, "dbmanager status::::::::::::::" + tempstatus);
								tempgamebeandoubleroulette.setStatus(tempstatus);

								Utils.Logger(extension, "counter:::::::::::::::::::::::" + count);

								GameStateZeroToDoubleNineTime.BET_PLACE_TIME = list.get(count).getBetplaceamountstate();
								GameStateZeroToDoubleNineTime.GAME_WAIT_TIME = list.get(count)
										.getGameresultwaitingstate();
								GameStateZeroToDoubleNineTime.GAME_RESULT_TIME = list.get(count).getResultstate();
								GameStateZeroToDoubleNineTime.TotalGameTime = list.get(count).getTotalGameTime();
								GameStateZeroToDoubleNineTime.status = list.get(count).getStatus();

							} else {

								try {
									boolean gamestatus = tempGameListBeansDouble.get(0).getGameMachine()
											.setMachineStatusDouble(false);

									tempgamebeandoubleroulette.setStatus(gamestatus);
								} catch (Exception e) {
									Utils.Logger(extension, "error:::::::::::::::::::::" + e);
								}
							}

						}

						if (list.get(count).getDescription().equals("000 to 999 Triple Chance Game")) {

							Utils.Logger(extension,
									"TripleRoulette::::::::::::::::::::::count::::::::::::::::::" + count);
							if (list.get(count).getStatus() == 1) {

								Utils.Logger(extension,
										"Roulette Game:::::::::::TripleRoulette:::::::::::::machine Start:::::::::::::::::::::"
												+ list.get(count).getStatus()
												+ ":::::::::::::::::::::zeroTotripleNineLobbyRoom:::::::");

								boolean tempstatus = true;
								try {
									if (tempGameBeanslistTriple.size() != 0
											&& tempGameBeanslistTriple.get(0).getGameMachine() != null) {

										Utils.Logger(extension, "size++++++++++++" + tempGameBeanslistTriple.size()
												+ "machine::::::::" + tempGameBeanslistTriple.get(0).getGameMachine());

										tempstatus = tempGameBeanslistTriple.get(0).getGameMachine()
												.setMachineStatusTripleChance(true);
									}
								} catch (Exception e) {
									Utils.Logger(extension, "error:::::::::::::::::::::" + e);
								}
								Utils.Logger(extension, "dbmanager status::::::::::::::" + tempstatus);
								tempgamebeanTripleroulette.setStatus(tempstatus);

								Utils.Logger(extension, "counter:::::::::::::::::::::::" + count);

								GameStateZeroToTripleNineTime.BET_PLACE_TIME = list.get(count).getBetplaceamountstate();
								GameStateZeroToTripleNineTime.GAME_WAIT_TIME = list.get(count)
										.getGameresultwaitingstate();
								GameStateZeroToTripleNineTime.GAME_RESULT_TIME = list.get(count).getResultstate();
								GameStateZeroToTripleNineTime.TotalGameTime = list.get(count).getTotalGameTime();
								GameStateZeroToTripleNineTime.status = list.get(count).getStatus();

							} else {
								try {

									boolean gamestatus = tempGameBeanslistTriple.get(0).getGameMachine()
											.setMachineStatusTripleChance(false);

									tempgamebeanTripleroulette.setStatus(gamestatus);

								} catch (Exception e) {
									Utils.Logger(extension, "error:::::::::::::::::::::" + e);
								}

							}

						}
						Utils.Logger(extension, "list data timming:::::::::::::::" + count);

						count++;

					}

				} catch (Exception e) {

					Utils.ErrorLogger(extension,
							" Exception ::::::::::::::::DBMANAGER::::::::::::::::::GetMachineTime:::::::::::::::::::"
									+ e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}

		}.start();

	}

/////////////* PlayMart Game User Details *///////////////////////////////////////////

	public static void getUserGameDetail_PlayMart(String userid, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ISFSArray sFSArray = new SFSArray();

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call playmart_getusergamedetailbyday(?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);

					tempResultSet = tempStatement.executeQuery();

					while (tempResultSet.next()) {
						ISFSObject isfsObject = new SFSObject();
						long ticket_id = tempResultSet.getLong("Ticket_id");
						String Game_id = tempResultSet.getString("Game_id");
						String Play = tempResultSet.getString("Play");
						String Win = tempResultSet.getString("Win");
						String Result = tempResultSet.getString("Result");
						String isclaim = tempResultSet.getString("isclaim");
						String Draw_Time = tempResultSet.getString("Draw_Time");
						String Ticket_Time = tempResultSet.getString("Ticket_Time");

						isfsObject.putUtfString("Ticket_id", String.valueOf(ticket_id));
						isfsObject.putUtfString("Game_id", Game_id);
						isfsObject.putUtfString("Play", Play);
						isfsObject.putUtfString("Win", Win);
						isfsObject.putUtfString("Result", Result);
						isfsObject.putUtfString("isclaim", isclaim);
						isfsObject.putUtfString("Draw_Time", Draw_Time);
						isfsObject.putUtfString("Ticket_Time", Ticket_Time);
						sFSArray.addSFSObject(isfsObject);

						// listTicketPojos.add(tikPojo);

						pCallBack.call(sFSArray);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::getUserGameDetail_PlayMart  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::getUserGameDetail_PlayMart  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();
	}

/////////////* Triple Roulette Game User Details *///////////////////////////////////////////

	public static void getUserGameDetail_TripleRoulette(String userid, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ISFSArray sFSArray = new SFSArray();

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call TripleRoulette_getusergamedetailbyday(?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {
						ISFSObject isfsObject = new SFSObject();
						long ticket_id = tempResultSet.getLong("Ticket_id");
						String Game_id = tempResultSet.getString("Game_id");
						String Play = tempResultSet.getString("Play");
						String Win = tempResultSet.getString("Win");
						String Result = tempResultSet.getString("Result");
						String isclaim = tempResultSet.getString("isclaim");
						String Draw_Time = tempResultSet.getString("Draw_Time");
						String Ticket_Time = tempResultSet.getString("Ticket_Time");

						isfsObject.putUtfString("Ticket_id", String.valueOf(ticket_id));
						isfsObject.putUtfString("Game_id", Game_id);
						isfsObject.putUtfString("Play", Play);
						isfsObject.putUtfString("Win", Win);
						isfsObject.putUtfString("Result", Result);
						isfsObject.putUtfString("isclaim", isclaim);
						isfsObject.putUtfString("Draw_Time", Draw_Time);
						isfsObject.putUtfString("Ticket_Time", Ticket_Time);
						sFSArray.addSFSObject(isfsObject);

						// listTicketPojos.add(tikPojo);

					}
					pCallBack.call(sFSArray);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::getUserGameDetail_TripleRoulette  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::getUserGameDetail_TripleRoulette  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();
	}

/////////////* Double Roulette Game User Details *///////////////////////////////////////////

	public static void getUserGameDetail_DoubleRoulette(String userid, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ISFSArray sFSArray = new SFSArray();

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call DoubleRoulette_getusergamedetailbyday(?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {
						ISFSObject isfsObject = new SFSObject();
						long ticket_id = tempResultSet.getLong("Ticket_id");
						String Game_id = tempResultSet.getString("Game_id");
						String Play = tempResultSet.getString("Play");
						String Win = tempResultSet.getString("Win");
						String Result = tempResultSet.getString("Result");
						String isclaim = tempResultSet.getString("isclaim");
						String Draw_Time = tempResultSet.getString("Draw_Time");
						String Ticket_Time = tempResultSet.getString("Ticket_Time");

						isfsObject.putUtfString("Ticket_id", String.valueOf(ticket_id));
						isfsObject.putUtfString("Game_id", Game_id);
						isfsObject.putUtfString("Play", Play);
						isfsObject.putUtfString("Win", Win);
						isfsObject.putUtfString("Result", Result);
						isfsObject.putUtfString("isclaim", isclaim);
						isfsObject.putUtfString("Draw_Time", Draw_Time);
						isfsObject.putUtfString("Ticket_Time", Ticket_Time);
						sFSArray.addSFSObject(isfsObject);

						// listTicketPojos.add(tikPojo);

					}
					pCallBack.call(sFSArray);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();
	}

/////////////* Zero To nine SingleChance   Game User Details *///////////////////////////////////////////

	public static void getUserGameDetail_SingleChance(String userid, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ISFSArray sFSArray = new SFSArray();

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;
				try {

					String updationQuery = "call zeroToNine_SingleChance_getusergamedetailsbyday(?)";
					tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next() && tempResultSet != null) {
						ISFSObject isfsObject = new SFSObject();
						long ticket_id = tempResultSet.getLong("Ticket_id");
						String Game_id = tempResultSet.getString("Game_id");
						String Play = tempResultSet.getString("Play");
						String Win = tempResultSet.getString("Win");
						String Result = tempResultSet.getString("Result");
						String isclaim = tempResultSet.getString("isclaim");
						String Draw_Time = tempResultSet.getString("Draw_Time");
						String Ticket_Time = tempResultSet.getString("Ticket_Time");

						isfsObject.putUtfString("Ticket_id", String.valueOf(ticket_id));
						isfsObject.putUtfString("Game_id", Game_id);
						isfsObject.putUtfString("Play", Play);
						isfsObject.putUtfString("Win", Win);
						isfsObject.putUtfString("Result", Result);
						isfsObject.putUtfString("Isclaim", isclaim);
						isfsObject.putUtfString("Draw_Time", Draw_Time);
						isfsObject.putUtfString("Ticket_Time", Ticket_Time);

						Utils.Logger(extension,
								"dbmanager:::::::::::::::::::::::getUserGameDetail_SingleChance:::::::::::::isfsObject"
										+ isfsObject);

						sFSArray.addSFSObject(isfsObject);

					}

					Utils.Logger(extension,
							"dbmanager:::::::::::::::::::::::getUserGameDetail_SingleChance:::::::::sFSArray"
									+ sFSArray);

					pCallBack.call(sFSArray);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();
	}

	public static void getUserGameTurnOver(String userid, String startdate, String enddate, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ISFSArray sFSArray = new SFSArray();

				try {

					String updationQuery = "call getUserDailyTurnoverSummary(?,?,?)";
					CallableStatement tempStatement = getConnection().prepareCall(updationQuery);
					tempStatement.setString(1, userid);
					tempStatement.setString(2, startdate);
					tempStatement.setString(3, enddate);

					ResultSet tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					if (tempResultSet != null) {

						while (tempResultSet.next()) {
							ISFSObject isfsObject = new SFSObject();
//							if())
							String StartDate = TextUtils.isEmpty(tempResultSet.getString("StartDate")) ? "0"
									: (tempResultSet.getString("StartDate"));
							String EndDate = TextUtils.isEmpty(tempResultSet.getString("EndDate")) ? "0"
									: tempResultSet.getString("EndDate");
							String BetPoint = TextUtils.isEmpty(tempResultSet.getString("BetPoint")) ? "0"
									: tempResultSet.getString("BetPoint");
							String WinPoint = TextUtils.isEmpty(tempResultSet.getString("WinPoint")) ? "0"
									: tempResultSet.getString("WinPoint");
							String commipoint = TextUtils.isEmpty(tempResultSet.getString("commipoint")) ? "0"
									: tempResultSet.getString("commipoint");
							String ntppoint = TextUtils.isEmpty(tempResultSet.getString("ntppoint")) ? "0"
									: tempResultSet.getString("ntppoint");

							isfsObject.putUtfString("StartDate", StartDate);
							isfsObject.putUtfString("EndDate", EndDate);
							isfsObject.putUtfString("BetPoint", BetPoint);
							isfsObject.putUtfString("WinPoint", WinPoint);
							isfsObject.putUtfString("commipoint", commipoint);
							isfsObject.putUtfString("ntppoint", ntppoint);

							sFSArray.addSFSObject(isfsObject);

// listTicketPojos.add(tikPojo);

						}
						pCallBack.call(sFSArray);
					}

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				}
			}
		}.start();
	}

	public static void ZerotoNine_getUsersDayWiseResult(String userid, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ISFSArray sFSArray = new SFSArray();

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {

					String DBQuery = "call zeroToNine_getusersdaywiseresult()";
					tempStatement = getConnection().prepareCall(DBQuery);
					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {
						ISFSObject isfsObject = new SFSObject();
						String date = tempResultSet.getString("Date");
						String result = tempResultSet.getString("Result");

						isfsObject.putUtfString("Date", date);
						isfsObject.putUtfString("Result", result);

						sFSArray.addSFSObject(isfsObject);

					}
					pCallBack.call(sFSArray);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	/* Play Mart UsersDayWiseResult */

	public static void PlayMart_getUsersDayWiseResult(CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ISFSArray sFSArray = new SFSArray();

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {

					String DBQuery = "call PlayMart_getusersdaywiseresult()";
					tempStatement = getConnection().prepareCall(DBQuery);

					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {
						ISFSObject isfsObject = new SFSObject();
						String date = tempResultSet.getString("Date");
						String result = tempResultSet.getString("Result");

						isfsObject.putUtfString("Date", date);
						isfsObject.putUtfString("Result", result);

						sFSArray.addSFSObject(isfsObject);

					}
					pCallBack.call(sFSArray);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();
	}

	public static void Roulette_getUsersDayWiseResult(String userid, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ISFSArray sFSArray = new SFSArray();

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {

					String DBQuery = "call getusersdaywiseresult()";
					tempStatement = getConnection().prepareCall(DBQuery);
					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {
						ISFSObject isfsObject = new SFSObject();
						String date = tempResultSet.getString("Date");
						String result = tempResultSet.getString("Result");

						isfsObject.putUtfString("Date", date);
						isfsObject.putUtfString("Result", result);

						sFSArray.addSFSObject(isfsObject);

					}
					pCallBack.call(sFSArray);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension,
							"DBManager ::  roulette_getusersdaywiseresult  ::::::validateUserSession  :::: Error ::: ",
							e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension,
							"DBManager ::::roulette_getusersdaywiseresult  ::::::::::::validateUserSession  :::: Error ::: ",
							e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void DoubleChance_getUsersDayWiseResult(String userid, CallBack pCallBack) {

		new Thread() {

			@Override
			public void run() {

				ISFSArray sFSArray = new SFSArray();

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {

					String DBQuery = "call DoubleChance_getusersdaywiseresult()";
					tempStatement = getConnection().prepareCall(DBQuery);
					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {

						ISFSObject isfsObject = new SFSObject();
						String date = tempResultSet.getString("Date");
						String result = tempResultSet.getString("Result");

						isfsObject.putUtfString("Date", date);
						isfsObject.putUtfString("Result", result);

						sFSArray.addSFSObject(isfsObject);

					}
					pCallBack.call(sFSArray);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void TripleChance_getUsersDayWiseResult(String userid, CallBack pCallBack) {
		new Thread() {

			@Override
			public void run() {

				ISFSArray sFSArray = new SFSArray();

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {

					String DBQuery = "call TripleChance_getusersdaywiseresult()";
					tempStatement = getConnection().prepareCall(DBQuery);
					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {

						ISFSObject isfsObject = new SFSObject();

						String date = tempResultSet.getString("Date");
						String result = tempResultSet.getString("Result");

						isfsObject.putUtfString("Date", date);
						isfsObject.putUtfString("Result", result);

						sFSArray.addSFSObject(isfsObject);

					}
					pCallBack.call(sFSArray);

				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::validateUserSession  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void getAllGamesClaimStatus(String userid, String ticketid, int gameid, String gametype,
			CallBack pCallBack) {

		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;

		try {

			String DBQuery = "call claimTicket(?,?,?,?)";
			tempStatement = getConnection().prepareCall(DBQuery);
			tempStatement.setString(1, userid);
			tempStatement.setString(2, ticketid);
			tempStatement.setInt(3, gameid);
			tempStatement.setString(4, gametype);
			tempResultSet = tempStatement.executeQuery();
			Utils.Logger(extension, "Resultset Getting Statement is here ");

			if (tempResultSet != null && tempResultSet.next()) {

				ISFSObject isfsObject = new SFSObject();

				String status = tempResultSet.getString("STATUS");
				String msg = tempResultSet.getString("message");
				String totalbalance = tempResultSet.getString("totalbalance");

				isfsObject.putUtfString("status", status);
				isfsObject.putUtfString("message", msg);
				isfsObject.putUtfString("credits", totalbalance);

				pCallBack.call(isfsObject);
			}
		} catch (SQLException e) {
			Utils.ErrorLogger(extension, "DBManager ::::getsingleCanceClaimStatus  :::: Error ::: ", e);
		} catch (Exception e) {
			Utils.ErrorLogger(extension, "DBManager ::::getsingleCanceClaimStatus  :::: Error ::: ", e);
		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

		}

	}

	public static void getPlayMartClaimStatus(String userid, String ticketid, CallBack pCallBack) {
		new Thread() {

			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {

					String DBQuery = "call getClaimStatusPlayMart(?,?)";
					tempStatement = getConnection().prepareCall(DBQuery);
					tempStatement.setString(1, userid);
					tempStatement.setString(2, ticketid);
					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {

						ISFSObject isfsObject = new SFSObject();

						String status = tempResultSet.getString("status");
						String msg = tempResultSet.getString("msg");

						isfsObject.putUtfString("status", status);
						isfsObject.putUtfString("msg", msg);

						pCallBack.call(isfsObject);
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::getDoubleChanceClaimStatus  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::getDoubleChanceClaimStatus  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static class Data {
		private String betNos;
		private Double betAmount;

		public String getBetNos() {
			return betNos;
		}

		public void setBetNos(String betNos) {
			this.betNos = betNos;
		}

		public Double getBetAmount() {
			return betAmount;
		}

		public void setBetAmount(Double betAmount) {
			this.betAmount = betAmount;
		}

	}

	public static void getDoubleChanceClaimStatus(String userid, String ticketid, CallBack pCallBack) {
		new Thread() {

			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {

					String DBQuery = "call getClaimStatusDoubleChance(?,?)";
					tempStatement = getConnection().prepareCall(DBQuery);
					tempStatement.setString(1, userid);
					tempStatement.setString(2, ticketid);
					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {

						ISFSObject isfsObject = new SFSObject();

						String status = tempResultSet.getString("status");
						String msg = tempResultSet.getString("msg");

						isfsObject.putUtfString("status", status);
						isfsObject.putUtfString("msg", msg);

						pCallBack.call(isfsObject);
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::getDoubleChanceClaimStatus  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::getDoubleChanceClaimStatus  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void getRouletteClaimStatus(String userid, String ticketid, CallBack pCallBack) {
		new Thread() {

			@Override
			public void run() {

				ResultSet tempResultSet = null;
				CallableStatement tempStatement = null;

				try {

					String DBQuery = "call getClaimStatusRoulette(?,?)";
					tempStatement = getConnection().prepareCall(DBQuery);
					tempStatement.setString(1, userid);
					tempStatement.setString(2, ticketid);
					tempResultSet = tempStatement.executeQuery();
					Utils.Logger(extension, "Resultset Getting Statement is here ");

					while (tempResultSet.next()) {

						ISFSObject isfsObject = new SFSObject();

						String status = tempResultSet.getString("status");
						String msg = tempResultSet.getString("msg");

						isfsObject.putUtfString("status", status);
						isfsObject.putUtfString("msg", msg);

						pCallBack.call(isfsObject);
					}
				} catch (SQLException e) {
					Utils.ErrorLogger(extension, "DBManager ::::getRouletteClaimStatus  :::: Error ::: ", e);
				} catch (Exception e) {
					Utils.ErrorLogger(extension, "DBManager ::::getRouletteClaimStatus  :::: Error ::: ", e);
				} finally {
					CloseResult_And_Statement(tempResultSet, tempStatement);

				}

			}
		}.start();

	}

	public static void getAllbetsByTicketId(String ticketid, CallBack pcCallBack) {

		Utils.Logger(extension, "getAllbetsByTicketId::::::::::::::::: TICKETID:::::::::" + ticketid);

		try {

			ISFSArray isfsArray = new SFSArray();
			DB db = getMongoDB();

			DBCollection col = db.getCollection("ZeroToNineRoulette");

			DBObject query = BasicDBObjectBuilder.start().add("ticketid", ticketid).get();

			BasicDBObject fields = new BasicDBObject();

			fields.put("ZeroToNinedata", 3);

			DBCursor cursor = col.find(query);
			while (cursor.hasNext()) {

				String jsondata = cursor.next().toString();
				System.out.println(jsondata);

				try {

					JSONObject jsonObject = new JSONObject(jsondata);
					String Roulettebetdatastr = jsonObject.getString("ZeroToNinedata");

					JSONArray jsonArrayRoulettebetdata = new JSONArray(Roulettebetdatastr);

					System.out.println("------------------");
					// ArrayList<Data> dataList = new ArrayList<DBManager.Data>();
					for (int i = 0; i < jsonArrayRoulettebetdata.length(); i++) {
						ISFSObject isfsObject = new SFSObject();
						JSONObject object = jsonArrayRoulettebetdata.getJSONObject(i);
						String betno = object.getString("betNos");
						Double betAmount = object.getDouble("betAmount");

						isfsObject.putUtfString("betNos", betno);
						isfsObject.putDouble("betAmount", betAmount);
						isfsArray.addSFSObject(isfsObject);

					}

					pcCallBack.call(isfsArray);
//					isfsObject.putDouble("betamount", betamount);
					// isfsObject.putUtfString("betNos", betno);

				} catch (Exception e) {
					// TODO: handle exception
				}

			}
			pcCallBack.call(isfsArray);

		} catch (Exception e) {
			Utils.ErrorLogger(extension, "Dbmanager:::::::::::::::::::getAllbetsByTicketId:::::::::::::::::error" + e);
		} finally {
			closeMongoDb();
		}

	}

	public static void getAllbetsByTicketIdPlayMart(String ticketid, CallBack pcCallBack) {

		Utils.Logger(extension, "getAllbetsByTicketIdPlayMart::::::::::::::::: TICKETID:::::::::" + ticketid);

		try {

			ISFSArray isfsArray = new SFSArray();
			DB db = getMongoDB();

			DBCollection col = db.getCollection("PlayMart");

			DBObject query = BasicDBObjectBuilder.start().add("ticketid", ticketid).get();

			// BasicDBObject fields = new BasicDBObject();

			// fields.put("Roulettebetdata", 3);

			DBCursor cursor = col.find(query);
			while (cursor.hasNext()) {

				String jsondata = cursor.next().toString();
				System.out.println(jsondata);

				try {

					JSONObject jsonObject = new JSONObject(jsondata);
					String Roulettebetdatastr = jsonObject.getString("Roulettebetdata");

					JSONArray jsonArrayRoulettebetdata = new JSONArray(Roulettebetdatastr);

					System.out.println("------------------");
					// ArrayList<Data> dataList = new ArrayList<DBManager.Data>();
					for (int i = 0; i < jsonArrayRoulettebetdata.length(); i++) {
						ISFSObject isfsObject = new SFSObject();
						JSONObject object = jsonArrayRoulettebetdata.getJSONObject(i);
						String betno = object.getString("betNos");
						Double betAmount = object.getDouble("betAmount");

						isfsObject.putUtfString("betNos", betno);
						isfsObject.putDouble("betAmount", betAmount);
						isfsArray.addSFSObject(isfsObject);

					}

					pcCallBack.call(isfsArray);
//					isfsObject.putDouble("betamount", betamount);
					// isfsObject.putUtfString("betNos", betno);

				} catch (Exception e) {
					// TODO: handle exception
				}

			}
			pcCallBack.call(isfsArray);

		} catch (Exception e) {
			Utils.ErrorLogger(extension,
					"Dbmanager:::::::::::::::::::getAllbetsByTicketIdPlayMart:::::::::::::::::error" + e);
		} finally {
			closeMongoDb();
		}

	}

	public static void getAllCancelTicketByTicketid(String userid, String ticketid, int gameid, double betamount,
			CallBack pCallBack) {

		Utils.Logger(extension,
				"dbmanager::::::::::::::::::getAllCancelTicketByTicketid" + "userid:::::::::" + userid
						+ "ticketid:::::::::::::::" + ticketid + "gameid:::::::::" + gameid + "betamount::::::::::::"
						+ betamount);

		ResultSet tempResultSet = null;
		CallableStatement tempStatement = null;

		try {

			String DBQuery = "call getcancel_ticket(?,?,?,?)";
			tempStatement = getConnection().prepareCall(DBQuery);
			tempStatement.setString(1, userid);
			tempStatement.setString(2, ticketid);
			tempStatement.setInt(3, gameid);
			tempStatement.setString(4, String.valueOf(betamount));
			tempResultSet = tempStatement.executeQuery();
			Utils.Logger(extension, "Resultset Getting Statement is here ");

			if (tempResultSet.next()) {

				ISFSObject isfsObject = new SFSObject();

				String status = tempResultSet.getString("STATUS");
				String msg = tempResultSet.getString("message");

				String tickettime = tempResultSet.getString("tickettime");
				String totalbetamount = tempResultSet.getString("totalbetamount");
				String canceltime = tempResultSet.getString("canceltime");
				String drawtime = tempResultSet.getString("drawtime");

				isfsObject.putUtfString("status", status);
				isfsObject.putUtfString("msg", msg);

				isfsObject.putUtfString("tickettime", tickettime);
				isfsObject.putUtfString("totalbetamount", totalbetamount);
				isfsObject.putUtfString("canceltime", canceltime);
				isfsObject.putUtfString("drawtime", drawtime);
				pCallBack.call(isfsObject);

			}
		} catch (SQLException e) {
			Utils.ErrorLogger(extension, "DBManager ::::getRouletteClaimStatus  :::: Error ::: ", e);
		} catch (Exception e) {
			Utils.ErrorLogger(extension, "DBManager ::::getRouletteClaimStatus  :::: Error ::: ", e);
		} finally {
			CloseResult_And_Statement(tempResultSet, tempStatement);

		}

	}

}
