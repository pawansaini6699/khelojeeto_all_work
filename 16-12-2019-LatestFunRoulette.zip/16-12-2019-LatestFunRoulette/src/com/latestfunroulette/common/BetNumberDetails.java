package com.latestfunroulette.common;

public class BetNumberDetails {
	public String command = "";
	public double winAmountFactor;
	public double betSplitFactor;

	public String getCommand() {
		return command;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public double getWinAmountFactor() {
		return winAmountFactor;
	}

	public void setWinAmountFactor(double winAmountFactor) {
		this.winAmountFactor = winAmountFactor;
	}

	public double getBetSplitFactor() {
		return betSplitFactor;
	}

	public void setBetSplitFactor(double betSplitFactor) {
		this.betSplitFactor = betSplitFactor;
	}

	@Override
	public String toString() {
		return "BetNumberDetails [command=" + command + ", winAmountFactor=" + winAmountFactor + ", betSplitFactor="
				+ betSplitFactor + "]";
	}

}
