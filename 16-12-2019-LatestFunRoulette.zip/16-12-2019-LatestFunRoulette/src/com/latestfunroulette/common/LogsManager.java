package com.latestfunroulette.common;

import java.io.File;

public class LogsManager {

	public static void loggerDelete() {

		new Thread() {
			@Override
			public void run()

			{
				try {

					File folder1 = new File(System.getProperty("user.dir") + File.separator + "logs");
					File folder2 = new File(System.getProperty("user.dir") + File.separator + "logs" +File.separator + "http");
					File folder3 = new File(System.getProperty("user.dir") + File.separator + "logs"+ File.separator + "boot");

					File fList1[] = folder1.listFiles();
					File fList2[] = folder2.listFiles();
					File fList3[] = folder3.listFiles();

					for (File f1 : fList1) {
						if (f1.getName().startsWith("smartfox.log")) {

							System.out.println(f1.getName());
							f1.delete();
						}
						
					}

					for (File f3 : fList3) {
						if (f3.getName().startsWith("boot.log")) {

							System.out.println(" boot logs :::  " + f3.getName());
							f3.delete();
						}
					}

					for (File f2 : fList2) {
						if (f2.getName().endsWith(".log")) {

							System.out.println(" http logs ::: " + f2.getName());
							f2.delete();

						}
					}
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println(e);
				}

			}

		}.start();

	}

}
