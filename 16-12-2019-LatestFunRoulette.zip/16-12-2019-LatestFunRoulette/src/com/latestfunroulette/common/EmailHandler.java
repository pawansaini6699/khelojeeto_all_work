package com.latestfunroulette.common;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.latestfunroulette.extension.GameMainExtension;

public class EmailHandler {
	public void send(String umail, String upass, String playerName) {

		final String username = "developer@brsoftech.com";
		final String password = "brsoft@123";
		String user_mail = umail;
		String User_pass = upass;
		String host = "smtp.gmail.com";

		Properties props = new Properties();

		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.ssl.trust", host);

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			playerName = playerName.substring(0, 1).toUpperCase().concat(playerName).substring(1);
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("from-email@gmail.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(user_mail));
			message.setSubject("New Password");
			message.setText("Dear " + playerName + "," + "\n\n We have received your change password request."
					+ "\n\n New password is : " + User_pass
					+ "\n\n This is a system generated email please do not reply. \n\n\nThanks & Regards\nEstimation Kingdom Team.");

			Transport.send(message);

			Utils.Logger(GameMainExtension.extension,"New password successfully send on the user id:" + user_mail);

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	public void sendChatToMail(Map<String, String> userChat) {
		final String username = "developer@brsoftech.com";
		final String password = "brsoft@123";
		String user_mail = "vijen15690@gmail.com";
		Map<String, String> User_chat = new HashMap<String, String>();
		User_chat = userChat;
		String host = "smtp.gmail.com";

		Properties props = new Properties();

		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", "587");
		props.put("mail.smtp.ssl.trust", host);

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("from-email@gmail.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(user_mail));
			message.setSubject("User Abusive Chat History..");
			message.setText("Dear User," + "\n\n Please find the Users Chat.\n\n" + User_chat);
			Transport.send(message);
			Utils.Logger(GameMainExtension.extension,"Abusing Chat Data  send on the user id:" + user_mail);

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}
}