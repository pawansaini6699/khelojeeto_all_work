package com.latestfunroulette.common;

import com.latestfunroulette.cache.beans.SessionBean;
import com.latestfunroulette.common.Constants.Trigger;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.Zone;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;

import net.sf.json.JSONObject;

public class SupportTriggers {

	// WeakReference<SFSExtension> ref_extension;

	public SupportTriggers() {

		// ref_extension = new WeakReference<SFSExtension>(extension);

	}

	public Object handleTriggers(String cmd, Object params) {
		JSONObject tempJSONObj = new JSONObject();
		if (cmd.equalsIgnoreCase(Trigger.NAME)) {
			ISFSObject apiParams = (ISFSObject) params;
			String triggerId = apiParams.getUtfString(Trigger.ID);
			String triggerName = apiParams.getUtfString(Trigger.NAME);

			if (triggerId != null && !triggerId.trim().isEmpty() && triggerName != null
					&& !triggerName.trim().isEmpty()) {
				tempJSONObj.accumulate(Trigger.RESULT, Constants.EnableStatus.ENABLE);
				tempJSONObj.accumulate(Trigger.OPCODE, Constants.OPCode.SUCCESSFULL);
				tempJSONObj.accumulate(Trigger.MESSAGE, Constants.Message.TRIGGER_MESSAGE);
				print("SupportTriggers ::::::: HandleTriggers() ::::: TriggerName = " + triggerName + ",\n TriggerId = "
						+ triggerId);
				if (triggerName.equalsIgnoreCase(Trigger.ADD_USER_CHIPS)) {
					DBManager.updatePlayerChips(triggerId, new CallBack() {
						@Override
						public void call(Object... callback) {
						}
					});
				} else if (triggerName.equalsIgnoreCase(Trigger.USER_BLOCKED)) {
					DBManager.getUserBlockedStatus(triggerId, new CallBack() {
						@Override
						public void call(Object... callback) {

						}
					});
				} /*
					 * else if (triggerName.equalsIgnoreCase(Trigger.UPDATE_STATUS_SHAREPOINT)) {
					 * DBManager.getupdateSharePointDetailsByUserId(triggerId, new CallBack() {
					 * 
					 * @Override public void call(Object... callback) {
					 * 
					 * } });
					 * 
					 * }
					 */

				else if (triggerName.equalsIgnoreCase(Trigger.CURRENTTIME)) {
					Zone currentzone = GameMainExtension.extension.getParentZone();
					if (currentzone.getName().equalsIgnoreCase("RulletZone")) {

						tempJSONObj.accumulate(Trigger.CURRENTTIME,
								GameMainExtension.gamePlayEventTask.getAdminCurrentRouletteTime());

					}
				}

				else if (triggerName.equalsIgnoreCase(Trigger.UPDATE_MACHINE_STATUS)) {

					DBManager.machineTime();

				}

				else if (triggerName.equalsIgnoreCase(Trigger.CURRENT_SESSION_DATA)) {
					Utils.Logger(GameMainExtension.extension,
							"SupportTriggers :::::: Current Session data :::::: call");
					String extensionName = GameMainExtension.extension.getParentZone().getName();
					// Utils.Logger(GameMainExtension.extension," Support Triggers :::: Extension
					// Name ::::
					// "+extensionName);
					// RulletZone
					if (extensionName.equalsIgnoreCase("RouletteGame")) {

						/*
						 * SessionBean tempSessionBean =
						 * GameMainExtension.cache.getGameSessionBySessionId()
						 * .getValueByKey(triggerId);
						 */
						String sessiondata = "";
						/*
						 * if (tempSessionBean == null) { ISFSObject tempSFSObject = new SFSObject();
						 * tempSFSObject.putUtfString("Error", "Session is not exist."); sessiondata =
						 * tempSFSObject.toJson().toString(); } else { sessiondata =
						 * tempSessionBean.getSessionBetDetail(); }
						 */
						tempJSONObj.accumulate(Trigger.DATA, sessiondata);
					}
				} else if (triggerName.equalsIgnoreCase(Trigger.CURRENT_USER_ID)) {
					Utils.Logger(GameMainExtension.extension, "SupportTriggers :::::: User Session data :::::: call");
					String extensionName = GameMainExtension.extension.getParentZone().getName();
					// Utils.Logger(GameMainExtension.extension," Support Triggers :::: Extension
					// Name ::::
					// "+extensionName);
					// RulletZone
					if (extensionName.equalsIgnoreCase("RouletteGame")) {
						SessionBean tempSessionBean = GameMainExtension.cache.getGameSessionBySessionId()
								.getValueByKey(triggerId);
						String userData = "";
						if (tempSessionBean == null) {
							ISFSObject tempSFSObject = new SFSObject();
							tempSFSObject.putUtfString("Error", "User data is not exist.");
							userData = tempSFSObject.toJson().toString();
						} else {
							userData = tempSessionBean.getUserBetDetail(triggerId);
						}
						tempJSONObj.accumulate(Trigger.DATA, userData);
					}
				}

				else if (triggerName.equalsIgnoreCase(Trigger.ZERO_TO_NINE_CURRENT_SESSION_DATA)) {
					Utils.Logger(GameMainExtension.extension,
							"SupportTriggers :::::: Current Session data :::::: call");
					String extensionName = GameMainExtension.extension.getParentZone().getName();
					// Utils.Logger(GameMainExtension.extension," Support Triggers :::: Extension
					// Name ::::
					// "+extensionName);
					// RulletZone
					if (extensionName.equalsIgnoreCase("RouletteGame")) {
						com.latestfunroulette.ZerotoNineRoulette.cache.beans.SessionBean tempSessionBean = GameMainExtension.gameCacheZeroToNine
								.getGameSessionBySessionId().getValueByKey(triggerId);
						String sessiondata = "";
						if (tempSessionBean == null) {
							ISFSObject tempSFSObject = new SFSObject();
							tempSFSObject.putUtfString("Error", "Session is not exist.");
							sessiondata = tempSFSObject.toJson().toString();
						} else {
							sessiondata = tempSessionBean.getSessionBetDetail();
						}
						tempJSONObj.accumulate(Trigger.DATA, sessiondata);
					}
				}

				else if (triggerName.equalsIgnoreCase(Trigger.ZERO_TO_DOUBLE_NINE_CURRENT_SESSION_DATA)) {
					Utils.Logger(GameMainExtension.extension,
							"SupportTriggers :::::: Current Session data :::::: call");
					String extensionName = GameMainExtension.extension.getParentZone().getName();
					// Utils.Logger(GameMainExtension.extension," Support Triggers :::: Extension
					// Name ::::
					// "+extensionName);
					// RulletZone
					if (extensionName.equalsIgnoreCase("RouletteGame")) {
						com.latestfunroulette.dubliRoulette.cache.beans.SessionBean tempSessionBean = GameMainExtension.gameCacheDoubleRoulette
								.getGameSessionBySessionId().getValueByKey(triggerId);
						String sessiondata = "";
						if (tempSessionBean == null) {
							ISFSObject tempSFSObject = new SFSObject();
							tempSFSObject.putUtfString("Error", "Session is not exist.");
							sessiondata = tempSFSObject.toJson().toString();
						} else {
							// sessiondata = tempSessionBean.getSessionBetDetail();
						}
						tempJSONObj.accumulate(Trigger.DATA, sessiondata);
					}
				} /*
					 * else if (triggerName.equalsIgnoreCase(Trigger.
					 * ZERO_TO_TRIPLE_NINE_CURRENT_SESSION_DATA)) {
					 * Utils.Logger(GameMainExtension.extension,
					 * "SupportTriggers :::::: Current Session data :::::: call"); String
					 * extensionName = GameMainExtension.extension.getParentZone().getName(); //
					 * Utils.Logger(GameMainExtension.extension," Support Triggers :::: Extension
					 * Name :::: // "+extensionName); // RulletZone if
					 * (extensionName.equalsIgnoreCase("RouletteGame")) {
					 * com.latestfunroulette.TripleRoulette.cache.beans.SessionBean tempSessionBean
					 * = GameMainExtension.gameCacheTripleRoulette
					 * .getGameSessionBySessionId().getValueByKey(triggerId); String sessiondata =
					 * ""; if (tempSessionBean == null) { ISFSObject tempSFSObject = new
					 * SFSObject(); tempSFSObject.putUtfString("Error", "Session is not exist.");
					 * sessiondata = tempSFSObject.toJson().toString(); } else { sessiondata =
					 * tempSessionBean.getSessionBetDetail(); } tempJSONObj.accumulate(Trigger.DATA,
					 * sessiondata); }
					 * 
					 * }
					 */

				else {
					tempJSONObj.clear();
					tempJSONObj.accumulate(Trigger.RESULT, Constants.EnableStatus.DISABLE);
					tempJSONObj.accumulate(Trigger.OPCODE, Constants.OPCode.TRIGGER_ERROR);
					tempJSONObj.accumulate(Trigger.MESSAGE, Constants.Message.TRIGGER_ERROR_MESSAGE);
				}
			}

			else {
				tempJSONObj.accumulate(Trigger.RESULT, Constants.EnableStatus.DISABLE);
				tempJSONObj.accumulate(Trigger.OPCODE, Constants.OPCode.TRIGGER_ERROR);
				tempJSONObj.accumulate(Trigger.MESSAGE, Constants.Message.TRIGGER_ERROR_MESSAGE);
			}
		}

		else {
			tempJSONObj.accumulate(Trigger.RESULT, Constants.EnableStatus.DISABLE);
			tempJSONObj.accumulate(Trigger.OPCODE, Constants.OPCode.TRIGGER_ERROR);
			tempJSONObj.accumulate(Trigger.MESSAGE, Constants.Message.TRIGGER_ERROR_MESSAGE);
		}
		Utils.Logger(GameMainExtension.extension, "tempJSONObj" + tempJSONObj.toString());
		return tempJSONObj.toString();
	}

	private void print(Object msg) {
	}
}