package com.latestfunroulette.game.common;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.game.common.interfaces.IGloblaId;

public final class GlobalIds implements IGloblaId {

	private int tempGlobalId = 0;

	@Override
	public void updateId() {
		update();
	}

	@Override
	public int getCurrentId() {
		return getCurrent();
	}

	@Override
	public synchronized int getNextId() {
		return getNext();
	}

	@Override
	public synchronized String getNextId(String f) {
		return getNext(f);
	}

	private void update() {
		DBManager.getGlobalId(new CallBack() {

			@Override
			public void call(Object... value) {
				tempGlobalId = ((int) value[0]);
			}
		});
	}

	private int getCurrent() {
		return tempGlobalId;
	}

	public synchronized int getNext() {
		return ++tempGlobalId;
	}

	public synchronized String getNext(String format) {
		return String.format(format, ++tempGlobalId);
	}
}