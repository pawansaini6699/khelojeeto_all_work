package com.latestfunroulette.game.common;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

class Test extends Thread {

	Test() {
		setName("sqldata");
		
		Utils.Logger(GameMainExtension.extension,"insertdatathread"  +"thread name:::::::::::::"+getName());
		
	}
}