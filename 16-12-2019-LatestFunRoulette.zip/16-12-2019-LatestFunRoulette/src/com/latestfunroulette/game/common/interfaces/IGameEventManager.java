package com.latestfunroulette.game.common.interfaces;


import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.game.base.interfaces.IState;
import com.latestfunroulette.game.machine.interfaces.IStateMachine;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.latestfunroulette.cache.beans.GameBean;

public interface IGameEventManager {

	void onLiveBet(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onGetWinningNumber(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onCancelSpecificBet(User pUser, ISFSObject params,CallBack pCallBack);
	
	void onClearAllBet(User pUser, ISFSObject params,CallBack pCallBack);
	
	void onRebet(User pUser, ISFSObject params,CallBack pCallBack);
	
	void onBetOK(User pUser, ISFSObject params,CallBack pCallBack);
	
	

	void onPlayerLeave(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onRemoveBetCustomise(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onUserGameDetails(User pUser, ISFSObject params, CallBack pCallBack);

	void onUserGameDetailsStartAndEndDate(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onBetPrintExe(User pUser, ISFSObject params, CallBack pCallBack);
	
	void UsersDayWiseResult(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onCancelTicketRoulette(User pUser, ISFSObject params, CallBack pCallBack);
	
	void onClaimTicket(User pUser, ISFSObject params, CallBack pCallBack);
	
	
	/////////////////////////////////////////////////////////////////////////////////////

	default IStateMachine<GameBean> getGameMachine(String pRoomName) {
		if (GameMainExtension.cache.getGames().getValueByKey(pRoomName) != null) {
			print(" ::::::: GAME IS FOUND  ::::::::  " + pRoomName);
			return GameMainExtension.cache.getGames().getValueByKey(pRoomName).getGameMachine();
		} else {
			print(" ::::::: GAME IS NULL   ::::::::  " + pRoomName);
			return null;
		}
	}

	default IState<GameBean> getCurrentState(String pRoomName) {
		
		GameBean gb=GameMainExtension.cache.getGames().getValueByKey(pRoomName);
			return gb.getGameMachine().currentState();
	}

	default void print(String msg) {
		Utils.Logger(GameMainExtension.extension, "GameEventManager ::::: " + msg);
	}

}