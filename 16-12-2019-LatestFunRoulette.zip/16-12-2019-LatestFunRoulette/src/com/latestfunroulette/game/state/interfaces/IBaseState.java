package com.latestfunroulette.game.state.interfaces;

import com.latestfunroulette.game.base.interfaces.IState;

public interface IBaseState<G> extends IState<G> {

	


}
