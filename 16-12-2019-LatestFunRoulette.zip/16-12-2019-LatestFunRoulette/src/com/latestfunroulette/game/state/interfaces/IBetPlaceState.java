package com.latestfunroulette.game.state.interfaces;

import com.smartfoxserver.v2.entities.User;

public interface IBetPlaceState<G> extends IBaseState<G> {

	void onCancelBet(String roomname, String userid, String session_id);

	void onClearAll(String roomname, User user, String session_id);

	void onRebetRequest(String roomname, User user, String session_id);

	void betPlaceState(String userid, String session_id, int coins, int numbers, int gameid);

	void userBetSave(String roomname, User user, String session_id);

	void userBetRemove(String roomname, String session_id, int betno, User user, double coins);

	void userGameDetails(String roomname, User user);

	void userGameDetailsStartAndEndDate(String roomname, User user, String startDate, String endDate);

	void betPrintExe(String roomname, String sessionId, User user);

	void UsersDayWiseResultGameDetails(String roomname, User user);

	void betCancelByTicketId(String roomname, String sessionId, User user, String ticketid);

	void betClaimByTicketId_Roulette(String roomname, String sessionId, User user, String ticketid,int gameid,String gametype);

}
