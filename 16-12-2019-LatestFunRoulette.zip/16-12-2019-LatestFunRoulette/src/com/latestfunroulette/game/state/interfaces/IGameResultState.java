package com.latestfunroulette.game.state.interfaces;

public interface IGameResultState<G> extends IBaseState<G> {

}
