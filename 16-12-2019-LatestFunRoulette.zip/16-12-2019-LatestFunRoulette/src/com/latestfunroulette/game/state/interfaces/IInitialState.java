package com.latestfunroulette.game.state.interfaces;

public interface IInitialState<G> extends IBaseState<G> {

}