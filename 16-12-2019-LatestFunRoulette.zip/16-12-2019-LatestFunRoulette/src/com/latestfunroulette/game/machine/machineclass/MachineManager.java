package com.latestfunroulette.game.machine.machineclass;

import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.game.machine.interfaces.IMachineManager;
import com.latestfunroulette.game.machine.interfaces.IStateMachine;

public class MachineManager implements IMachineManager {

	@Override
	public void join(String pLoginId, String pRoomName) {
		GameBean tempGameBean = GameMainExtension.cache.getGames().getValueByKey(pRoomName);
		Utils.Logger(GameMainExtension.extension,tempGameBean.getGameMachine());
		if (tempGameBean.getGameMachine() == null) {
			IStateMachine<GameBean> tempStateMachine = new Machine();
			tempGameBean.setGameMachine(tempStateMachine);
		//	tempGameBean.setGameState(GameState.PLAYERWAIT);
			tempStateMachine.onStart(tempGameBean);
			tempStateMachine.onJoin(pLoginId);
		} else {
			tempGameBean.getGameMachine().onJoin(pLoginId);
		}
	}
}