/**
 * 
 */
package com.latestfunroulette.game.machine.interfaces;

import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.RTimer;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.game.base.interfaces.IState;
import com.latestfunroulette.game.state.BetPlaceBetAmountState;
import com.latestfunroulette.game.state.GameResultWaitingState;
import com.latestfunroulette.game.state.InitialState;
import com.latestfunroulette.game.state.GameResultState;

/**
 * @author Ubuntu
 *
 */
public interface IStateMachine<G> extends IState<G> {

	void onNext(String pState);

	IState<G> currentState();

	boolean isMachineStatus();

	boolean setMachineStatusSingle(boolean status);

	RTimer getTimer();

	default IState<GameBean> getState(String pState) {
		Utils.Logger(GameMainExtension.extension, "IStateMachine:::::::::::pState" + pState);
		IState<GameBean> tempState = null;

		if (pState.equalsIgnoreCase(GameState.INITIAL)) {
			tempState = new InitialState();

			// Utils.Logger(GameMainExtension.extension, "INITIAL" + tempState);
		} else if (pState.equalsIgnoreCase(GameState.BETPLACESTATE)) {

			tempState = new BetPlaceBetAmountState();
			// Utils.Logger(GameMainExtension.extension, "PLAYERWAIT" + pState);

		} else if (pState.equalsIgnoreCase(GameState.RESULTWAIT)) {
			tempState = new GameResultWaitingState();

		} else if (pState.equalsIgnoreCase(GameState.RESULT)) {
			tempState = new GameResultState();
		} else if (pState.equalsIgnoreCase(GameState.EXIT)) {

			//
		}
		return tempState;
	}
}