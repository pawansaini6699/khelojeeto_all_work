package com.latestfunroulette.game.machine.interfaces;

public interface IMachineManager {

	void join(String pLoginId, String pRoomName);

}