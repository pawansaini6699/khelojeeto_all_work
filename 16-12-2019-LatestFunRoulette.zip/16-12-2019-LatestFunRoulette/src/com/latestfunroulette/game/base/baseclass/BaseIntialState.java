package com.latestfunroulette.game.base.baseclass;

import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.game.base.interfaces.BaseState;

public abstract class BaseIntialState extends BaseState {

	@Override
	protected void init(GameBean pGameBane, int pStateTime) {
		// TODO Auto-generated method stub
		super.init(pGameBane, pStateTime);
		updateSessionId();
	}

	private void updateSessionId() {

	}

}
