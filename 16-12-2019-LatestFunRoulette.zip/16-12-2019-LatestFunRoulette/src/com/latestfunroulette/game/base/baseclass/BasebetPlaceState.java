package com.latestfunroulette.game.base.baseclass;

import java.util.List;

import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.cache.beans.RouletteBetBeans;
import com.latestfunroulette.cache.beans.SessionBean;
import com.latestfunroulette.cache.beans.UserBetBean;
import com.latestfunroulette.common.BetNumbers;
import com.latestfunroulette.common.RemoveBetNumbersCustomise;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.game.base.interfaces.BaseState;
import com.smartfoxserver.v2.entities.User;

public abstract class BasebetPlaceState extends BaseState {

	@Override
	protected void init(GameBean pGameBane, int pStateTime) {
		super.init(pGameBane, pStateTime);
		SessionBean sessionBean = GameMainExtension.cache.getGameSessionBySessionId()
				.getValueByKey(pGameBane.getSession_id());
		if (sessionBean != null) {
			Utils.Logger(GameMainExtension.extension, "BaseState::::::::::::::::::::" + sessionBean.toString());

		} else {
			Utils.Logger(GameMainExtension.extension, "BaseState::::::::::::::::::::is null");

		}

	}

	protected void updateBetStatus(String userid, String session_id, int coins, int number, int gameid) {

		Utils.Logger(GameMainExtension.extension, "BasebetPlaceState  ::::::  userid" + userid + "sessionid"
				+ session_id + "coins" + coins + "selectednumbers" + number);

		BetNumbers.splitBetNumbers(userid, session_id, coins, number, gameid);

	}

	public void cancelSpecificBet(String userid, String session_id) {

		String betAmount = "";
		SessionBean tempGameSessionBean = GameMainExtension.cache.getGameSessionBySessionId().getValueByKey(session_id);
		if (tempGameSessionBean != null) {
			UserBetBean tempUser = tempGameSessionBean.getUserBetBeanByUserId(userid);
			List<RouletteBetBeans> tempRouletteBets = tempUser.getUserRouletteBets();

			if (tempUser != null) {

				// betAmount = tempUser.getTotalBetAmount();
				betAmount = String.valueOf(tempRouletteBets.get((tempRouletteBets.size() - 1)).getBetAmount());
			}
			tempGameSessionBean.cancelSpecificRouletteBet(userid);

			getEvents().specificClearBet(this, betAmount, userid);
		}
	}

	public void clearAllBetsRoulette(String session_id, User user, String roomname) {
		double betamount = 0;

		SessionBean tempSessionBean = GameMainExtension.cache.getGameSessionBySessionId().getValueByKey(session_id);
		if (tempSessionBean != null) {
			UserBetBean tempUser = tempSessionBean.getUserBetBeanByUserId(user.getName());
			if (tempUser != null) {

				betamount = Double.parseDouble((tempUser.getTotalBetAmount()));
			}

			tempSessionBean.cancelAllRouletteBet(user.getName());
			getEvents().clearBet(this, betamount, user);

		}

	}

	public void onUserBetSave(String roomname, User user, String session_id) {

		SessionBean tempSession = GameMainExtension.cache.getGameSessionBySessionId().getValueByKey(session_id);
		// Room tempRoom =
		// GameMainExtension.extension.getParentZone().getRoomByName(roomname);

		// List<User> tempUsers1 = tempRoom.getUserList();

		if (tempSession != null) {
			UserBetBean tempUserBetBean = tempSession.getUserBetBeanByUserId(user.getName());

			if (tempUserBetBean != null) {
				tempUserBetBean.setBetStatus(true);
				Utils.Logger(GameMainExtension.extension, "true");
				getEvents().betSave(this, user, session_id, roomname);
			}
		}
	}

	public void betRemoveUser(String session_id, String roomname, int betno, User user, double coins) {
		RemoveBetNumbersCustomise.splitBetNumbersRemove(session_id, betno, user, coins);

		// tempSessionBean.cancelSpecifiChooseAdmin(userid, String.valueOf(betno));
		getEvents().betRemoveUser(this, session_id, roomname, betno, user, coins);

	}

	public void getGameDetailsRoulette(String roomname, User user) {
		getEvents().getGameDetails(this, roomname, user);

	}

	public void getGameDetailsRouletteStartAndEndDate(String roomname, User user, String startDate, String EndDate) {
		getEvents().getGameDetailsDateWise(this, roomname, user, startDate, EndDate);

	}

	public void betPrintExeUser(String roomname, String sessionid, User user) {

		getEvents().sendUserbetsDetails(this, roomname, sessionid, user);

	}

	public void getGameDetailsResult_Roulette(String roomname, User user) {
		getEvents().sendGameDetailsResult_Roulette(this, roomname, user);

	}

	public void betCancelByTicketIdUser(String roomname, String sessionid, User user, String ticket_id) {

		getEvents().betCancelByTicketId(this, roomname, sessionid, user, ticket_id);

	}
	
	public void betClaimByTicketIdUser(String roomname, String sessionid, User user, String ticket_id,int gameid,String gametype) {

		getEvents().betClaimByTicketId(this, roomname, sessionid, user, ticket_id,gameid,gametype);

	}

}
