/**
 * 
 */
package com.latestfunroulette.cache.caching;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.cache.beans.SessionBean;
import com.latestfunroulette.cache.caching.interfaces.ISessionCache;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

/**
 * @author nagjee
 *
 */
public class SessionCache extends HashMap<String, SessionBean>
		implements Serializable, ISessionCache<String, SessionBean> {

	private static final long serialVersionUID = 1L;

	@Override
	public void add(SessionBean v) {
		put(v.getSessionId(), v);
	}

	@Override
	public void delete(String k) {
		try {
			remove(k);
		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension,"SessionCache:::::::::::::::" + e);
		}
	}

	@Override
	public SessionBean getValueByKey(String k) {

		return get(k);

	}

	@Override
	public List<SessionBean> getAllValue() {
		return new ArrayList<>(values());
	}

	@Override
	public void clearAllSession() {
		// clear();
	}

	@Override
	public HashMap<String, SessionBean> getAll() {
		return this;
	}

	@Override
	public void update(String k, SessionBean v) {
		// TODO Auto-generated method stub

	}

	@Override
	public final void clear() {
		// super.clear();
	}

}