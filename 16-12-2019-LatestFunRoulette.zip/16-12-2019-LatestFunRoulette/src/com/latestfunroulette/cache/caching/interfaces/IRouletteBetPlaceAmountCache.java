/**
 * 
 */
package com.latestfunroulette.cache.caching.interfaces;

/**
 * @author Lal Chand Sharma
 *
 */
public interface IRouletteBetPlaceAmountCache<K,V> extends IBaseCache<K, V> {

}
