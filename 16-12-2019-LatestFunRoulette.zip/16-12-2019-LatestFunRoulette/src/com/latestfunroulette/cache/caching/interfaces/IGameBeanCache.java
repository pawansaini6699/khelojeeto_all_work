package com.latestfunroulette.cache.caching.interfaces;

public interface IGameBeanCache<K, V> extends IBaseCache<K, V> {

}