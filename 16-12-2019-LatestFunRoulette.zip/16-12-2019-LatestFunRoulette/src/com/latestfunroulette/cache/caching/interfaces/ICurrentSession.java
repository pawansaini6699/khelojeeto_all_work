/**
 * 
 */
package com.latestfunroulette.cache.caching.interfaces;

/**
 * @author nagjee
 *
 */
public interface ICurrentSession<S> {

	void updateCurrentSession(S s);
	
	S getCurrentSession();
	
}
