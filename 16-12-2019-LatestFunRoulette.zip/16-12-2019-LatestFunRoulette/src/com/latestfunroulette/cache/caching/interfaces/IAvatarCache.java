package com.latestfunroulette.cache.caching.interfaces;

public interface IAvatarCache<K, V> extends IBaseCache<K, V> {

}