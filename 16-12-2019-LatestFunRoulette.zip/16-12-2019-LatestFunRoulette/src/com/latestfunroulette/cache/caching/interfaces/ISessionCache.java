/**
 * 
 */
package com.latestfunroulette.cache.caching.interfaces;

/**
 * @author nagjee
 *
 */
public interface ISessionCache<K,V> extends IBaseCache<K, V> {

 void clearAllSession();	
 
 
	
}
