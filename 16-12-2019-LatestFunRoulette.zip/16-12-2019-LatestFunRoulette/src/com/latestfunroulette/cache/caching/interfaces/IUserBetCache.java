/**
 * 
 */
package com.latestfunroulette.cache.caching.interfaces;

/**
 * @author nagjee
 *
 */
public interface IUserBetCache<K,V> extends IBaseCache<K, V> {

}
