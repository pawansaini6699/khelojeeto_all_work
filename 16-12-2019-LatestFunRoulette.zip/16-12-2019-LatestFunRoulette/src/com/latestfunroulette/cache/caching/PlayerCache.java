package com.latestfunroulette.cache.caching;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.cache.caching.interfaces.IPlayerCache;

public class PlayerCache extends HashMap<String, Player> implements Serializable, IPlayerCache<String, Player> {

	private static final long serialVersionUID = 1L;



	@Override
	public void add(Player v) {
		put(v.getUserid(), v);
	}

	@Override
	public void delete(String k) {
		remove(k);
	}

	@Override
	public Player getValueByKey(String k) {
		return get(k);
	}

	@Override
	public List<Player> getAllValue() {
		return new ArrayList<>(values());
	}

	@Override
	public HashMap<String, Player> getAll() {
		return getAll();
	}

	@Override public void update(String k, Player v) { // TODO Auto-generated
	
	  
	  }

}