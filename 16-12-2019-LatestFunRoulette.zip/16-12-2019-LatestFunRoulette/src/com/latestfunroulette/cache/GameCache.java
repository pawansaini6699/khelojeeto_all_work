package com.latestfunroulette.cache;

import com.latestfunroulette.cache.beans.AvatarBean;
import com.latestfunroulette.cache.beans.CurrentSessionBean;
import com.latestfunroulette.cache.beans.GameBean;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.cache.beans.SessionBean;
import com.latestfunroulette.cache.caching.AvatarCache;
import com.latestfunroulette.cache.caching.GameBeanCache;
import com.latestfunroulette.cache.caching.PlayerCache;
import com.latestfunroulette.cache.caching.SessionCache;
import com.latestfunroulette.cache.caching.interfaces.IAvatarCache;
import com.latestfunroulette.cache.caching.interfaces.ICurrentSession;
import com.latestfunroulette.cache.caching.interfaces.IGameBeanCache;
import com.latestfunroulette.cache.caching.interfaces.IPlayerCache;
import com.latestfunroulette.cache.caching.interfaces.ISessionCache;

/**
 * @author nagjee
 *
 */
public class GameCache {

	private volatile static IPlayerCache<String, Player> tempPlayerCache;
	private ISessionCache<String, SessionBean> tempSessionCache = null;

	
	private ICurrentSession<String> tempGameSession = null;
	private static IGameBeanCache<String, GameBean> tempGame;
	private static IAvatarCache<String, AvatarBean> tempAvatar;

	public GameCache() {
		tempAvatar = new AvatarCache();
		tempPlayerCache = new PlayerCache();
		tempGame = new GameBeanCache();
		tempSessionCache = new SessionCache();
		tempGameSession = new CurrentSessionBean();
	
	}

	public ISessionCache<String, SessionBean> getGameSessionBySessionId() {
		return tempSessionCache;
	}

	

	public ICurrentSession<String> getSession() {
		return tempGameSession;
	}

	public IGameBeanCache<String, GameBean> getGames() {
		return tempGame;
	}

	public IAvatarCache<String, AvatarBean> getAvatar() {
		return tempAvatar;
	}

	public IPlayerCache<String, Player> getPlayer() {
		return tempPlayerCache;
	}
}