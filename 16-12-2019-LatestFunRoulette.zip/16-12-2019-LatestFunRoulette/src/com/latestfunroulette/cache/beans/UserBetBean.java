/**
 * 
 */
package com.latestfunroulette.cache.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;

import com.latestfunroulette.cache.caching.RouletteBetPlaceAmountCache;
import com.latestfunroulette.cache.caching.interfaces.IRouletteBetPlaceAmountCache;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

public class UserBetBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userId;

	private int gameId;

	private boolean betStatus = false;
	private BigDecimal totalBetAmount1 = new BigDecimal(0.0);
	private List<RouletteBetBeans> tempRouletteBets = new ArrayList<RouletteBetBeans>();
	List<RouletteBetBeans> tempamountwithoutsplit = new ArrayList<RouletteBetBeans>();
	HashSet<String> betnohashset = new HashSet<String>();
	private IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> rouletteBetPlaceAmount = new RouletteBetPlaceAmountCache();

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
		addBetPlaces();
	}

	public int getGameId() {
		return gameId;
	}

	public void setGameId(int gameId) {
		this.gameId = gameId;
	}

	public boolean isBetStatus() {
		return betStatus;
	}

	public void setBetStatus(boolean betStatus) {
		this.betStatus = betStatus;
	}

	public String getTotalBetAmount() {
		return totalBetAmount1.toString();
	}

	public void setTotalBetAmount(String totalBetAmount) {
		this.totalBetAmount1 = new BigDecimal(totalBetAmount);
	}

	public List<RouletteBetBeans> getUserRouletteBets() {
		return tempRouletteBets;
	}

	public List<RouletteBetBeans> getUserRouletteBetsWithoutSplit() {
		return tempamountwithoutsplit;
	}

	public synchronized void addRouletteBet(int pBetAmount, String pBetNos, int pBetPlaceCount, double pBetSplitAmount,
			int pBetWinAmount, String pCommand) {
		// totalBetAmount = String.valueOf(Double.parseDouble(totalBetAmount) +
		// pBetAmount);
		totalBetAmount1 = totalBetAmount1.add(new BigDecimal(pBetAmount));
		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		// splitamount = splitamount.add(new BigDecimal(pBetSplitAmount));
		// splitamount = splitamount.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension,"UserBetBean::::::::::::::addRouletteBet:::::::::::::::::::totalBetAmount1:::::::::::::::::"
				+ totalBetAmount1 + "betno" + pBetNos + "::::::::::::::::::::");

		RouletteBetBeans tempRouletteBet = new RouletteBetBeans();
		tempRouletteBet.setBetAmount(pBetAmount);
		tempRouletteBet.setBetNos(pBetNos);
		tempRouletteBet.setBetPlaceCount(pBetPlaceCount);
		tempRouletteBet.setSplitBetAmount(pBetSplitAmount);
		tempRouletteBet.setBetWinAmount(pBetWinAmount);
		tempRouletteBet.setCommands(pCommand);
		tempRouletteBets.add(tempRouletteBet);

	
	}

	public synchronized void addRouletteBetWithOutSplit(int pBetAmount, String pBetNos, int pBetWinAmount,
			String pCommand) {

		RouletteBetBeans tempRouletteBet = new RouletteBetBeans();

		if (betnohashset.contains(pBetNos)) {
			Utils.Logger(GameMainExtension.extension,"addRouletteBetWithOutSplit::::::::::::::::::::if part:::::::::::::::");
			for (int i = 0; i < tempamountwithoutsplit.size(); i++) {
				if (tempamountwithoutsplit.get(i).getBetNos().equals(pBetNos)) {

					tempamountwithoutsplit.get(i)
							.setBetAmount(pBetAmount + tempamountwithoutsplit.get(i).getBetAmount());
					break;
				}
			}

		} else {

			Utils.Logger(GameMainExtension.extension,"addRouletteBetWithOutSplit:::::::::::::::::::::::::::else part:::::");
			tempRouletteBet.setBetAmount(pBetAmount);
			tempRouletteBet.setBetNos(pBetNos);
			// tempRouletteBet.setBetWinAmount(pBetWinAmount);
			tempRouletteBet.setCommands(pCommand);
			tempamountwithoutsplit.add(tempRouletteBet);

		}

		betnohashset.add(pBetNos);

	}

	public synchronized void cancelSpecificRouletteBet() {

		RouletteBetBeans tempRemovableBean = (tempRouletteBets.get(tempRouletteBets.size() - 1));

		totalBetAmount1 = totalBetAmount1.subtract((new BigDecimal((tempRemovableBean).getBetAmount())));

		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		ListIterator<RouletteBetBeans> iterator = tempamountwithoutsplit.listIterator();

		// RouletteBetBeans tempRouletteBetBeans =
		// (tempRouletteBets.get(tempRouletteBets.size() - 1));

		Utils.Logger(GameMainExtension.extension,"tempRemovableBean:::::::::::::::::" + tempRemovableBean + " size::::::::::::::::::::"
				+ tempRouletteBets.size());

		while (iterator.hasNext()) {

			RouletteBetBeans rouletteBetBeans = (RouletteBetBeans) iterator.next();

			tempRouletteBets.remove(tempRemovableBean);

			Utils.Logger(GameMainExtension.extension,"tempRouletteBets ::::::::::::::::::::::::size::::::::::::" + tempRouletteBets.size());

			if (rouletteBetBeans.getBetNos().equals(tempRemovableBean.getBetNos())) {

				// tempRouletteBets.remove(tempRouletteBets.size() - 1);
				// tempRouletteBetBeans = (tempRouletteBets.get(tempRouletteBets.size() - 1));

				if (tempRouletteBets.size() != 0) {

					Utils.Logger(GameMainExtension.extension,"tempRouletteBets :::::::::::::::::if condition:::::::size::::::::::::"
							+ tempRouletteBets.size());

					// tempRemovableBean = tempRemovableBean;
				} else {
					tempRemovableBean = new RouletteBetBeans();

				}

				Utils.Logger(GameMainExtension.extension,"cancelSpecificRouletteBet:::::::::::::::listbetamount:::::::::::::"
						+ tempRemovableBean.getBetAmount());
				rouletteBetBeans.setBetAmount(rouletteBetBeans.getBetAmount() - tempRemovableBean.getBetAmount());

			}
			Utils.Logger(GameMainExtension.extension,":::::::before if:::::::::BetNo::::::::::::::::::" + rouletteBetBeans.getBetNos()
					+ "::::::::::::::::::betamount::::::::::::::::::::" + rouletteBetBeans.getBetAmount());
			if (rouletteBetBeans.getBetAmount() == 0) {

				iterator.remove();


			}
			Utils.Logger(GameMainExtension.extension,":::::::after if:::::::::BetNo::::::::::::::::::" + rouletteBetBeans.getBetNos()
					+ "::::::::::::::::::betamount::::::::::::::::::::" + rouletteBetBeans.getBetAmount());
		}

		Utils.Logger(GameMainExtension.extension,
				" UserBet BEan cancelSpecificRouletteBet()::::::::::::::::::::  totalBetAmount1 " + totalBetAmount1
						+ "::::::::::::::::::tempamountwithoutsplit:::::::::::" + tempamountwithoutsplit + "iterator"
						+ iterator.hasNext());

		Utils.Logger(GameMainExtension.extension,
				"UserBet BEan cancelSpecificRouletteBet()::::::::::::::::::::  userlist" + tempRouletteBets);

		if (totalBetAmount1.doubleValue() < 0)
			totalBetAmount1 = new BigDecimal(0.0);
	}

	public RouletteBetBeans getCurrentRouletteBet() {
		return tempRouletteBets.get(tempRouletteBets.size() - 1);

	}

	

	public void cancelAllRouletteBet() {

		Utils.Logger(GameMainExtension.extension,
				" UserBet BEan cancelAllRouletteBet() tempRouletteBets  " + tempRouletteBets.toString());
		tempRouletteBets.clear();
		tempamountwithoutsplit.clear();

		Utils.Logger(GameMainExtension.extension,
				"UserBetBean:::::::::::::::::cancelAllRouletteBet::::::::::::::::::::::::tempRouletteBets:::::::::::::::::::::::"
						+ tempRouletteBets);
		Utils.Logger(GameMainExtension.extension,
				"UserBetBean:::::::::::::::::cancelAllRouletteBet::::::::::::::::::::::::tempamountwithoutsplit:::::::::::::::::::::::"
						+ tempamountwithoutsplit);

	}

	public synchronized void cancelRandomBets(UserBetBean userBetBean, String betNo, String userid) {

		Utils.Logger(GameMainExtension.extension,
				":::: user bet bean::::::::::::::::cancelRandomBets :::::::totalBetAmount1::" + totalBetAmount1);

		List<RouletteBetBeans> selectedbetlist = new ArrayList<RouletteBetBeans>();
		List<RouletteBetBeans> unselectedbetlist = new ArrayList<RouletteBetBeans>();

		ListIterator<RouletteBetBeans> iterator = tempRouletteBets.listIterator();

		while (iterator.hasNext()) {

			RouletteBetBeans rouletteBetBeans = (RouletteBetBeans) iterator.next();

			if (rouletteBetBeans.getBetNos().equals(betNo)) {

				selectedbetlist.add(rouletteBetBeans);

				Utils.Logger(GameMainExtension.extension,"selectedbetlist" + selectedbetlist);
			} else {
				unselectedbetlist.add(rouletteBetBeans);
				Utils.Logger(GameMainExtension.extension,"unselectedbetlist" + unselectedbetlist);
			}

		}

		if (selectedbetlist.size() > 0) {

			totalBetAmount1 = totalBetAmount1
					.subtract((new BigDecimal((selectedbetlist.get(selectedbetlist.size() - 1)).getBetAmount())));

			totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

			selectedbetlist.remove(selectedbetlist.size() - 1);

			Utils.Logger(GameMainExtension.extension,"selectedbetlist::::::::::::::::remove" + selectedbetlist);

			Utils.Logger(GameMainExtension.extension,
					" UserBet BEan cancelRandomBets()  totalBetAmount1 " + totalBetAmount1);

			if (totalBetAmount1.doubleValue() < 0)
				totalBetAmount1 = new BigDecimal(0.0);

		}
		tempRouletteBets.clear();
		Utils.Logger(GameMainExtension.extension,"list++++++++++++" + tempRouletteBets);
		tempRouletteBets.addAll(selectedbetlist);
		tempRouletteBets.addAll(unselectedbetlist);
		Utils.Logger(GameMainExtension.extension,"list:::::::::::::::" + tempRouletteBets);

		Utils.Logger(GameMainExtension.extension,":::: user bet bean::::::::::::::::cancelRandomBets :::::::tempRouletteBets::"
				+ tempRouletteBets + ":::::::::::::::::::::::::::::::totalbetamount" + totalBetAmount1);

	}

	public synchronized void cancelRandomBetsWithoutSplit(UserBetBean userBetBean, String betNo, double coins,
			String userid) {

		Utils.Logger(GameMainExtension.extension,":::: user bet bean::::::::::::::::cancelRandomBetsWithoutSplit :::::::betNo::" + betNo);

		List<RouletteBetBeans> selectedbetWithoutsplitlist = new ArrayList<RouletteBetBeans>();
		List<RouletteBetBeans> unselectedbetWithoutsplitlist = new ArrayList<RouletteBetBeans>();

		ListIterator<RouletteBetBeans> iterator = tempamountwithoutsplit.listIterator();

		while (iterator.hasNext()) {

			RouletteBetBeans rouletteBetBeans = (RouletteBetBeans) iterator.next();

			if (rouletteBetBeans.getBetNos().equals(betNo)) {

				selectedbetWithoutsplitlist.add(rouletteBetBeans);

				Utils.Logger(GameMainExtension.extension,"selectedbetWithoutsplitlist" + selectedbetWithoutsplitlist);
			} else {
				unselectedbetWithoutsplitlist.add(rouletteBetBeans);
				Utils.Logger(GameMainExtension.extension,"unselectedbetWithoutsplitlist" + unselectedbetWithoutsplitlist);
			}

		}

		if (selectedbetWithoutsplitlist.size() > 0) {

			Utils.Logger(GameMainExtension.extension,"selectedbetWithoutsplitlist:::::::::::::::::" + selectedbetWithoutsplitlist
					+ ":::::::::size::::::::  " + selectedbetWithoutsplitlist.size());
			RouletteBetBeans tempRouletteBetBeans = (selectedbetWithoutsplitlist
					.get(selectedbetWithoutsplitlist.size() - 1));

			if (tempRouletteBetBeans.getBetAmount() == 0) {
				Utils.Logger(GameMainExtension.extension,
						"selectedbetWithoutsplitlist:::::::::::::::::size" + selectedbetWithoutsplitlist.size());
				selectedbetWithoutsplitlist.remove(tempRouletteBetBeans);
			} else {
				tempRouletteBetBeans.setBetAmount(tempRouletteBetBeans.getBetAmount() - coins);

			}

		}

		tempamountwithoutsplit.clear();
		Utils.Logger(GameMainExtension.extension,"list++++++++++++" + tempamountwithoutsplit);
		tempamountwithoutsplit.addAll(selectedbetWithoutsplitlist);
		tempamountwithoutsplit.addAll(unselectedbetWithoutsplitlist);
		Utils.Logger(GameMainExtension.extension,"list:::::::::::::::" + tempamountwithoutsplit);
	}

	//////////////////////////////////////////////////////////////////////////

	public IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> getUserBetPlaceAmount() {
		return rouletteBetPlaceAmount;
	}

	private void addBetPlaces() {
		for (int bp = 0; bp < 38; bp++) {

			if (bp == 0) {
				RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
				tempRBP.setBetNo("00");
				rouletteBetPlaceAmount.add(tempRBP);

			} else {

				RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
				tempRBP.setBetNo(String.valueOf(bp - 1));
				rouletteBetPlaceAmount.add(tempRBP);
			}
		}
	}

	public synchronized void doubletotalBetAmount(double pBetAmount) { //
		// totalBetAmount = String.valueOf(Double.parseDouble(totalBetAmount) +
		// pBetAmount);

		totalBetAmount1 = totalBetAmount1.add(new BigDecimal(pBetAmount));
		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension,"totalBetAmount1:::::::::::::::::" + totalBetAmount1);

	}

	@Override
	public String toString() {
		return "UserBetBean [userId=" + userId + ", gameId=" + gameId + ", betStatus=" + betStatus
				+ ", totalBetAmount1=" + totalBetAmount1 + ", tempRouletteBets=" + tempRouletteBets
				+ ", rouletteBetPlaceAmount=" + rouletteBetPlaceAmount + "]";
	}

	public void setUserRouletteBets(List<RouletteBetBeans> tempRouletteBets) {
		this.tempRouletteBets = tempRouletteBets;
	}

}