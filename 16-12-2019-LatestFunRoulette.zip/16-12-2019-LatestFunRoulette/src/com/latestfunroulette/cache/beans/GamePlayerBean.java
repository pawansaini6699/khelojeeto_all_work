package com.latestfunroulette.cache.beans;

import java.io.Serializable;

import com.latestfunroulette.common.Constants.DefaultValue;
import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.UserConnectionStatus;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;

public class GamePlayerBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;
	private String userid;
	

	private String image;
	private String chips;
	private String currentLevel = DefaultValue.BEGINNER_LEVEL;
	private String currentLevelCount = DefaultValue.ZERO;

	private String seatNo = DefaultValue.ZERO;
	private boolean status = EnableStatus.ENABLE;
	private boolean bot = EnableStatus.DISABLE;
	private boolean botConfirmation = EnableStatus.DISABLE;
	private boolean isRoundRestart = EnableStatus.DISABLE;
	private String chatText = "Chat:";
	private int userStatus = UserConnectionStatus.NONE;
	private boolean isAutoPLay = EnableStatus.DISABLE;
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getChatText() {
		return chatText;
	}

	public void setChatText(String chatText) {
		this.chatText = chatText;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getChips() {
		return chips;
	}

	public void setChips(String chips) {
		this.chips = chips;
	}

	public String getCurrentLevel() {
		return currentLevel;
	}

	public void setCurrentLevel(String currentLevel) {
		this.currentLevel = currentLevel;
	}

	public String getCurrentLevelCount() {
		return currentLevelCount;
	}

	public void setCurrentLevelCount(String currentLevelCount) {
		this.currentLevelCount = currentLevelCount;
	}

	public String getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public boolean isBot() {
		return bot;
	}

	public void setBot(boolean bot) {
		this.bot = bot;
	}

	public boolean isRoundRestart() {
		return isRoundRestart;
	}

	public void setRoundRestart(boolean isRoundRestart) {
		this.isRoundRestart = isRoundRestart;
	}

	public int getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(int userStatus) {
		this.userStatus = userStatus;
	}

	public boolean isAutoPLay() {
		return isAutoPLay;
	}

	public void setAutoPLay(boolean isAutoPLay) {
		this.isAutoPLay = isAutoPLay;
	}
	
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	@Override
	public boolean equals(Object obj) {
		boolean status = false;
		if (obj == null || !(obj instanceof GamePlayerBean))
			return status;

		GamePlayerBean tempGamePlayerBean = (GamePlayerBean) obj;
		if (tempGamePlayerBean.getUserid().equalsIgnoreCase(userid)) {
			status = true;
		}
		return status;
	}

	public ISFSObject toSFSObj() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString(Param.USER_NAME, name);
		tempSFSObj.putUtfString(Param.USERID, userid);
		tempSFSObj.putUtfString(Param.USER_IMAGE, image);
		tempSFSObj.putUtfString(Param.SEAT_NO, seatNo);
		tempSFSObj.putUtfString(Param.BOT_STATUS, (bot ? EnableStatus.TRUE : EnableStatus.FALSE));
		tempSFSObj.putUtfString(Param.IS_ROUND_RESTART, (isRoundRestart ? EnableStatus.TRUE : EnableStatus.FALSE));
		tempSFSObj.putUtfString(Param.LEVEL_COUNT, currentLevelCount);
		tempSFSObj.putUtfString(Param.PLAYER_RANK,
				String.valueOf(GameMainExtension.cache.getPlayer().getValueByKey(userid).getPlayerRank()));
		return tempSFSObj;
	}

	public ISFSObject toBotSFSObj() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString(Param.USER_NAME, name);
		tempSFSObj.putUtfString(Param.USERID, userid);
		tempSFSObj.putUtfString(Param.USER_IMAGE, image);
		tempSFSObj.putUtfString(Param.SEAT_NO, seatNo);
		return tempSFSObj;
	}

	public ISFSObject toLobbySFSObj() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString(Param.USERID, getUserid());
		tempSFSObj.putUtfString(Param.SEAT_NO, seatNo);
		tempSFSObj.putUtfString(Param.TOTAL_SCORE, DefaultValue.ZERO);
		tempSFSObj.putUtfString(Param.BOT_STATUS, (bot ? EnableStatus.TRUE : EnableStatus.FALSE));
		return tempSFSObj;
	}

	public boolean isBotConfirmation() {
		return botConfirmation;
	}

	public void setBotConfirmation(boolean botConfirmation) {
		this.botConfirmation = botConfirmation;
	}

	@Override
	public String toString() {
		return "GamePlayerBean [name=" + name + ", userid=" + userid + ", image=" + image + ", chips=" + chips
				+ ", currentLevel=" + currentLevel + ", currentLevelCount=" + currentLevelCount + ", seatNo=" + seatNo
				+ ", status=" + status + ", bot=" + bot + ", botConfirmation=" + botConfirmation + ", isRoundRestart="
				+ isRoundRestart + ", chatText=" + chatText + ", userStatus=" + userStatus + ", isAutoPLay="
				+ isAutoPLay + ", user=" + user + "]";
	}
}