/**
 * 
 */
package com.latestfunroulette.cache.beans;

import java.io.Serializable;
import java.math.BigDecimal;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;

/**
 * @author Lal Chand Sharma
 *
 */
public class RouletteBetPlaceAmountBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String betNo;

	// private double betAmount = 0.0;
	private BigDecimal betAmountBig = new BigDecimal(0.0);

	public String getBetNo() {
		return betNo;
	}

	public void setBetNo(String betNo) {
		this.betNo = betNo;
	}

	public double getBetAmount() {
		return betAmountBig.doubleValue();
	}

	public synchronized void updateBetAmount(double pBetAmount) {

		Utils.Logger(GameMainExtension.extension,"updateBetAmount:::::::::::::::::::::::::: pBetAmount" + pBetAmount);

		betAmountBig = betAmountBig.add(new BigDecimal(pBetAmount));
		betAmountBig = betAmountBig.setScale(5, BigDecimal.ROUND_HALF_DOWN);
		
	}
	public synchronized void updateBetAmountdouble(double pBetAmount) {

		Utils.Logger(GameMainExtension.extension,"updateBetAmount:::::::::::::::::::::::::: pBetAmount" + pBetAmount);

		betAmountBig = (new BigDecimal(pBetAmount));
		betAmountBig = betAmountBig.setScale(5, BigDecimal.ROUND_HALF_DOWN);
		Utils.Logger(GameMainExtension.extension,
				" RouletteBetPlaceBean:::::::::::::updateBetAmount:::::::betamount" + betAmountBig);
	}

	public synchronized void removeBetAmount(double pBetAmount) {
		Utils.Logger(GameMainExtension.extension,
				" RouletteBetPlaceBean:::::::::::::removeBetAmount:::::::betamount" + pBetAmount);

		betAmountBig = betAmountBig.subtract(new BigDecimal(pBetAmount));
		betAmountBig = betAmountBig.setScale(5, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension,
				" RouletteBetPlaceBean:::::::::::::removeBetAmount:::::::betamount" + betAmountBig);

		if (betAmountBig.doubleValue() < 0)
			betAmountBig = new BigDecimal(0.0);
	}

	public ISFSObject toSFSObj() {
		ISFSObject tempSFSObj = new SFSObject();
		/*
		 * tempSFSObj.putUtfString("BET_NO", betNo);
		 * tempSFSObj.putUtfString("BET_AMOUNT", String.valueOf(betAmount));
		 */
		tempSFSObj.putUtfString(betNo, betAmountBig.toPlainString());
		return tempSFSObj;
	}

	public synchronized void doubleupdateBetAmount(double pBetAmount) {

		Utils.Logger(GameMainExtension.extension,"pBetAmount::::::::::::::" + pBetAmount);

		Utils.Logger(GameMainExtension.extension,"betamountuser" + pBetAmount);
		betAmountBig = betAmountBig.add(new BigDecimal(pBetAmount));
		betAmountBig = betAmountBig.setScale(3, BigDecimal.ROUND_HALF_DOWN);
		Utils.Logger(GameMainExtension.extension,
				" RouletteBetPlaceBean::::::::double:::::updateBetAmount:::::::betamountbig" + betAmountBig);
	}

	@Override
	public String toString() {
		return "RouletteBetPlaceAmountBean [betNo=" + betNo + ", betAmountBig=" + betAmountBig + "]";
	}

}