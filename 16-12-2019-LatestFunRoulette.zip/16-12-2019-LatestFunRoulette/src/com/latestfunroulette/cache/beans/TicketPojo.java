package com.latestfunroulette.cache.beans;

public class TicketPojo {

private String Ticket_id;
private String Game_id;
private String Play;
private String Win;
private String Result;
private String Draw_Time;
private String Ticket_Time;
public String getTicket_id () {
return Ticket_id;
}
public void setTicket_id(String ticket_id) {
Ticket_id = ticket_id;
}
public String getGame_id() {
return Game_id;
}
public void setGame_id(String game_id) {
Game_id = game_id;
}
public String getPlay() {
return Play;
}
public void setPlay(String play) {
Play = play;
}
public String getWin() {
return Win;
}
public void setWin(String win) {
Win = win;
}
public String getResult() {
return Result;
}
public void setResult(String result) {
Result = result;
}
public String getDraw_Time() {
return Draw_Time;
}
public void setDraw_Time(String draw_Time) {
Draw_Time = draw_Time;
}
public String getTicket_Time() {
return Ticket_Time;
}
public void setTicket_Time(String ticket_Time) {
Ticket_Time = ticket_Time;
}
@Override
public String toString() {
return "Bat Information [Ticket_id=" + Ticket_id + ", Game_id=" + Game_id + ", Play=" + Play + ", Win=" + Win
+ ", Result=" + Result + ", Draw_Time=" + Draw_Time + ", Ticket_Time=" + Ticket_Time + "] ";
}



}