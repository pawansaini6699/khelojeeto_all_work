package com.latestfunroulette.dubliRoulette.state.interfaces;

import com.smartfoxserver.v2.entities.User;

public interface IBetPlaceState<G> extends IBaseState<G> {

	void onCancelBet(String roomname, User user, String session_id, String tabletype, int betno, double betAmount);

	void onClearAll(User user, String session_id);

	void onRebetRequest(String roomname, User user, String session_id);

	void betPlaceState(String userid, String session_id, double coins, int numbers, String tabletype, int gameid);

	void userBetSave(String roomname, User user, String session_id);

	void userBetRemove(String roomname, String session_id, String betno, User user);

	void userGameDetails(String roomname, User user);

	void userGameDetailsStartAndEndDate(String roomname, User user, String startDate, String endDate);

	void betPrintExe(String roomname, String sessionId, User user);

	void betPlaceRandomWise(User pUser, String session_id, double coins, int numbers, String tabletype, int gameid,
			int tablebetno);
	
	void UsersDayWiseDetails(String roomname, User user);
	
	void betCancelByTicketId(String roomname, String sessionId, User user, String ticketid);
	
	void betClaimByTicketId_DoubleChance(String roomname, String sessionId, User user, String ticketid,int gameid,String gametype);


}
