package com.latestfunroulette.dubliRoulette.state.interfaces;

public interface IGameResultState<G> extends IBaseState<G> {

}
