package com.latestfunroulette.dubliRoulette.state.interfaces;

import com.latestfunroulette.dubliRoulette.base.interfaces.IState;

public interface IBaseState<G> extends IState<G> {

	


}
