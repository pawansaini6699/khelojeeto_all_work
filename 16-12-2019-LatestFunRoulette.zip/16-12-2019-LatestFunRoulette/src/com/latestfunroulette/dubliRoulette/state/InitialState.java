package com.latestfunroulette.dubliRoulette.state;

import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.GameStateZeroToDoubleNineTime;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.dubliRoulette.base.baseclass.BaseIntialState;
import com.latestfunroulette.dubliRoulette.cache.beans.GameBean;
import com.latestfunroulette.dubliRoulette.state.interfaces.IInitialState;
import com.latestfunroulette.extension.GameMainExtension;

public class InitialState extends BaseIntialState implements IInitialState<GameBean> {

	int count = 0;

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,"dubliRoulette:::::::::::::::::InitialState");
		super.init(g, GameStateZeroToDoubleNineTime.INITIAL_TIME);
		getTimer().resetTimer();

	}

	@Override
	public void onProcess() {
		long currenttime =  getTimer().getElapsedTime();
		Utils.Logger(GameMainExtension.extension,
				"DoubleChance:::::::::::::::::::InitialState :::: OnProcess():::::::: getTimer().getElapsedTime()"
						+ currenttime);

		

		// Utils.Logger(GameMainExtension.extension," current time ::::::::::::::" + currenttime);
		if (currenttime > getStateTime()) {
			onExist();
		}

		/*
		 * else if (currenttime == 0) { DBManager.machineTime(); }
		 * 
		 * else if (currenttime == 14) {
		 * 
		 * DBManager.machineTime();
		 * 
		 * } else if (currenttime == 2) {
		 * 
		 * DBManager.machineTime();
		 * 
		 * }
		 */
	}

	@Override
	public void onJoin(String pLoginId) {
		print("dubliRoulette::::::::::::::::InitialState :::: OnJoin()");
		getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {
		print("dubliRoulette:::::::::::::::::::::::::::::::::onExist");
		
		
		getGameBean().setGameState(GameState.BETPLACESTATE);
		getGameMachine().onNext(getGameBean().getGameState());
	}

}