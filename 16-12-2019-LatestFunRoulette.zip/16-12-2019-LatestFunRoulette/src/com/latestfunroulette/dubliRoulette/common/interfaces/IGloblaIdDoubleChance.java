package com.latestfunroulette.dubliRoulette.common.interfaces;

public interface IGloblaIdDoubleChance {

	void updateId();

	int getCurrentId();

	int getNextId();

	String getNextId(String f);
}