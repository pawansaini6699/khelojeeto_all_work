package com.latestfunroulette.dubliRoulette.common.interfaces;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.latestfunroulette.dubliRoulette.base.interfaces.BaseState;

public interface IGameEvents {

	void sendLiveTime(BaseState pState);

	void sendPlayerWaiting(BaseState pState);

	void sendbetPlace(BaseState pState, int time);

	void clearBet(BaseState pState, double betAmount, User user);

	void onRebetRoulette(BaseState pState, User user, String session_id);

	// void gameResultWaitingState(BaseState pState);

	void gameResultState(BaseState pState);

	void sendOnlineLobbyEvent(BaseState pstState, String loginid);

	void currentSystemTmer(int time);

	void specificClearBet(BaseState pstState, double betamount, User user);

	public void newSessionGenarate(BaseState baseState);

	void betSave(BaseState baseState, User user, String session_id, String roomname);

	void betRemoveUser(BaseState baseState, String session_id, String roomname, String betno, User user);

	void getGameDetails_DoubleChance(BaseState baseState, String roomname, User user);

	public void betinsertOnTime(BaseState baseState, long currenttime);

	public void onJoinSendUserData(BaseState baseState, String loginId);

	public void onLeaveUserRoom(BaseState baseState, String loginin);

	void betNumberResponse(User user, BaseState pstState, String betsarray[]);

	void betSaveOnTime(BaseState baseState);

	void getGameDetailsDateWise_DoubleChance(BaseState baseState, String roomname, User user, String StartDate,
			String endDate);

	void sendUserbetsDetails(BaseState baseState, String roomaname, String sessionid, User user);

	void sendGameDetailsResult(BaseState baseState, String roomaname, User user);

	void betCancelByTicketId(BaseState baseState, String roomaname, String sessionid, User user, String ticket_id);

	void betClaimByTicketId(BaseState baseState, String roomaname, String sessionid, User user, String ticket_id,
			int gameid, String gametype);

	default void print(String msg) {
		Utils.Logger(GameMainExtension.extension, "GameEvents :::: " + msg);
	}

}