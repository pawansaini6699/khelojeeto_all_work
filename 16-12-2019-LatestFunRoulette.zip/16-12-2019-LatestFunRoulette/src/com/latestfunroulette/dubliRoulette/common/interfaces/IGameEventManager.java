package com.latestfunroulette.dubliRoulette.common.interfaces;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.dubliRoulette.base.interfaces.IState;
import com.latestfunroulette.dubliRoulette.cache.beans.GameBean;
import com.latestfunroulette.dubliRoulette.machine.interfaces.IStateMachine;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;

public interface IGameEventManager {
	void onLiveBet(User pUser, ISFSObject params, CallBack pCallBack);

	void onGetWinningNumber(User pUser, ISFSObject params, CallBack pCallBack);

	void onCancelSpecificBet(User pUser, ISFSObject params, CallBack pCallBack);

	void onClearAllBet(User pUser, ISFSObject params, CallBack pCallBack);

	void onRebet(User pUser, ISFSObject params, CallBack pCallBack);

	void onBetOK(User pUser, ISFSObject params, CallBack pCallBack);

	void onDoubleRandomBets(User pUser, ISFSObject params, CallBack pCallBack);

	void onUserGameDetails(User user, ISFSObject params, CallBack callBack);

	void onUserGameDetailsStartAndEndDate(User pUser, ISFSObject params, CallBack pCallBack);

	void onPlayerLeave(User pUser, ISFSObject params, CallBack pCallBack);

	void onRemoveBetCustomise(User pUser, ISFSObject params, CallBack pCallBack);

	void onBetPrintExe(User pUser, ISFSObject params, CallBack pCallBack);

	void UsersDayWiseResult(User pUser, ISFSObject params, CallBack pCallBack);

	void onCancelTicketDoubleChance(User pUser, ISFSObject params, CallBack pCallBack);

	void onClaimTicket(User pUser, ISFSObject params, CallBack pCallBack);

	/////////////////////////////////////////////////////////////////////////////////////

	default IStateMachine<GameBean> getGameMachine(String pRoomName) {
		if (GameMainExtension.cache.getGames().getValueByKey(pRoomName) != null) {
			print(" ::::::: GAME IS FOUND  ::::::::  " + pRoomName);
			return GameMainExtension.gameCacheDoubleRoulette.getGames().getValueByKey(pRoomName).getGameMachine();
		} else {
			print(" ::::::: GAME IS NULL   ::::::::  " + pRoomName);
			return null;
		}
	}

	default IState<GameBean> getCurrentState(String pRoomName) {

		GameBean gb = GameMainExtension.gameCacheDoubleRoulette.getGames().getValueByKey(pRoomName);
		return gb.getGameMachine().currentState();
	}

	default void print(String msg) {
		Utils.Logger(GameMainExtension.extension, "GameEventManager ::::: " + msg);
	}

}