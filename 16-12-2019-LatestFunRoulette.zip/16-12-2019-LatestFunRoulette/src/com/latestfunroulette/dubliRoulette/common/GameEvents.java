package com.latestfunroulette.dubliRoulette.common;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Events;
import com.latestfunroulette.common.Constants.GameStateZeroToDoubleNineTime;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.dubliRoulette.base.interfaces.BaseState;
import com.latestfunroulette.dubliRoulette.cache.beans.GameBean;
import com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans;
import com.latestfunroulette.dubliRoulette.cache.beans.SessionBean;
import com.latestfunroulette.dubliRoulette.cache.beans.UserBetBean;
import com.latestfunroulette.dubliRoulette.cache.caching.interfaces.ISessionCache;
import com.latestfunroulette.dubliRoulette.client.TicketPrint;
import com.latestfunroulette.dubliRoulette.client.UpdateGameWinAmountDoubleNine;
import com.latestfunroulette.dubliRoulette.common.interfaces.IGameEvents;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class GameEvents implements IGameEvents {

	private WeakReference<SFSExtension> ref_extension = null;
	List<SessionBean> ls = null;

	public GameEvents(SFSExtension pExtension) {
		ref_extension = new WeakReference<SFSExtension>(pExtension);

	}

	@Override
	public void sendPlayerWaiting(BaseState pState) {

	}

	@Override
	public void sendbetPlace(BaseState pState, int count) {

	}

	@Override
	public void clearBet(BaseState pState, double pbetamount, User user) {

		try {
			GameBean tempGameBean = pState.getGameBean();

			int iBetAmount = (int) Math.round((pbetamount));

			ISFSObject isfsObject = new SFSObject();
			isfsObject.putUtfString(Param.ROOM_NAME, tempGameBean.getRoomName());
			isfsObject.putUtfString(Param.MESSAGE, "Live Bets clear Successfully!!");
			isfsObject.putUtfString(Param.BETAMOUNT, String.valueOf(iBetAmount));
			isfsObject.putUtfString(Param.STATE, pState.getGameBean().getGameState());
			isfsObject.putUtfString(Param.STATUS, "true");

			tempGameBean.setRoomName(tempGameBean.getRoomName());
			GameMainExtension.gameCacheDoubleRoulette.getGames().add(tempGameBean);

			Utils.Logger(GameMainExtension.extension, "tempsfsobj" + isfsObject.getDump());
			ref_extension.get().send(Events.CLEARALL, isfsObject, user);

		} catch (Exception e) {
			Utils.ErrorLogger(ref_extension.get(), "GameEvents ::: clearBet() :: ERROR :: ", e);
		}

	}

	@Override
	public void gameResultState(BaseState pState) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sendLiveTime(BaseState pState) {

		try {

			String updatedsessionid = String.valueOf(GameMainExtension.globlaIddoublechance.getNextId());

			Utils.Logger(GameMainExtension.extension,
					"updatedsessionid::::::::::::::::::::::::::::::::" + updatedsessionid);

			GameBean gameBean = pState.getGameBean();

			Utils.Logger(GameMainExtension.extension,
					"Doublechance:::::::::::::::GameEvents:::::::::::::::::sendLiveTime ::::::::::::gmaebean"
							+ gameBean.toString());

			int currentsessionid = Integer.parseInt(updatedsessionid);
			Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

			String wheelno = getWinminnumber();

			DBManager.UpdateLiveTimePlayDoubleChance(currentsessionid, wheelno, new CallBack() {

				@Override
				public void call(Object... call) {

					int oldsessionid = (int) call[0];
					int jackport = (int) call[1];

					String psessionId = String.valueOf(oldsessionid);
					String pwheelno = (wheelno);
					Utils.Logger(GameMainExtension.extension,
							"Doublechance:::::::::::::GameEvents::::::::sendLiveTime:::::::::" + "gloabalid:::  "
									+ oldsessionid + "sessionid ::::::: " + psessionId + "wheelno " + pwheelno);

					UpdateGameWinAmountDoubleNine.updateWinAmount(pState, psessionId, pwheelno, tempRoom, jackport,
							gameBean.getTicketid());

				}
			});

			//

		} catch (Exception e) {
			Utils.ErrorLogger(ref_extension.get(), "GameEvents ::: sendLiveTime() :: ERROR :: ", e);
		}
	}

	@Override
	public void onRebetRoulette(BaseState pState, User user, String session_id) {

		GameBean tempGameBean = pState.getGameBean();
		ISFSObject isfsObject = new SFSObject();

		String oldsessionid = tempGameBean.getSession_id();

		SessionBean tempSession = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
				.getValueByKey(session_id);

		SessionBean oldtempSession = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
				.getValueByKey(oldsessionid);

		UserBetBean tempolduserbetbean = oldtempSession.getUserBetBeanByUserId(user.getName());

		tempolduserbetbean.setBetStatus(false);

		HashMap<String, HashMap<String, RouletteBetBeans>> tempRouletteBetbeanstableMap = tempolduserbetbean
				.getUserRouletteBets();

		Utils.Logger(GameMainExtension.extension,
				":::::::::::::   GameEvents  ::::::::::::::::::onRebetRoulette::::::: tempRouletteBetbeanstableMap  :::::::::::    size  ::::::"
						+ tempRouletteBetbeanstableMap.size());

		for (Map.Entry<String, HashMap<String, RouletteBetBeans>> tableentry : tempRouletteBetbeanstableMap
				.entrySet()) {

			HashMap<String, RouletteBetBeans> tempRouletteMap = tempRouletteBetbeanstableMap.get(tableentry.getKey());

			for (Map.Entry<String, RouletteBetBeans> rouletteEntry : tempRouletteMap.entrySet()) {

				RouletteBetBeans tempRouletteBetBeans = tempRouletteMap.get(rouletteEntry.getKey());

				tempSession.addUserBet(tempolduserbetbean.getUserId(), session_id, tempRouletteBetBeans.getBetAmount(),

						tempRouletteBetBeans.getBetNos(), tempRouletteBetBeans.getBetWinAmount(),
						tempRouletteBetBeans.getTabletype(), tempolduserbetbean.getGameId());

			}

			GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId().add(tempSession);

			Utils.Logger(GameMainExtension.extension, "onRebetRoulette::::::::::::::::::::::::::::::::::::::::::"
					+ "getbetamount " + tempolduserbetbean.getTotalBetAmount());

			isfsObject.putUtfString(Param.MESSAGE, "Rebet success");
			isfsObject.putUtfString(Param.STATUS, "true");

			Utils.Logger(GameMainExtension.extension,
					"GameEvents::::::::::::::::::onRebetRoulette::::::::Response:::::::isfsobject "
							+ isfsObject.getDump());

			ref_extension.get().send(Events.REBET_NUMBERS, isfsObject, user);

		}
	}

	public void sendOnlineLobbyEvent(BaseState pState, String loginid) {

		Utils.Logger(GameMainExtension.extension, "User:::::name:::::::loginid" + loginid);

		GameBean gameBean = pState.getGameBean();

		DBManager.userStatus(loginid, new CallBack() {

			@Override
			public void call(Object... callback) {

				ISFSObject tempSFSObj = (ISFSObject) callback[0];

				Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

				List<User> tempUsers = tempRoom.getUserList();
				int onlineplayerscount = tempUsers.size();

				Utils.Logger(ref_extension.get(),
						"game bean room name" + gameBean.getRoomName() + " gamebean time  " + gameBean.getTime()
								+ " fivewinning number " + gameBean.getLastfivenumber() + "winning number :::::: "
								+ gameBean.getWinningnumber());

				tempSFSObj.putUtfString(Param.ROOM_NAME, gameBean.getRoomName());
				tempSFSObj.putUtfString(Param.ONLINE_PLAYER_COUNT, String.valueOf(onlineplayerscount));
				tempSFSObj.putUtfString(Param.TIMER, gameBean.getTime());
				tempSFSObj.putUtfString(Param.LASTFIVENUMBER, gameBean.getLastfivenumber());
				tempSFSObj.putUtfString(Param.WINNINGNUMBER, gameBean.getWinningnumber());
				tempSFSObj.putUtfString(Param.STATE, pState.getGameBean().getGameState());

				Utils.Logger(GameMainExtension.extension,
						"CommonEvents::::::::::::::::::sendOnlineLobbyEvent::::::::Response:::::::isfsobject "
								+ tempSFSObj.getDump());

				ref_extension.get().send(Events.DOUBLE_CHANCE_LOBBY_REQUEST, tempSFSObj, tempUsers);

			}
		});

	}

	public String getWinminnumber() {

		String wheel = DBManager.winningNumberDoubleChance();

		return wheel;

	}

	@Override
	public void betinsertOnTime(BaseState baseState, long currenttime) {

		try {

			GameBean tempGameBean = baseState.getGameBean();
			String roomname = baseState.getGameBean().getRoomName();
			String userid = baseState.getGameBean().getUserid();
			// String credits = baseState.getGameBean().getCredits();

			Utils.Logger(GameMainExtension.extension, "roomname" + roomname + "gmaebean:::::::::::::::" + baseState);

			Utils.Logger(GameMainExtension.extension, "betinsertOnTime ::: currenttime" + currenttime);

			DBManager.sendSessionIdOfRulleteDoubleChance(userid, new CallBack() {

				@Override
				public void call(Object... callback) {
					String session_id = (String) callback[0];

					Utils.Logger(GameMainExtension.extension,
							"GameEvents :::: betinsertOnTime :::: Session Id :::: " + session_id);
					SessionBean tempSessionBean = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
							.getValueByKey(session_id);

					if (tempSessionBean != null) {
						List<UserBetBean> tempUsers = tempSessionBean.getAllUserBets();
						int userSize = tempUsers.size();

						Utils.Logger(GameMainExtension.extension,
								"GameEvents :::::betinsertOnTime::::::: before User size :::: " + userSize);

						try {

							for (int u = 0; u < userSize; u++) {
								UserBetBean tempUserBetBean = tempUsers.get(u);

								if (tempUserBetBean.getTotalBetAmount() != "0") {
									if (tempUserBetBean != null && !tempUserBetBean.isBetStatus()) {

										tempSessionBean.cancelAllRouletteBet(tempUserBetBean.getUserId());
										--u;
										--userSize;
									} else {

										String userid = tempUserBetBean.getUserId();
										int gameid = tempUserBetBean.getGameId();
										Utils.Logger(GameMainExtension.extension,
												"GameEvents :::::betinsertOnTime::::::: ::::: Update live_update_roulette_history user id :::: "
														+ userid);
										Utils.Logger(GameMainExtension.extension,
												"GameEvents :::::betinsertOnTime::::::: :::: User Id :::: " + userid
														+ " :::: Session Id ::: " + session_id
														+ " :::: Total Bet Amount :::  "
														+ tempUserBetBean.getTotalBetAmount());

										try {

											DBManager.insertZeroToDoubleNinesql(session_id, tempUserBetBean, gameid,
													tempGameBean);

										} catch (Exception e) {
											Utils.Logger(GameMainExtension.extension,
													"run time exception::::::::::::" + e);
										}

									}
								}
							}
						} catch (Exception e) {
							Utils.ErrorLogger(GameMainExtension.extension,
									"GameEvents :::::betinsertOnTime::::::: :::: Remove Loop Error :::: ", e);
						}

					}
				}
			});

		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension, "SendServerLivetimer :::: Error ::::: ", e);
		}
	}

	@Override
	public void newSessionGenarate(BaseState basestate) {

		Utils.Logger(GameMainExtension.extension,
				"DoubleRoulette::::::::::::GameEvents:::::::::::::basestate" + basestate.toString());

		GameBean gameBean = basestate.getGameBean();
		String roomname = gameBean.getRoomName();
		String userid = gameBean.getUserid();
		// String sessionid=gameBean.getSession_id();

		String currenttime = String.valueOf(basestate.getTimer().getElapsedTime());

		int time = 60 - (Integer.parseInt(currenttime));

		Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());
		List<User> tempUsers = tempRoom.getUserList();
		int onlineplayerscount = tempUsers.size();

		new Thread() {
			@Override
			public void run() {
				try {

					DBManager.sendSessionIdOfRulleteDoubleChance(userid, new CallBack() {

						@Override
						public void call(Object... callback) {
							String session_id = (String) callback[0];
							String status = (String) callback[1];
							String resultwheel = (String) callback[2];
							String credits = (String) callback[3];
							String lastfivewinningnumber = (String) callback[4];
							String oldSessionId = (String) callback[5];
							String jackport = (String) callback[6];

							Utils.Logger(GameMainExtension.extension,
									"GameEvents::::::::::::::::::::::::::::::newSessionGenarate:::::::::::::oldSessionId"
											+ oldSessionId + "credits" + credits);

							ISFSObject isfsObject = new SFSObject();
							isfsObject.putUtfString(Param.SESSION_ID, session_id);
							isfsObject.putUtfString(Param.WINNINGNUMBER, resultwheel);
							isfsObject.putInt(Param.TIMER, time);
							isfsObject.putUtfString(Param.STATE, basestate.getGameBean().getGameState());
							isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
							isfsObject.putInt(Param.ONLINE_PLAYER_COUNT, onlineplayerscount);
							isfsObject.putUtfString(Param.ROOM_NAME, roomname);
							isfsObject.putUtfString(Param.STATUS, status);
							isfsObject.putInt(Param.BETPLACETIME, GameStateZeroToDoubleNineTime.BET_PLACE_TIME);
							isfsObject.putUtfString(Param.JACKPORT, jackport);

							Utils.Logger(GameMainExtension.extension,
									":::::::::::::::::DoubleRoulette:::::::::::::::::::::GameEvents:::::::::::::::::newSessionGenarate::::::::::isfsObject:::::"
											+ isfsObject.getDump());

							ref_extension.get().send(Request.NEWSESSIONGENERATE, isfsObject, tempUsers);

							print("RouletteGameExtension ::::51 New Session ::::: " + session_id);

							SessionBean tempsessionbean1 = new SessionBean();

							gameBean.setSession_id(oldSessionId);
							GameMainExtension.gameCacheDoubleRoulette.getGames().add(gameBean);

							tempsessionbean1.setSessionId(session_id);

							// Utils.Logger(GameMainExtension.extension,
							// "RouletteGameExtension ::::51 New Session ::::: " +
							// tempsessionbean.toString());

							ISessionCache<String, SessionBean> tempSessionCache = GameMainExtension.gameCacheDoubleRoulette
									.getGameSessionBySessionId();

							if (tempSessionCache == null) {
								Utils.Logger(GameMainExtension.extension,
										"RouletteGameExtension :::: Session Cache is null");
							} else {
								Utils.Logger(GameMainExtension.extension,
										"RouletteGameExtension :::: Session Cache is not null");
								// tempSessionCache.clearAllSession();

								tempSessionCache.add(tempsessionbean1);

								Set<String> set = tempSessionCache.getAll().keySet();

								for (String s : new ArrayList<String>(set)) {

									String url = s;

									if (url.equalsIgnoreCase(session_id)) {
										Utils.Logger(GameMainExtension.extension, " Value = " + url);
									} else if (url.equalsIgnoreCase(oldSessionId)) {

										Utils.Logger(GameMainExtension.extension, " Value = " + url);
									} else {
										tempSessionCache.delete(s);
									}

								}

							}

						}
					});
				} catch (Exception e) {
					Utils.ErrorLogger(GameMainExtension.extension,
							"GameEvents::::::::::::::::::::newSessionGenarate RunMethod :::::: Error :::: ", e);
				}

			}
		}.start();
	}

	@Override
	public void onJoinSendUserData(BaseState baseState, String loginId) {

		GameBean gameBean = baseState.getGameBean();
		gameBean.setUserid(loginId);

		GameMainExtension.gameCacheDoubleRoulette.getGames().add(gameBean);
		Utils.Logger(GameMainExtension.extension, "gamebean" + gameBean.toString());

		String roomname = gameBean.getRoomName();

		Utils.Logger(GameMainExtension.extension, "User:::::name:::::::" + loginId + " roomname::::::::" + roomname);

		DBManager.getLastFiveNumberDoubleNine(loginId, new CallBack() {

			@Override
			public void call(Object... callback) {

				Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

				User user = tempRoom.getUserByName(loginId);
				String currenttime = String.valueOf(baseState.getTimer().getElapsedTime());
				System.out.println("single roulette room::::::::::::::::::currenttime" + currenttime);
				int time = (60 - Integer.parseInt(currenttime));
				// GameBean gameBean =
				// GameMainExtension.cache.getGames().getValueByKey(tempRoom.getName());
				// GameBean gameBean =
				// GameMainExtension.cache.getGames().getValueByKey(loginuser);

				Utils.Logger(GameMainExtension.extension,
						"sendSingleRouletteLobbyEvent::::::::::gamebean" + gameBean.toString());
				// Player tempPlayer =
				// GameMainExtension.cache.getPlayer().getValueByKey(loginId);
				ISFSObject isfsObject = (ISFSObject) callback[0];
				Utils.Logger(GameMainExtension.extension, "ROOM NAME" + tempRoom.getName());
				List<User> tempUsers = tempRoom.getUserList();
				int onlineplayerscount = tempUsers.size();

				isfsObject.putUtfString(Param.ONLINE_PLAYER_COUNT, String.valueOf(onlineplayerscount));
				isfsObject.putUtfString(Param.ROOM_NAME, "DOUBLE_CHANCE_ROOM");

				// isfsObject.putUtfString(Param.TIMER, String.valueOf(time));
				isfsObject.putUtfString(Param.TIMER, String.valueOf(time));
				isfsObject.putUtfString(Param.STATE, baseState.getGameBean().getGameState());

				Utils.Logger(GameMainExtension.extension,
						"CommonEvents::::::::::::::::::senddoubleChanceLobbyEvent::::::::Response:::::::isfsobject "
								+ isfsObject.getDump());

				ref_extension.get().send(Events.DOUBLE_CHANCE_LOBBY_REQUEST, isfsObject, user);

			}
		});

	}

	@Override
	public void currentSystemTmer(int time) {

		try {
			ISFSExtension tempSFSExtension = SmartFoxServer.getInstance().getZoneManager().getZoneByName("RouletteGame")
					.getExtension();
			ISFSObject obj = new SFSObject();
			obj.putInt(Param.CURRENT_TIME, time);
			Utils.Logger(GameMainExtension.extension,
					"GameEvent:::::::::::currentSystemTmer  ::::  Params ::::: " + obj.getDump());
			tempSFSExtension.handleClientRequest(Request.CURRENTTIME, null, obj);

		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension, "currentSystemTmer :::::: Error :::: ", e);
		}

	}

	@Override
	public void onLeaveUserRoom(BaseState baseState, String loginId) {

	}

	@Override
	public void betSave(BaseState baseState, User tempuser1, String session_id, String roomname) {

		GameBean tempGameBean = baseState.getGameBean();

		SessionBean tempSession = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
				.getValueByKey(session_id);

		Utils.Logger(GameMainExtension.extension, "GameEvents::::::::::::userid:::::::::::::::::" + tempuser1
				+ " sessionid " + session_id + "roomname" + roomname);

		if (tempSession != null) {

			UserBetBean userBetBean = tempSession.getUserBetBeanByUserId(tempuser1.getName());

			if (userBetBean != null) {
				userBetBean.setBetStatus(true);

			}

			// final int i1=i;
			DBManager.BetOkUpdateBalance(tempuser1.getName(), userBetBean.getTotalBetAmount(), new CallBack() {

				@Override
				public void call(Object... call) {
					try {
						double currentbalance = (double) call[0];
						double totalbetamount = Double.parseDouble(userBetBean.getTotalBetAmount());

						double balance = currentbalance + totalbetamount;
						Utils.Logger(GameMainExtension.extension,
								"betokbalance::::::::::::totalbetamount::::::: " + totalbetamount
										+ ":::::::::::updated balance::::::::" + balance + "totalbetamount:::::"
										+ userBetBean.getTotalBetAmount());

						tempGameBean.setCredits(String.valueOf(balance));

						// int onlineplayerscount = tempUsers.size();

						ISFSObject isfsObject = new SFSObject();
						isfsObject.putUtfString(Param.USERID, tempuser1.getName());
						isfsObject.putUtfString(Param.SESSION_ID, session_id);
						isfsObject.putUtfString(Param.MESSAGE, "Bet Save Successfully");
						isfsObject.putUtfString(Param.TOTALBETAMT, String.valueOf(currentbalance));
						isfsObject.putUtfString(Param.STATE, "2");
						isfsObject.putUtfString(Param.STATUS, "true");
						Utils.Logger(GameMainExtension.extension, "RESPONSE::::::::::" + isfsObject.getDump());

						GameMainExtension.extension.send(Request.BETOK, isfsObject, tempuser1);

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

			});

		}
	}

	@Override
	public void betSaveOnTime(BaseState baseState) {

		GameBean gameBean = baseState.getGameBean();
		String userid = gameBean.getUserid();
		String currenttime = String.valueOf(baseState.getTimer().getElapsedTime());

		int time = 60 - (Integer.parseInt(currenttime));

		Player player = GameMainExtension.cache.getPlayer().getValueByKey(userid);

		Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

		List<User> tempUsers1 = tempRoom.getUserList();

		ISFSObject isfsObject = new SFSObject();
		isfsObject.putInt(Param.TIMER, time);
		isfsObject.putUtfString(Param.STATE, "2");
		isfsObject.putUtfString(Param.STATUS, "true");

		Utils.Logger(GameMainExtension.extension,
				"DoubleChance:::::::::::::::::::::::GameEvents::::::::::::::::betSaveOnTime::::::::::::isfsobj:::::"
						+ isfsObject.getDump());

		GameMainExtension.extension.send(Events.STATEHANDLER, isfsObject, tempUsers1);

		try {
			if (player != null) {

				DBManager.sendSessionIdOfRulleteDoubleChance(userid, new CallBack() {

					@Override
					public void call(Object... callback) {
						String session_id = (String) callback[0];

						Utils.Logger(GameMainExtension.extension,
								"SendServerLiveTimer ::::betSaveOnTime:::::::::::: sendSessionIdOfRulleteDoubleChance :::: Session Id :::: "
										+ session_id);
						SessionBean tempSessionBean = GameMainExtension.gameCacheDoubleRoulette
								.getGameSessionBySessionId().getValueByKey(session_id);

						if (tempSessionBean != null) {

							Utils.Logger(GameMainExtension.extension,
									"SendServerLiveTimer ::::betSaveOnTime::::::::::::tempSessionBean");

							List<UserBetBean> tempUsers = tempSessionBean.getAllUserBets();

							int userSize = tempUsers.size();

							Utils.Logger(GameMainExtension.extension,
									" 50::::::::timer:::::  User size :::: " + userSize);

							try {

								for (int u = 0; u < userSize; u++) {

									UserBetBean tempUserBetBean = tempUsers.get(u);

									Utils.Logger(GameMainExtension.extension, "status" + tempUserBetBean.isBetStatus());

									if (tempUserBetBean != null && !tempUserBetBean.isBetStatus()) {

										// String userid = tempUserBetBean.getUserId();

										User user = tempRoom.getUserByName(tempUserBetBean.getUserId());
										try {
											Utils.Logger(GameMainExtension.extension,
													"user::::::::::::::" + user.getName());
											Utils.Logger(GameMainExtension.extension,
													"roomname::::::::::::::" + tempRoom.getName());

										} catch (Exception e) {
											Utils.Logger(GameMainExtension.extension, "error ::::::::::::::::::::" + e);
										}
										Utils.Logger(GameMainExtension.extension,
												"SingleROuletteGame:::::::::::::::::::::::GameEvents::::::::::::::::betSaveOnTime:::::::::::::::user"
														+ user.getName() + "roomname" + tempRoom.getName()
														+ "player:::::::::::::" + player.toString());

										betSave(baseState, user, session_id, tempRoom.getName());

									}
								}

							} catch (Exception e) {
								Utils.ErrorLogger(GameMainExtension.extension, "error" + e);
							}
						}

					}

				});

			}
		} catch (Exception e) {
			Utils.ErrorLogger(ref_extension.get(), "gameEvents::::::::::::::::::::::error" + e);
		}
	}

	@Override
	public void specificClearBet(BaseState pstState, double betamount, User pUser) {
		GameBean gameBean = pstState.getGameBean();
		Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

		User user = tempRoom.getUserByName(pUser.getName());

		if (gameBean != null) {

			// List<User> tempUsers = tempRoom.getUserList();

			ISFSObject isfsObject = new SFSObject();
			isfsObject.putDouble(Param.CREDITS, betamount);
			isfsObject.putUtfString(Param.STATUS, "true");
			ref_extension.get().send(Request.REMOVE_BET_CUSTOMISE_REQUEST, isfsObject, user);

		}

	}

	@Override
	public void betRemoveUser(BaseState baseState, String session_id, String roomname, String betno, User user) {

		GameBean gameBean = baseState.getGameBean();

		if (gameBean != null) {

			ISFSObject isfsObject = new SFSObject();
			isfsObject.putUtfString(Param.MESSAGE, "Remove Bet Successfully");
			isfsObject.putUtfString(Param.STATUS, "true");
			ref_extension.get().send(Request.BETREMOVECUSTOMISE, isfsObject, user);

		}

	}

	@Override
	public void getGameDetails_DoubleChance(BaseState baseState, String roomname, User user) {

		GameBean gameBean = baseState.getGameBean();

		if (gameBean != null) {

			DBManager.getUserGameDetail_DoubleRoulette(user.getName(), new CallBack() {

				@Override
				public void call(Object... callback) {

					ISFSArray tempHistoryList = (ISFSArray) callback[0];
					ISFSObject tempSFSObj = new SFSObject();
					tempSFSObj.putSFSArray(Param.USER_GAME_LIST, tempHistoryList);
					print("Response ::getSharePointDetailsByUserId:: Prames ::: " + tempSFSObj.getDump());
					GameMainExtension.extension.send(Request.USER_GAME_DETAILS_DAY_WISE_DOUBLE_CHANCE, tempSFSObj,
							user);

				}
			});

		}

	}

	@Override
	public void getGameDetailsDateWise_DoubleChance(BaseState baseState, String roomname, User user, String startDate,
			String EndDate) {

		GameBean gameBean = baseState.getGameBean();

		if (gameBean != null) {

			DBManager.getUserGameTurnOver(user.getName(), startDate, EndDate, new CallBack() {

				@Override
				public void call(Object... callback) {

					ISFSArray tempHistoryList = (ISFSArray) callback[0];
					ISFSObject tempSFSObj = new SFSObject();
					tempSFSObj.putSFSArray(Param.USER_GAME_LIST, tempHistoryList);
					print("Response ::getSharePointDetailsByUserId:: Prames ::: " + tempSFSObj.getDump());
					GameMainExtension.extension.send(Request.USER_GAME_DETAILS_DATE_WISE_DOUBLE_CHANCE, tempSFSObj,
							user);

				}
			});

		}

	}

	@Override
	public void betNumberResponse(User user, BaseState pstState, String[] betsarray) {

		GameBean gameBean = pstState.getGameBean();

		if (gameBean != null) {

			ISFSObject isfsObject = new SFSObject();
			isfsObject.putUtfString(Param.MESSAGE, "Bets Send Successfully");
			isfsObject.putUtfString(Param.STATUS, "true");
			isfsObject.putUtfString(Param.BETSARRAY, Arrays.toString(betsarray));

			print("Response ::Double chahnce:::::::::GameEvents:::::::betNumberResponse:: Prames ::: "
					+ isfsObject.getDump());

			ref_extension.get().send(Request.USER_BETS_TABLE_DOUBLE, isfsObject, user);

		}

	}

	@Override
	public void sendUserbetsDetails(BaseState baseState, String roomname, String sessionid, User user) {
		Utils.Logger(GameMainExtension.extension, "sessionid:::::::::::::::::::" + sessionid + "roomname" + roomname);

		String betnos = "";
		double betamount = 0;

		List<String> tempSetTicketIdList = new ArrayList<String>();
		ISFSArray isfsArray = new SFSArray();

		HashMap<String, HashMap<String, HashMap<String, RouletteBetBeans>>> tempUserBetSetTicketId = TicketPrint
				.getTicketGenerateHashMap();

		HashMap<String, HashMap<String, RouletteBetBeans>> tempUserTableTypeMap = new HashMap<String, HashMap<String, RouletteBetBeans>>();

		SessionBean oldtempSession = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
				.getValueByKey(sessionid);
		UserBetBean tempolduserbetbean = oldtempSession.getUserBetBeanByUserId(user.getName());

		HashMap<String, HashMap<String, RouletteBetBeans>> tempRoulettebetBeanMapKey = tempolduserbetbean
				.getUserRouletteBets();

		String ticketid = DBManager.getTicketId();
		System.out.println("tempolduserbetbean::::::::::::::" + tempolduserbetbean.toString());

		System.out.println("ticketid::::::::::::::::::" + ticketid + "tempRoulettebetBeanMapKey:::::::::::::::"
				+ tempRoulettebetBeanMapKey.toString());

		HashMap<String, RouletteBetBeans> tempUserBetsSingle = tempRoulettebetBeanMapKey.get("SINGLE");
		HashMap<String, RouletteBetBeans> tempUserBetsDouble = tempRoulettebetBeanMapKey.get("DOUBLE");

		if (tempUserBetsSingle != null) {
			try {
				for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempUserBetsSingle.entrySet()) {

					String betno = (String) tempRouletteBetBeans.getKey();

					RouletteBetBeans tempRouletteBetBeansSingle = tempUserBetsSingle.get(betno);

					ISFSObject isfsObject = new SFSObject();
					betnos = tempRouletteBetBeansSingle.getBetNos();
					betamount = tempRouletteBetBeansSingle.getBetAmount();

					isfsObject.putUtfString(Param.BETNO, betnos);
					isfsObject.putDouble(Param.BETAMOUNT, betamount);
					isfsArray.addSFSObject(isfsObject);

					tempUserTableTypeMap.put("SINGLE", tempUserBetsSingle);

				}
			} catch (Exception e) {

				Utils.ErrorLogger(GameMainExtension.extension, "Single chance:::::::::::::::error ::::::::::::::" + e);
			}
		}
		if (tempUserBetsDouble != null) {

			try {
				for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempUserBetsDouble.entrySet()) {

					String betno = (String) tempRouletteBetBeans.getKey();
					RouletteBetBeans tempRouletteBetBeansDouble = tempUserBetsDouble.get(betno);

					ISFSObject isfsObject = new SFSObject();
					betnos = tempRouletteBetBeansDouble.getBetNos();
					betamount = tempRouletteBetBeansDouble.getBetAmount();

					isfsObject.putUtfString(Param.BETNO, betnos);
					isfsObject.putDouble(Param.BETAMOUNT, betamount);
					isfsArray.addSFSObject(isfsObject);

					tempUserTableTypeMap.put("DOUBLE", tempUserBetsDouble);

				}

			} catch (Exception e) {
				Utils.ErrorLogger(GameMainExtension.extension,
						" Double Chance:::::::::::::::::error ::::::::::::::" + e);
			}
		}

		tempUserBetSetTicketId.put(ticketid, tempUserTableTypeMap);
		tempSetTicketIdList.add(ticketid);

		try {

			DBManager.insertZeroToDoubleNinesql(sessionid, tempolduserbetbean, tempolduserbetbean.getGameId(),
					baseState.getGameBean());

		} catch (Exception e) {

			System.out.println("error::::::::::::::::::::::::::::::e" + e);
		}

		GameBean gameBean = baseState.getGameBean();

		// TicketPrint.setTicketGenerateHashMap(ticketGenerateHashMap);

		if (gameBean != null) {

			// List<User> tempUsers = tempRoom.getUserList();

			System.out.println("isfsArray:::::::::::::::::" + isfsArray);

			ISFSObject isfsObject1 = new SFSObject();
			isfsObject1.putUtfString(Param.SESSIONID, sessionid);
			isfsObject1.putUtfString(Param.USERID, user.getName());
			isfsObject1.putUtfString(Param.TICKETID, ticketid);
			isfsObject1.putUtfString(Param.USERID, user.getName());
			isfsObject1.putSFSArray("BETDETAILS", isfsArray);

			GameMainExtension.extension.send(Request.PRINT_BET_NUMBERS_DOUBLECHANCE, isfsObject1, user);

		}

		tempolduserbetbean.setUserRouletteBetsmap(new HashMap<String, HashMap<String, RouletteBetBeans>>());

		tempolduserbetbean.setTotalBetAmount("0");

		oldtempSession.setSessionBetAmount(0);

	}

	@Override
	public void sendGameDetailsResult(BaseState baseState, String roomaname, User user) {
		GameBean gameBean = baseState.getGameBean();

		if (gameBean != null) {

			DBManager.DoubleChance_getUsersDayWiseResult(user.getName(), new CallBack() {

				@Override
				public void call(Object... callback) {

					ISFSArray tempHistoryList = (ISFSArray) callback[0];
					ISFSObject tempSFSObj = new SFSObject();
					tempSFSObj.putSFSArray(Param.USER_GAME_LIST, tempHistoryList);
					print("Response ::sendDayWiseResultGameDetails Double chance:: Prames ::: " + tempSFSObj.getDump());
					GameMainExtension.extension.send(Request.USERS_DAY_WISE_RESULT_DOUBLECHANCE, tempSFSObj, user);

				}
			});

		}
	}

	@Override
	public void betCancelByTicketId(BaseState baseState, String roomaname, String sessionid, User user,
			String ticket_id) {

		Utils.Logger(GameMainExtension.extension, "baseState:::::::::::::" + baseState + " roomaname::::::::"
				+ roomaname + "sessionid:::::::::::::::::" + sessionid);

		String betnos = "";
		double betamount = 0;

		ISFSArray isfsArray = new SFSArray();

		HashMap<String, HashMap<String, RouletteBetBeans>> tempUserDataByTicketIdHashMap = TicketPrint
				.getTableTypeHashMapByTicketId(ticket_id);

		try {

			RouletteBetBeans tempRouletteBetBeans = null;
			HashMap<String, RouletteBetBeans> tempBetNoHashMap = null;

			for (Map.Entry<String, HashMap<String, RouletteBetBeans>> tempRouletteBetBeansTableType : tempUserDataByTicketIdHashMap
					.entrySet()) {

				String tabletype = tempRouletteBetBeansTableType.getKey();

				tempBetNoHashMap = TicketPrint.getBetNoRouletteBetBeanByTicketIdAndTableType(ticket_id, tabletype);

				for (Map.Entry<String, RouletteBetBeans> betNoBeanHashMap : tempBetNoHashMap.entrySet()) {

					ISFSObject isfsObject = new SFSObject();
					String betno = betNoBeanHashMap.getKey();

					tempRouletteBetBeans = tempBetNoHashMap.get(betno);

					betnos = tempRouletteBetBeans.getBetNos();
					betamount = tempRouletteBetBeans.getBetAmount();

					isfsObject.putUtfString(Param.BETNO, betnos);
					isfsObject.putDouble(Param.BETAMOUNT, betamount);
					isfsArray.addSFSObject(isfsObject);
				}

			}

			ISFSObject isfsObject1 = new SFSObject();
			isfsObject1.putUtfString(Param.SESSIONID, sessionid);
			isfsObject1.putUtfString(Param.USERID, user.getName());
			isfsObject1.putUtfString(Param.TICKETID, ticket_id);
			isfsObject1.putUtfString(Param.USERID, user.getName());
			isfsObject1.putSFSArray("BETDETAILS", isfsArray);

			Utils.Logger(GameMainExtension.extension, "isfsObject1::::::::::::::::::::" + isfsObject1.getDump());

			ref_extension.get().send(Request.CANCEL_BET_NUMBERS_BY_TICKET_DOUBLECHANCE, isfsObject1, user);

			if (tempBetNoHashMap.size() > 0) {
				tempBetNoHashMap.remove(betnos);
				tempUserDataByTicketIdHashMap.remove(ticket_id);

			}

		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension,
					"GameEvents::::::::::::::betCancelByTicketId:::::::::::::error" + e);
		}

	}

	@Override
	public void betClaimByTicketId(BaseState baseState, String roomaname, String sessionid, User user, String ticket_id,
			int gameid, String gametype) {

		Utils.Logger(GameMainExtension.extension,
				"DoubleChance::::::::::::::::::::::::GameEvnets::::::::::::::::::::::::::betClaimByTicket:::"
						+ baseState.getGameBean() + "roomname::::::::::::" + roomaname + "user::::::::::"
						+ user.getName() + "gameid:::::::::::::" + gameid + " gametype" + gametype);
		GameBean gameBean = baseState.getGameBean();

		if (gameBean != null) {

			DBManager.getDoubleChanceClaimStatus(user.getName(), ticket_id, new CallBack() {

				@Override
				public void call(Object... callback) {

					ISFSArray tempHistoryList = (ISFSArray) callback[0];
					ISFSObject tempSFSObj = new SFSObject();
					tempSFSObj.putSFSArray(Param.USER_GAME_LIST, tempHistoryList);
					print("Response ::betClaimByTicket:: Prames ::: " + tempSFSObj.getDump());
					GameMainExtension.extension.send(Request.CLAIM_BET_NUMBERS_BY_TICKET_PM, tempSFSObj, user);

				}
			});

		}

	}
}
