/**
 * 
 */
package com.latestfunroulette.dubliRoulette.cache.caching;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetPlaceAmountBeanSingleChance;
import com.latestfunroulette.dubliRoulette.cache.caching.interfaces.IRouletteBetPlaceAmountCache;


/**
 * @author Akshay Agarwal
 * @Date 26-07-1994
 */
public class RouletteBetPlaceAmountCacheSingleChance extends HashMap<String, RouletteBetPlaceAmountBeanSingleChance>
		implements Serializable, IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBeanSingleChance> {

	private static final long serialVersionUID = 1L;

	@Override
	public void add(RouletteBetPlaceAmountBeanSingleChance v) {
		put(v.getBetNo(), v);
	}

	@Override
	public void delete(String k) {
		remove(k);
	}

	@Override
	public RouletteBetPlaceAmountBeanSingleChance getValueByKey(String k) {
		return get(k);
	}

	@Override
	public List<RouletteBetPlaceAmountBeanSingleChance> getAllValue() {
		return new ArrayList<>(values());
	}

	@Override
	public HashMap<String, RouletteBetPlaceAmountBeanSingleChance> getAll() {

		return null;
	}

	@Override
	public void update(String k, RouletteBetPlaceAmountBeanSingleChance v) {

	}



}
