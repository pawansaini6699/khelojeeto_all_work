/**
 * 
 */
package com.latestfunroulette.dubliRoulette.cache.caching.interfaces;

/**
 * @author nagjee
 *
 */
public interface IUserBetCache<K,V> extends IBaseCache<K, V> {

}
