/**
 * 
 */
package com.latestfunroulette.dubliRoulette.cache.caching.interfaces;

import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

/**
 * @author nagjee
 *
 */
public interface IBaseCache<K, V> {

	void add(V v);

	void delete(K k);

	V getValueByKey(K k);

	List<V> getAllValue();

	HashMap<K, V> getAll();

	void update(K k, V v);

	default void print(Object msg) {
		Utils.Logger(GameMainExtension.extension, msg);
	}

}
