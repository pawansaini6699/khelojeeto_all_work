/**
 * 
 */
package com.latestfunroulette.dubliRoulette.cache.caching.interfaces;

/**
 * @author nagjee
 *
 */
public interface ISessionCache<K,V> extends IBaseCache<K, V> {

 void clearAllSession();	
 
 
	
}
