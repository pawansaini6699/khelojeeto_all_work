package com.latestfunroulette.dubliRoulette.cache;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.cache.caching.PlayerCache;
import com.latestfunroulette.cache.caching.interfaces.IPlayerCache;
import com.latestfunroulette.dubliRoulette.cache.beans.AvatarBean;
import com.latestfunroulette.dubliRoulette.cache.beans.CurrentSessionBean;
import com.latestfunroulette.dubliRoulette.cache.beans.GameBean;
import com.latestfunroulette.dubliRoulette.cache.beans.SessionBean;
import com.latestfunroulette.dubliRoulette.cache.caching.AvatarCache;
import com.latestfunroulette.dubliRoulette.cache.caching.GameBeanCache;
import com.latestfunroulette.dubliRoulette.cache.caching.SessionCache;
import com.latestfunroulette.dubliRoulette.cache.caching.interfaces.IAvatarCache;
import com.latestfunroulette.dubliRoulette.cache.caching.interfaces.ICurrentSession;
import com.latestfunroulette.dubliRoulette.cache.caching.interfaces.IGameBeanCache;
import com.latestfunroulette.dubliRoulette.cache.caching.interfaces.ISessionCache;

/**
 * @author nagjee
 *
 */
public class GameCacheDoubleRoulette {

	private volatile static IPlayerCache<String, Player> tempPlayerCache;
	private ISessionCache<String, SessionBean> tempSessionCache = null;

	private ICurrentSession<String> tempGameSession = null;
	private static IGameBeanCache<String, GameBean> tempGame;
	private static IAvatarCache<String, AvatarBean> tempAvatar;

	public GameCacheDoubleRoulette() {
		tempAvatar = new AvatarCache();
		tempPlayerCache = new PlayerCache();
		tempGame = new GameBeanCache();
	    tempSessionCache = new SessionCache();
		tempGameSession = new CurrentSessionBean();

	}

	public ISessionCache<String, SessionBean> getGameSessionBySessionId() {
		return tempSessionCache;
	}

	public ICurrentSession<String> getSession() {
		return tempGameSession;
	}

	public IGameBeanCache<String, GameBean> getGames() {
		return tempGame;
	}

	public IAvatarCache<String, AvatarBean> getAvatar() {
		return tempAvatar;
	}

	public IPlayerCache<String, Player> getPlayer() {
		return tempPlayerCache;
	}
}