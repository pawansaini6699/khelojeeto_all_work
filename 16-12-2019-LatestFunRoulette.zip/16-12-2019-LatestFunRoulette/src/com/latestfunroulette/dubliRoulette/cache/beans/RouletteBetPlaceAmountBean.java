/**
 * 
 */
package com.latestfunroulette.dubliRoulette.cache.beans;

import java.io.Serializable;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;

/**
 * @author Lal Chand Sharma
 * @author br Akshay Agarwal
 */
public class RouletteBetPlaceAmountBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String betNo;

	private double betAmount = 0.0;

	public String getBetNo() {
		return betNo;
	}

	public void setBetNo(String betNo) {
		this.betNo = betNo;
	}

	public double getBetAmount() {
		return betAmount;
	}

	public synchronized void updateBetAmount(double pBetAmount) {
		betAmount += pBetAmount;
		Utils.Logger(GameMainExtension.extension,
				" RouletteBetPlaceBean:::::::::::::updateBetAmount:::::::betamount" + betAmount);
	}

	public synchronized void removeBetAmount(double pBetAmount) {

		betAmount -= pBetAmount;
		Utils.Logger(GameMainExtension.extension,
				" RouletteBetPlaceBean:::::::::::::removeBetAmount:::::::betamount" + betAmount);

	}

	public ISFSObject toSFSObj() {
		ISFSObject tempSFSObj = new SFSObject();
		/*
		 * tempSFSObj.putUtfString("BET_NO", betNo);
		 * tempSFSObj.putUtfString("BET_AMOUNT", String.valueOf(betAmount));
		 */
		tempSFSObj.putUtfString(betNo, String.valueOf(betAmount));
		return tempSFSObj;
	}

	@Override
	public String toString() {
		return "RouletteBetPlaceAmountBean [betNo=" + betNo + ", betAmount=" + betAmount + "]";
	}
}