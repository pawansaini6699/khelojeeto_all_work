/**
 * 
 */
package com.latestfunroulette.dubliRoulette.cache.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.dubliRoulette.cache.caching.UserBetCache;
import com.latestfunroulette.dubliRoulette.cache.caching.interfaces.IUserBetCache;
import com.latestfunroulette.extension.GameMainExtension;

/**
 * @author nagjee
 *
 */
public class SessionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String sessionId;
	private IUserBetCache<String, UserBetBean> userBets = new UserBetCache();
	// private double totalSessionBetAmount = 0.0;
	private BigDecimal totalSessionBetAmount = new BigDecimal(0.0);
	private String rouletteWinPosition = "-1";
	double totalcoins = 0;
	// private IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean>
	// rouletteBetPlaceAmount = new RouletteBetPlaceAmountCache();
	// private IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean>
	// rouletteBetPlaceAmountSingleChance = new RouletteBetPlaceAmountCache();

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
		// addBetPlaces();
		// addBetPlacesSingleChance();
	}

	public UserBetBean getUserBetBeanByUserId(String pUserId) {
		return userBets.getValueByKey(pUserId);
	}

	public List<UserBetBean> getAllUserBets() {
		return userBets.getAllValue();
	}

	public String getRouletteWinPosition() {
		return rouletteWinPosition;
	}

	public void setRouletteWinPosition(String rouletteWinPosition) {
		this.rouletteWinPosition = rouletteWinPosition;
	}

	public void addUserBet(String pUserId, String sessionid, double coins, String pBetNos, double winAmount,
			String tabletype, int gameid) {

		Utils.Logger(GameMainExtension.extension,
				"SessionBean ::: before add amount ::::  User Id :::: " + pUserId + " ::: Session Id ::: " + sessionid
						+ " :::: Bet Amount ::: " + coins + "::::pBetNos:::::" + pBetNos
						+ ":::::::pBetPlaceCount::::::::::" + " ::::::pBetWinAmount::::::" + winAmount);

		UserBetBean tempUserBetBean = null;
		if ((tempUserBetBean = getUserBetBeanByUserId(pUserId)) == null) {
			tempUserBetBean = new UserBetBean(); // tempUserBetBean.setUserId(pUserId);
			tempUserBetBean.setUserId(pUserId);
			tempUserBetBean.setGameId(gameid);
			userBets.add(tempUserBetBean);
		}

		tempUserBetBean.addUpdateRouletteBet(coins, pBetNos, winAmount, tabletype);

		updateSessionTotalBetAmount(coins);

		Utils.Logger(GameMainExtension.extension, "SessionBean ::: after add amount ::::  User Id :::: " + pUserId
				+ " ::: Session Id ::: " + sessionid + " :::: Bet Amount ::: " + tempUserBetBean.getTotalBetAmount());

		// getSessionBetDetail();
	}

	public void addUserBetDouble(String pUserID) {

		new Thread() {

			@Override
			public void run() {

				Utils.Logger(GameMainExtension.extension, ":::::::::::::::::::::::::SESSIONBEAN::::::::::::::::::::");
				UserBetBean tempUserBet = getUserBetBeanByUserId(pUserID);

				BigDecimal tempUserBetAmount = new BigDecimal(tempUserBet.getTotalBetAmount());

				Utils.Logger(GameMainExtension.extension,
						"SESSIONBEAN::::::::::::::::::::::tempUserBetAmount" + tempUserBetAmount);
				updateSessionTotalBetAmount(tempUserBetAmount.doubleValue());
				double userTotalBetAmount = tempUserBetAmount.doubleValue() * 2;
				tempUserBet.setTotalBetAmount(String.valueOf(userTotalBetAmount));

				try {
					HashMap<String, RouletteBetBeans> tempUserBetsSingle = tempUserBet
							.getUserRouletteBetsTableType("SINGLE");

					HashMap<String, RouletteBetBeans> tempUserBetsDouble = tempUserBet
							.getUserRouletteBetsTableType("DOUBLE");

					Utils.Logger(GameMainExtension.extension, "SINGLE:::::::::::::::::::::" + tempUserBetsSingle);
					Utils.Logger(GameMainExtension.extension, "DOUBLE:::::::::::::::::::::" + tempUserBetsDouble);

					for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempUserBetsSingle.entrySet()) {

						String betno = (String) tempRouletteBetBeans.getKey();

						RouletteBetBeans tempRouletteBetBeanssingle = tempUserBetsSingle.get(betno);

						tempRouletteBetBeanssingle.setBetAmount(tempRouletteBetBeanssingle.getBetAmount() * 2);

					}

					for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempUserBetsDouble.entrySet()) {

						String betno = (String) tempRouletteBetBeans.getKey();

						RouletteBetBeans tempRouletteBetBeansDouble = tempUserBetsDouble.get(betno);

						tempRouletteBetBeansDouble.setBetAmount(tempRouletteBetBeansDouble.getBetAmount() * 2);

					}

					Utils.Logger(GameMainExtension.extension,
							"Session Bean ::: AddUserBetDouble :::: TotalSession Amount :::: " + getTotalBetAmount()
									+ " ::::: User Total Bet Amount ::::: " + tempUserBet.getTotalBetAmount());

				} catch (Exception e) {
					Utils.Logger(GameMainExtension.extension, "SESSIONBEAN::::::::::::::::::::::error" + e);

				}
			}
		}.start();

	}

	public void cancelSpecifiChooseAdmin(int pBetNo, String pUserId, double coins) {

		Utils.Logger(GameMainExtension.extension, "coins :::::::::::::::::::::" + coins + "pBetNo" + pBetNo);

		totalcoins = totalcoins + coins;
		Utils.Logger(GameMainExtension.extension, "totalcoins:::::::::::::::::::::" + totalcoins);

		try {
			UserBetBean tempUserBet = getUserBetBeanByUserId(pUserId);
			tempUserBet.cancelSpecificRouletteBet(String.valueOf(pBetNo), coins);

			tempUserBet.remainingTotalBetAmount(coins);
			Utils.Logger(GameMainExtension.extension, "Total bet amount:::::::::::::::::::"
					+ tempUserBet.getTotalBetAmount() + "totalcoins::::::::::::::::::" + coins);

		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension, " Triple Chance:::::::::::::::::error ::::::::::::::" + e);

		}

		clearSessionTotalBetAmount(coins);

	} // getSessionBetDetail(); }

	/*
	 * private void removeBetAmountSpecific(UserBetBean pUserBetBean, String betno,
	 * double coins, RouletteBetBeans pUserRouletteBet) {
	 * 
	 * Utils.Logger(GameMainExtension.extension,
	 * "SessionBean::::::::::::::::::::removeBetAmountSpecific::::::::::::::UserBetBean:::::::::::::::::"
	 * + pUserBetBean); Utils.Logger(GameMainExtension.extension,"hello");
	 * 
	 * double pBetSplitAmount = pUserRouletteBet.getSplitBetAmount();
	 * 
	 * clearSessionTotalBetAmount(coins);
	 * 
	 * String[] tempBets = betno.split(","); for (int b = 0; b < tempBets.length;
	 * b++) { String tempBetNo = tempBets[b].trim(); RouletteBetPlaceAmountBean
	 * tempRBP = rouletteBetPlaceAmount.getValueByKey(tempBetNo);
	 * 
	 * if (tempRBP != null) {
	 * 
	 * tempRBP.removeBetAmount(pBetSplitAmount);
	 * 
	 * Utils.Logger(GameMainExtension.extension," Bet :::: " + tempBetNo +
	 * "    :::: Totale remove Bet Amount :::: " + tempRBP.getBetAmount() +
	 * "::::::::::::::::tempRBP:::::::::::" + tempRBP.toString()); }
	 * 
	 * RouletteBetPlaceAmountBean tempUserRBP =
	 * pUserBetBean.getUserBetPlaceAmount().getValueByKey(tempBetNo);
	 * Utils.Logger(GameMainExtension.extension,
	 * "removeBetAmountSpecific::::::::::::tempRBP" + tempRBP.toString()); if
	 * (tempUserRBP != null) { tempUserRBP.removeBetAmount(pBetSplitAmount);
	 * Utils.Logger(GameMainExtension.extension," Bet :::: " + tempBetNo +
	 * "   ::::::  " + pUserBetBean.getUserId() +
	 * " :::: Totale user remove Bet Amount :::: " + tempUserRBP.getBetAmount() +
	 * "::::::::::::::::tempUserRBP:::::::::::" + tempUserRBP.toString()); } }
	 * 
	 * }
	 */

	public void cancelAllRouletteBet(String pUserId) {

		UserBetBean tempUserBetBean = null;
		if ((tempUserBetBean = userBets.getValueByKey(pUserId)) != null) {
			if (!tempUserBetBean.isBetStatus()) { //
				tempUserBetBean.cancelAllRouletteBet();
				String totalbetamount = tempUserBetBean.getTotalBetAmount();

				tempUserBetBean.setTotalBetAmount("0");

				clearSessionTotalBetAmount(Double.parseDouble(totalbetamount));
				userBets.delete(pUserId);
			}
		} //
			// getSessionBetDetail();
	}

//////////////////////////////////////////////////////////////////////////////

	/*
	 * public IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean>
	 * getRouletteBetPlaceAmount() { return rouletteBetPlaceAmount; }
	 * 
	 * public IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean>
	 * getRouletteBetPlaceAmountSingleChance() { return
	 * rouletteBetPlaceAmountSingleChance; }
	 */
	/*
	 * private void addBetPlaces() { for (int bp = 0; bp < 100; bp++) {
	 * 
	 * RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
	 * tempRBP.setBetNo(String.valueOf(bp));
	 * 
	 * rouletteBetPlaceAmount.add(tempRBP);
	 * 
	 * } }
	 * 
	 * private void addBetPlacesSingleChance() { for (int bp = 0; bp < 10; bp++) {
	 * 
	 * RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
	 * tempRBP.setBetNo(String.valueOf(bp));
	 * 
	 * rouletteBetPlaceAmountSingleChance.add(tempRBP); }
	 * 
	 * }
	 */
	/*
	 * private void updateBetAmount(UserBetBean pUserBetBean, String pBetNos, double
	 * coins) { Utils.Logger(GameMainExtension.extension,
	 * "SessionBean:::::::::::::updateBetAmount::::::::::pBetNos" + pBetNos +
	 * "pBetSplitAmount::::::::::::::"); String[] tempBets = pBetNos.split(","); for
	 * (int b = 0; b < tempBets.length; b++) { String tempBetNo =
	 * tempBets[b].trim(); // RouletteBetPlaceAmountBean tempRBP =
	 * rouletteBetPlaceAmount.getValueByKey(tempBetNo); //
	 * RouletteBetPlaceAmountBean tempRBPSingleChance =
	 * rouletteBetPlaceAmountSingleChance.getValueByKey(tempBetNo);
	 * 
	 * Utils.Logger(GameMainExtension.extension," Bet :::: " + tempBetNo +
	 * " tempBets : " + tempRBP.getBetAmount());
	 * 
	 * if (tempRBP != null) { tempRBP.updateBetAmount(coins);
	 * Utils.Logger(GameMainExtension.extension, " Bet :::: " + tempBetNo +
	 * "    :::: Totale update Bet Amount :::: " + tempRBP.getBetAmount()); }
	 * 
	 * RouletteBetPlaceAmountBean tempUserRBP =
	 * pUserBetBean.getUserBetPlaceAmount().getValueByKey(tempBetNo);
	 * 
	 * if (tempUserRBP != null) { tempUserRBP.updateBetAmount(coins);
	 * Utils.Logger(GameMainExtension.extension," Bet :::: " + tempBetNo +
	 * "  ::::: User Id ::::: " + pUserBetBean.getUserId() +
	 * "  :::: Totale user update Bet Amount :::: " + tempUserRBP.getBetAmount()); }
	 * } }
	 */

	/*
	 * private void removeBetAmount(UserBetBean pUserBetBean, RouletteBetBeans
	 * pUserRouletteBet) { Utils.Logger(GameMainExtension.extension,
	 * "SessionBean:::::::::::::::::::::::::removeBetAmount" +
	 * pUserRouletteBet.getBetAmount());
	 * 
	 * String pBetNos = pUserRouletteBet.getBetNos(); double pBetSplitAmount =
	 * pUserRouletteBet.getSplitBetAmount();
	 * clearSessionTotalBetAmount(pUserRouletteBet.getBetAmount());
	 * 
	 * String[] tempBets = pBetNos.split(","); for (int b = 0; b < tempBets.length;
	 * b++) { String tempBetNo = tempBets[b].trim(); RouletteBetPlaceAmountBean
	 * tempRBP = rouletteBetPlaceAmount.getValueByKey(tempBetNo); if (tempRBP !=
	 * null) { // Utils.Logger(GameMainExtension.gsfs, "SessionBean ::::::::
	 * RemoveBetAmount // ::::: before Roulette Bet No. ::: "+tempBetNo+" ::::
	 * Amount :::: // "+tempRBP.getBetAmount());
	 * tempRBP.removeBetAmount(pBetSplitAmount); //
	 * Utils.Logger(GameMainExtension.gsfs, "SessionBean :::::::: RemoveBetAmount //
	 * ::::: after Roulette Bet No. ::: "+tempBetNo+" :::: Amount :::: //
	 * "+tempRBP.getBetAmount()); Utils.Logger(GameMainExtension.extension, " Bet
	 * :::: " + tempBetNo + "    :::: Totale remove Bet Amount :::: " +
	 * tempRBP.getBetAmount()); }
	 * 
	 * RouletteBetPlaceAmountBean tempUserRBP =
	 * pUserBetBean.getUserBetPlaceAmount().getValueByKey(tempBetNo); if
	 * (tempUserRBP != null) { tempUserRBP.removeBetAmount(pBetSplitAmount);
	 * Utils.Logger(GameMainExtension.extension," Bet :::: " + tempBetNo +
	 * "   ::::::  " + pUserBetBean.getUserId() +
	 * " :::: Totale user remove Bet Amount :::: " + tempUserRBP.getBetAmount()); }
	 * } }
	 */

/////////////////////////////////////////////////////////////////

	private synchronized void updateSessionTotalBetAmount(double pBetAmount) {
		totalSessionBetAmount = totalSessionBetAmount.add(new BigDecimal(pBetAmount));
		totalSessionBetAmount = totalSessionBetAmount.setScale(3, BigDecimal.ROUND_HALF_DOWN);
		Utils.Logger(GameMainExtension.extension,
				" RouletteBetPlaceBean:::::::::::::updateBetAmount:::::::betamount" + totalSessionBetAmount);

		// totalSessionBetAmount += pBetAmount;
		// Utils.Logger(GameMainExtension.extension,"sessionbean::::::::::::updateSessionTotalBetAmount():::::::::::::::::::::
		// "+totalSessionBetAmount);
	}

	public synchronized void updateSessionTotalBetAmountUser(double pBetAmount) {
		Utils.Logger(GameMainExtension.extension,
				"totalSessionBetAmount::::::::::::sessionbean:::::::::" + totalSessionBetAmount);

		totalSessionBetAmount = totalSessionBetAmount.add(new BigDecimal(pBetAmount));
		totalSessionBetAmount = totalSessionBetAmount.setScale(3, BigDecimal.ROUND_HALF_DOWN);
		Utils.Logger(GameMainExtension.extension,
				" RouletteBetPlaceBean:::::::::::::::::::totalSessionBetAmount" + totalSessionBetAmount);

		// totalSessionBetAmount += pBetAmount;
		// Utils.Logger(GameMainExtension.extension,"sessionbean::::::::::::updateSessionTotalBetAmount():::::::::::::::::::::
		// "+totalSessionBetAmount);
	}

	private synchronized void clearSessionTotalBetAmount(double pBetAmount) {

		totalSessionBetAmount = totalSessionBetAmount.subtract(new BigDecimal(pBetAmount));
		totalSessionBetAmount = totalSessionBetAmount.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension,
				"clearSessionTotalBetAmount::::::::::::totalSessionBetAmount:::::::::" + totalSessionBetAmount);

		if (totalSessionBetAmount.doubleValue() < 0)
			totalSessionBetAmount = new BigDecimal(0.0);
	}

	/*
	 * totalSessionBetAmount -= pBetAmount;
	 * Utils.Logger(GameMainExtension.extension,
	 * "clearsessiontotelbetamount:::::::::" + pBetAmount +
	 * "totalSessionBetAmount:::::::::" + totalSessionBetAmount);
	 * totalSessionBetAmount -= pBetAmount; if (totalSessionBetAmount < 0)
	 * totalSessionBetAmount = 0.0; }
	 */

	public double getTotalBetAmount() {
		return totalSessionBetAmount.doubleValue();
	}

	public void setSessionBetAmount(double totalSessionBetAmount) {
		this.totalSessionBetAmount = new BigDecimal(totalSessionBetAmount);
	}

	/*
	 * public String getSessionBetDetail() { ISFSObject tempSFSObj = new
	 * SFSObject(); tempSFSObj.putUtfString("TOTAL_SESSION_BET_AMOUNT",
	 * String.valueOf(totalSessionBetAmount)); SFSArray sfsArray = new SFSArray();
	 * for (int bp = 0; bp < 37; bp++) { List<UserBetBean> tempBetUsers =
	 * userBets.getAllValue(); double tempTotalBetAmount = 0; for (int u = 0; u <
	 * tempBetUsers.size(); u++) { UserBetBean tempUses = tempBetUsers.get(u);
	 * double tempUserBetAmount = Double.parseDouble(tempUses.getTotalBetAmount());
	 * if(tempUses != null && tempUserBetAmount > 0) { RouletteBetPlaceAmountBean
	 * tempUserRBP = tempUses.getUserBetPlaceAmount()
	 * .getValueByKey(String.valueOf(bp)); if(tempUserRBP != null){
	 * tempTotalBetAmount += tempUserRBP.getBetAmount(); } } }
	 * sfsArray.addUtfString(String.valueOf(tempTotalBetAmount)); }
	 * tempSFSObj.putSFSArray("SESSION_BETS", sfsArray);
	 * 
	 * return tempSFSObj.toJson().toString(); }
	 */

	/*
	 * public String getSessionBetDetail() { ISFSObject tempSFSObj = new
	 * SFSObject(); tempSFSObj.putUtfString("TOTAL_SESSION_BET_AMOUNT",
	 * String.valueOf(totalSessionBetAmount));
	 * tempSFSObj.putUtfString("TOTAL_USER_BET_AMOUNT",
	 * String.valueOf(totalSessionBetAmount)); SFSArray sfsArray = new SFSArray();
	 * 
	 * for (int bp = 0; bp < 100; bp++) { if (bp == 0) {
	 * 
	 * sfsArray.addUtfString(String.valueOf(rouletteBetPlaceAmount.getValueByKey(
	 * "00").getBetAmount())); } else { sfsArray.addUtfString(
	 * String.valueOf(rouletteBetPlaceAmount.getValueByKey(String.valueOf(bp -
	 * 1)).getBetAmount()));
	 * 
	 * } } tempSFSObj.putSFSArray("SESSION_BETS", sfsArray);
	 * 
	 * return tempSFSObj.toJson().toString(); }
	 */

	/*
	 * public String getUserBetDetail(String pUserID) { ISFSObject tempSFSObj = new
	 * SFSObject(); UserBetBean tempUserBet = getUserBetBeanByUserId(pUserID);
	 * 
	 * tempSFSObj.putUtfString("TOTAL_SESSION_BET_AMOUNT",
	 * String.valueOf(totalSessionBetAmount));
	 * tempSFSObj.putUtfString("TOTAL_USER_BET_AMOUNT",
	 * String.valueOf(tempUserBet.getTotalBetAmount())); SFSArray sfsArray = new
	 * SFSArray(); Map<String, RouletteBetPlaceAmountBean> tempUserBets =
	 * tempUserBet.getUserBetPlaceAmount().getAll();
	 * 
	 * for (int bp = 0; bp < 100; bp++) {
	 * 
	 * sfsArray.addUtfString(String.valueOf(tempUserBets.get(String.valueOf(bp)).
	 * getBetAmount()));
	 * 
	 * }
	 * 
	 * tempSFSObj.putSFSArray("USER_BETS", sfsArray);
	 * 
	 * return tempSFSObj.toJson().toString(); }
	 */

	@Override
	public String toString() {
		return "SessionBean [sessionId=" + sessionId + "]";
	}

}