package com.latestfunroulette.dubliRoulette.client;

import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.dubliRoulette.common.GameEventMangaer;
import com.latestfunroulette.dubliRoulette.common.interfaces.IGameEventManager;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class DoubleChance_UsersDayWiseResult extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User pUser, ISFSObject params) {
		
		new Thread()
		{
			public void run()
			{
				Utils.Logger(getParentExtension() ,  " DoubleChance_UsersDayWiseResult :::::::  Request"
						+ "  ::::  User:::::::: "   + pUser.getName() +  "  ::: Params  ::::  "  +  
						params.getDump());
				
				try {
					
					IGameEventManager tempEvent = new GameEventMangaer();
					tempEvent.UsersDayWiseResult(pUser, params, new CallBack() {

						@Override
						public void call(Object... values) {
							
							
						}
						
					});
					
				}
				catch (Exception e) {
					
					
				}
			}
			
		}.start();
	}

}
