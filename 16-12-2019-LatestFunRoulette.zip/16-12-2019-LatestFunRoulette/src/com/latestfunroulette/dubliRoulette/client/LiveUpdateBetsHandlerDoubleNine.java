package com.latestfunroulette.dubliRoulette.client;


import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.dubliRoulette.common.GameEventMangaer;
import com.latestfunroulette.dubliRoulette.common.interfaces.IGameEventManager;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.BaseClientRequestHandler;

public class LiveUpdateBetsHandlerDoubleNine extends BaseClientRequestHandler {

	@Override
	public void handleClientRequest(User user, ISFSObject params) {

		new Thread() {

			@Override
			public void run() {

				Utils.Logger(getParentExtension(), "LiveUpdateBetsHandlerClass :::: Request :::: User ::: "
						+ user.getName() + " ::: Params :::: " + params.getDump());

				try {

					IGameEventManager tempEvents = new GameEventMangaer();

					tempEvents.onLiveBet(user, params, new CallBack() {

						@Override
						public void call(Object... values) {

						}
					});
				} catch (Exception e) {

				}

			}

		}.start();

	}
}
