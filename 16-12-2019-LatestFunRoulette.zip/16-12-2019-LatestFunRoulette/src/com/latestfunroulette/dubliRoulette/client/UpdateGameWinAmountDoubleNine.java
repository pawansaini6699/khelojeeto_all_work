package com.latestfunroulette.dubliRoulette.client;

import java.util.List;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Events;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.dubliRoulette.base.interfaces.BaseState;
import com.latestfunroulette.dubliRoulette.cache.beans.GameBean;
import com.latestfunroulette.dubliRoulette.cache.beans.SessionBean;
import com.latestfunroulette.dubliRoulette.cache.beans.UserBetBean;
import com.latestfunroulette.dubliRoulette.cache.beans.RouletteBetBeans;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.SFSExtension;

import scala.ref.WeakReference;

public class UpdateGameWinAmountDoubleNine {
	@SuppressWarnings("unused")
	private WeakReference<SFSExtension> ref_extension = null;

	public UpdateGameWinAmountDoubleNine(SFSExtension extension) {
		ref_extension = new WeakReference<SFSExtension>(extension);
	}

	public static void updateWinAmount(BaseState basestate, String pSession, String pWinnumber, Room roomname,
			int jackport, String ticketno) {

		new Thread() {
			@Override
			public void run() {

				Utils.Logger(GameMainExtension.extension, "Doublechance:::::::::::::::::UpdateGameWinAmountManager"
						+ "sessionid" + pSession + " winnnumber" + pWinnumber);

				GameBean gameBean = basestate.getGameBean();
				Player player = GameMainExtension.cache.getPlayer().getValueByKey(gameBean.getUserid());
				SessionBean tempSession = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
						.getValueByKey(pSession);
				Room tempRoom = GameMainExtension.extension.getParentZone().getRoomByName(gameBean.getRoomName());

				int winamountsingle = 0;
				int winamountdouble = 0;
				String tempWinamount = "";
				int betamountsingle = 0;
				int betamountdouble = 0;
				if (tempSession != null) {

					List<UserBetBean> tempUserBetBeans = tempSession.getAllUserBets();
					if (tempUserBetBeans != null) {
						for (int u = 0; u < tempUserBetBeans.size(); u++) {
							UserBetBean tempUser = tempUserBetBeans.get(u);
							int gameId = tempUser.getGameId();
							User tempSFSUser = tempRoom.getUserByName(tempUser.getUserId());

							if (tempUser != null && tempUser.isBetStatus()) {

								List<String> tempStrings = TicketPrint.getTempRouletteBetBeans();

								System.out.println(
										"UpdateGameWinAmountDoubleNine:::::::::::::tempStrings:::::::::" + tempStrings);

								if (tempStrings.size() > 0) {

									for (String ticketno : tempStrings) {
										System.out.println("UpdateGameWinAmountDoubleNine:::::::::::::ticketno:::::::::"
												+ tempStrings);

										RouletteBetBeans tEMPBeansSingle = TicketPrint
												.getRouletteBetBeanByTicketIdOrTableTypeOrBetNo(ticketno, "SINGLE",
														String.valueOf(pWinnumber));

										RouletteBetBeans tEMPBeansDouble = TicketPrint
												.getRouletteBetBeanByTicketIdOrTableTypeOrBetNo(ticketno, "DOUBLE",
														String.valueOf(pWinnumber));

										if (tEMPBeansSingle != null) {
											betamountsingle = (int) (tEMPBeansSingle.getBetAmount());
											winamountsingle = betamountsingle * 9 * jackport;
											Utils.Logger(GameMainExtension.extension,
													"Triple chance:::::::::::::::SINGLE CHANCE::::::::::tempRoulettebeansSingle "
															+ winamountsingle);

										} else {
											Utils.Logger(GameMainExtension.extension,
													"Triple chance:::::::::::::::SINGLE CHANCE::::::::::tempRoulettebeansSingle "
															+ tEMPBeansSingle);
											tEMPBeansSingle = new RouletteBetBeans();
										}
										if (tEMPBeansDouble != null) {
											Utils.Logger(GameMainExtension.extension,
													"Triplechance::::::::::::::::::::::UpdateGameWinAmountTripleNine :::::::::double::::::::::::tempRoulettebeansDouble::NOT NULL:"
															+ tEMPBeansDouble.toString());

											betamountdouble = (int) tEMPBeansDouble.getBetAmount();
											winamountdouble = betamountdouble * 90 * jackport;
										} else {
											Utils.Logger(GameMainExtension.extension,
													"Triplechance::::::::::::::::::::::UpdateGameWinAmountTripleNine :::::::::double::::::::::::::::::::tempRoulettebeansDouble:::::null");

											tEMPBeansDouble = new RouletteBetBeans();
										}

										int userexistStatus = 1;

// 

										if (tempSFSUser != null) {
											Utils.Logger(GameMainExtension.extension,
													"Doublechance:::::::::::::::::::::::: UpdateUserCreditsbeforeTakeHandler:::::::::::::::::::userexistStatus "
															+ userexistStatus);

											userexistStatus = 0;
										}

										gameBean.setTotalsessionwinamount(String.valueOf(tempWinamount));
										gameBean.setJackport(jackport);
										GameMainExtension.gameCacheDoubleRoulette.getGames().add(gameBean);

										DBManager.updateUserWinAmountsqlZeroToDoubleNine(tempUser.getUserId(),
												tempWinamount, pWinnumber, pSession, winamountsingle, winamountdouble,
												jackport, ticketno, new CallBack() {

													@Override
													public void call(Object... callback) {

														{

															ISFSObject isfsObject = (ISFSObject) callback[0];

															Utils.Logger(GameMainExtension.extension,
																	"---------- UpdateUserCreditsbeforeTakeHandler----------response "
																			+ isfsObject.getDump());
															GameMainExtension.extension.send(Events.UPDATEUSERCREDITS,
																	isfsObject, tempSFSUser);
														}

													}
												});

										DBManager.updateUserWinAmountmongoZeroToDoubleNine(tempUser.getUserId(),
												pSession, pWinnumber, tempWinamount, userexistStatus, player.getChips(),
												jackport);

										DBManager.updateUserWinAmountmongoDoubleChanceZeroToNine(tempUser.getUserId(),
												pSession, pWinnumber, tempWinamount, userexistStatus, player.getChips(),
												jackport);

									}

									Utils.Logger(GameMainExtension.extension,
											"::::::::: UpdateGameWinAmount :::::::::::::totalsessionbetamount"
													+ tempSession.getTotalBetAmount()
													+ ":::::::::::   winamount   ::::::::::::::::" + tempWinamount);
									DBManager.updateLiveTimeDataZeroToDoubleNine(tempSession.getTotalBetAmount(),
											String.valueOf(tempWinamount), gameId, jackport);

								} else {

									try {
										RouletteBetBeans tempRoulettebeansSingle = tempUser
												.getUserRouletteBetsByBetNoAndTableType(
														String.valueOf(pWinnumber.charAt(0)), "SINGLE");

										if (tempRoulettebeansSingle != null) {
											betamountsingle = (int) (tempRoulettebeansSingle.getBetAmount());
										} else {
											tempRoulettebeansSingle = new RouletteBetBeans();
										}
									} catch (Exception e) {
										Utils.Logger(GameMainExtension.extension,
												"Doublechance::::::::::::::::UpdateGameWinAmountDoubleNine:::::::::::single::::::::::error"
														+ e);
									}

									try {
										RouletteBetBeans tempRoulettebeansDouble = tempUser
												.getUserRouletteBetsByBetNoAndTableType(pWinnumber, "DOUBLE");

										if (tempRoulettebeansDouble != null) {
											betamountdouble = (int) tempRoulettebeansDouble.getBetAmount();
										} else {

											tempRoulettebeansDouble = new RouletteBetBeans();
										}
									} catch (Exception e) {
										Utils.Logger(GameMainExtension.extension,
												"Doublechance:::::::::::::::::::::::::::UpdateGameWinAmountDoubleNine::::::::::::double:::::::::error"
														+ e);
									}

									winamountsingle = betamountsingle * 9 * jackport;

									winamountdouble = betamountdouble * 90 * jackport;

									gameBean.setWinner(String.valueOf(winamountsingle + winamountdouble));

									// BigDecimal tempBigDecimal = new BigDecimal((tempWinnumberBetAmount *36));
									tempWinamount = String.valueOf(winamountsingle + winamountdouble);

									Utils.Logger(GameMainExtension.extension,
											"Doublechance::::::::::::::::::::::::UpdateGameWinAmountManager::::::::"
													+ "tempWinamount" + tempWinamount);

									int userexistStatus = 1;

									if (tempSFSUser != null) {
										Utils.Logger(GameMainExtension.extension,
												"Doublechance:::::::::::::::::::::::: UpdateUserCreditsbeforeTakeHandler:::::::::::::::::::userexistStatus "
														+ userexistStatus);

										userexistStatus = 0;
									}

									gameBean.setTotalsessionwinamount(String.valueOf(tempWinamount));
									gameBean.setJackport(jackport);

									GameMainExtension.gameCacheDoubleRoulette.getGames().add(gameBean);

									DBManager.updateUserWinAmountsqlZeroToDoubleNine(tempUser.getUserId(),
											tempWinamount, pWinnumber, pSession, winamountsingle, winamountdouble,
											jackport, ticketno, new CallBack() {

												@Override
												public void call(Object... callback) {

													{

														ISFSObject isfsObject = (ISFSObject) callback[0];

														Utils.Logger(GameMainExtension.extension,
																"---------- UpdateUserCreditsbeforeTakeHandler----------response "
																		+ isfsObject.getDump());
														GameMainExtension.extension.send(Events.UPDATEUSERCREDITS,
																isfsObject, tempSFSUser);
													}

												}
											});

									DBManager.updateUserWinAmountmongoZeroToDoubleNine(tempUser.getUserId(), pSession,
											pWinnumber, tempWinamount, userexistStatus, player.getChips(), jackport);

									DBManager.updateUserWinAmountmongoDoubleChanceZeroToNine(tempUser.getUserId(),
											pSession, pWinnumber, tempWinamount, userexistStatus, player.getChips(),
											jackport);

								}

								Utils.Logger(GameMainExtension.extension,
										"::::::::: UpdateGameWinAmount :::::::::::::totalsessionbetamount"
												+ tempSession.getTotalBetAmount()
												+ ":::::::::::   winamount   ::::::::::::::::" + tempWinamount);
								DBManager.updateLiveTimeDataZeroToDoubleNine(tempSession.getTotalBetAmount(),
										String.valueOf(tempWinamount), gameId, jackport);

							}

						}

					}
				}
			}

		}.start();
	}

}
