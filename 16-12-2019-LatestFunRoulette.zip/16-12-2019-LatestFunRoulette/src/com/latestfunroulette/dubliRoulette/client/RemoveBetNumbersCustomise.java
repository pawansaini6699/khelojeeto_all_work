package com.latestfunroulette.dubliRoulette.client;


import com.latestfunroulette.ZerotoNineRoulette.cache.beans.SessionBean;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;


public class RemoveBetNumbersCustomise {

	static double winAmountFactor = 0;
	static double betSplitFactor = 0;
	static String command = "";
	public static void splitBetNumbersRemove(String sessionId,int betnumbers,User user,double coins) {
	String[] dayString = {};
	

	switch (betnumbers) {

	case 0:
		dayString = new String[] { "0" };
		command = "STRAIGHT UP";
		winAmountFactor = 9;

		break;
	case 1:
		dayString = new String[] { "1" };
		command = "STRAIGHT UP";
		winAmountFactor = 9;

		break;
	case 2:
		dayString = new String[] { "2" };
		command = "STRAIGHT UP";
		winAmountFactor = 9;

		break;
	case 3:
		dayString = new String[] { "3" };
		command = "STRAIGHT UP";
		winAmountFactor = 9;

		break;
	case 4:
		dayString = new String[] { "4" };
		command = "STRAIGHT UP";
		winAmountFactor = 9;

		break;
	case 5:
		dayString = new String[] { "5" };
		command = "STRAIGHT UP";
		winAmountFactor = 9;

		break;
	case 6:
		dayString = new String[] { "6" };
		command = "STRAIGHT UP";
		winAmountFactor = 9;

		break;
	case 7:
		dayString = new String[] { "7" };
		command = "STRAIGHT UP";
		winAmountFactor = 9;

		break;
	case 8:
		dayString = new String[] { "8" };
		command = "STRAIGHT UP";
		winAmountFactor = 9;

		break;
	case 9:
		dayString = new String[] { "9" };
		command = "STRAIGHT UP";
		winAmountFactor = 9;

		break;
	case 10:
		dayString = new String[] { "1", "3", "5", "7", "9" };
		command = "ODD_NUMBER";
		winAmountFactor = 9;

		break;

	case 11:

		dayString = new String[] { "0", "2", "4", "6", "8" };
		command = "EVEN_NUMBER";
		winAmountFactor = 9;

		break;

	}

//	double winAmount = coins * winAmountFactor;

	StringBuilder tempSelectedNumbers = new StringBuilder();
	/*
	 * Utils.Logger(GameMainExtension.extension,
	 * "BetNumbersZeroToNine:::::::::::::::: winAmount:::::::::::::::::::::::::::::"
	 * + winAmount);
	 */
	// StringBuilder tempSelectedNumbers = new StringBuilder();

	SessionBean tempGameSessionBean = GameMainExtension.gameCacheZeroToNine.getGameSessionBySessionId()
			.getValueByKey(sessionId);

	for (int i = 0; i < dayString.length; i++) {

		Utils.Logger(GameMainExtension.extension,"dayString:::::::::::::" + dayString[i]);

		tempSelectedNumbers.append(dayString[i] + ",");
		Utils.Logger(GameMainExtension.extension,dayString[i]);
		Utils.Logger(GameMainExtension.extension,sessionId);

		if (tempGameSessionBean == null) {

			Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean::::is null" + ":::::::    ");

		} else {

			Utils.Logger(GameMainExtension.extension,"BetNumbers:::::::tempGameSessionBean::::::::::::::not null::::::::::::::::::::::::::::::::");
			tempGameSessionBean.cancelSpecifiChooseAdmin(tempSelectedNumbers.toString(),user.getName(),coins);

			
		
			

		}

	}
	
}
}

