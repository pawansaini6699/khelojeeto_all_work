package com.latestfunroulette.dubliRoulette.machine.machineclass;

import java.lang.ref.WeakReference;
import java.util.concurrent.ScheduledFuture;


import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.dubliRoulette.base.baseclass.BaseStateMachine;
import com.latestfunroulette.dubliRoulette.cache.beans.GameBean;
import com.latestfunroulette.dubliRoulette.machine.interfaces.IStateMachine;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class AllMachineManager {

	BaseStateMachine<GameBean> baseStateMachine = null;

	WeakReference<SFSExtension> ref_extension;
	ScheduledFuture<?> taskHandlerForGames;

	public void OnInitialState(Room proom, GameBean gameBean) {
		
		gameBean.setRoomName(proom.getName());
		gameBean.setGameTurnTime(1);
		gameBean.setGameState(GameState.INITIAL);

		IStateMachine<GameBean> gameMachine = new Machine();
	//	gameBean.setGameMachineDoubli(gameMachine);
		gameBean.setGameMachine(gameMachine);
		gameMachine.onStart(gameBean);
		

		/*
		 * taskHandlerForGames = tempSFS.getTaskScheduler().scheduleAtFixedRate(new
		 * Runnable() {
		 * 
		 * @Override public void run() { getGame.onProcess(); }
		 * 
		 * }, 0, 1, TimeUnit.SECONDS);
		 */

		/*
		 * GameBean gameBean = new GameBean(); gameBean.setRoomName(proom.getName());
		 * gameBean.setGameTurnTime(1); gameBean.setGameState(GameState.INITIAL);
		 * 
		 * IStateMachine<GameBean> getGame = new Machine();
		 * gameBean.setGameMachine(getGame); getGame.onStart(gameBean);
		 * 
		 * TimerTask timerTask = new TimerTask() {
		 * 
		 * @Override public void run() {
		 * 
		 * getGame.onProcess();
		 * 
		 * } }; Timer tempTimer = new Timer("Test state Machine");
		 * tempTimer.scheduleAtFixedRate(timerTask, 500, 1000);
		 */
	}

}
