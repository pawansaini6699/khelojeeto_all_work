package com.latestfunroulette.dubliRoulette.machine.interfaces;

public interface IMachineManager {

	void join(String pLoginId, String pRoomName);

}