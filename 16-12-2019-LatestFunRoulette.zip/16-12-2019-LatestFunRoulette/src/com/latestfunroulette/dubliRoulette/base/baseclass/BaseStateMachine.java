package com.latestfunroulette.dubliRoulette.base.baseclass;

import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.dubliRoulette.base.interfaces.IState;
import com.latestfunroulette.dubliRoulette.cache.beans.GameBean;
import com.latestfunroulette.dubliRoulette.client.RTimer;
import com.latestfunroulette.dubliRoulette.machine.interfaces.IStateMachine;

public abstract class BaseStateMachine<G> implements IStateMachine<G> {

	private G g;
	private boolean machineStatus = true;
	private String stateName = GameState.INITIAL;
	private IState<GameBean> currentState = null;
	private RTimer timer = null;

	// private Deck cardDeck = null;

	protected void setGameBean(G g) {
		this.g = g;
		timer = new RTimer();
		// this.cardDeck = new Deck();
	}
	

	public G getGameBean() {
		return g;
	}

	/*
	 * public Deck getDeck() { return cardDeck; }
	 */

	protected void setCurrentState(String pState) {
		this.stateName = pState;
		currentState = getState(pState);
	}

	public IState<GameBean> getCurrentState() {
		return this.currentState;
	}

	public String getStateName() {
		return this.stateName;
	}

	protected void setMachineStatus(boolean pStatus) {
		this.machineStatus = pStatus;
	}

	public boolean getMachinState() {
		return this.machineStatus;
	}

	public RTimer getTimers() {
		return timer;
	}
	
	
	

}