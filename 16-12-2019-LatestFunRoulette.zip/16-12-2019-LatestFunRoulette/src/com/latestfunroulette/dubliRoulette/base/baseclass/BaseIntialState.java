package com.latestfunroulette.dubliRoulette.base.baseclass;


import com.latestfunroulette.dubliRoulette.base.interfaces.BaseState;
import com.latestfunroulette.dubliRoulette.cache.beans.GameBean;

public abstract class BaseIntialState extends BaseState {

	@Override
	protected void init(GameBean pGameBane, int pStateTime) {
		// TODO Auto-generated method stub
		super.init(pGameBane, pStateTime);
		updateSessionId();
	}

	private void updateSessionId() {

	}

}
