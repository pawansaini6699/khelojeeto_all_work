package com.latestfunroulette.dubliRoulette.base.baseclass;

import com.latestfunroulette.common.BetNumberRandomGenerateDouble;
import com.latestfunroulette.common.BetNumberZeroToDoubleNine;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.dubliRoulette.base.interfaces.BaseState;
import com.latestfunroulette.dubliRoulette.cache.beans.GameBean;
import com.latestfunroulette.dubliRoulette.cache.beans.SessionBean;
import com.latestfunroulette.dubliRoulette.cache.beans.UserBetBean;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;

public abstract class BasebetPlaceState extends BaseState {

	@Override
	protected void init(GameBean pGameBane, int pStateTime) {
		super.init(pGameBane, pStateTime);
		SessionBean sessionBean = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
				.getValueByKey(pGameBane.getSession_id());
		if (sessionBean != null) {
			Utils.Logger(GameMainExtension.extension, "BaseState::::::::::::::::::::" + sessionBean.toString());

		} else {
			Utils.Logger(GameMainExtension.extension, "BaseState::::::::::::::::::::is null");

		}

	}

	protected void updateBetStatus(String userid, String session_id, double coins, int number, String tabletype,
			int gameid) {

		Utils.Logger(GameMainExtension.extension, "BasebetPlaceState  :::::: " + "userid" + userid + "sessionid"
				+ session_id + "coins" + coins + "selectednumbers" + number + "gameid::::::::::::::::::" + gameid);

		BetNumberZeroToDoubleNine.doubleRoulette(userid, session_id, coins, number, tabletype, gameid);
		// BetNumbers.splitBetNumbers(userid, session_id, coins, number);

	}

	protected void placeBetNoRandom(User user, String session_id, double coins, int limit, String tabletype, int gameid,
			int tableplaceno) {

		Utils.Logger(GameMainExtension.extension, "BasebetPlaceState  :::::: " + "userid" + user.getName() + "sessionid"
				+ session_id + "coins" + coins + "selectednumbers" + limit + "gameid::::::::::::::::::" + gameid);

		String betsarr[] = BetNumberRandomGenerateDouble.fiveNumberGenerate(user.getName(), session_id, coins, limit,
				tableplaceno, tabletype, gameid);
		getEvents().betNumberResponse(user, this, betsarr);

		// BetNumbers.splitBetNumbers(userid, session_id, coins, number);

	}

	public void cancelSpecificBet(User user, String session_id, String tableType, int betNo, double betAmount) {

		SessionBean tempGameSessionBean = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
				.getValueByKey(session_id);
		if (tempGameSessionBean != null) {
			UserBetBean tempUser = tempGameSessionBean.getUserBetBeanByUserId(user.getName());
			if (tempUser != null) {
				// betAmount = Double.parseDouble(tempUser.getTotalBetAmount());
			}
			tempGameSessionBean.cancelSpecifiChooseAdmin(betNo, user.getName(), betAmount);

			getEvents().specificClearBet(this, betAmount, user);
		}
	}

	public void clearAllBetsRoulette(User user, String session_id) {
		double betamount = 0.0;
		SessionBean tempSessionBean = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
				.getValueByKey(session_id);
		if (tempSessionBean != null) {
			UserBetBean tempUser = tempSessionBean.getUserBetBeanByUserId(user.getName());
			if (tempUser != null) {
				betamount = Double.parseDouble(tempUser.getTotalBetAmount());
			}

			tempSessionBean.cancelAllRouletteBet(user.getName());
			getEvents().clearBet(this, betamount, user);

		}

	}

	public void onUserBetSave(String roomname, User user, String session_id) {

		SessionBean tempSession = GameMainExtension.gameCacheDoubleRoulette.getGameSessionBySessionId()
				.getValueByKey(session_id);
		if (tempSession != null) {
			UserBetBean tempUserBetBean = tempSession.getUserBetBeanByUserId(user.getName());

			if (tempUserBetBean != null) {
				tempUserBetBean.setBetStatus(true);
				Utils.Logger(GameMainExtension.extension, "true");
				getEvents().betSave(this, user, session_id, roomname);
			}
		}

	}

	public void getGameDetailsDoubleChance(String roomname, User user) {
		getEvents().getGameDetails_DoubleChance(this, roomname, user);

	}

	public void getGameDetailsRouletteStartAndEndDateDoubleChance(String roomname, User user, String startDate,
			String EndDate) {
		getEvents().getGameDetailsDateWise_DoubleChance(this, roomname, user, startDate, EndDate);

	}

	public void betPrintExeUser(String roomname, String sessionId, User user) {
		getEvents().sendUserbetsDetails(this, roomname, sessionId, user);

	}

	public void getGameDetailsResult_DoubleChance(String roomname, User user) {
		getEvents().sendGameDetailsResult(this, roomname, user);

	}

	public void betCancelByTicketIdUser(String roomname, String sessionid, User user, String ticket_id) {

		getEvents().betCancelByTicketId(this, roomname, sessionid, user, ticket_id);

	}

	public void betClaimByTicketId(String roomname, String sessionid, User user, String ticket_id,int gameid,String gametype) {

		getEvents().betClaimByTicketId(this, roomname, sessionid, user, ticket_id,gameid,gametype);

	}

}
