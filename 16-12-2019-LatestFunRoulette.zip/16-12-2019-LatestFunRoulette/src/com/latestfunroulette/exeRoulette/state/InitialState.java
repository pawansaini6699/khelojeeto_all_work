package com.latestfunroulette.exeRoulette.state;

import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.GameStateTime;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.base.baseclass.BaseIntialState;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.exeRoulette.state.interfaces.IInitialState;
import com.latestfunroulette.extension.GameMainExtension;



public class InitialState extends BaseIntialState implements IInitialState<GameBean> {

	int count = 0;

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,"SingleRouletteRoom::::::::::InitialState" + g.getGameTurnTime());
		super.init(g, GameStateTime.INITIAL_TIME);
		int currenttime = (int) getTimer().getElapsedTime();
		Utils.Logger(GameMainExtension.extension,"onStart" + "timer" + currenttime);

	}

	@Override
	public void onProcess() {
		Utils.Logger(GameMainExtension.extension,"SingleRouletteRoom:::::::::::::::InitialState :::: OnProcess():::::::: getTimer().getElapsedTime()"
				+ getTimer().getElapsedTime() + "getStateTime()" + getStateTime());

		if (getTimer().getElapsedTime() > getStateTime()) {
			onExist();
		}

	}

	@Override
	public void onJoin(String pLoginId) {
		print("SingleRouletteRoom::::::::::::::InitialState :::: OnJoin()");

		//getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {
		Utils.Logger(GameMainExtension.extension,"SingleRouletteRoom::::::::::::::::SingleRouletteRoom");
		getGameBean().setGameState(GameState.BETPLACESTATE);
		getGameMachine().onNext(getGameBean().getGameState());
	}

}