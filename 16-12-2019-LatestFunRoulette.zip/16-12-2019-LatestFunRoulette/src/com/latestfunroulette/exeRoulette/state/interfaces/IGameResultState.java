package com.latestfunroulette.exeRoulette.state.interfaces;

public interface IGameResultState<G> extends IBaseState<G> {

}
