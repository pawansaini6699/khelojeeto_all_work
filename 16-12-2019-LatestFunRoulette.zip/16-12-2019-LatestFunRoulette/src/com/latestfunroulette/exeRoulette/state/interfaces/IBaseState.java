package com.latestfunroulette.exeRoulette.state.interfaces;

import com.latestfunroulette.exeRoulette.base.interfaces.IState;

public interface IBaseState<G> extends IState<G> {

	


}
