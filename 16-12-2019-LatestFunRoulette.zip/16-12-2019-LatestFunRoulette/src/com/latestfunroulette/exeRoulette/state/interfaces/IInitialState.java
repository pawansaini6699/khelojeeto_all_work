package com.latestfunroulette.exeRoulette.state.interfaces;

public interface IInitialState<G> extends IBaseState<G> {

}