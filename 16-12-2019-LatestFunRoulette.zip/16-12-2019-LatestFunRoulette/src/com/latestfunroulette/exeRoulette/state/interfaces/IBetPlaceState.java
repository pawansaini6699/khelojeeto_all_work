package com.latestfunroulette.exeRoulette.state.interfaces;

import com.smartfoxserver.v2.entities.User;

public interface IBetPlaceState<G> extends IBaseState<G> {

	
	void onCancelBet(String roomname,String userid, String session_id); 
	
	void onClearAll(String roomname,User user, String session_id);
	
	void onRebetRequest(String roomname, User user, String session_id);
	
	void betPlaceState(String userid, String session_id, int coins,
			int numbers);
	
	void userBetSave(String roomname,User user, String session_id);
	
	void userBetRemove(String roomname,String session_id,int betno,User user,double coins);
	

}
