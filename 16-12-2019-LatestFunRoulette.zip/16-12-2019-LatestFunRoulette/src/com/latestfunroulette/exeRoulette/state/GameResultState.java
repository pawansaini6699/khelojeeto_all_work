package com.latestfunroulette.exeRoulette.state;

import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.GameStateTime;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.base.interfaces.BaseState;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.exeRoulette.state.interfaces.IGameWaitingState;
import com.latestfunroulette.extension.GameMainExtension;

public class GameResultState extends BaseState implements IGameWaitingState<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,"SingleRouletteRoom:::::::::::::::::GameResultState" + g.getGameTurnTime());
		super.init(g, GameStateTime.GAME_RESULT_TIME);
		Utils.Logger(GameMainExtension.extension,"GameResultState :::: OnStart()");
		getEvents().sendLiveTime(this);

	}

	@Override
	public void onProcess() {
		Utils.Logger(GameMainExtension.extension,"GameResultState :::: onProcess()");
		Utils.Logger(GameMainExtension.extension,"GameResultState:::::::::getTimer().getElapsedTime()" + getTimer().getElapsedTime()
				);
		if (getTimer().getElapsedTime() > getStateTime()) {
			onExist();

		}
	}

	@Override
	public void onJoin(String pLoginId) {
		print("GameResultWaitingState :::: OnJoin()");
		getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);
		// TODO Auto-generated method stub

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {

		getTimer().resetTimer();
		getGameBean().setGameState(GameState.BETPLACESTATE);
		getGameMachine().onNext(getGameBean().getGameState());

	}

}
