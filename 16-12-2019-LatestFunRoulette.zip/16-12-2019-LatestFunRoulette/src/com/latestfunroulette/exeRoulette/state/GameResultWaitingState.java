package com.latestfunroulette.exeRoulette.state;

import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.GameStateTime;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.base.interfaces.BaseState;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.exeRoulette.state.interfaces.IGameWaitingState;
import com.latestfunroulette.extension.GameMainExtension;

public class GameResultWaitingState extends BaseState implements IGameWaitingState<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,"SingleRouletteRoom::::::::::::GameResultWaitingState :::: OnStart()");
		Utils.Logger(GameMainExtension.extension,"GameResultWaitingState" + g.getGameTurnTime());
		super.init(g, GameStateTime.GAME_WAIT_TIME);
		
	//	int time = (int) getTimer().getElapsedTime();
		
		   
	
		
		

	}

	@Override
	public void onProcess() {

		Utils.Logger(GameMainExtension.extension,"GameResultWaitingState :::: onProcess()");
		Utils.Logger(GameMainExtension.extension,"GameResultWaitingState:::::::::getTimer().getElapsedTime()" + getTimer().getElapsedTime()
				);

		if (getTimer().getElapsedTime() > getStateTime()) {
			getGameBean().setGameState(GameState.RESULT);
			onExist();
		}
		else if(getTimer().getElapsedTime()==52) {
			int time=(int)getTimer().getElapsedTime();
			getEvents().betinsertOnTime(this,time);
		
			 
			
		}

	}

	public void onJoin(String pLoginId) {
		print("GameResultWaitingState :::: OnJoin()");
		getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {
	
		getGameMachine().onNext(getGameBean().getGameState());

	}

}
