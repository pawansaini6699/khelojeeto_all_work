package com.latestfunroulette.exeRoulette.state;


import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.GameStateTime;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.base.baseclass.BasebetPlaceState;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.exeRoulette.state.interfaces.IBetPlaceState;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;

public class BetPlaceBetAmountState extends BasebetPlaceState implements IBetPlaceState<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,"SingleRouletteRoom::::::::::::::::::::::BetPlaceBetAmountState" + g.getGameTurnTime());
		print("BetPlaceBetAmountState :::: OnStart()");
		super.init(g, GameStateTime.BET_PLACE_TIME);
	//	int time = (int) getTimer().getElapsedTime();
		getTimer().resetTimer();
		getEvents().newSessionGenarate(this);
		

	}

	@Override
	public void onProcess() {

		Utils.Logger(GameMainExtension.extension,
				"BetPlaceBetAmountState:::::::::::::::getTimer().getElapsedTime() " + getTimer().getElapsedTime());

		if (getTimer().getElapsedTime() > getStateTime()) {
			Utils.Logger(GameMainExtension.extension,"onprocess:::::::::::::::game::::::::::: state"+GameState.RESULTWAIT);
			getGameBean().setGameState(GameState.RESULTWAIT);
			onExist();

		}else if(getTimer().getElapsedTime()== 48) {
			getEvents().betSaveOnTime(this);
		}
		

	}

	@Override
	public void onJoin(String pLoginId) {
		getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);

	}

	@Override
	public void playWaitingState() {

	}

	@Override
	public void gameResultState() {

	}

	@Override
	public void onExist() {
		Utils.Logger(GameMainExtension.extension,"state"+getGameBean().getGameState());
		getGameMachine().onNext(getGameBean().getGameState());

	}

	@Override
	public void betPlaceState(String userid, String session_id, int coins,
			int selectednumber) {

		Utils.Logger(GameMainExtension.extension,
				"BetPlaceBetAmountState:::::::::::::::betPlaceState :::: betPlaceState() :::: :::: user id ::: " + userid + ":::::::  session_id :::: ::" + session_id
						+ " coins :::::::: " + coins + " :::::selectednumbers :::::::: " + selectednumber);
		updateBetStatus(userid, session_id, coins, selectednumber);

	}

	@Override
	public void onCancelBet(String roomname,String userid, String session_id) {

		Utils.Logger(GameMainExtension.extension, "onCancelBet :::: onCancelBet() :::: roomname ::: " + roomname
				+ " ::::: user id ::: " + userid + ":::::::  session_id :::: ::" + session_id);

		cancelSpecificBet(userid, session_id);

	}

	@Override
	public void onClearAll(String roomname, User user, String session_id) {

		

		Utils.Logger(GameMainExtension.extension, "onClearAll :::: onClearAll() :::: roomname ::: " + roomname
				+ " ::::: user id ::: " + user.getName() + ":::::::  session_id :::: ::" + session_id);

		clearAllBetsRoulette(session_id,user,roomname);

	}

	@Override
	public void onRebetRequest(String roomname, User user, String session_id) {

		Utils.Logger(GameMainExtension.extension, "onRebetRequest :::: onRebetRequest() :::: roomname ::: " + roomname
				+ " ::::: user id ::: " + user.getName() + ":::::::  session_id :::: ::" + session_id);
		getEvents().onRebetRoulette(this, user, session_id);

	}

	@Override
	public void userBetSave(String roomname, User user, String session_id) {
		Utils.Logger(GameMainExtension.extension, "userBetSave :::: userBetSave() :::: roomname ::: " + roomname
				+ " ::::: user id ::: " + user.getName() + "sessionid :::: ::" + session_id);
	//	Room tempRoom = GameMainExtension.extension.getParentZone().getRoomByName(roomname);

		//List<User> tempUsers1 = tempRoom.getUserList();

		getEvents().betSave(this,user,session_id,roomname);
		
		onUserBetSave(roomname, user, session_id);

	}

	@Override
	public void userBetRemove(String roomname,String session_id, int betno,User user,double coins) {
		Utils.Logger(GameMainExtension.extension, "userBetSave :::: userBetSave() :::: roomname ::: " + roomname
				+":::::::  session_id :::: ::" + session_id +"betno::::::::"+betno +" ::::::  user  :::::  "+ user.getName());
		betRemoveUser(session_id, roomname, betno,user,coins);
		
	
		
	}

}
