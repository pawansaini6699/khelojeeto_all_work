package com.latestfunroulette.exeRoulette.cache.caching.interfaces;

public interface IGameBeanCache<K, V> extends IBaseCache<K, V> {

}