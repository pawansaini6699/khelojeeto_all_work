/**
 * 
 */
package com.latestfunroulette.exeRoulette.cache.caching.interfaces;

/**
 * @author nagjee
 *
 */
public interface IUserBetCache<K,V> extends IBaseCache<K, V> {

}
