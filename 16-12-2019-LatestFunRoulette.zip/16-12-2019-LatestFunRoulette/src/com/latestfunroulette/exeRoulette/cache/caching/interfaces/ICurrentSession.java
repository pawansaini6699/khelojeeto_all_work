/**
 * 
 */
package com.latestfunroulette.exeRoulette.cache.caching.interfaces;

/**
 * @author nagjee
 *
 */
public interface ICurrentSession<S> {

	void updateCurrentSession(S s);
	
	S getCurrentSession();
	
}
