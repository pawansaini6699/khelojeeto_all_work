/**
 * 
 */
package com.latestfunroulette.exeRoulette.cache.caching.interfaces;

/**
 * @author nagjee
 *
 */
public interface ISessionCache<K,V> extends IBaseCache<K, V> {

 void clearAllSession();	
 
 
	
}
