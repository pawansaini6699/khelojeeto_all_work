package com.latestfunroulette.exeRoulette.cache;


import com.latestfunroulette.exeRoulette.cache.beans.AvatarBean;
import com.latestfunroulette.exeRoulette.cache.beans.CurrentSessionBean;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.exeRoulette.cache.beans.SessionBean;
import com.latestfunroulette.exeRoulette.cache.caching.AvatarCache;
import com.latestfunroulette.exeRoulette.cache.caching.GameBeanCache;
import com.latestfunroulette.exeRoulette.cache.caching.SessionCache;
import com.latestfunroulette.exeRoulette.cache.caching.interfaces.IAvatarCache;
import com.latestfunroulette.exeRoulette.cache.caching.interfaces.ICurrentSession;
import com.latestfunroulette.exeRoulette.cache.caching.interfaces.IGameBeanCache;
import com.latestfunroulette.exeRoulette.cache.caching.interfaces.ISessionCache;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.cache.caching.PlayerCache;
import com.latestfunroulette.cache.caching.interfaces.IPlayerCache;

public class GameCacheExe {



		private volatile static IPlayerCache<String, Player> tempPlayerCache;
		private ISessionCache<String, SessionBean> tempSessionCache = null;

		
		private ICurrentSession<String> tempGameSession = null;
		private static IGameBeanCache<String, GameBean> tempGame;
		private static IAvatarCache<String, AvatarBean> tempAvatar;

		public GameCacheExe() {
			tempAvatar = new AvatarCache();
			tempPlayerCache = new PlayerCache();
			tempGame = new GameBeanCache();
			tempSessionCache = new SessionCache();
			tempGameSession = new CurrentSessionBean();
		
		}

		public ISessionCache<String, SessionBean> getGameSessionBySessionId() {
			return tempSessionCache;
		}

		

		public ICurrentSession<String> getSession() {
			return tempGameSession;
		}

		public IGameBeanCache<String, GameBean> getGames() {
			return tempGame;
		}

		public IAvatarCache<String, AvatarBean> getAvatar() {
			return tempAvatar;
		}

		public IPlayerCache<String, Player> getPlayer() {
			return tempPlayerCache;
		}
	
}
