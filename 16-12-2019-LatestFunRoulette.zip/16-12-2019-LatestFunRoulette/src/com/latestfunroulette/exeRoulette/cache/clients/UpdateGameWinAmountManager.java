package com.latestfunroulette.exeRoulette.cache.clients;

import java.lang.ref.WeakReference;
import java.util.List;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.base.interfaces.BaseState;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.exeRoulette.cache.beans.SessionBean;
import com.latestfunroulette.exeRoulette.cache.beans.UserBetBean;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class UpdateGameWinAmountManager {

	@SuppressWarnings("unused")
	private WeakReference<SFSExtension> ref_extension = null;

	public UpdateGameWinAmountManager(SFSExtension extension) {
		ref_extension = new WeakReference<SFSExtension>(extension);
	}

	public static void updateWinAmount(BaseState basestate, String pSession, String pWinnumber, Room roomname) {

		new Thread() {
			@Override
			public void run() {

				Utils.Logger(GameMainExtension.extension,
						"UpdateGameWinAmountManager" + "sessionid" + pSession + " winnnumber" + pWinnumber);

				GameBean gameBean = basestate.getGameBean();
				Player player = GameMainExtension.cache.getPlayer().getValueByKey(gameBean.getUserid());
				SessionBean tempSession = GameMainExtension.GameCacheexe.getGameSessionBySessionId()
						.getValueByKey(pSession);
				Room tempRoom = GameMainExtension.extension.getParentZone().getRoomByName(gameBean.getRoomName());

				int winamount = 0;
				if (tempSession != null) {

					List<UserBetBean> tempUserBetBeans = tempSession.getAllUserBets();

					for (int u = 0; u < tempUserBetBeans.size(); u++) {
						UserBetBean tempUser = tempUserBetBeans.get(u);
						//int gameId = tempUser.getGameId();

						if (tempUser != null && tempUser.isBetStatus()) {

							String winningnumber = (pWinnumber.equals("0") ? "00"
									: String.valueOf((Integer.parseInt(pWinnumber) - 1)));

							double tempWinnumberBetAmount = tempUser.getUserBetPlaceAmount()
									.getValueByKey(String.valueOf(winningnumber)).getBetAmount();

							winamount = ((int) Math.round((tempWinnumberBetAmount * 36)));

							gameBean.setWinner(String.valueOf(winamount));

							// BigDecimal tempBigDecimal = new BigDecimal((tempWinnumberBetAmount *36));
							String tempWinamount = String.valueOf(winamount);
							

							Utils.Logger(GameMainExtension.extension,
									"UpdateGameWinAmountManager::::::::" + "tempWinamount" + tempWinamount);

							int userexistStatus = 1;

							User tempSFSUser = tempRoom.getUserByName(tempUser.getUserId());
							

							if (tempSFSUser != null) {
								Utils.Logger(GameMainExtension.extension,
										"---------- UpdateUserCreditsbeforeTakeHandler----------userexistStatus "
												+ userexistStatus);

								userexistStatus = 0;
							}

							gameBean.setTotalsessionwinamount(String.valueOf(winamount));
							GameMainExtension.GameCacheexe.getGames().add(gameBean);
							// final int winamountuser=winamount;

							/*
							 * DBManager.updateUserWinAmountsql(tempUser.getUserId(), 1, tempWinamount,
							 * winningnumber, pSession, new CallBack() {
							 * 
							 * 
							 * 
							 * 
							 * @Override public void call(Object... callback) {
							 * 
							 * {
							 * 
							 * ISFSObject isfsObject = (ISFSObject) callback[0];
							 * 
							 * isfsObject.putUtfString(Param.WINAMOUNT, String.valueOf(winamountuser));
							 * Utils.Logger(GameMainExtension.extension,
							 * "---------- UpdateUserCreditsbeforeTakeHandler----------response " +
							 * isfsObject.getDump());
							 * GameMainExtension.extension.send(Events.UPDATEUSERCREDITS, isfsObject,
							 * tempSFSUser); }
							 * 
							 * } });
							 */

							DBManager.updateUserWinAmountmongo(tempUser.getUserId(), pSession, 1, winningnumber,
									tempWinamount, userexistStatus, player.getChips());

							Utils.Logger(GameMainExtension.extension,
									"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
							Utils.Logger(GameMainExtension.extension,
									"  :::: UpdateGameWinAmount :::: User Id :::: " + tempUser.getUserId()
											+ " :::: Win number :::: " + pWinnumber
											+ " :::  Win number bet amount :::: " + tempWinnumberBetAmount
											+ " :::: Win amount ::: " + tempWinamount );
							Utils.Logger(GameMainExtension.extension,
									"::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
						}
					}
					Utils.Logger(GameMainExtension.extension,
							"::::::::: UpdateGameWinAmount :::::::::::::totalsessionbetamount"
									+ tempSession.getTotalBetAmount() + ":::::::::::   winamount   ::::::::::::::::"
									+ winamount);
					//DBManager.updateLiveTimeData(tempSession.getTotalBetAmount(), String.valueOf(winamount));

				}
			}

		}.start();
	}
}