/**
 * 
 */
package com.latestfunroulette.exeRoulette.cache.beans;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.cache.caching.RouletteBetPlaceAmountCache;
import com.latestfunroulette.exeRoulette.cache.caching.interfaces.IRouletteBetPlaceAmountCache;
import com.latestfunroulette.extension.GameMainExtension;

public class UserBetBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userId;

	/* Bet Status :- Save : true and default : false */
	private boolean betStatus = false;
	private BigDecimal totalBetAmount1 = new BigDecimal(0.0);
	//private String totalBetAmount = "0";
	private List<RouletteBetBeans> tempRouletteBets = new ArrayList<RouletteBetBeans>();
	private IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> rouletteBetPlaceAmount = new RouletteBetPlaceAmountCache();

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
		addBetPlaces();
	}

	public boolean isBetStatus() {
		return betStatus;
	}

	public void setBetStatus(boolean betStatus) {
		this.betStatus = betStatus;
	}

	public String getTotalBetAmount() {
		return totalBetAmount1.toString();
	}

	public void setTotalBetAmount(String totalBetAmount) {
		this.totalBetAmount1 = new BigDecimal(totalBetAmount);
	}

	public List<RouletteBetBeans> getUserRouletteBets() {
		return tempRouletteBets;
	}

	public synchronized void addRouletteBet(int pBetAmount, String pBetNos, int pBetPlaceCount, double pBetSplitAmount,
			int pBetWinAmount) {
		// totalBetAmount = String.valueOf(Double.parseDouble(totalBetAmount) +
		// pBetAmount);
		totalBetAmount1 = totalBetAmount1.add(new BigDecimal(pBetAmount));
		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension,"totalBetAmount1:::::::::::::::::" + totalBetAmount1 + "betno" + pBetNos);

		RouletteBetBeans tempRouletteBet = new RouletteBetBeans();
		tempRouletteBet.setBetAmount(pBetAmount);
		tempRouletteBet.setBetNos(pBetNos);
		tempRouletteBet.setBetPlaceCount(pBetPlaceCount);
		tempRouletteBet.setSplitBetAmount(pBetSplitAmount);
		tempRouletteBet.setBetWinAmount(pBetWinAmount);
		// tempRouletteBet.setBetCommands(pCommand);
		tempRouletteBets.add(tempRouletteBet);
		// tempRouletteBetsdouble.add(tempRouletteBet);

		// Utils.Logger(GameMainExtension.extension,"addRouletteBet ::::::tempRouletteBet" +
		// tempRouletteBet.toString() + "totalBetAmount" + totalBetAmount1);
	}

	public synchronized void cancelSpecificRouletteBet() {

		Utils.Logger(GameMainExtension.extension,":::: user bet bean::::::::::::::::cancelSpecificRouletteBet :::::::totalBetAmount1::"+totalBetAmount1);
	
		Utils.Logger(GameMainExtension.extension,":::: user bet bean::::::::::::::::cancelSpecificRouletteBet :::::::total user remove amount::"+ tempRouletteBets.get((tempRouletteBets.size() - 1)).getBetAmount());
		
		totalBetAmount1 = totalBetAmount1.subtract((new BigDecimal
				((tempRouletteBets.get(tempRouletteBets.size() - 1)).getBetAmount())
				));

		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);
		
		Utils.Logger(GameMainExtension.extension,
				" UserBet BEan cancelSpecificRouletteBet()  totalBetAmount1 " +totalBetAmount1);
	
		
		
		if (totalBetAmount1.doubleValue() < 0)
			totalBetAmount1 = new BigDecimal(0.0);
	}

	// totalBetAmount = String.valueOf(Double.parseDouble(totalBetAmount)
	// - tempRouletteBets.get((tempRouletteBets.size() - 1)).getBetAmount());
	// tempRouletteBets.remove(tempRouletteBets.size() - 1);
	// Utils.Logger(GameMainExtension.extension,"Remove ::::::cancelSpecificRouletteBet:::::::::: userId
	// :::: " + userId + " totelbatamount "
	// + totalBetAmount + " :::::: totalbtamountsize ::::::: " +
	// tempRouletteBets.size());
	// }

	public RouletteBetBeans getCurrentRouletteBet() {
		return tempRouletteBets.get(tempRouletteBets.size() - 1);
	}

	public void cancelAllRouletteBet() {

		Utils.Logger(GameMainExtension.extension,
				" UserBet BEan cancelAllRouletteBet() tempRouletteBets  " + tempRouletteBets.toString());
		tempRouletteBets.clear();

	}

	public synchronized void cancelRandomBets(UserBetBean userBetBean, String betNo, String userid) {

		List<RouletteBetBeans> newlist = new ArrayList<RouletteBetBeans>();
		Utils.Logger(GameMainExtension.extension,"LIST" + tempRouletteBets + "size" + tempRouletteBets.size());

		Utils.Logger(GameMainExtension.extension,userBetBean.getUserId());
		if (userid.equalsIgnoreCase(userBetBean.getUserId()))
			// {
			newlist.addAll(tempRouletteBets);
		Utils.Logger(GameMainExtension.extension,"newlist" + newlist.toString());

		int count = 0;
		for (int i = 0; i <= newlist.size() - 1; i++) {

			Utils.Logger(GameMainExtension.extension,tempRouletteBets.get(count).getBetNos());

			if (tempRouletteBets.get(count).getBetNos().contains(betNo)) {

				tempRouletteBets.remove(count);
				Utils.Logger(GameMainExtension.extension,"true");
				Utils.Logger(GameMainExtension.extension,tempRouletteBets);
			} else {
				count++;
				Utils.Logger(GameMainExtension.extension,"false");
			}

		}
	}

	//////////////////////////////////////////////////////////////////////////

	public IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> getUserBetPlaceAmount() {
		return rouletteBetPlaceAmount;
	}

	private void addBetPlaces() {
		for (int bp = 0; bp < 38; bp++) {

			if (bp == 0) {
				RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
				tempRBP.setBetNo("00");
				rouletteBetPlaceAmount.add(tempRBP);

			} else {

				RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
				tempRBP.setBetNo(String.valueOf(bp - 1));
				rouletteBetPlaceAmount.add(tempRBP);
			}
		}
	}

	public synchronized void doubletotalBetAmount(double pBetAmount) { //
		// totalBetAmount = String.valueOf(Double.parseDouble(totalBetAmount) +
		// pBetAmount);

		totalBetAmount1 = totalBetAmount1.add(new BigDecimal(pBetAmount));
		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension,"totalBetAmount1:::::::::::::::::" + totalBetAmount1);

	}

	@Override
	public String toString() {
		return "UserBetBean [userId=" + userId + ", betStatus=" + betStatus + ", totalBetAmount1=" + totalBetAmount1
				+ ", tempRouletteBets=" + tempRouletteBets + ", rouletteBetPlaceAmount=" + rouletteBetPlaceAmount + "]";
	}

}