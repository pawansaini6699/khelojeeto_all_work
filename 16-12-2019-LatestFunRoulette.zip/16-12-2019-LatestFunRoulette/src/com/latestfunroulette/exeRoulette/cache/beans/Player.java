package com.latestfunroulette.exeRoulette.cache.beans;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.common.Constants.DefaultValue;
import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.LoginStatus;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.UserConnectionStatus;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;

public class Player implements Serializable {

	private static final long serialVersionUID = 1L;

	private String name;
	private String userid;
	private String socialId;
	private String userType;
	private String deviceId;
	private String deviceType;
	private String image;
	private String emailid = "";
	private String mobileno;
	private String password;
	private String chips = "0";
	private String ipaddress;
	private String username;
	private List<String> playerGameList;

	private HashMap<String, String> playerGameMap;

	private int connectionStatus = UserConnectionStatus.NONE;
	private int userBlockStatus = DefaultValue.INITIAL;
	private int loginStatus = LoginStatus.NONE;
	private int playerRank = 0;
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Player() {
	}

	public Player(ISFSObject params) {
		
		name = params.getUtfString(Param.NAME);
		// socialId = params.getUtfString(Param.SOCIAL_ID);
		userType = params.getUtfString(Param.USER_TYPE);
		deviceId = params.getUtfString(Param.DEVICE_ID);
		deviceType = params.getUtfString(Param.DEVICE_TYPE);
		image = params.getUtfString(Param.USER_IMAGE);
		emailid = params.getUtfString(Param.EMAILID);
		mobileno = params.getUtfString(Param.MOBILE_NO);
		password = params.getUtfString(Param.PASSWORD);
		// chips = params.getUtfString(Param.CHIPS);
		// gender = params.getUtfString(Param.GENDER);
		// nationality = params.getUtfString(Param.USER_NATIONALITY);
		// livingcountry = Param.STATIC_COUNTRY;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSocialId() {
		return socialId;
	}

	public void setSocialId(String socailId) {
		this.socialId = socailId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getChips() {
		return chips;
	}

	public void setChips(String chips) {
		this.chips = chips;
	}

	public String getIpaddress() {
		return ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public List<String> getPlayerGameList() {
		return playerGameList;
	}

	public void setPlayerGameList(List<String> playerGameList) {
		this.playerGameList = playerGameList;
	}

	public int getUserBlockStatus() {
		return userBlockStatus;
	}

	public void setUserBlockStatus(int userBlockStatus) {
		this.userBlockStatus = userBlockStatus;
	}

	public int getConnectionStatus() {
		return connectionStatus;
	}

	public void setConnectionStatus(int connectionStatus) {
		this.connectionStatus = connectionStatus;
	}

	public int getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(int loginStatus) {
		this.loginStatus = loginStatus;
	}

	public HashMap<String, String> getPlayerGameMap() {
		return playerGameMap;
	}

	public void setPlayerGameMap(HashMap<String, String> playerGameMap) {
		this.playerGameMap = playerGameMap;
	}

	public int getPlayerRank() {
		return playerRank;
	}

	public void setPlayerRank(int playerRank) {
		this.playerRank = playerRank;
	}

	public ISFSObject toSFS() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString(Param.NAME, name.equalsIgnoreCase("") ? "" : name);
		tempSFSObj.putUtfString(Param.USERID, userid.equalsIgnoreCase("") ? "" : userid);
		tempSFSObj.putUtfString(Param.USER_IMAGE, image.equalsIgnoreCase("") ? "" : image);
		tempSFSObj.putUtfString(Param.USER_TYPE, userType.equalsIgnoreCase("") ? "" : userType);
		tempSFSObj.putUtfString(Param.CHIPS, chips.equalsIgnoreCase("") ? "" : chips);
		tempSFSObj.putUtfString(Param.MOBILE_NO, mobileno.equalsIgnoreCase("") ? "" : mobileno);
		// tempSFSObj.putUtfString(Param.BOT_STATUS, String.valueOf(isBot()));
		tempSFSObj.putUtfString(Param.IS_USER_BLOCK, (userBlockStatus == 0 ? EnableStatus.FALSE : EnableStatus.TRUE));
		return tempSFSObj;
	}

	public ISFSObject toUpdateProfileSFS() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString(Param.NAME, name);
		tempSFSObj.putUtfString(Param.USERID, emailid);
		tempSFSObj.putUtfString(Param.USER_IMAGE, image);
		tempSFSObj.putUtfString(Param.CHIPS, chips);
		tempSFSObj.putUtfString(Param.MOBILE_NO, mobileno);
		tempSFSObj.putUtfString(Param.IS_USER_BLOCK, (userBlockStatus == 0 ? EnableStatus.FALSE : EnableStatus.TRUE));
		return tempSFSObj;
	}

	public ISFSObject toProfileSFS() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString(Param.NAME, name);
		tempSFSObj.putUtfString(Param.USERID, userid);
		tempSFSObj.putUtfString(Param.USER_IMAGE, image);
		tempSFSObj.putUtfString(Param.CHIPS, chips);
		tempSFSObj.putUtfString(Param.MOBILE_NO, mobileno);
		tempSFSObj.putUtfString(Param.USER_TYPE, userType);

		if (userType.equalsIgnoreCase(Param.CUSTOM)) {
			tempSFSObj.putUtfString(Param.USERID, emailid);
			if (password != null) {
				if (!password.isEmpty()) {
					tempSFSObj.putUtfString(Param.PASSWORD, password);
				}
			} else {
				tempSFSObj.putNull(Param.PASSWORD);
			}

			tempSFSObj.putNull(Param.SOCIAL_ID);
		} else if (userType.equalsIgnoreCase(Param.FACEBOOK) || userType.equalsIgnoreCase(Param.GOOGLE)) {
			tempSFSObj.putUtfString(Param.SOCIAL_ID, socialId);
			tempSFSObj.putUtfString(Param.USERID, emailid);
			tempSFSObj.putNull(Param.PASSWORD);
		}

		// tempSFSObj.putUtfString (Param.LEVEL, level) ;
		// tempSFSObj.putUtfString(Param.LEVEL, levelcount);
		// tempSFSObj.putUtfString(Param.LEVEL_COUNT, levelcount);
		// tempSFSObj.putUtfString(Param.TOTAL_GAME, totalgames);
		// tempSFSObj.putUtfString(Param.KING, king);
		// tempSFSObj.putUtfString(Param.KOUZ, kouz);
		/*
		 * tempSFSObj.putUtfString(Param.DASH_CALL, dashcall);
		 * tempSFSObj.putUtfString(Param.EIGHT_CALL, eightcall);
		 */
		// tempSFSObj.putUtfString(Param.KING_PERCENT,
		// Utils.kingKouzPercent(Integer.parseInt(king), Integer.parseInt(totalgames)));
		// tempSFSObj.putUtfString(Param.KOUZ_PERCENT,Utils.kingKouzPercent(Integer.parseInt(kouz),
		// Integer.parseInt(totalgames)));
		return tempSFSObj;
	}

	@Override
	public String toString() {
		return "Player [name=" + name + ", userid=" + userid + ", socialId=" + socialId + ", userType=" + userType
				+ ", deviceId=" + deviceId + ", deviceType=" + deviceType + ", image=" + image + ", emailid=" + emailid
				+ ", mobileno=" + mobileno + ", password=" + password + ", chips=" + chips + ", ipaddress=" + ipaddress
				+ ", username=" + username + ", playerGameList=" + playerGameList + ", playerGameMap=" + playerGameMap
				+ ", connectionStatus=" + connectionStatus + ", userBlockStatus=" + userBlockStatus + ", loginStatus="
				+ loginStatus + ", playerRank=" + playerRank + ", user=" + user + ", reconnectStatus=" + reconnectStatus
				+ "]";
	}

	public ISFSObject updateChips() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString(Param.USERID, userid);
		tempSFSObj.putUtfString(Param.USER_TYPE, userType);
		tempSFSObj.putUtfString(Param.CHIPS, chips);
		return tempSFSObj;
	}

	private String reconnectStatus = "NONE";

	public void setReconnectStatus(String reconnectStatus) {
		this.reconnectStatus = reconnectStatus;

	}

	public String getReconnectStatus() {

		return reconnectStatus;
	}
}