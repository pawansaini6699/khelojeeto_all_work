package com.latestfunroulette.exeRoulette.cache.beans;

import java.io.Serializable;

import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;

/**
 * 
 * @author Ubuntu Avatars image bean
 */
public class AvatarBean implements Serializable, Cloneable {

	private static final long serialVersionUID = -4791714777871957499L;

	private String avatarid;
	private String avatar_url;
	private boolean enable;

	@Override
	protected AvatarBean clone() throws CloneNotSupportedException {
		AvatarBean tempAvatarBean = null;
		try {
			tempAvatarBean = (AvatarBean) super.clone();
		} catch (CloneNotSupportedException e) {
			Utils.ErrorLogger(GameMainExtension.extension, "Avatar Bean CloneNotSupport Exception = ", e);
		}
		return tempAvatarBean;
	}

	public String getAvatarid() {
		return avatarid;
	}

	public void setAvatarid(String avatarid) {
		this.avatarid = avatarid;
	}

	public String getAvatar_url() {
		return avatar_url;
	}

	public void setAvatar_url(String avatar_url) {
		this.avatar_url = avatar_url;
	}

	public boolean isEnable() {
		return enable;
	}

	public void setEnable(boolean enable) {
		this.enable = enable;
	}

	public ISFSObject toSFSObj() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString(Param.AVATAR_ID, avatarid);
		tempSFSObj.putUtfString(Param.AVATAR_URL, avatar_url);
		return tempSFSObj;
	}
}