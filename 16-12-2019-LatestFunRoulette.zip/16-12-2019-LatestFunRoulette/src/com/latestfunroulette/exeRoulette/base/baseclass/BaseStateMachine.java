package com.latestfunroulette.exeRoulette.base.baseclass;

import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.exeRoulette.base.interfaces.IState;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.exeRoulette.machine.interfaces.IStateMachine;
import com.latestfunroulette.common.RTimer;

public abstract class BaseStateMachine<G> implements IStateMachine<G> {

	private G g;
	private boolean machineStatus = false;
	private String stateName = GameState.INITIAL;
	private IState<GameBean> currentState = null;
	public RTimer timer = null;
	
	// private Deck cardDeck = null;

	protected void setGameBean(G g) {
		this.g = g;
		
			//timer = new RTimer();
		    
		
	}

	public G getGameBean() {
		return g;
	}

	/*
	 * public Deck getDeck() { return cardDeck; }
	 */

	protected void setCurrentState(String pState) {
		this.stateName = pState;
		currentState = getState(pState);
	}

	public IState<GameBean> getCurrentState() {
		return this.currentState;
	}

	public String getStateName() {
		return this.stateName;
	}

	protected void setMachineStatus(boolean pStatus) {
		this.machineStatus = pStatus;
	}

	public boolean getMachinState() {
		return this.machineStatus;
	}

	public RTimer getTimers() {
		return timer;
	}
	
	

}