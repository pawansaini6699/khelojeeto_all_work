package com.latestfunroulette.exeRoulette.common.interfaces;

public interface IGloblaId {

	void updateId();

	int getCurrentId();

	int getNextId();

	String getNextId(String f);
}