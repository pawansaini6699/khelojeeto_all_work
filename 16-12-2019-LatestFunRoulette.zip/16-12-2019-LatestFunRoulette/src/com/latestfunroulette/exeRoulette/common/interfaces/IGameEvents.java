package com.latestfunroulette.exeRoulette.common.interfaces;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.base.interfaces.BaseState;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;

public interface IGameEvents {

	void sendLiveTime(BaseState pState);

	void sendPlayerWaiting(BaseState pState);

	void sendbetPlace(BaseState pState, int time);

	void clearBet(BaseState pState, double betAmount,User user);

	void onRebetRoulette(BaseState pState,User user, String session_id);

	//void gameResultWaitingState(BaseState pState);

	void gameResultState(BaseState pState);

	void sendOnlineLobbyEvent(BaseState pstState, String loginid);
	
	void currentSystemTmer(int time);
	
	void specificClearBet(BaseState pstState,String betamount,String userid);

	
	public void newSessionGenarate(BaseState baseState);
	
	void betSave(BaseState baseState,User user,String session_id,String roomname);
	
	void betRemoveUser(BaseState baseState,String session_id,String roomname,int betno,User user,double coins);
	
	public void betinsertOnTime(BaseState baseState, int currenttime);
	
	public void onJoinSendUserData(BaseState baseState,String loginId);
	
	public void onLeaveUserRoom(BaseState baseState,String loginin);
	
	void betSaveOnTime(BaseState baseState); 

	default void print(String msg) {
		Utils.Logger(GameMainExtension.extension, "GameEvents :::: " + msg);
	}

}