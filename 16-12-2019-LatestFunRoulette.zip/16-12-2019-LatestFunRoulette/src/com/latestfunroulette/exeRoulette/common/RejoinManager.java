package com.latestfunroulette.exeRoulette.common;

import com.latestfunroulette.cache.beans.Player;
import com.smartfoxserver.v2.entities.User;

public class RejoinManager {

	public void rejoin(User pUser, Player tempPlayer) {

	
		
	}
}