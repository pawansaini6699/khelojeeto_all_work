package com.latestfunroulette.exeRoulette.common;


import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.StaticRooms;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.exeRoulette.common.interfaces.IGameEventManager;
import com.latestfunroulette.exeRoulette.state.interfaces.IBetPlaceState;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;

public class GameEventMangaer implements IGameEventManager {

	@Override
	public void onPlayerLeave(User pUser, ISFSObject params, CallBack pCallBack) {
		Utils.Logger(GameMainExtension.extension, " onPlayerLeave() :::: Request :::: User :::: " + pUser.getName()
				+ " :::::: Params :::: " + params.getDump());
		String roomName = params.getUtfString(Param.ROOMNAME);
		getGameMachine(roomName).onLeave(pUser.getName());
		pCallBack.call(roomName);
	}

	@Override
	public void onLiveBet(User pUser, ISFSObject params, CallBack pCallBack) {

		Utils.Logger(GameMainExtension.extension, " onLiveBet() :::: Request :::: User :::: " + pUser.getName()
				+ " :::::: Params :::: " + params.getDump() + "::::pUser " + pUser.getName());
		String roomName = params.getUtfString(Param.ROOMNAME);
		String user_id = params.getUtfString(Param.USERID);
		String session_id = params.getUtfString(Param.SESSIONID);

		int coins = params.getInt(Param.COINS);
		//String command = params.getUtfString(Params.COMMANDNAME);
		int numbers = params.getInt(Param.ID);

	
	
		
		Utils.Logger(GameMainExtension.extension,
				"ROOMNAME::::::::" + roomName + "  userid " + user_id + "sessionid::::::" + session_id
						+ "  coins :::::::::  " + coins +  "numbers"
						+ numbers);
		
		
		
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(StaticRooms.SINGLE_ROULETTE_ROOM);

		Utils.Logger(GameMainExtension.extension, " tempstate::::: " + tempState);

		tempState.betPlaceState(user_id, session_id,coins,numbers);

	}

	@Override
	public void onCancelSpecificBet(User pUser, ISFSObject params, CallBack pCallBack) {

		Utils.Logger(GameMainExtension.extension, " onCancelSpecificBet() :::: Request :::: User :::: "
				+ pUser.getName() + " :::::: Params ::::" + params.getDump());
		
		String roomName = params.getUtfString(Param.ROOMNAME);
		String user_id = params.getUtfString(Param.USERID);
		String session_id = params.getUtfString(Param.SESSIONID);
		
		Utils.Logger(GameMainExtension.extension, "onCancelSpecificBet::::::::::::userid"+user_id);
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.onCancelBet(roomName, user_id, session_id);

	}

	@Override
	public void onClearAllBet(User pUser, ISFSObject params, CallBack pCallBack) {
		Utils.Logger(GameMainExtension.extension, " onClearAllBet() :::: Request :::: User :::: " + pUser.getName()
				+ " :::::: Params ::::" + params.getDump());
		String roomName = params.getUtfString(Param.ROOMNAME);
		String user_id = params.getUtfString(Param.USERID);
		String session_id = params.getUtfString(Param.SESSIONID);

		Utils.Logger(GameMainExtension.extension, "SingleRouletteGame:::::::::::::::::::::::::::::onClearAllBet::::::::::::userid"+user_id);
		
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.onClearAll(roomName,pUser, session_id);
	}

	@Override
	public void onRebet(User pUser, ISFSObject params, CallBack pCallBack) {

		String roomName = params.getUtfString(Param.ROOMNAME);
		String user_id = params.getUtfString(Param.USERID);
		String session_id = params.getUtfString(Param.SESSIONID);

		Utils.Logger(GameMainExtension.extension, "GameEventManager:::::::::::::::::onRebet::::::::userid"+user_id);
		
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.onRebetRequest(roomName,pUser, session_id);

	}

	@Override
	public void onGetWinningNumber(User pUser, ISFSObject params, CallBack pCallBack) {

		// String roomName = params.getUtfString(Params.ROOMNAME);

		// IGameWaitingState<GameBean> iGameWaitingState = (IGameWaitingState<GameBean>)
		// getCurrentState(roomName);

		// iGameWaitingState.onGetWinNumber(roomName);

	}

	@Override
	public void onBetOK(User pUser, ISFSObject params, CallBack pCallBack) {

		String sessionId = params.getUtfString(Param.SESSIONID);
		String userId = params.getUtfString(Param.USERID);
		String roomName = params.getUtfString(Param.ROOMNAME);
		Utils.Logger(GameMainExtension.extension, "GameEventManager:::::::::::::::onBetOk::::::userid"+userId);
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.userBetSave(roomName, pUser, sessionId);

	}

	@Override
	public void onRemoveBetCustomise(User pUser, ISFSObject params, CallBack pCallBack) {
		String roomName = params.getUtfString(Param.ROOMNAME);
		//String userId = params.getUtfString(Param.USERID);
		String sessionId = params.getUtfString(Param.SESSIONID);
		int id = params.getInt(Param.ID);
		double coins=params.getDouble(Param.COINS);
		
		
		IBetPlaceState<GameBean> tempState = (IBetPlaceState<GameBean>) getCurrentState(roomName);
		tempState.userBetRemove(roomName, sessionId,id,pUser,coins);

		
	}

}