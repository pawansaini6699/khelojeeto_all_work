package com.latestfunroulette.exeRoulette.common;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Events;
import com.latestfunroulette.common.Constants.GameStateTime;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.base.interfaces.BaseState;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.exeRoulette.cache.beans.RouletteBetBeans;
import com.latestfunroulette.exeRoulette.cache.beans.SessionBean;
import com.latestfunroulette.exeRoulette.cache.beans.UserBetBean;
import com.latestfunroulette.exeRoulette.cache.caching.interfaces.ISessionCache;
import com.latestfunroulette.exeRoulette.cache.clients.UpdateGameWinAmountManager;
import com.latestfunroulette.exeRoulette.common.interfaces.IGameEvents;
import com.latestfunroulette.extension.GameMainExtension;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class GameEvents implements IGameEvents {

	private WeakReference<SFSExtension> ref_extension = null;
	List<SessionBean> ls = null;

	public GameEvents(SFSExtension pExtension) {
		ref_extension = new WeakReference<SFSExtension>(pExtension);

	}

	@Override
	public void sendPlayerWaiting(BaseState pState) {

	}

	@Override
	public void sendbetPlace(BaseState pState, int count) {

	}

	@Override
	public void clearBet(BaseState pState, double pbetamount, User user) {

		try {
			GameBean tempGameBean = pState.getGameBean();

			int iBetAmount = (int) Math.round((pbetamount));

			ISFSObject isfsObject = new SFSObject();
			isfsObject.putUtfString(Param.ROOM_NAME, tempGameBean.getRoomName());
			isfsObject.putUtfString(Param.MESSAGE, "Live Bets clear Successfully!!");
			isfsObject.putUtfString(Param.BETAMOUNT, String.valueOf(iBetAmount));
			isfsObject.putUtfString(Param.STATE, pState.getGameBean().getGameState());
			isfsObject.putUtfString(Param.STATUS, "true");

			tempGameBean.setRoomName(tempGameBean.getRoomName());
			GameMainExtension.GameCacheexe.getGames().add(tempGameBean);

			Utils.Logger(GameMainExtension.extension, "tempsfsobj" + isfsObject.getDump());
			ref_extension.get().send(Events.CLEARALL, isfsObject, user);

		} catch (Exception e) {
			Utils.ErrorLogger(ref_extension.get(), "GameEvents ::: clearBet() :: ERROR :: ", e);
		}

	}

	@Override
	public void gameResultState(BaseState pState) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sendLiveTime(BaseState pState) {

		try {

			String updatedsessionid = String.valueOf(GameMainExtension.globlaId.getNextId());

			GameBean gameBean = pState.getGameBean();

			Utils.Logger(GameMainExtension.extension,
					"GameEvents:::::::::::::::::sendLiveTime ::::::::::::gmaebean" + gameBean.toString());

			int currentsessionid = Integer.parseInt(updatedsessionid);
			Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

		
			int wheelno = getWinminnumber();

			DBManager.UpdateLiveTimePlay(currentsessionid, wheelno, new CallBack() {

				@Override
				public void call(Object... call) {

					int oldsessionid = (int) call[0];

					String psessionId = String.valueOf(oldsessionid);
					String pwheelno = String.valueOf(wheelno);
					Utils.Logger(GameMainExtension.extension,
							"GameEvents::::::::sendLiveTime:::::::::" + "gloabalid:::  " + oldsessionid
									+ "sessionid ::::::: " + psessionId + "wheelno " + pwheelno);

					UpdateGameWinAmountManager.updateWinAmount(pState, psessionId, pwheelno, tempRoom);

				}
			});

			//

		} catch (Exception e) {
			Utils.ErrorLogger(ref_extension.get(), "GameEvents ::: sendLiveTime() :: ERROR :: ", e);
		}
	}

	@Override
	public void onRebetRoulette(BaseState pState, User user, String session_id) {

		GameBean tempGameBean = pState.getGameBean();
		ISFSObject isfsObject = new SFSObject();

		String oldsessionid = tempGameBean.getSession_id();

		SessionBean tempSession = GameMainExtension.GameCacheexe.getGameSessionBySessionId().getValueByKey(session_id);

		SessionBean oldtempSession = GameMainExtension.GameCacheexe.getGameSessionBySessionId()
				.getValueByKey(oldsessionid);

		UserBetBean tempolduserbetbean = oldtempSession.getUserBetBeanByUserId(user.getName());

		tempolduserbetbean.setBetStatus(false);

		List<RouletteBetBeans> listroulette = tempolduserbetbean.getUserRouletteBets();

		Utils.Logger(GameMainExtension.extension,
				":::::::::::::   GameEvents  ::::::::::::::::::onRebetRoulette::::::: list size  ::::::"
						+ listroulette.size());

		// IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> //

		double totalbetamount = 0.0, totalwinamount = 0.0;

		for (int i = 0; i <= listroulette.size() - 1; i++) {

			totalbetamount = totalbetamount + (listroulette.get(i).getBetAmount());
			totalwinamount = totalwinamount + (listroulette.get(i).getBetWinAmount()); //
			totalwinamount += listroulette.get(i).getBetWinAmount();

			Utils.Logger(GameMainExtension.extension, "totalbetamount" + totalbetamount);
			Utils.Logger(GameMainExtension.extension, "totalwinamount" + totalwinamount);

			tempSession.addUserBet(tempolduserbetbean.getUserId(), session_id, (int) listroulette.get(i).getBetAmount(),

					listroulette.get(i).getBetNos(), listroulette.get(i).getBetPlaceCount(),
					listroulette.get(i).getSplitBetAmount(), (int) listroulette.get(i).getBetWinAmount());

		}

		GameMainExtension.GameCacheexe.getGameSessionBySessionId().add(tempSession);
		Utils.Logger(GameMainExtension.extension, "tempSession" + tempSession.toString());

		Utils.Logger(GameMainExtension.extension, "onRebetRoulette::::::::::::::::::::::::::::::::::::::::::"
				+ "getbetamount " + tempolduserbetbean.getTotalBetAmount());

		isfsObject.putUtfString(Param.MESSAGE, "Rebet success");
		isfsObject.putUtfString(Param.STATUS, "true");

		Utils.Logger(GameMainExtension.extension,
				"GameEvents::::::::::::::::::onRebetRoulette::::::::Response:::::::isfsobject " + isfsObject.getDump());

		ref_extension.get().send(Events.REBET_NUMBERS, isfsObject, user);

	}

	public void sendOnlineLobbyEvent(BaseState pState, String loginid) {

		Utils.Logger(GameMainExtension.extension, "User:::::name:::::::loginid" + loginid);

		GameBean gameBean = pState.getGameBean();

		DBManager.userStatus(loginid, new CallBack() {

			@Override
			public void call(Object... callback) {

				ISFSObject tempSFSObj = (ISFSObject) callback[0];

				Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

				List<User> tempUsers = tempRoom.getUserList();
				int onlineplayerscount = tempUsers.size();

				Utils.Logger(ref_extension.get(),
						"game bean room name" + gameBean.getRoomName() + " gamebean time  " + gameBean.getTime()
								+ " fivewinning number " + gameBean.getLastfivenumber() + "winning number :::::: "
								+ gameBean.getWinningnumber());

				tempSFSObj.putUtfString(Param.ROOM_NAME, gameBean.getRoomName());
				tempSFSObj.putUtfString(Param.ONLINE_PLAYER_COUNT, String.valueOf(onlineplayerscount));
				tempSFSObj.putUtfString(Param.TIMER, gameBean.getTime());
				tempSFSObj.putUtfString(Param.LASTFIVENUMBER, gameBean.getLastfivenumber());
				tempSFSObj.putUtfString(Param.WINNINGNUMBER, gameBean.getWinningnumber());
				tempSFSObj.putUtfString(Param.STATE, pState.getGameBean().getGameState());

				Utils.Logger(GameMainExtension.extension,
						"CommonEvents::::::::::::::::::sendOnlineLobbyEvent::::::::Response:::::::isfsobject "
								+ tempSFSObj.getDump());

				ref_extension.get().send(Events.SINGLE_ROULETTE_LOBBY_REQUEST, tempSFSObj, tempUsers);

			}
		});

	}

	public int getWinminnumber() {

		int wheel = DBManager.winningNumber();

		return wheel;

	}

	@Override
	public void betinsertOnTime(BaseState baseState, int currenttime) {

		try {

			String roomname = baseState.getGameBean().getRoomName();
			String userid = baseState.getGameBean().getUserid();
			String credits = baseState.getGameBean().getCredits();

			Utils.Logger(GameMainExtension.extension, "roomname" + roomname + "gmaebean:::::::::::::::" + baseState);

			Utils.Logger(GameMainExtension.extension, "betinsertOnTime ::: currenttime" + currenttime);

			DBManager.sendSessionIdOfRullete(userid, new CallBack() {

				@Override
				public void call(Object... callback) {
					String session_id = (String) callback[0];

					Utils.Logger(GameMainExtension.extension,
							"GameEvents :::: betinsertOnTime :::: Session Id :::: " + session_id);
					SessionBean tempSessionBean = GameMainExtension.GameCacheexe.getGameSessionBySessionId()
							.getValueByKey(session_id);

					if (tempSessionBean != null) {
						List<UserBetBean> tempUsers = tempSessionBean.getAllUserBets();
						int userSize = tempUsers.size();

						Utils.Logger(GameMainExtension.extension,
								"GameEvents :::::betinsertOnTime::::::: before User size :::: " + userSize);

						try {

							for (int u = 0; u < userSize; u++) {
								UserBetBean tempUserBetBean = tempUsers.get(u);
								if (tempUserBetBean != null && !tempUserBetBean.isBetStatus()) {
									tempSessionBean.cancelAllRouletteBet(tempUserBetBean.getUserId());
									--u;
									--userSize;
								}
							}

						} catch (Exception e) {
							Utils.ErrorLogger(GameMainExtension.extension,
									"GameEvents :::::betinsertOnTime::::::: :::: Remove Loop Error :::: ", e);
						}

						try {
							tempUsers = tempSessionBean.getAllUserBets();
							userSize = tempUsers.size();

						} catch (Exception e) {
							Utils.ErrorLogger(GameMainExtension.extension,
									"GameEvents :::::betinsertOnTime::::::: ::::: Upload data on loop server error ::::: ",
									e);
						}

						Utils.Logger(GameMainExtension.extension,
								"GameEvents :::::betinsertOnTime::::::: ::::: after User size :::: " + userSize);

						try {

							for (int u = 0; u < userSize; u++) {
								UserBetBean tempUserBetBean = tempUsers.get(u);
								if (tempUserBetBean != null && tempUserBetBean.isBetStatus()) {

									try {

										String userid = tempUserBetBean.getUserId();
										Utils.Logger(GameMainExtension.extension,
												"GameEvents :::::betinsertOnTime::::::: ::::: Update live_update_roulette_history user id :::: "
														+ userid);
										Utils.Logger(GameMainExtension.extension,
												"GameEvents :::::betinsertOnTime::::::: :::: User Id :::: " + userid
														+ " :::: Session Id ::: " + session_id
														+ " :::: Total Bet Amount :::  "
														+ tempUserBetBean.getTotalBetAmount());

										DBManager.insertLiveRouletteBetsExe(session_id, tempUserBetBean);

										DBManager.insertrouletteDataMongoexe(session_id, tempUserBetBean, credits);

										// Accessing the database

									} catch (Exception e) {
										Utils.ErrorLogger(GameMainExtension.extension,
												"GameEvents :::::betinsertOnTime::::::: ::::: Upload data insertLiveRouletteBets in loop server error ::::: ",
												e);
									}

								}
							}

						} catch (Exception e) {
							Utils.ErrorLogger(GameMainExtension.extension,
									"SendServerLiveTimer ::::: Upload data on loop server error ::::: ", e);
						}

					}
				}
			});

		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension, "SendServerLivetimer :::: Error ::::: ", e);
		}
	}

	@Override
	public void newSessionGenarate(BaseState basestate) {

		Utils.Logger(GameMainExtension.extension,
				"SingleROulette::::::::::::GameEvents:::::::::::::basestate" + basestate.toString());

		GameBean gameBean = basestate.getGameBean();
		String roomname = gameBean.getRoomName();
		String userid = gameBean.getUserid();
		// String sessionid=gameBean.getSession_id();

		String currenttime = String.valueOf(basestate.getTimer().getElapsedTime());

		int time = 60 - (Integer.parseInt(currenttime));

		Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());
		List<User> tempUsers = tempRoom.getUserList();
		int onlineplayerscount = tempUsers.size();

		// int gameTypeId = 1;

		new Thread() {
			@Override
			public void run() {
				try {

					DBManager.sendSessionIdOfRullete(userid, new CallBack() {

						@Override
						public void call(Object... callback) {
							String session_id = (String) callback[0];
							String status = (String) callback[1];
							String resultwheel = (String) callback[2];
							String credits = (String) callback[3];
							String lastfivewinningnumber = (String) callback[4];
							String oldSessionId = (String) callback[5];
							String usercurrentwinamount = (String) callback[6];

							Utils.Logger(GameMainExtension.extension,
									"newSessionGenarate:::::::::::::oldSessionId" + oldSessionId
											+ "userwinamount::::::::::::" + usercurrentwinamount + "credits" + credits);

							ISFSObject isfsObject = new SFSObject();
							isfsObject.putUtfString(Param.SESSION_ID, session_id);
							isfsObject.putUtfString(Param.WINNINGNUMBER, resultwheel);
							isfsObject.putInt(Param.TIMER, time);
							isfsObject.putUtfString(Param.STATE, basestate.getGameBean().getGameState());
							isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
							isfsObject.putInt(Param.ONLINE_PLAYER_COUNT, onlineplayerscount);
							isfsObject.putUtfString(Param.ROOM_NAME, roomname);
							isfsObject.putUtfString(Param.STATUS, status);
							isfsObject.putInt(Param.BETPLACETIME, GameStateTime.BET_PLACE_TIME);
							isfsObject.putUtfString(Param.WINAMOUNT, usercurrentwinamount);

							Utils.Logger(GameMainExtension.extension,
									"SingleRoulette::::::::::::::::::::::GameEvents:::::::::::::::::newSessionGenarate::::::::::isfsObject:::::"
											+ isfsObject.getDump());

							ref_extension.get().send(Request.NEWSESSIONGENERATE, isfsObject, tempUsers);

							// String new_session_id1 = randomString(40);

							// GameMainExtension.cache.getSession().updateCurrentSession(session_id);

							print("RouletteGameExtension ::::51 New Session ::::: " + session_id);

							// tempsessionbean.setSessionId(session_id);

							SessionBean tempsessionbean1 = new SessionBean();

							gameBean.setSession_id(oldSessionId);
							GameMainExtension.GameCacheexe.getGames().add(gameBean);

							tempsessionbean1.setSessionId(session_id);

							// Utils.Logger(GameMainExtension.extension,
							// "RouletteGameExtension ::::51 New Session ::::: " +
							// tempsessionbean.toString());

							ISessionCache<String, SessionBean> tempSessionCache = GameMainExtension.GameCacheexe
									.getGameSessionBySessionId();

							if (tempSessionCache == null) {
								Utils.Logger(GameMainExtension.extension,
										"RouletteGameExtension :::: Session Cache is null");
							} else {
								Utils.Logger(GameMainExtension.extension,
										"RouletteGameExtension :::: Session Cache is not null");
								// tempSessionCache.clearAllSession();

								tempSessionCache.add(tempsessionbean1);

								Set<String> set = tempSessionCache.getAll().keySet();

								for (String s : new ArrayList<String>(set)) {

									String url = s;

									if (url.equalsIgnoreCase(session_id)) {
										Utils.Logger(GameMainExtension.extension, " Value = " + url);
									} else if (url.equalsIgnoreCase(oldSessionId)) {

										Utils.Logger(GameMainExtension.extension, " Value = " + url);
									} else {
										tempSessionCache.delete(s);
									}

								}

								/*
								 * Set<String> s1 = tempSessionCache.getAll().keySet(); for(String stock : s1){
								 * Utils.Logger(GameMainExtension.extension,stock); }
								 */

							}

							// print("RouletteGameExtension ::::51 New Session ::::tempsessionbean: "
							// + tempsessionbean1.toString());

							// print("RouletteGameExtension ::::51 ::::SessionBeancahing: " +
							// tempsessionbean1.toString());

						}
					});
				} catch (Exception e) {
					Utils.ErrorLogger(GameMainExtension.extension, "newSessionGenarate RunMethod :::::: Error :::: ",
							e);
				}

			}
		}.start();
	}

	@Override
	public void onJoinSendUserData(BaseState baseState, String loginId) {

		GameBean gameBean = baseState.getGameBean();
		gameBean.setUserid(loginId);

		Utils.Logger(GameMainExtension.extension, "gamebean" + gameBean.toString());

		String roomname = gameBean.getRoomName();

		Utils.Logger(GameMainExtension.extension, "User:::::name:::::::" + loginId + " roomname::::::::" + roomname);

		new Thread() {
			public void run() {

				DBManager.getLastFiveNumber(loginId, new CallBack() {

					@Override
					public void call(Object... callback) {

						Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

						String currenttime = String.valueOf(baseState.getTimer().getElapsedTime());

						int time = (60 - Integer.parseInt(currenttime));
						// GameBean gameBean =
						// GameMainExtension.cache.getGames().getValueByKey(tempRoom.getName());
						// GameBean gameBean =
						// GameMainExtension.cache.getGames().getValueByKey(loginuser);

						Utils.Logger(GameMainExtension.extension,
								"sendSingleRouletteLobbyEvent::::::::::gamebean" + gameBean.toString());
						// Player tempPlayer =
						// GameMainExtension.cache.getPlayer().getValueByKey(loginId);
						ISFSObject isfsObject = (ISFSObject) callback[0];
						Utils.Logger(GameMainExtension.extension, "ROOM NAME" + tempRoom.getName());
						List<User> tempUsers = tempRoom.getUserList();
						int onlineplayerscount = tempUsers.size();

						isfsObject.putUtfString(Param.ONLINE_PLAYER_COUNT, String.valueOf(onlineplayerscount));
						isfsObject.putUtfString(Param.ROOM_NAME, "SINGLE_ROULETTE_ROOM");

						// isfsObject.putUtfString(Param.TIMER, String.valueOf(time));
						isfsObject.putUtfString(Param.TIMER, String.valueOf(time));
						isfsObject.putUtfString(Param.STATE, baseState.getGameBean().getGameState());

						Utils.Logger(GameMainExtension.extension,
								"CommonEvents::::::::::::::::::sendSingleRouletteLobbyEvent::::::::Response:::::::isfsobject "
										+ isfsObject.getDump());

						ref_extension.get().send(Events.SINGLE_ROULETTE_LOBBY_REQUEST, isfsObject, tempUsers);

					}
				});

			};
		}.start();
	}

	@Override
	public void currentSystemTmer(int time) {

		try {
			ISFSExtension tempSFSExtension = SmartFoxServer.getInstance().getZoneManager().getZoneByName("RouletteGame")
					.getExtension();
			ISFSObject obj = new SFSObject();
			obj.putInt(Param.CURRENT_TIME, time);
			Utils.Logger(GameMainExtension.extension,
					"GameEvent:::::::::::currentSystemTmer  ::::  Params ::::: " + obj.getDump());
			tempSFSExtension.handleClientRequest(Request.CURRENTTIME, null, obj);

		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension, "currentSystemTmer :::::: Error :::: ", e);
		}

	}

	@Override
	public void onLeaveUserRoom(BaseState baseState, String loginId) {

	}

	@Override
	public void betSave(BaseState baseState, User tempuser1, String session_id, String roomname) {

		// GameBean tempGameBean = baseState.getGameBean();

		SessionBean tempSession = GameMainExtension.GameCacheexe.getGameSessionBySessionId().getValueByKey(session_id);

		Utils.Logger(GameMainExtension.extension, "GameEvents::::::::::::userid:::::::::::::::::" + tempuser1
				+ " sessionid " + session_id + "roomname" + roomname);

		if (tempSession != null) {

			UserBetBean userBetBean = tempSession.getUserBetBeanByUserId(tempuser1.getName());

			if (userBetBean != null) {
				userBetBean.setBetStatus(true);

			}

			// final int i1=i;
			/*
			 * DBManager.BetOkUpdateBalance(tempuser1.getName(),
			 * userBetBean.getTotalBetAmount().toString(), new CallBack() {
			 * 
			 * 
			 * @Override public void call(Object... call) { try { double currentbalance =
			 * (double) call[0]; double totalbetamount =
			 * (Double.parseDouble(userBetBean.getTotalBetAmount()));
			 * Utils.Logger(GameMainExtension.extension,
			 * "betokbalance::::::::::::currentbalance" + currentbalance +
			 * "totalbetamount:::::" + totalbetamount);
			 * 
			 * double balance = currentbalance + totalbetamount;
			 * Utils.Logger(GameMainExtension.extension,
			 * "betokbalance::::::::::::updated balance" + balance + "totalbetamount:::::" +
			 * userBetBean.getTotalBetAmount());
			 * 
			 * tempGameBean.setCredits(String.valueOf(balance));
			 * 
			 * // int onlineplayerscount = tempUsers.size();
			 * 
			 * ISFSObject isfsObject = new SFSObject();
			 * isfsObject.putUtfString(Param.USERID, tempuser1.getName());
			 * isfsObject.putUtfString(Param.SESSION_ID, session_id);
			 * isfsObject.putUtfString(Param.MESSAGE, "Bet Save Successfully");
			 * isfsObject.putUtfString(Param.TOTALBETAMT, String.valueOf(currentbalance));
			 * isfsObject.putUtfString(Param.STATE, "2");
			 * isfsObject.putUtfString(Param.STATUS, "true");
			 * Utils.Logger(GameMainExtension.extension, "RESPONSE::::::::::" +
			 * isfsObject.getDump());
			 * 
			 * GameMainExtension.extension.send(Request.BETOK, isfsObject, tempuser1);
			 * 
			 * } catch (Exception e) { // TODO Auto-generated catch block
			 * e.printStackTrace(); }
			 * 
			 * }
			 * 
			 * });
			 */
		}
	}

	@Override
	public void betSaveOnTime(BaseState baseState) {

		GameBean gameBean = baseState.getGameBean();
		String userid = gameBean.getUserid();
		String currenttime = String.valueOf(baseState.getTimer().getElapsedTime());

		int time = 60 - (Integer.parseInt(currenttime));

		Player player = GameMainExtension.cache.getPlayer().getValueByKey(userid);

		Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

		List<User> tempUsers1 = tempRoom.getUserList();

		ISFSObject isfsObject = new SFSObject();
		isfsObject.putInt(Param.TIMER, time);
		isfsObject.putUtfString(Param.STATE, "2");
		isfsObject.putUtfString(Param.STATUS, "true");

		Utils.Logger(GameMainExtension.extension,
				"SingleROuletteGame:::::::::::::::::::::::GameEvents::::::::::::::::betSaveOnTime::::::::::::isfsobj:::::"
						+ isfsObject.getDump());

		GameMainExtension.extension.send(Events.STATEHANDLER, isfsObject, tempUsers1);

		if (player == null) {

			Utils.Logger(GameMainExtension.extension, "null");

		} else {
			// User user = player.getUser();

			DBManager.sendSessionIdOfRullete(userid, new CallBack() {

				@Override
				public void call(Object... callback) {
					String session_id = (String) callback[0];

					Utils.Logger(GameMainExtension.extension,
							"SendServerLiveTimer ::::betSaveOnTime:::::::::::: SendSessionIdofRullete :::: Session Id :::: "
									+ session_id);
					SessionBean tempSessionBean = GameMainExtension.GameCacheexe.getGameSessionBySessionId()
							.getValueByKey(session_id);

					if (tempSessionBean != null) {

						Utils.Logger(GameMainExtension.extension,
								"SendServerLiveTimer ::::betSaveOnTime::::::::::::tempSessionBean"
										+ tempSessionBean.toString());

						List<UserBetBean> tempUsers = tempSessionBean.getAllUserBets();

						int userSize = tempUsers.size();

						Utils.Logger(GameMainExtension.extension, " 50::::::::timer:::::  User size :::: " + userSize);

						try {

							for (int u = 0; u < userSize; u++) {

								UserBetBean tempUserBetBean = tempUsers.get(u);

								Utils.Logger(GameMainExtension.extension, "tempUserBetBean" + tempUserBetBean.toString()
										+ "status" + tempUserBetBean.isBetStatus());

								if (tempUserBetBean != null && !tempUserBetBean.isBetStatus()) {

									// String userid = tempUserBetBean.getUserId();

									User user = tempRoom.getUserByName(tempUserBetBean.getUserId());
									try {
										Utils.Logger(GameMainExtension.extension,
												"user::::::::::::::" + user.getName());
										Utils.Logger(GameMainExtension.extension,
												"roomname::::::::::::::" + tempRoom.getName());

									} catch (Exception e) {
										Utils.Logger(GameMainExtension.extension, "error ::::::::::::::::::::" + e);
									}
									Utils.Logger(GameMainExtension.extension,
											"SingleROuletteGame:::::::::::::::::::::::GameEvents::::::::::::::::betSaveOnTime:::::::::::::::user"
													+ user.getName() + "roomname" + tempRoom.getName()
													+ "player:::::::::::::" + player.toString());

									betSave(baseState, user, session_id, tempRoom.getName());

								}
							}

						} catch (Exception e) {
							Utils.ErrorLogger(GameMainExtension.extension, "error" + e);
						}
					}

				}

			});

		}
	}

	@Override
	public void specificClearBet(BaseState pstState, String betamount, String userid) {
		GameBean gameBean = pstState.getGameBean();
		Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

		User user = tempRoom.getUserByName(userid);

		if (gameBean != null) {

			// List<User> tempUsers = tempRoom.getUserList();

			ISFSObject isfsObject = new SFSObject();
			isfsObject.putUtfString(Param.CREDITS, betamount);
			isfsObject.putUtfString(Param.STATUS, "true");
			ref_extension.get().send(Request.REMOVELIVEBETREQUEST, isfsObject, user);

		}

	}

	@Override
	public void betRemoveUser(BaseState baseState, String session_id, String roomname, int betno, User user,
			double coins) {

		GameBean gameBean = baseState.getGameBean();
		// Room tempRoom =
		// ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

		if (gameBean != null) {

			// List<User> tempUsers = tempRoom.getUserList();

			ISFSObject isfsObject = new SFSObject();
			isfsObject.putUtfString(Param.MESSAGE, "Remove Bet Successfully");
			isfsObject.putUtfString(Param.STATUS, "true");
			ref_extension.get().send(Request.BETREMOVECUSTOMISE, isfsObject, user);

		}

	}
}
