/**
 * 
 */
package com.latestfunroulette.exeRoulette.machine.interfaces;




import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.base.interfaces.IState;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.exeRoulette.state.BetPlaceBetAmountState;
import com.latestfunroulette.exeRoulette.state.GameResultState;
import com.latestfunroulette.exeRoulette.state.GameResultWaitingState;
import com.latestfunroulette.exeRoulette.state.InitialState;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.common.RTimer;


/**
 * @author Ubuntu
 *
 */
public interface IStateMachine<G> extends IState<G> {

	void onNext(String pState);
	RTimer getTimer();
	IState<G> currentState();

	default IState<GameBean> getState(String pState) {
		Utils.Logger(GameMainExtension.extension, "IStateMachine:::::::::::pState" + pState);
		IState<GameBean> tempState = null;

		if (pState.equalsIgnoreCase(GameState.INITIAL)) {
			tempState = new InitialState();

			// Utils.Logger(GameMainExtension.extension, "INITIAL" + tempState);
		} else if (pState.equalsIgnoreCase(GameState.BETPLACESTATE)) {

			tempState = new BetPlaceBetAmountState();
			// Utils.Logger(GameMainExtension.extension, "PLAYERWAIT" + pState);

		} else if (pState.equalsIgnoreCase(GameState.RESULTWAIT)) {
			tempState = new GameResultWaitingState();

		} else if (pState.equalsIgnoreCase(GameState.RESULT)) {
			tempState = new GameResultState();
		} else if (pState.equalsIgnoreCase(GameState.EXIT)) {

			//
		}
		return tempState;
	}
}