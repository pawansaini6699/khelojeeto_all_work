package com.latestfunroulette.exeRoulette.machine.machineclass;


import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.RTimer;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.exeRoulette.base.baseclass.BaseStateMachine;
import com.latestfunroulette.exeRoulette.base.interfaces.IState;
import com.latestfunroulette.exeRoulette.cache.beans.GameBean;
import com.latestfunroulette.extension.GameMainExtension;


public class Machine extends BaseStateMachine<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,"Machine ::::ZerotoNineRoulette OnStart()");
		// print("Machine :::: OnStart()");
		super.setGameBean(g);
		onNext(g.getGameState());
		super.setMachineStatus(EnableStatus.ENABLE);
	}

	@Override
	public void onProcess() {
		Utils.Logger(GameMainExtension.extension,"Machine :::ZerotoNineRoulette: OnProcess()");
		// print("Machine :::: OnProcess()");
		if (getMachinState()) {
			getCurrentState().onProcess();
		} else {
			onExist();
		}
	}

	// getCurrentState = initial state
	@Override
	public void onNext(String pState) {

		 print("Machine :::::::::::::::onNext()" + pState);

		if (pState.equalsIgnoreCase(GameState.EXIT)) {
			onExist();
		} else {
			setCurrentState(pState);

			getCurrentState().onStart(getGameBean());
			// getCurrentState().onProcess();
		}
	}

	@Override
	public void onJoin(String pLoginId) {

		Utils.Logger(GameMainExtension.extension,"ZerotoNineRoulette::::::::::ploginid:::::::::::::" + pLoginId);
		getCurrentState().onJoin(pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getCurrentState().onLeave(pLoginId);

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {
		// TODO Auto-generated method stub

	}

	@Override
	public IState<GameBean> currentState() {
		// TODO Auto-generated method stub
		return getCurrentState();
	}
	@Override
	public RTimer getTimer() {
		// TODO Auto-generated method stub
		return getTimers();
	}

}