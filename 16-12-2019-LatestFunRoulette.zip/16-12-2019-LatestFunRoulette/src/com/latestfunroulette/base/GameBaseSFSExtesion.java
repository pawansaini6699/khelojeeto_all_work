package com.latestfunroulette.base;

import com.latestfunroulette.TripleRoulette.client.UpdateTaskHandlerTripleNine;
import com.latestfunroulette.TripleRoulette.comman.GlobalIdsTripleChance;
import com.latestfunroulette.TripleRoulette.comman.interfaces.IGloblaIdTripleChance;
import com.latestfunroulette.ZerotoNineRoulette.client.UpdateTaskHandlerZeroToNine;
import com.latestfunroulette.ZerotoNineRoulette.common.GlobalIdsZeroToNine;
import com.latestfunroulette.ZerotoNineRoulette.common.interfaces.IGloblaIdZeroToNine;
import com.latestfunroulette.common.BetNumberRandomGenerate;
import com.latestfunroulette.common.BetNumberRandomGenerateDouble;
import com.latestfunroulette.common.BetNumbersConstant;
import com.latestfunroulette.common.CommonEvents;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.ExecuteTimer;
import com.latestfunroulette.common.ServerShutDownHook;
import com.latestfunroulette.common.UpdateTaskHandler;
import com.latestfunroulette.dubliRoulette.client.UpdateTaskHandlerDoubleNine;
import com.latestfunroulette.dubliRoulette.common.GlobalIdsDoubleChance;
import com.latestfunroulette.dubliRoulette.common.interfaces.IGloblaIdDoubleChance;
import com.latestfunroulette.extension.game.GamePlayEventTask;
import com.latestfunroulette.game.common.GlobalIds;
import com.latestfunroulette.game.common.interfaces.IGloblaId;
import com.latestfunroulette.playMart.client.UpdateTaskHandlerPlayMart;
import com.latestfunroulette.playMart.common.GlobalIdsPlayMart;
import com.latestfunroulette.playMart.common.interfaces.IGloblaIdPlayMart;
import com.smartfoxserver.v2.extensions.SFSExtension;

public abstract class GameBaseSFSExtesion extends SFSExtension {

	// public static GameCache cache;
	public static ServerShutDownHook serverShutDown;
	public static UpdateTaskHandler updateTask;
	public static UpdateTaskHandlerZeroToNine updateTask_single_chance;
	public static UpdateTaskHandlerDoubleNine updateTask_double_nine;
	public static UpdateTaskHandlerTripleNine updateTaskHandlerTripleNine;

	public static UpdateTaskHandlerPlayMart updateTaskHandlerPlayMart;

	public static GamePlayEventTask gamePlayEventTask;
	// private SupportTriggers triggers;
	public static IGloblaId globlaId;
	public static IGloblaIdZeroToNine globlaIdZeroToNine;
	public static IGloblaIdDoubleChance globlaIddoublechance;
	public static IGloblaIdTripleChance globlaIdTripleChance;
	public static IGloblaIdPlayMart globlaIdPlayMart;
//	public static UpdateTaskHandler updateTask;

	@Override
	public void init() {

		// cache = new GameCache();
		serverShutDown = new ServerShutDownHook(this);
System.out.println(" @@@@@@@@@@@@   Hello User :::::  ######  How Are You ??  ");
		DBManager.DBInit(this, this.getParentZone());
		BetNumbersConstant.init();
		BetNumberRandomGenerate.init();
		BetNumberRandomGenerateDouble.init();
		ExecuteTimer.init();

		updateTask = new UpdateTaskHandler(this);
		updateTask_single_chance = new UpdateTaskHandlerZeroToNine(this);
		updateTask_double_nine = new UpdateTaskHandlerDoubleNine(this);
		updateTaskHandlerTripleNine = new UpdateTaskHandlerTripleNine(this);
		updateTaskHandlerPlayMart = new UpdateTaskHandlerPlayMart(this);

		gamePlayEventTask = new GamePlayEventTask();

		// triggers = new SupportTriggers();
		new CommonEvents(this);
		globlaId = new GlobalIds();
		globlaIdZeroToNine = new GlobalIdsZeroToNine();
		globlaIddoublechance = new GlobalIdsDoubleChance();
		globlaIdTripleChance = new GlobalIdsTripleChance();
		globlaIdPlayMart = new GlobalIdsPlayMart();

		globlaIdZeroToNine.updateId();
		globlaId.updateId();
		globlaIddoublechance.updateId();
		globlaIdTripleChance.updateId();
		globlaIdPlayMart.updateId();

		init(this);
		clientEventHandler();
		serverEventHandler();
		SingleEventHandler();
		DoubleEventHandler();
		ThripleEventHandler();
		ZeroToNineEventHandler();
		PlayMartEventHandler();
		GameEventHandler();
		updateTasks();
		// gamePlayEventTask();

	}

	public abstract void updateTasks();

	// public abstract void gamePlayEventTask();

	public abstract void init(SFSExtension extension);

	public abstract void serverEventHandler();

	public abstract void clientEventHandler();

	public abstract void ZeroToNineEventHandler();

	public abstract void SingleEventHandler();

	public abstract void DoubleEventHandler();

	public abstract void ThripleEventHandler();

	public abstract void PlayMartEventHandler();

	public abstract void GameEventHandler();

}
