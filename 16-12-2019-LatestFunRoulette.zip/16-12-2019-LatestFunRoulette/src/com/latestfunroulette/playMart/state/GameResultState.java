package com.latestfunroulette.playMart.state;

import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.gameStatePlatMart;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.base.interfaces.BaseState;
import com.latestfunroulette.playMart.cache.beans.GameBean;
import com.latestfunroulette.playMart.state.interfaces.IGameWaitingState;

public class GameResultState extends BaseState implements IGameWaitingState<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,
				"PlayMart:::::::::::::::::::GameResultState::::::::::::onStart::::::");
		super.init(g, gameStatePlatMart.GAME_RESULT_TIME);
		getEvents().sendLiveTime(this);

	}

	@Override
	public void onProcess() {

		long currenttime = getTimer().getElapsedTime();
		Utils.Logger(GameMainExtension.extension,
				"playmart::::::::::::::::::GameResultState:::::::::onProcess():::::::::::::::::::::::timer"
						+ currenttime);
		if (currenttime >= getStateTime()) {
			onExist();

		}
	}

	@Override
	public void onJoin(String pLoginId) {
		print("GameResultWaitingState :::: OnJoin()");
		getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);
		// TODO Auto-generated method stub

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {

		getGameBean().setGameState(GameState.BETPLACESTATE);
		getGameMachine().onNext(getGameBean().getGameState());

	}

}
