package com.latestfunroulette.playMart.state;

import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.gameStatePlatMart;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.base.baseclass.BasebetPlaceState;
import com.latestfunroulette.playMart.cache.beans.GameBean;
import com.latestfunroulette.playMart.state.interfaces.IBetPlaceState;
import com.smartfoxserver.v2.entities.User;

public class BetPlaceBetAmountState extends BasebetPlaceState implements IBetPlaceState<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension,
				"PlayMart:::::::::::::::::::BetPlaceBetAmountState:::::::::onStart:::::::::::");

		super.init(g, gameStatePlatMart.BET_PLACE_TIME);
		getTimer().resetTimer();
		getEvents().newSessionGenarate(this);

	}

	@Override
	public void onProcess() {

		long currenttime = getTimer().getElapsedTime();
		Utils.Logger(GameMainExtension.extension,
				"playmart::::::::::::::::::::BetPlaceBetAmountState:::::::::::::::timer " + currenttime);
		if (currenttime > getStateTime()) {

			onExist();

		} /*
			 * else if (getTimer().getElapsedTime() == 48) {
			 * 
			 * 
			 * }
			 */

	}

	@Override
	public void onJoin(String pLoginId) {
		getEvents().onJoinSendUserData(this, pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getEvents().onLeaveUserRoom(this, pLoginId);

	}

	@Override
	public void playWaitingState() {

	}

	@Override
	public void gameResultState() {

	}

	@Override
	public void onExist() {
		getGameBean().setGameState(GameState.RESULTWAIT);
		Utils.Logger(GameMainExtension.extension, "state" + getGameBean().getGameState());
		getGameMachine().onNext(getGameBean().getGameState());

	}

	@Override
	public void betPlaceState(User pUser, String session_id, double coins, int selectednumber, int gameid) {

		Utils.Logger(GameMainExtension.extension,
				"Play mart ::::::::::::::::::::BetPlaceBetAmountState:::::::::::::::betPlaceState :::: betPlaceState() :::: "
						+ " ::::: user id ::: " + pUser.getName() + ":::::::  session_id :::: ::" + session_id
						+ " coins :::::::: " + coins + " :::::selectednumbers :::::::: " + selectednumber);
		updateBetStatus(pUser, session_id, coins, selectednumber, gameid);

	}

	@Override
	public void onCancelBet(String roomname, User user, String session_id, int betno, double betamount) {

		Utils.Logger(GameMainExtension.extension, "onCancelBet :::: onCancelBet() :::: roomname ::: " + roomname
				+ " ::::: user id ::: " + user.getName() + ":::::::  session_id :::: ::" + session_id);

		cancelSpecificBet(user, session_id, betno, betamount);

	}

	@Override
	public void onClearAll(String roomname, User pUser, String session_id) {

		Utils.Logger(GameMainExtension.extension, "onClearAll :::: onClearAll() :::: roomname ::: " + roomname
				+ " ::::: user id ::: " + pUser.getName() + ":::::::  session_id :::: ::" + session_id);

		clearAllBetsRoulette(pUser, session_id, roomname);

	}

	@Override
	public void onRebetRequest(String roomname, User user, String session_id) {

		Utils.Logger(GameMainExtension.extension, "onRebetRequest :::: onRebetRequest() :::: roomname ::: " + roomname
				+ " ::::: user id ::: " + user.getName() + ":::::::  session_id :::: ::" + session_id);
		getEvents().onRebetRoulette(this, user, session_id);

	}

	@Override
	public void userBetSave(String roomname, User user, String session_id) {
		Utils.Logger(GameMainExtension.extension, "userBetSave :::: userBetSave() :::: roomname ::: " + roomname
				+ " ::::: user id ::: " + user.getName() + "sessionid :::: ::" + session_id);
		getEvents().betSave(this, user, session_id, roomname);

		onUserBetSave(roomname, user, session_id);

	}

	@Override
	public void userBetRemove(String roomname, String session_id, int betno, User user, double coins) {
		Utils.Logger(GameMainExtension.extension,
				"userBetSave :::: userBetRemove() :::: roomname ::: " + roomname + " ::::: user id ::: "
						+ user.getName() + ":::::::  session_id :::: ::" + session_id + "betno::::::::" + betno);
		betRemoveUser(session_id, roomname, betno, user, coins);

	}

	@Override
	public void userGameDetails(String roomname, User user) {

		Utils.Logger(GameMainExtension.extension, "userGameDetails :::: userGameDetails() :::: roomname ::: " + roomname
				+ " ::::::  user  :::::  " + user.getName());
		getGameDetailsPlayMart(roomname, user);

	}

	@Override
	public void userGameDetailsStartAndEndDate(String roomname, User user, String startDate, String endDate) {

		Utils.Logger(GameMainExtension.extension,
				"userGameDetailsStartAndEndDate  :::: userGameDetailsStartAndEndDate() :::: roomname ::: " + roomname
						+ " ::::::  user  :::::  " + user.getName());
		getGameDetailsRouletteStartAndEndDatePlayMart(roomname, user, startDate, endDate);

	}

	@Override
	public void betPrintExe(String roomname, String sessionId, User user) {

		betPrintExeUser(roomname, sessionId, user);
	}

	@Override
	public void UsersDayWiseResultDetails_PlayMart(String roomname, User pUser) {
		Utils.Logger(GameMainExtension.extension, "UsersDayWiseResultDetails_PlayMart ::::  :::: roomname ::: "
				+ roomname + " ::::::  user  :::::  " + pUser.getName());
		getGameDetailsResult_PlayMart(roomname, pUser);

	}

	@Override
	public void betCancelByTicketId(String roomname, String sessionId, User user, String ticketid,int gameid,double betamount) {
		Utils.Logger(GameMainExtension.extension, "roomaname::::::::" + roomname + "sessionid:::::::::::::::::"
				+ sessionId + "  user" + user + "ticketid" + ticketid);
		betCancelByTicketIdUser(roomname, sessionId, user, ticketid,gameid,betamount);

	}

	@Override
	public void betClaimByTicketId_PlayMart(String roomname, String sessionId, User user, String ticketid,int gameid,String gametype) {

		betClaimByTicketId(roomname, sessionId, user, ticketid,gameid,gametype);
	}

	@Override
	public void betShowAllDetails(String roomname, User pUser, String ticketid) {
		
		Utils.Logger(GameMainExtension.extension, "betShowAllDetails :::: :::: roomname ::: " + roomname
				+ " ::::::  user  :::::  " + pUser.getName() + "ticketid" + ticketid);
		betAllShow(roomname, pUser,ticketid);
		
		
	}

}
