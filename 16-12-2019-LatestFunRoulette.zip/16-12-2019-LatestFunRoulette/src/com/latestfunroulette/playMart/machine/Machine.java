package com.latestfunroulette.playMart.machine;

import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.base.baseclass.BaseStateMachine;
import com.latestfunroulette.playMart.base.interfaces.IState;
import com.latestfunroulette.playMart.cache.beans.GameBean;
import com.latestfunroulette.playMart.client.RTimer;

public class Machine extends BaseStateMachine<GameBean> {

	@Override
	public void onStart(GameBean g) {
		Utils.Logger(GameMainExtension.extension, "Machine ::::PlayMart::::::::::::: OnStart()");
		// print("Machine :::: OnStart()");
		super.setGameBean(g);
		onNext(g.getGameState());
		onGetStatus(g.isStatus());
	}

	@Override
	public void onProcess() {
		// print("Machine :::: OnProcess()");
		if (getMachinState()) {
			getCurrentState().onProcess();
		} else {
			onExist();
		}
	}

	// getCurrentState = initial state
	@Override
	public void onNext(String pState) {

		print("Machine :::::::::::::::onNext()" + pState);

		if (pState.equalsIgnoreCase(GameState.EXIT)) {
			onExist();
		} else {

			setCurrentState(pState);

			getCurrentState().onStart(getGameBean());
			// getCurrentState().onProcess();
		}
	}

	public void onGetStatus(boolean status) {

		if (status) {
			super.setMachineStatus(EnableStatus.ENABLE);
		} else {

		}

	}

	@Override
	public void onJoin(String pLoginId) {

		Utils.Logger(GameMainExtension.extension, "PlayMart::::::::::ploginid:::::::::::::" + pLoginId);
		getCurrentState().onJoin(pLoginId);

	}

	@Override
	public void onLeave(String pLoginId) {
		getCurrentState().onLeave(pLoginId);

	}

	@Override
	public void playWaitingState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void gameResultState() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onExist() {
		

	}

	@Override
	public IState<GameBean> currentState() {
		// TODO Auto-generated method stub
		return getCurrentState();
	}

	@Override
	public RTimer getTimer() {

		return getTimers();
	}

	@Override
	public boolean isMachineStatus() {
		return getMachinState();
	}

	@Override
	public boolean setMachineStatusPlayMart(boolean status) {

		setMachineStatus(status);
		return status;

	}

}
