package com.latestfunroulette.playMart.machine;



import java.lang.ref.WeakReference;
import java.util.concurrent.ScheduledFuture;


import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.playMart.base.baseclass.BaseStateMachine;
import com.latestfunroulette.playMart.cache.beans.GameBean;
import com.latestfunroulette.playMart.machine.interfaces.IStateMachine;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class AllMachineManager {

	BaseStateMachine<GameBean> baseStateMachine = null;

	WeakReference<SFSExtension> ref_extension;
	ScheduledFuture<?> taskHandlerForGames;

	public void OnInitialState(Room proom, GameBean gameBean) {
		
		gameBean.setRoomName(proom.getName());
		gameBean.setGameTurnTime(1);
		gameBean.setGameState(GameState.INITIAL);

		IStateMachine<GameBean> gameMachine = new Machine();
	//	gameBean.setGameMachineDoubli(gameMachine);
		gameBean.setGameMachine(gameMachine);
		gameMachine.onStart(gameBean);
		

	
	}

}

