package com.latestfunroulette.playMart.machine.interfaces;

public interface IMachineManager {

	void join(String pLoginId, String pRoomName);

}