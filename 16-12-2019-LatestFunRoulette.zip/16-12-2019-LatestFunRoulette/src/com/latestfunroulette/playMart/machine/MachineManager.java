package com.latestfunroulette.playMart.machine;





import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.cache.beans.GameBean;
import com.latestfunroulette.playMart.machine.interfaces.IMachineManager;
import com.latestfunroulette.playMart.machine.interfaces.IStateMachine;


public class MachineManager implements IMachineManager {

	@Override
	public void join(String pLoginId, String pRoomName) {
		GameBean tempGameBean = GameMainExtension.gamecachePlayMart.getGames().getValueByKey(pRoomName);
		Utils.Logger(GameMainExtension.extension,tempGameBean.getGameMachine());
		if (tempGameBean.getGameMachine() == null) {
			IStateMachine<GameBean> tempStateMachine = new Machine();
			tempGameBean.setGameMachine(tempStateMachine);
		//	tempGameBean.setGameState(GameState.PLAYERWAIT);
			tempStateMachine.onStart(tempGameBean);
			tempStateMachine.onJoin(pLoginId);
		} else {
			tempGameBean.getGameMachine().onJoin(pLoginId);
		}
	}
}
