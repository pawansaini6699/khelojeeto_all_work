package com.latestfunroulette.playMart.cache.caching.interfaces;

public interface ICurrentSession<S> {

	void updateCurrentSession(S s);
	
	S getCurrentSession();
	
}