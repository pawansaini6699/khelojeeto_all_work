package com.latestfunroulette.playMart.cache.caching;

/**
 * 
 */


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.cache.beans.SessionBean;
import com.latestfunroulette.playMart.cache.caching.interfaces.ISessionCache;



/**
 * @author nagjee
 *
 */
public class SessionCache extends HashMap<String, SessionBean>
		implements Serializable, ISessionCache<String, SessionBean> {

	private static final long serialVersionUID = 1L;

	@Override
	public void add(SessionBean v) {
		Utils.Logger(GameMainExtension.extension,"SessionCache::::::::::::::::::::::::::::::: add" + v);
		// Utils.Logger(GameMainExtension.extension,"SessionCache :::: Add new Session() :::: Session ::::
		// "+v.toString());
		put(v.getSessionId(), v);
	}

	@Override
	public void delete(String k) {
		try {
			remove(k);
			Utils.Logger(GameMainExtension.extension,"SessionCache::::::::::::::::::::::::::::::: delete" + k);
		} catch (Exception e) {
			Utils.Logger(GameMainExtension.extension,"SessionCache:::::::::::::::" + e);
		}
	}

	@Override
	public SessionBean getValueByKey(String k) {

		Utils.Logger(GameMainExtension.extension,"SessionCache::::::::::::::::::::::::::::::: getValueByKey" + k);
		return get(k);

	}

	@Override
	public List<SessionBean> getAllValue() {
		Utils.Logger(GameMainExtension.extension,"SessionCache::::::::::::::::::::::::::::::: getAllValue");
		return new ArrayList<>(values());
	}

	@Override
	public void clearAllSession() {
		Utils.Logger(GameMainExtension.extension,"SessionCache::::::::::::::::::::::::::::::: clearAllSession");
		// clear();
	}

	@Override
	public HashMap<String, SessionBean> getAll() {
		Utils.Logger(GameMainExtension.extension,"SessionCache::::::::::::::::::::::::::::::: getAll");
		// TODO Auto-generated method stub
		return this;
	}

	@Override
	public void update(String k, SessionBean v) {
		Utils.Logger(GameMainExtension.extension,"SessionCache::::::::::::::::::::::::::::::: update");
		// TODO Auto-generated method stub

	}

	@Override
	public final void clear() {
		Utils.Logger(GameMainExtension.extension,"SessionCache::::::::::::::::::::::::::::::: clear()");
		// super.clear();
	}

}
