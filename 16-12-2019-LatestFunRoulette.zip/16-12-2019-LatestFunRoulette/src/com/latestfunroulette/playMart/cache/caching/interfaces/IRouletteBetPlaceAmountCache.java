package com.latestfunroulette.playMart.cache.caching.interfaces;



public interface IRouletteBetPlaceAmountCache<K,V> extends IBaseCache<K, V> {

}