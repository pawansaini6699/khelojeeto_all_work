package com.latestfunroulette.playMart.cache.caching.interfaces;



public interface IAvatarCache<K, V> extends IBaseCache<K, V> {

}