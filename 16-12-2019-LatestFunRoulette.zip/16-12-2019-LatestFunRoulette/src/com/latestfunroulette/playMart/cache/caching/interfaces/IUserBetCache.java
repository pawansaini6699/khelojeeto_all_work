package com.latestfunroulette.playMart.cache.caching.interfaces;


public interface IUserBetCache<K,V> extends IBaseCache<K, V> {

}
