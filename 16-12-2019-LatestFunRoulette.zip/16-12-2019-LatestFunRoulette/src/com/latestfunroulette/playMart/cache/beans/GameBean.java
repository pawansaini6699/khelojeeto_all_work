package com.latestfunroulette.playMart.cache.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.latestfunroulette.common.Constants.EnableStatus;
import com.latestfunroulette.common.Constants.GameState;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.playMart.client.RTimer;
import com.latestfunroulette.playMart.machine.interfaces.IStateMachine;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSObject;

public class GameBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String gameType;
	private String gameState = GameState.INITIAL;
	List<Integer> betsArr = new ArrayList<>();
	private int gameTurnTime;
	private String commands;
	private int betno;
	private RTimer tempTimer;
	private String roomName;
	private String credits;
	private String bets;
	private String session_id;
	private String winner;
	private String winningnumber;
	private String totelbetamt;
	private String lastfivenumber;
	private String currentgamesession;
	private boolean isPassword = EnableStatus.DISABLE;
	private String password;
	private String time;
	private String totalsessionwinamount;
	private boolean isStatus;
	private int jackport;
	private String ticketid;
	private boolean isPrintstatus;
	// SessionBean
	// sessionBean=GameMainExtension.cache.getGameSessionBySessionId().getValueByKey(session_id);

	public boolean isPrintstatus() {
		return isPrintstatus;
	}

	public void setPrintstatus(boolean isPrintstatus) {
		this.isPrintstatus = isPrintstatus;
	}

	public String getTicketid() {
		return ticketid;
	}

	public void setTicketid(String ticketid) {
		this.ticketid = ticketid;
	}

	public boolean isStatus() {
		return isStatus;
	}

	public void setStatus(boolean isStatus) {
		this.isStatus = isStatus;
	}

	private IStateMachine<GameBean> gameMachine;

	// List<UserBetBean> userBetBean=sessionBean.getAllUserBets();

	private volatile List<GamePlayerBean> playerBeans = new ArrayList<GamePlayerBean>();

	public String getTotalsessionwinamount() {
		return totalsessionwinamount;
	}

	public void setTotalsessionwinamount(String totalsessionwinamount) {
		this.totalsessionwinamount = totalsessionwinamount;
	}

	public String getGameType() {
		return gameType;
	}

	public void setGameType(String gameType) {
		this.gameType = gameType;
	}

	private String userid;
	private int coins;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public int getCoins() {
		return coins;
	}

	public void setCoins(int coins) {
		this.coins = coins;
	}

	public int getJackport() {
		return jackport;
	}

	public void setJackport(int jackport) {
		this.jackport = jackport;
	}

	public String getCommands() {
		return commands;
	}

	public void setCommands(String commands) {
		this.commands = commands;
	}

	public int getBetno() {
		return betno;
	}

	public void setBetno(int betno) {
		this.betno = betno;
	}

	public RTimer getTempTimer() {
		return tempTimer;
	}

	public void setTempTimer(RTimer tempTimer) {
		this.tempTimer = tempTimer;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public RTimer getTimer() {
		return tempTimer;
	}
	/*
	 * private void addTimer() { tempTimer = new RTimer(); }
	 */

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isPassword() {
		return isPassword;
	}

	public void setPassword(boolean isPassword) {
		this.isPassword = isPassword;
	}

	public int getGameTurnTime() {
		return gameTurnTime;
	}

	public void setGameTurnTime(int gameTurnTime) {
		this.gameTurnTime = gameTurnTime;
	}

	private volatile List<GamePlayerBean> players = new ArrayList<>();
	private Room sfsRoom;

	public List<GamePlayerBean> getPlayers() {
		return players;
	}

	@Override
	public String toString() {
		return "GameBean [gameType=" + gameType + ", gameState=" + gameState + ", betsArr=" + betsArr
				+ ", gameTurnTime=" + gameTurnTime + ", commands=" + commands + ", betno=" + betno + ", tempTimer="
				+ tempTimer + ", roomName=" + roomName + ", credits=" + credits + ", bets=" + bets + ", session_id="
				+ session_id + ", winner=" + winner + ", winningnumber=" + winningnumber + ", totelbetamt="
				+ totelbetamt + ", lastfivenumber=" + lastfivenumber + ", currentgamesession=" + currentgamesession
				+ ", isPassword=" + isPassword + ", password=" + password + ", time=" + time
				+ ", totalsessionwinamount=" + totalsessionwinamount + ", isStatus=" + isStatus + ", jackport="
				+ jackport + ", ticketid=" + ticketid + ", isPrintstatus=" + isPrintstatus + ", gameMachine="
				+ gameMachine + ", playerBeans=" + playerBeans + ", userid=" + userid + ", coins=" + coins
				+ ", players=" + players + ", sfsRoom=" + sfsRoom + "]";
	}

	public Room getSfsRoom() {
		return sfsRoom;
	}

	public void setSfsRoom(Room sfsRoom) {
		this.sfsRoom = sfsRoom;
	}

	public void setPlayers(List<GamePlayerBean> players) {
		this.players = players;
	}

	public String getCredits() {
		return credits;
	}

	public void setCredits(String credits) {
		this.credits = credits;
	}

	public String getBets() {
		return bets;
	}

	public void setBets(String bets) {
		this.bets = bets;
	}

	public String getSession_id() {
		return session_id;
	}

	public void setSession_id(String session_id) {
		this.session_id = session_id;
	}

	public String getWinner() {
		return winner;
	}

	public void setWinner(String winner) {
		this.winner = winner;
	}

	public String getWinningnumber() {
		return winningnumber;
	}

	public void setWinningnumber(String winningnumber) {
		this.winningnumber = winningnumber;
	}

	public String getTotelbetamt() {
		return totelbetamt;
	}

	public void setTotelbetamt(String totelbetamt) {
		this.totelbetamt = totelbetamt;
	}

	public String getCurrentgamesession() {
		return currentgamesession;
	}

	public void setCurrentgamesession(String currentgamesession) {
		this.currentgamesession = currentgamesession;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getLastfivenumber() {
		return lastfivenumber;
	}

	public void setLastfivenumber(String lastfivenumber) {
		this.lastfivenumber = lastfivenumber;
	}

	public List<Integer> getBetsArr() {
		return betsArr;
	}

	public void setBetsArr(List<Integer> betsArr) {
		this.betsArr = betsArr;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public IStateMachine<GameBean> getGameMachine() {
		return gameMachine;
	}

	public void setGameMachine(IStateMachine<GameBean> gameMachine) {
		this.gameMachine = gameMachine;
	}

	public String getGameState() {
		return gameState;
	}

	public void setGameState(String gameState) {
		this.gameState = gameState;
	}

	public ISFSObject toSFS() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString(Param.CREDITS, credits.equalsIgnoreCase("") ? "" : credits);
		tempSFSObj.putUtfString(Param.SESSION_ID, session_id.equalsIgnoreCase("") ? "" : session_id);

		// tempSFSObj.putUtfString(Param.BOT_STATUS, String.valueOf(isBot()));
		return tempSFSObj;
	}

	public void clearAll() {

		playerBeans.clear();
	}

}
