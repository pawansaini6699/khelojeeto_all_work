package com.latestfunroulette.playMart.cache.beans;

/**
 * Akshay
 */

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.cache.caching.RouletteBetPlaceAmountCache;
import com.latestfunroulette.playMart.cache.caching.UserBetCache;
import com.latestfunroulette.playMart.cache.caching.interfaces.IRouletteBetPlaceAmountCache;
import com.latestfunroulette.playMart.cache.caching.interfaces.IUserBetCache;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.SFSObject;

/**
 * @author nagjee
 *
 */
public class SessionBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String sessionId;
	private IUserBetCache<String, UserBetBean> userBets = new UserBetCache();
	private BigDecimal totalSessionBetAmount = new BigDecimal(0.0);

	private String rouletteWinPosition = "-1";
	private IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> rouletteBetPlaceAmount = new RouletteBetPlaceAmountCache();

	private double totalcoins = 0;

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
		// addBetPlaces();
	}

	public UserBetBean getUserBetBeanByUserId(String pUserId) {
		return userBets.getValueByKey(pUserId);
	}

	public void getDeleteUserBetBeanByUserId(String pUserId) {
		System.out.println("pUserId:::::::::::::" + pUserId);
		userBets.delete(pUserId);
	}

	public List<UserBetBean> getAllUserBets() {
		return userBets.getAllValue();
	}

	public String getRouletteWinPosition() {
		return rouletteWinPosition;
	}

	public void setRouletteWinPosition(String rouletteWinPosition) {
		this.rouletteWinPosition = rouletteWinPosition;
	}

	public void addUserBet(String pUserId, String sessionid, double coins, double splitamount, String pBetNos,
			double winAmount, int gameid, boolean rebetstatus) {

		Utils.Logger(GameMainExtension.extension,
				"Play Mart::::::::::::::::::::::::SessionBean ::: before add amount ::::  User Id :::: " + pUserId
						+ " ::: Session Id ::: " + sessionid + "coins:::::::::::" + coins + "::::pBetNos:::::::::::"
						+ pBetNos + " ::::::pBetWinAmount::::::" + winAmount + "splitamount:::::::::::" + splitamount);

		UserBetBean tempUserBetBean = null;
		if ((tempUserBetBean = getUserBetBeanByUserId(pUserId)) == null) {
			tempUserBetBean = new UserBetBean(); // tempUserBetBean.setUserId(pUserId);
			tempUserBetBean.setUserId(pUserId);
			tempUserBetBean.setGameId(gameid);

			userBets.add(tempUserBetBean);
		}

		tempUserBetBean.addUpdateRouletteBet(coins, splitamount, pBetNos, winAmount, rebetstatus);

		// updateBetAmount(tempUserBetBean, pBetNos, coins);

		if (!rebetstatus) {

			updateSessionTotalBetAmount(coins);
		} else {
			updateSessionTotalBetAmount((splitamount));

		}

		Utils.Logger(GameMainExtension.extension, "SessionBean ::: after add amount ::::  User Id :::: " + pUserId
				+ " ::: Session Id ::: " + sessionid + " :::: Bet Amount ::: " + tempUserBetBean.getTotalBetAmount());

		// getSessionBetDetail();
	}

	public void addUserBetDouble(String pUserID) {

		new Thread() {

			@Override
			public void run() {

				Utils.Logger(GameMainExtension.extension,
						":::::::::::::playmart ::::::::::::SESSIONBEAN:::::::::::::::::addUserBetDouble:::");
				UserBetBean tempUserBet = getUserBetBeanByUserId(pUserID);

				BigDecimal tempUserBetAmount = new BigDecimal(tempUserBet.getTotalBetAmount());

				Utils.Logger(GameMainExtension.extension,
						"SESSIONBEAN::::::::::::::::::::::tempUserBetAmount" + tempUserBetAmount);
				updateSessionTotalBetAmount(tempUserBetAmount.doubleValue());
				double userTotalBetAmount = tempUserBetAmount.doubleValue() * 2;
				tempUserBet.setTotalBetAmount(String.valueOf(userTotalBetAmount));

				try {
					HashMap<String, RouletteBetBeans> tempUserBetsplaymart = tempUserBet.getUserRouletteBets();

					Utils.Logger(GameMainExtension.extension,
							"tempUserBetsplaymart:::::::::::::::::::::" + tempUserBetsplaymart);

					for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempUserBetsplaymart.entrySet()) {

						String betno = (String) tempRouletteBetBeans.getKey();

						RouletteBetBeans tempRouletteBetBeanssingle = tempUserBetsplaymart.get(betno);

						tempRouletteBetBeanssingle.setBetAmount(tempRouletteBetBeanssingle.getBetAmount() * 2);
						tempRouletteBetBeanssingle
								.setSplitBetAmount(tempRouletteBetBeanssingle.getSplitBetAmount() * 2);

					}

					Utils.Logger(GameMainExtension.extension,
							"play mart::::::::::::::::::::::Session Bean ::: AddUserBetDouble :::: TotalSession Amount :::: "
									+ getTotalBetAmount() + " ::::: User Total Bet Amount ::::: "
									+ tempUserBet.getTotalBetAmount());

				} catch (Exception e) {
					Utils.Logger(GameMainExtension.extension, "SESSIONBEAN::::::::::::::::::::::error" + e);

				}
			}
		}.start();

	}

	public void cancelSpecifiChooseAdmin(String pBetNo, String pUserId, double coins, double splitamount) {

		Utils.Logger(GameMainExtension.extension, "coins :::::::::::::::::::::" + coins + "pBetNo" + pBetNo);

		totalcoins = totalcoins + coins;
		Utils.Logger(GameMainExtension.extension, "totalcoins:::::::::::::::::::::" + totalcoins);
		new Thread() {

			@Override
			public void run() {
				UserBetBean tempUserBet = getUserBetBeanByUserId(pUserId);
				try {

					tempUserBet.cancelSpecificRouletteBet(pBetNo, coins, splitamount, pUserId);

					tempUserBet.remainingTotalBetAmount(coins);
					Utils.Logger(GameMainExtension.extension, "Total bet amount:::::::::::::::::::"
							+ tempUserBet.getTotalBetAmount() + "totalcoins::::::::::::::::::" + totalcoins);

				} catch (Exception e) {
					Utils.ErrorLogger(GameMainExtension.extension,
							" PlayMart:::::::::::::::::error ::::::::::::::" + e);

				}

				clearSessionTotalBetAmount(coins);

				HashMap<String, RouletteBetBeans> hashMap = tempUserBet.getUserRouletteBets();

				System.out.println(
						"hashmap::::::::::::::ggfdgdfsgdgdfsgfdsgdsgdsg::::::::::::::::::::::::: ssize::::::::::::::::::::::::::::"
								+ hashMap.size());

				if (hashMap.size() == 0) {
					userBets.delete(pUserId);
				}

			}
		}.start();

	}

	public void cancelAllRouletteBet(String pUserId) {

		UserBetBean tempUserBetBean = null;
		if ((tempUserBetBean = userBets.getValueByKey(pUserId)) != null) {
			if (!tempUserBetBean.isBetStatus()) {

				tempUserBetBean.cancelAllRouletteBet();
				userBets.delete(pUserId);
			}
		}
		// getSessionBetDetail();
	}

//////////////////////////////////////////////////////////////////////////////

	public IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> getRouletteBetPlaceAmount() {
		return rouletteBetPlaceAmount;
	}

	private synchronized void updateSessionTotalBetAmount(double pBetAmount) {
		totalSessionBetAmount = totalSessionBetAmount.add(new BigDecimal(pBetAmount));
		totalSessionBetAmount = totalSessionBetAmount.setScale(3, BigDecimal.ROUND_HALF_DOWN);
		Utils.Logger(GameMainExtension.extension,
				" RouletteBetPlaceBean:::::::::::::updateBetAmount:::::::totalSessionBetAmount"
						+ totalSessionBetAmount);

	}

	private synchronized void clearSessionTotalBetAmount(double pBetAmount) {
		totalSessionBetAmount = totalSessionBetAmount.subtract(new BigDecimal(pBetAmount));
		totalSessionBetAmount = totalSessionBetAmount.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension, "clearsessiontotelbetamount:::::::::" + pBetAmount
				+ "totalSessionBetAmount:::::::::" + totalSessionBetAmount);

		if (totalSessionBetAmount.doubleValue() < 0)
			totalSessionBetAmount = new BigDecimal(0.0);

	}

	public synchronized void updateSessionTotalBetAmountUser(double pBetAmount) {
		Utils.Logger(GameMainExtension.extension,
				"totalSessionBetAmount::::::::::::sessionbean:::::::::" + totalSessionBetAmount);

		totalSessionBetAmount = totalSessionBetAmount.add(new BigDecimal(pBetAmount));
		totalSessionBetAmount = totalSessionBetAmount.setScale(3, BigDecimal.ROUND_HALF_DOWN);
		Utils.Logger(GameMainExtension.extension,
				" RouletteBetPlaceBean:::::::::::::::::::totalSessionBetAmount" + totalSessionBetAmount);

	}

	public double getTotalBetAmount() {
		return Math.round(totalSessionBetAmount.doubleValue());
	}

	public String getSessionBetDetail() {
		ISFSObject tempSFSObj = new SFSObject();
		tempSFSObj.putUtfString("TOTAL_SESSION_BET_AMOUNT", String.valueOf(totalSessionBetAmount));
		SFSArray sfsArray = new SFSArray();
		for (int bp = 0; bp < 12; bp++) {

			sfsArray.addUtfString(
					String.valueOf(rouletteBetPlaceAmount.getValueByKey(String.valueOf(bp)).getBetAmount()));

		}

		tempSFSObj.putSFSArray("SESSION_BETS", sfsArray);

		return tempSFSObj.toJson().toString();
	}

	@Override
	public String toString() {
		return "SessionBean [sessionId=" + sessionId + "]";
	}

	public void setSessionBetAmount(double totalSessionBetAmount) {
		this.totalSessionBetAmount = new BigDecimal(totalSessionBetAmount);

		System.out.println("totalSessionBetAmount+++++++++++:::::::::::::::::" + totalSessionBetAmount);
	}

}
