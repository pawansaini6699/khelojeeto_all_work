package com.latestfunroulette.playMart.cache.beans;

/**
 * Akshay Agarwal
 */

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

public class UserBetBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userId;
	private int gameId;

	List<RouletteBetBeans> tempamountwithoutsplit = new ArrayList<RouletteBetBeans>();
	HashSet<String> betnohashset = new HashSet<String>();
	private BigDecimal totalBetAmount1 = new BigDecimal(0.0);
	
	HashMap<String, RouletteBetBeans> tempRouletteBetBeansMap = new HashMap<String, RouletteBetBeans>();;
	private List<RouletteBetBeans> tempRouletteBets = new ArrayList<RouletteBetBeans>();
	// private IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean>
	// rouletteBetPlaceAmount = new RouletteBetPlaceAmountCache();

	/* Bet Status :- Save : true and default : false */
	private boolean betStatus = false;

	// private String totalBetAmount = "0";
	public int getGameId() {
		return gameId;
	}

	public void setGameId(int gameId) {
		this.gameId = gameId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
		// addBetPlaces();
	}

	public boolean isBetStatus() {
		return betStatus;
	}

	public void setBetStatus(boolean betStatus) {
		this.betStatus = betStatus;
	}

	public String getTotalBetAmount() {

		System.out.println("userbetbean::::::::::::::::::::::getTotalBetAmount"
				+ String.valueOf((Math.round(totalBetAmount1.doubleValue()))));
		return String.valueOf((Math.round(totalBetAmount1.doubleValue())));

	}

	public void setTotalBetAmount(String totalBetAmount) {
		this.totalBetAmount1 = new BigDecimal((totalBetAmount));
		System.out.println("totalBetAmount1" + totalBetAmount1);
	}

	public HashMap<String, RouletteBetBeans> getUserRouletteBets() {
		return tempRouletteBetBeansMap;
	}

	public HashMap<String, RouletteBetBeans> getUserRouletteBetsbean() {
		return tempRouletteBetBeansMap;
	}

	public void setUserRouletteBetsbean(HashMap<String, RouletteBetBeans> tempHashMap) {
		tempRouletteBetBeansMap = tempHashMap;
	}

	public RouletteBetBeans getUserplayerData(String betno) {
		return tempRouletteBetBeansMap.get(betno);
	}

	/*
	 * public List<RouletteBetBeans> getUserRouletteBets() { return
	 * tempRouletteBets; }
	 * 
	 * public List<RouletteBetBeans> getUserRouletteBetsPlayMart() { return
	 * tempamountwithoutsplit; }
	 */

	public synchronized void addUpdateRouletteBet(double coins, double splitamount, String pBetNos,
			double pBetWinAmount, boolean rebetstatus) {
		// totalBetAmount = String.valueOf(Double.parseDouble(totalBetAmount) +
		// pBetAmount);

		if (!rebetstatus) {

			totalBetAmount1 = totalBetAmount1.add(new BigDecimal(coins));

			totalBetAmount1 = totalBetAmount1.setScale(3, RoundingMode.CEILING);
		} else {
			totalBetAmount1 = totalBetAmount1.add(new BigDecimal(splitamount));
			totalBetAmount1 = totalBetAmount1.setScale(3, RoundingMode.CEILING);

		}

		Utils.Logger(GameMainExtension.extension,
				"PlayMart:::::::::::::::::::UserBetBean::::::::"
						+ "::::::addRouletteBet:::::::::::::::::::totalBetAmount1:::::::::::::::::"

						+ totalBetAmount1 + "betno" + pBetNos);

		// tempRouletteBet.setCommands(pCommand);
//		hashmapbetno.put(pBetNos,tempRouletteBet);

		updateUserBetData(pBetNos, coins, splitamount, pBetWinAmount, rebetstatus);

	}

	public void updateUserBetData(String BetNo, double coins, double splitBetAmount, double pBetWinAmount,
			boolean rebetstatus) {

		String[] tempBets = BetNo.split(",");

		for (int b = 0; b < tempBets.length; b++) {
			String pBetNos = tempBets[b].trim();
			//

			// tableKeyRouletteMap.get(tabletype);
			// suppose bet No : 5
			if (tempRouletteBetBeansMap.containsKey(pBetNos) && !rebetstatus) {
				RouletteBetBeans rouletteBetBeans = tempRouletteBetBeansMap.get(pBetNos);
				rouletteBetBeans.setBetAmount(rouletteBetBeans.getBetAmount());
				rouletteBetBeans.setSplitBetAmount(rouletteBetBeans.getSplitBetAmount() + splitBetAmount);
				rouletteBetBeans.setBetWinAmount(rouletteBetBeans.getBetWinAmount() + pBetWinAmount);
			} else {
				RouletteBetBeans tempRouletteBet = new RouletteBetBeans();
				tempRouletteBet.setBetAmount(coins);
				tempRouletteBet.setSplitBetAmount(splitBetAmount);
				tempRouletteBet.setBetNos(pBetNos);
				tempRouletteBet.setBetWinAmount(pBetWinAmount);

				tempRouletteBetBeansMap.put(pBetNos, tempRouletteBet);
			}
			Utils.Logger(GameMainExtension.extension,
					"tempRouletteBetBeansMap:::::::::::::::::::" + tempRouletteBetBeansMap);

		}

	}

	public synchronized void cancelSpecificRouletteBet(String pBetNos, double betamount, double splitamount,
			String userId) {

		System.out.println("cancelSpecificRouletteBet:::::::::::::::::::::::::::::betno:::::" + pBetNos
				+ "splitamount::::" + splitamount);

		Utils.Logger(GameMainExtension.extension,
				"play mart chance::::::::::::::UserBetBean:::::::::::::::::::::totalBetAmount1:::::::::::::::::::::::::"
						+ totalBetAmount1);

		List<String> removableBetNoList = new ArrayList<String>();
		String[] tempBets = pBetNos.split(",");
		for (int b = 0; b < tempBets.length; b++) {
			String Ubetno = tempBets[b].trim();

			System.out.println(
					"cancelSpecificRouletteBet::::::::::::::::betno::::::::::::::" + " user betno::::::: " + Ubetno);

			for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempRouletteBetBeansMap.entrySet()) {

				String betno = (String) tempRouletteBetBeans.getKey();

				RouletteBetBeans tempRouletteBetBeansplaymart = tempRouletteBetBeansMap.get(betno);

				System.out.println("betno::::::::::::::::" + betno + "user betno:::::::::::::" + Ubetno);

				if (betno.equalsIgnoreCase(Ubetno)) {

					tempRouletteBetBeansplaymart
							.setBetAmount(BigDecimal.valueOf(tempRouletteBetBeansplaymart.getBetAmount() - splitamount)
									.setScale(2, RoundingMode.HALF_UP).doubleValue());

					System.out.println("useramount:::::::::::::::::::::" + tempRouletteBetBeansplaymart.getBetAmount());
				}
				if (tempRouletteBetBeansplaymart.getBetAmount() == 0) {

					removableBetNoList.add(betno);

					System.out.println("list size::::::::::::::::::::::" + removableBetNoList);

				}
			}

		}
		System.out.println("before remove bets size:::::::::::::::::::::::::::::::" + tempRouletteBetBeansMap.size());

		for (int i = 0; i < removableBetNoList.size(); i++) {

			String betno = removableBetNoList.get(i);
			if (tempRouletteBetBeansMap.containsKey(betno)) {

				tempRouletteBetBeansMap.remove(betno);

			}
		}

		System.out.println("After remove bets size:::::::::::::::::::::::::::::::" + tempRouletteBetBeansMap.size());

	} // getSessionBetDetail(); }

	public RouletteBetBeans getCurrentRouletteBet() {
		return tempRouletteBets.get(tempRouletteBets.size() - 1);
	}

	public RouletteBetBeans getCurrentRouletteBetWithoutSplit() {
		return tempamountwithoutsplit.get(tempamountwithoutsplit.size() - 1);

	}

	public void cancelAllRouletteBet() {

		Utils.Logger(GameMainExtension.extension,
				" UserBet BEan cancelAllRouletteBet() tempRouletteBets  " + tempRouletteBets.toString());
		tempRouletteBetBeansMap.clear();

	}

	public synchronized void remainingTotalBetAmount(double totalcoins) {

		Utils.Logger(GameMainExtension.extension,
				"remainingTotalBetAmount::::::::::::::totalBetAmount1:::::::::::::::::::::::" + totalBetAmount1
						+ " totalcoins::::::::::::::: " + totalcoins);
		totalBetAmount1 = totalBetAmount1.subtract(new BigDecimal(totalcoins));
		totalBetAmount1 = totalBetAmount1.setScale(3, BigDecimal.ROUND_HALF_DOWN);

		Utils.Logger(GameMainExtension.extension, "remainingTotalBetAmount:::::::::::::::::" + totalBetAmount1);
		if (totalBetAmount1.doubleValue() < 0)
			totalBetAmount1 = new BigDecimal(0.0);

	}

	//////////////////////////////////////////////////////////////////////////

	/*
	 * public IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean>
	 * getUserBetPlaceAmount() { return rouletteBetPlaceAmount; }
	 */

	/*
	 * private void addBetPlaces() { for (int bp = 0; bp < 12; bp++) {
	 * 
	 * RouletteBetPlaceAmountBean tempRBP = new RouletteBetPlaceAmountBean();
	 * tempRBP.setBetNo(String.valueOf((bp))); rouletteBetPlaceAmount.add(tempRBP);
	 * // } } }
	 */

	@Override
	public String toString() {
		return "UserBetBean [userId=" + userId + ", betStatus=" + betStatus + ", totalBetAmount=" + totalBetAmount1
				+ ", gameId=" + gameId + "]";
	}

}
