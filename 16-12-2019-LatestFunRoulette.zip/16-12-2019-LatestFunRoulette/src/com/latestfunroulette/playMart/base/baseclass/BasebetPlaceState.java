package com.latestfunroulette.playMart.base.baseclass;

import com.latestfunroulette.common.BetNumberPlayMart;
import com.latestfunroulette.common.RemoveBetNumber;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.base.interfaces.BaseState;
import com.latestfunroulette.playMart.cache.beans.SessionBean;
import com.latestfunroulette.playMart.cache.beans.UserBetBean;
import com.smartfoxserver.v2.entities.User;

public abstract class BasebetPlaceState extends BaseState {

	@Override
	protected void init(com.latestfunroulette.playMart.cache.beans.GameBean pGameBane, int pStateTime) {
		super.init(pGameBane, pStateTime);
		SessionBean sessionBean = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
				.getValueByKey(pGameBane.getSession_id());
		if (sessionBean != null) {
			Utils.Logger(GameMainExtension.extension, "BaseState::::::::::::::::::::" + sessionBean.toString());

		} else {
			Utils.Logger(GameMainExtension.extension, "BaseState::::::::::::::::::::is null");

		}

	}

	protected void updateBetStatus(User pUser, String session_id, double coins, int number, int gameid) {

		Utils.Logger(GameMainExtension.extension, "PlayMart::::::::::::::::::BasebetPlaceState  ::::::: " + "userid"
				+ pUser + "sessionid" + session_id + "coins" + coins + "selectednumbers" + number);

		new BetNumberPlayMart(pUser, session_id, coins, number, gameid);

	}

	public void cancelSpecificBet(User user, String session_id, int betno, double betAmount) {

		// String betAmount = "";
		SessionBean tempGameSessionBean = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
				.getValueByKey(session_id);
		if (tempGameSessionBean != null) {
			UserBetBean tempUser = tempGameSessionBean.getUserBetBeanByUserId(user.getName());
			// List<RouletteBetBeans> tempRouletteBets = tempUser.getUserRouletteBets();
			if (tempUser != null) {

				// betAmount = tempUser.getTotalBetAmount();
				// betAmount = String.valueOf(tempRouletteBets.get((tempRouletteBets.size() -
				// 1)).getBetAmount());
			}
			new RemoveBetNumber(user, session_id, betAmount, betno);

			getEvents().specificClearBet(this, betAmount, user);
		}
	}

	public void clearAllBetsRoulette(User pUser, String session_id, String roomname) {
		double betamount = 0;

		SessionBean tempSessionBean = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
				.getValueByKey(session_id);
		if (tempSessionBean != null) {
			UserBetBean tempUser = tempSessionBean.getUserBetBeanByUserId(pUser.getName());
			if (tempUser != null) {

				betamount = Double.parseDouble((tempUser.getTotalBetAmount()));
			}

			tempSessionBean.cancelAllRouletteBet(pUser.getName());
			getEvents().clearBet(this, betamount, pUser);

		}

	}

	public void onUserBetSave(String roomname, User user, String session_id) {

		SessionBean tempSession = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
				.getValueByKey(session_id);
		if (tempSession != null) {
			UserBetBean tempUserBetBean = tempSession.getUserBetBeanByUserId(user.getName());

			if (tempUserBetBean != null) {
				tempUserBetBean.setBetStatus(true);
				Utils.Logger(GameMainExtension.extension, "true");
				getEvents().betSave(this, user, session_id, roomname);
			}
		}
	}

	public void betRemoveUser(String session_id, String roomname, int betno, User user, double coins) {

		// SessionBean tempSessionBean =
		// GameMainExtension.gameCacheZeroToNine.getGameSessionBySessionId().getValueByKey(session_id);

		// RemoveBetNumbersCustomise.splitBetNumbersRemove(session_id, betno, user,
		// coins);

		getEvents().betRemoveUser(this, user);

	}

	public void getGameDetailsPlayMart(String roomname, User user) {
		getEvents().getGameDetails(this, roomname, user);

	}

	public void getGameDetailsRouletteStartAndEndDatePlayMart(String roomname, User user, String startDate,
			String EndDate) {
		getEvents().getGameDetailsDateWise(this, roomname, user, startDate, EndDate);

	}

	public void betPrintExeUser(String roomname, String sessionid, User user) {

		getEvents().sendUserbetsDetails(this, roomname, sessionid, user);

	}

	public void getGameDetailsResult_PlayMart(String roomname, User user) {

		getEvents().UsersDayWiseResultDetails_PlayMart(this, roomname, user);

	}

	public void betCancelByTicketIdUser(String roomname, String sessionid, User user, String ticket_id,int gameid,double betamount) {

		getEvents().betCancelByTicketId(this, roomname, sessionid, user, ticket_id,gameid,betamount);

	}

	public void betClaimByTicketId(String roomname, String sessionid, User user, String ticket_id, int gameid,
			String gametype) {

		getEvents().betClaimByTicketId(this, roomname, sessionid, user, ticket_id, gameid, gametype);

	}
	

	public void betAllShow(String roomName, User pUser,String ticketid) {
		getEvents().getAllbetsByTicketId(this, roomName, pUser,ticketid);
	}
}
