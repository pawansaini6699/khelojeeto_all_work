package com.latestfunroulette.playMart.base.interfaces;

/**
 * 
 */


import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;

/**
 * @author Ubuntu
 *
 */
public interface IState<G> {

	void onStart(G g);

	void onProcess();

	void onJoin(String pLoginId);

	void onLeave(String pLoginId);

	void playWaitingState();

	void gameResultState();

	void onExist();
	

	default void print(String msg) { //

		// Utils.Logger(GameMainExtension.extension,"Game State machine ::::: "+msg);
		Utils.Logger(GameMainExtension.extension, "Game State Machine :::: " + msg);
	}

}