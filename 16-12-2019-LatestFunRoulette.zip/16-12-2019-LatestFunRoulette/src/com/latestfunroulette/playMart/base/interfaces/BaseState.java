package com.latestfunroulette.playMart.base.interfaces;


import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.cache.beans.GameBean;
import com.latestfunroulette.playMart.client.RTimer;
import com.latestfunroulette.playMart.common.GameEvents;
import com.latestfunroulette.playMart.common.interfaces.IGameEvents;
import com.latestfunroulette.playMart.machine.interfaces.IStateMachine;

public class BaseState {

	private RTimer tempTimer;
	private IStateMachine<GameBean> gameMachine = null;
	private GameBean tempGameBean = null;
	private IGameEvents gameEvents = null;
	private String SessionId;
	private int stateTime = 0;

	protected void init(GameBean pGameBane, int pStateTime) {
		this.tempGameBean = pGameBane;
		this.stateTime = pStateTime;
		//this.gameMachine = pGameBane.getGameMachineDoubli();
		this.gameMachine = pGameBane.getGameMachine();
		this.gameEvents = new GameEvents(GameMainExtension.extension);
		tempTimer=pGameBane.getGameMachine().getTimer();
		
		
		//addTimer();
	}

	/*
	 * public void addTimer() {
	 * 
	 * tempTimer = new RTimer();
	 * 
	 * // Utils.Logger(GameMainExtension.extension,tempTimer);
	 * 
	 * }
	 */
	public RTimer getTimer() {
		return tempTimer;
	}

	public int getStateTime() {
		return stateTime;
	}

	public IStateMachine<GameBean> getGameMachine() {
		return gameMachine;
	}
	public void setGameMachine(IStateMachine<GameBean> gameMachine) {
		this.gameMachine = gameMachine;
	}

	public IGameEvents getEvents() {
		return gameEvents;
	}

	public RTimer getTempTimer() {
		return tempTimer;
	}

	public void setTempTimer(RTimer tempTimer) {
		this.tempTimer = tempTimer;
	}

	public GameBean getTempGameBean() {
		return tempGameBean;
	}

	public void setTempGameBean(GameBean tempGameBean) {
		this.tempGameBean = tempGameBean;
	}

	public IGameEvents getGameEvents() {
		return gameEvents;
	}

	public void setGameEvents(IGameEvents gameEvents) {
		this.gameEvents = gameEvents;
	}

	public String getSessionId() {
		return SessionId;
	}

	public void setSessionId(String sessionId) {
		SessionId = sessionId;
	}

	

	public void setStateTime(int stateTime) {
		this.stateTime = stateTime;
	}

	public GameBean getGameBean() {
		return tempGameBean;
	}

	@Override
	public String toString() {
		return "BaseState [tempTimer=" + tempTimer + ", gameMachine=" + gameMachine + ", tempGameBean=" + tempGameBean
				+ ", gameEvents=" + gameEvents + ", SessionId=" + SessionId + ", stateTime=" + stateTime + "]";
	}

}
