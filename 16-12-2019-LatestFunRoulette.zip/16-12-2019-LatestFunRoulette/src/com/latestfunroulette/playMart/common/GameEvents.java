package com.latestfunroulette.playMart.common;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Events;
import com.latestfunroulette.common.Constants.Param;
import com.latestfunroulette.common.Constants.Request;
import com.latestfunroulette.common.Constants.gameStatePlatMart;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.base.interfaces.BaseState;
import com.latestfunroulette.playMart.cache.beans.GameBean;
import com.latestfunroulette.playMart.cache.beans.RouletteBetBeans;
import com.latestfunroulette.playMart.cache.beans.SessionBean;
import com.latestfunroulette.playMart.cache.beans.UserBetBean;
import com.latestfunroulette.playMart.cache.caching.interfaces.ISessionCache;
import com.latestfunroulette.playMart.client.TicketPrint;
import com.latestfunroulette.playMart.client.UpdateGameWinAmountPlayMart;
import com.latestfunroulette.playMart.common.interfaces.IGameEvents;
import com.smartfoxserver.v2.SmartFoxServer;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSArray;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.entities.data.SFSArray;
import com.smartfoxserver.v2.entities.data.SFSObject;
import com.smartfoxserver.v2.extensions.ISFSExtension;
import com.smartfoxserver.v2.extensions.SFSExtension;

public class GameEvents implements IGameEvents {

	private WeakReference<SFSExtension> ref_extension = null;
	List<SessionBean> ls = null;

	public GameEvents(SFSExtension pExtension) {
		ref_extension = new WeakReference<SFSExtension>(pExtension);

	}

	@Override
	public void sendPlayerWaiting(BaseState pState) {

	}

	@Override
	public void sendbetPlace(BaseState pState, int count) {

	}

	@Override
	public void clearBet(BaseState pState, double pbetamount, User user) {

		try {
			GameBean tempGameBean = pState.getGameBean();

			int iBetAmount = (int) Math.round((pbetamount));

			ISFSObject isfsObject = new SFSObject();
			isfsObject.putUtfString(Param.ROOM_NAME, tempGameBean.getRoomName());
			isfsObject.putUtfString(Param.MESSAGE, "Live Bets clear Successfully!!");
			isfsObject.putUtfString(Param.BETAMOUNT, String.valueOf(iBetAmount));
			isfsObject.putUtfString(Param.STATE, pState.getGameBean().getGameState());
			isfsObject.putUtfString(Param.STATUS, "true");

			tempGameBean.setRoomName(tempGameBean.getRoomName());
			GameMainExtension.gamecachePlayMart.getGames().add(tempGameBean);

			Utils.Logger(GameMainExtension.extension, "tempsfsobj" + isfsObject.getDump());
			ref_extension.get().send(Events.CLEARALL_SINGLECHANCE, isfsObject, user);

		} catch (Exception e) {
			Utils.ErrorLogger(ref_extension.get(), "GameEvents ::: clearBet() :: ERROR :: ", e);
		}

	}

	@Override
	public void gameResultState(BaseState pState) {
		// TODO Auto-generated method stub

	}

	@Override
	public void sendLiveTime(BaseState pState) {

		try {

			String updatedsessionid = String.valueOf(GameMainExtension.globlaIdPlayMart.getNextId());

			GameBean gameBean = pState.getGameBean();

			Utils.Logger(GameMainExtension.extension,
					"GameEvents:::::::::::::::::sendLiveTime ::::::::::::gmaebean" + gameBean.toString());

			int currentsessionid = Integer.parseInt(updatedsessionid);

			int wheelno = getWinminnumber();

			Utils.Logger(GameMainExtension.extension, "sendLiveTimewheelno::::::::::::::::::::::::" + wheelno);

			DBManager.UpdateLiveTimePlayPlayMart(currentsessionid, String.valueOf(wheelno), new CallBack() {

				@Override
				public void call(Object... call) {

					int oldsessionid = (int) call[0];
					int jackport = (int) call[1];

					String psessionId = String.valueOf(oldsessionid);
					int pwheelno = wheelno;
					Utils.Logger(GameMainExtension.extension,
							"GameEvents::::::::sendLiveTime:::::::::" + "gloabalid:::  " + oldsessionid
									+ "sessionid ::::::: " + psessionId + "wheelno " + pwheelno);
					Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

					UpdateGameWinAmountPlayMart.updateWinAmount(pState, psessionId, pwheelno, tempRoom, jackport,
							gameBean.getTicketid());

				}
			});

			//

		} catch (Exception e) {
			Utils.ErrorLogger(ref_extension.get(), "GameEvents ::: sendLiveTime() :: ERROR :: ", e);
		}
	}

	@Override
	public void onRebetRoulette(BaseState pState, User user, String session_id) {

		double amount = 0;
		GameBean tempGameBean = pState.getGameBean();

		Utils.Logger(ref_extension.get(), "gamebean:::::::::::::::::::::" + tempGameBean);
		ISFSObject isfsObject = new SFSObject();

		String oldsessionid = tempGameBean.getSession_id();

		SessionBean tempSession = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
				.getValueByKey(session_id);

		Utils.Logger(ref_extension.get(),
				"gamebean:::::::::::::::::::::new session:::::::::::::::::" + tempSession.toString());

		SessionBean oldtempSession = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
				.getValueByKey(oldsessionid);

		Utils.Logger(ref_extension.get(),
				"gamebean:::::::::::::::::::::oldtempSession:::::::::::::::::" + oldtempSession.toString());

		UserBetBean tempolduserbetbean = oldtempSession.getUserBetBeanByUserId(user.getName());

		tempolduserbetbean.setBetStatus(false);

		HashMap<String, RouletteBetBeans> tempRouletteBetbeanstableMap = tempolduserbetbean.getUserRouletteBets();

		Utils.Logger(GameMainExtension.extension,
				":::::::::::::   GameEvents  ::::::::::::::::::onRebetRoulette::::::: list size  ::::::"
						+ tempRouletteBetbeanstableMap.size() + "tempRouletteBetbeanstableMap:::::::::::::::::::"
						+ tempRouletteBetbeanstableMap.toString());

		for (Map.Entry<String, RouletteBetBeans> betnomapentry : tempRouletteBetbeanstableMap.entrySet()) {

			String betno = betnomapentry.getKey();

			RouletteBetBeans tempRouletteBetBeans = tempRouletteBetbeanstableMap.get(betno);

			amount = amount + tempRouletteBetBeans.getSplitBetAmount();

			System.out.println("rebet :::::::::::::::betno" + betno + "tempRouletteBetBeans::::::::::::"
					+ tempRouletteBetBeans.toString());

			tempSession.addUserBet(tempolduserbetbean.getUserId(), session_id, tempRouletteBetBeans.getBetAmount(),
					tempRouletteBetBeans.getSplitBetAmount(), tempRouletteBetBeans.getBetNos(),
					tempRouletteBetBeans.getBetWinAmount(), tempolduserbetbean.getGameId(), true);

		}

		// tempSession.setSessionBetAmount(Math.round(amount));
		// tempolduserbetbean.setTotalBetAmount(tempolduserbetbean.getTotalBetAmount());

		System.out.println(
				"GameEvents::::::::::::::::::::onrebet::::::::::::tempolduserbetbean" + tempolduserbetbean.toString());

		GameMainExtension.gamecachePlayMart.getGameSessionBySessionId().add(tempSession);

		// IRouletteBetPlaceAmountCache<String, RouletteBetPlaceAmountBean> //

		System.out.println(
				"gggggggggggggggggggggggggggggggggggggg" + oldtempSession.getUserBetBeanByUserId(user.getName()));

		Utils.Logger(GameMainExtension.extension, "tempSession" + tempSession.toString());

		Utils.Logger(GameMainExtension.extension, "onRebetRoulette::::::::::::::::::::::::::::::::::::::::::"
				+ "getbetamount " + tempolduserbetbean.getTotalBetAmount());

		isfsObject.putUtfString(Param.MESSAGE, "Rebet success");
		isfsObject.putUtfString(Param.STATUS, "true");

		Utils.Logger(GameMainExtension.extension,
				"GameEvents::::::::::::::::::onRebetRoulette::::::::Response:::::::isfsobject " + isfsObject.getDump());

		ref_extension.get().send(Events.REBET_NUMBERS_PLAYMART, isfsObject, user);

	}

	/*
	 * public void sendOnlineLobbyEvent(BaseState pState, String loginid) {
	 * 
	 * Utils.Logger(GameMainExtension.extension, "User:::::name:::::::loginid" +
	 * loginid);
	 * 
	 * GameBean gameBean = pState.getGameBean();
	 * 
	 * DBManager.userStatus(loginid, new CallBack() {
	 * 
	 * @Override public void call(Object... callback) {
	 * 
	 * ISFSObject tempSFSObj = (ISFSObject) callback[0];
	 * 
	 * Room tempRoom =
	 * ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());
	 * 
	 * List<User> tempUsers = tempRoom.getUserList(); int onlineplayerscount =
	 * tempUsers.size();
	 * 
	 * Utils.Logger(ref_extension.get(), "game bean room name" +
	 * gameBean.getRoomName() + " gamebean time  " + gameBean.getTime() +
	 * " fivewinning number " + gameBean.getLastfivenumber() +
	 * "winning number :::::: " + gameBean.getWinningnumber());
	 * 
	 * tempSFSObj.putUtfString(Param.ROOM_NAME, gameBean.getRoomName());
	 * tempSFSObj.putUtfString(Param.ONLINE_PLAYER_COUNT,
	 * String.valueOf(onlineplayerscount)); tempSFSObj.putUtfString(Param.TIMER,
	 * gameBean.getTime()); tempSFSObj.putUtfString(Param.LASTFIVENUMBER,
	 * gameBean.getLastfivenumber()); tempSFSObj.putUtfString(Param.WINNINGNUMBER,
	 * gameBean.getWinningnumber()); tempSFSObj.putUtfString(Param.STATE,
	 * pState.getGameBean().getGameState());
	 * 
	 * Utils.Logger(GameMainExtension.extension,
	 * "CommonEvents::::::::::::::::::PlayMart::::::::Response:::::::isfsobject " +
	 * tempSFSObj.getDump());
	 * 
	 * ref_extension.get().send(Events.Play_Mart_LOBBY_REQUEST, tempSFSObj,
	 * tempUsers);
	 * 
	 * } });
	 * 
	 * }
	 */

	public int getWinminnumber() {

		int wheel = DBManager.winningNumberPlayMart();

		return wheel;

	}

	@Override
	public void betinsertOnTime(BaseState baseState, long currenttime) {

		try {

			String roomname = baseState.getGameBean().getRoomName();
			String userid = baseState.getGameBean().getUserid();
			// String credits = baseState.getGameBean().getCredits();

			Utils.Logger(GameMainExtension.extension, "roomname" + roomname + "gmaebean:::::::::::::::" + baseState);

			Utils.Logger(GameMainExtension.extension, "betinsertOnTime ::: currenttime" + currenttime);

			DBManager.sendSessionIdOfRulletePlayMart(userid, baseState.getGameBean(), new CallBack() {

				@Override
				public void call(Object... callback) {
					String session_id = (String) callback[0];

					Utils.Logger(GameMainExtension.extension,
							"GameEvents :::: betinsertOnTime :::: Session Id :::: " + session_id);
					SessionBean tempSessionBean = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
							.getValueByKey(session_id);

					if (tempSessionBean != null) {
						List<UserBetBean> tempUsers = tempSessionBean.getAllUserBets();

						System.out.println("GameEvents:::::::::::::::::::::::::::tempUsers::::::::::::::::::::"
								+ tempUsers.toString());

						int userSize = tempUsers.size();

						Utils.Logger(GameMainExtension.extension,
								"GameEvents :::::betinsertOnTime::::::: before User size :::: " + userSize);

						try {

							for (int u = 0; u < userSize; u++) {
								UserBetBean tempUserBetBean = tempUsers.get(u);

								Utils.Logger(GameMainExtension.extension,
										"GameEvents :::::betinsertOnTime::::::: UserBetBean::::::::::: "
												+ tempUserBetBean.toString() + "total amount :::::::::");

								if (Double.parseDouble(tempUserBetBean.getTotalBetAmount()) != 0) {
									if (tempUserBetBean != null && !tempUserBetBean.isBetStatus()) {
										tempSessionBean.cancelAllRouletteBet(tempUserBetBean.getUserId());
										--u;
										--userSize;
									} else {

										try {

											String userid = tempUserBetBean.getUserId();
											// int gameid = tempUserBetBean.getGameId();

											Utils.Logger(GameMainExtension.extension,
													"GameEvents :::::betinsertOnTime::::::: ::::: Update live_update_roulette_history user id :::: "
															+ userid);
											Utils.Logger(GameMainExtension.extension,
													"GameEvents :::::betinsertOnTime::::::: :::: User Id :::: " + userid
															+ " :::: Session Id ::: " + session_id
															+ " :::: Total Bet Amount :::  "
															+ tempUserBetBean.getTotalBetAmount());

											DBManager.insertPlayMartsql(session_id, tempUserBetBean, 1,
													baseState.getGameBean());

										} catch (Exception e) {
											Utils.ErrorLogger(GameMainExtension.extension,
													"GameEvents :::::betinsertOnTime::::::: ::::: Upload data insertLiveRouletteBets in loop server error ::::: ",
													e);
										}

									}
								}
							}

						} catch (Exception e) {
							Utils.ErrorLogger(GameMainExtension.extension,
									"GameEvents :::::betinsertOnTime::::::: :::: Remove Loop Error :::: ", e);
						}

					}
				}
			});

		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension, "SendServerLivetimer :::: Error ::::: ", e);
		}
	}

	@Override
	public void newSessionGenarate(BaseState basestate) {

		Utils.Logger(GameMainExtension.extension,
				"SingleChance::::::::::::GameEvents:::::::::::::basestate" + basestate.toString());

		GameBean gameBean = basestate.getGameBean();
		String roomname = gameBean.getRoomName();
		String userid = gameBean.getUserid();
		// String sessionid=gameBean.getSession_id();

		String currenttime = String.valueOf(basestate.getTimer().getElapsedTime());

		int time = 60 - (Integer.parseInt(currenttime));

		Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());
		List<User> tempUsers = tempRoom.getUserList();
		int onlineplayerscount = tempUsers.size();

		new Thread() {
			@Override
			public void run() {
				try {

					DBManager.sendSessionIdOfRulletePlayMart(userid, gameBean, new CallBack() {

						@Override
						public void call(Object... callback) {
							String session_id = (String) callback[0];
							String status = (String) callback[1];
							String resultwheel = (String) callback[2];
							String credits = (String) callback[3];
							String lastfivewinningnumber = (String) callback[4];
							String oldSessionId = (String) callback[5];
							String jackport = (String) callback[6];

							Utils.Logger(GameMainExtension.extension,
									"newSessionGenarate:::::::::::::oldSessionId" + oldSessionId + "credits" + credits);

							ISFSObject isfsObject = new SFSObject();
							isfsObject.putUtfString(Param.SESSION_ID, session_id);
							isfsObject.putUtfString(Param.WINNINGNUMBER, resultwheel);
							isfsObject.putInt(Param.TIMER, time);
							isfsObject.putUtfString(Param.STATE, basestate.getGameBean().getGameState());
							isfsObject.putUtfString(Param.LASTFIVENUMBER, lastfivewinningnumber);
							isfsObject.putInt(Param.ONLINE_PLAYER_COUNT, onlineplayerscount);
							isfsObject.putUtfString(Param.ROOM_NAME, roomname);
							isfsObject.putUtfString(Param.STATUS, status);
							isfsObject.putInt(Param.BETPLACETIME, gameStatePlatMart.BET_PLACE_TIME);
							isfsObject.putUtfString(Param.JACKPORT, jackport);

							Utils.Logger(GameMainExtension.extension,
									"PlayMart::::::::::::::::::::::GameEvents:::::::::::::::::newSessionGenarate::::::::::isfsObject:::::"
											+ isfsObject.getDump());

							ref_extension.get().send(Request.NEWSESSIONGENERATE, isfsObject, tempUsers);

							// String new_session_id1 = randomString(40);

							// GameMainExtension.cache.getSession().updateCurrentSession(session_id);

							print("RouletteGameExtension ::::51 New Session ::::: " + session_id);

							// tempsessionbean.setSessionId(session_id);

							SessionBean tempsessionbean1 = new SessionBean();

							gameBean.setSession_id(oldSessionId);
							GameMainExtension.gamecachePlayMart.getGames().add(gameBean);

							tempsessionbean1.setSessionId(session_id);

							// Utils.Logger(GameMainExtension.extension,
							// "RouletteGameExtension ::::51 New Session ::::: " +
							// tempsessionbean.toString());

							ISessionCache<String, SessionBean> tempSessionCache = GameMainExtension.gamecachePlayMart
									.getGameSessionBySessionId();

							if (tempSessionCache == null) {
								Utils.Logger(GameMainExtension.extension,
										"RouletteGameExtension :::: Session Cache is null");
							} else {
								Utils.Logger(GameMainExtension.extension,
										"RouletteGameExtension :::: Session Cache is not null");
								// tempSessionCache.clearAllSession();

								tempSessionCache.add(tempsessionbean1);

								Set<String> set = tempSessionCache.getAll().keySet();

								for (String s : new ArrayList<String>(set)) {

									String url = s;

									if (url.equalsIgnoreCase(session_id)) {
										Utils.Logger(GameMainExtension.extension, " Value = " + url);
									} else if (url.equalsIgnoreCase(oldSessionId)) {

										Utils.Logger(GameMainExtension.extension, " Value = " + url);
									} else {
										tempSessionCache.delete(s);
									}

								}

							}

						}
					});
				} catch (Exception e) {
					Utils.ErrorLogger(GameMainExtension.extension, "newSessionGenarate RunMethod :::::: Error :::: ",
							e);
				}

			}
		}.start();
	}

	@Override
	public void onJoinSendUserData(BaseState baseState, String loginId) {

		GameBean gameBean = baseState.getGameBean();
		gameBean.setUserid(loginId);

		GameMainExtension.gamecachePlayMart.getGames().add(gameBean);
		Utils.Logger(GameMainExtension.extension, "gamebean" + gameBean.toString());

		String roomname = gameBean.getRoomName();

		Utils.Logger(GameMainExtension.extension, "User:::::name:::::::" + loginId + " roomname::::::::" + roomname);

		new Thread() {
			public void run() {

				DBManager.getLastFiveNumberPlayMart(loginId, new CallBack() {

					@Override
					public void call(Object... callback) {

						Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

						User user = tempRoom.getUserByName(loginId);
						String currenttime = String.valueOf(baseState.getTimer().getElapsedTime());

						int time = (60 - Integer.parseInt(currenttime));

						Utils.Logger(GameMainExtension.extension,
								"sendPlayMartEvent::::::::::gamebean" + gameBean.toString());
						// Player tempPlayer =
						// GameMainExtension.cache.getPlayer().getValueByKey(loginId);
						ISFSObject isfsObject = (ISFSObject) callback[0];
						Utils.Logger(GameMainExtension.extension, "ROOM NAME" + tempRoom.getName());
						List<User> tempUsers = tempRoom.getUserList();
						int onlineplayerscount = tempUsers.size();

						isfsObject.putUtfString(Param.ONLINE_PLAYER_COUNT, String.valueOf(onlineplayerscount));
						isfsObject.putUtfString(Param.ROOM_NAME, "PLAY_MART_ROOM");

						// isfsObject.putUtfString(Param.TIMER, String.valueOf(time));
						isfsObject.putUtfString(Param.TIMER, String.valueOf(time));
						isfsObject.putUtfString(Param.STATE, baseState.getGameBean().getGameState());

						Utils.Logger(GameMainExtension.extension,
								"CommonEvents::::::::::::::::::sendSingleRouletteLobbyEvent::::::::Response:::::::isfsobject "
										+ isfsObject.getDump());

						ref_extension.get().send(Events.PLAY_MART_LOBBY_REQUEST, isfsObject, user);

					}
				});

			};
		}.start();
	}

	@Override
	public void currentSystemTmer(int time) {

		try {
			ISFSExtension tempSFSExtension = SmartFoxServer.getInstance().getZoneManager().getZoneByName("RouletteGame")
					.getExtension();
			ISFSObject obj = new SFSObject();
			obj.putInt(Param.CURRENT_TIME, time);
			Utils.Logger(GameMainExtension.extension,
					"GameEvent:::::::::::currentSystemTmer  ::::  Params ::::: " + obj.getDump());
			tempSFSExtension.handleClientRequest(Request.CURRENTTIME, null, obj);

		} catch (Exception e) {
			Utils.ErrorLogger(GameMainExtension.extension, "currentSystemTmer :::::: Error :::: ", e);
		}

	}

	@Override
	public void onLeaveUserRoom(BaseState baseState, String loginId) {

	}

	@Override
	public void betSave(BaseState baseState, User tempuser1, String session_id, String roomname) {

		GameBean tempGameBean = baseState.getGameBean();

		SessionBean tempSession = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
				.getValueByKey(session_id);

		System.out.println("gameevents:::::::::::::::tempSession:::::::::::::::::::::" + tempSession.toString());

		Utils.Logger(GameMainExtension.extension, "GameEvents::::::::::::userid:::::::::::::::::" + tempuser1
				+ " sessionid " + session_id + "roomname" + roomname);

		if (tempSession != null) {

			UserBetBean userBetBean = tempSession.getUserBetBeanByUserId(tempuser1.getName());

			Utils.Logger(GameMainExtension.extension,
					"PLayMART :::::::::::::::gameevents::::::::::::::::::::::::::::::::::::::::::userBetBean"
							+ userBetBean.toString());

			int gameid = userBetBean.getGameId();

			if (userBetBean != null && gameid == 14 && tempGameBean.isPrintstatus() == true) {

				userBetBean.setBetStatus(true);

			} else if (userBetBean != null && gameid == 13 && gameid == 15) {

				userBetBean.setBetStatus(true);

			}

			// final int i1=i;
			DBManager.BetOkUpdateBalance(tempuser1.getName(), userBetBean.getTotalBetAmount(), new CallBack() {

				@Override
				public void call(Object... call) {
					try {
						double currentbalance = (double) call[0];
						double totalbetamount = Double.parseDouble((userBetBean.getTotalBetAmount()));
						Utils.Logger(GameMainExtension.extension, "betokbalance::::::::::::currentbalance"
								+ currentbalance + "totalbetamount:::::" + totalbetamount);

						Utils.Logger(GameMainExtension.extension, "betokbalance::::::::::::updated balance"
								+ currentbalance + "totalbetamount:::::" + userBetBean.getTotalBetAmount());

						tempGameBean.setCredits(String.valueOf(currentbalance));

						// int onlineplayerscount = tempUsers.size();

						ISFSObject isfsObject = new SFSObject();
						isfsObject.putUtfString(Param.USERID, tempuser1.getName());
						isfsObject.putUtfString(Param.SESSION_ID, session_id);
						isfsObject.putUtfString(Param.MESSAGE, "Bet Save Successfully");
						isfsObject.putUtfString(Param.TOTALBETAMT, String.valueOf(currentbalance));
						isfsObject.putUtfString(Param.STATE, "2");
						isfsObject.putUtfString(Param.STATUS, "true");
						Utils.Logger(GameMainExtension.extension, "RESPONSE::::::::::" + isfsObject.getDump());

						GameMainExtension.extension.send(Request.BETOK, isfsObject, tempuser1);

					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}

			});

		}
	}

	@Override
	public void betSaveOnTime(BaseState baseState) {

		GameBean gameBean = baseState.getGameBean();
		String userid = gameBean.getUserid();
		String currenttime = String.valueOf(baseState.getTimer().getElapsedTime());

		int time = 60 - (Integer.parseInt(currenttime));

		Player player = GameMainExtension.cache.getPlayer().getValueByKey(userid);

		Room tempRoom = ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

		List<User> tempUsers1 = tempRoom.getUserList();

		ISFSObject isfsObject = new SFSObject();
		isfsObject.putInt(Param.TIMER, time);
		isfsObject.putUtfString(Param.STATE, "2");
		isfsObject.putUtfString(Param.STATUS, "true");

		Utils.Logger(GameMainExtension.extension,
				"SingleROuletteGame:::::::::::::::::::::::GameEvents::::::::::::::::betSaveOnTime::::::::::::isfsobj:::::"
						+ isfsObject.getDump());

		GameMainExtension.extension.send(Events.STATEHANDLER, isfsObject, tempUsers1);

		if (player == null) {

			Utils.Logger(GameMainExtension.extension, "null");

		} else {
			// User user = player.getUser();

			DBManager.sendSessionIdOfRulletePlayMart(userid, baseState.getGameBean(), new CallBack() {

				@Override
				public void call(Object... callback) {
					String session_id = (String) callback[0];

					Utils.Logger(GameMainExtension.extension,
							"SendServerLiveTimer ::::betSaveOnTime:::::::::::: sendSessionIdOfRulletePlayMart :::: Session Id :::: "
									+ session_id);
					SessionBean tempSessionBean = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
							.getValueByKey(session_id);

					if (tempSessionBean != null) {

						Utils.Logger(GameMainExtension.extension, "SendServerLiveTimer ::::betSaveOnTime::::::::::::"
								+ "tempSessionBean ::::::::::::::" + tempSessionBean.toString());

						List<UserBetBean> tempUsers = tempSessionBean.getAllUserBets();

						System.out.println("tempUsers::::::::::::::::" + tempUsers.toString());

						int userSize = tempUsers.size();

						Utils.Logger(GameMainExtension.extension, " 50::::::::timer:::::  User size :::: " + userSize);

						try {

							for (int u = 0; u < userSize; u++) {

								UserBetBean tempUserBetBean = tempUsers.get(u);

								Utils.Logger(GameMainExtension.extension, "status" + tempUserBetBean.isBetStatus()
										+ "tempUserBetBean::::::::" + tempUserBetBean.toString());

								if (tempUserBetBean != null && !tempUserBetBean.isBetStatus()) {

									// String userid = tempUserBetBean.getUserId();

									User user = tempRoom.getUserByName(tempUserBetBean.getUserId());
									try {
										Utils.Logger(GameMainExtension.extension,
												"user::::::::::::::" + user.getName());
										Utils.Logger(GameMainExtension.extension,
												"roomname::::::::::::::" + tempRoom.getName());

									} catch (Exception e) {
										Utils.Logger(GameMainExtension.extension, "error ::::::::::::::::::::" + e);
									}
									Utils.Logger(GameMainExtension.extension,
											"PlayMartGame:::::::::::::::::::::::GameEvents::::::::::::::::betSaveOnTime:::::::::::::::user"
													+ user.getName() + "roomname" + tempRoom.getName()
													+ "player:::::::::::::" + player.toString());

									betSave(baseState, user, session_id, tempRoom.getName());

								}
							}

						} catch (Exception e) {
							Utils.ErrorLogger(GameMainExtension.extension, "error" + e);
						}
					}

				}

			});

		}
	}

	@Override
	public void specificClearBet(BaseState pstState, double betamount, User user) {
		GameBean gameBean = pstState.getGameBean();

		if (gameBean != null) {

			// List<User> tempUsers = tempRoom.getUserList();

			ISFSObject isfsObject = new SFSObject();
			isfsObject.putUtfString(Param.CREDITS, String.valueOf(betamount));
			isfsObject.putUtfString(Param.STATUS, "true");
			ref_extension.get().send(Request.REMOVE_BET_PLAYMART_CUSTOMISE_REQUEST, isfsObject, user);

		}

	}

	@Override
	public void betRemoveUser(BaseState baseState, User user) {

		GameBean gameBean = baseState.getGameBean();
		// Room tempRoom =
		// ref_extension.get().getParentZone().getRoomByName(gameBean.getRoomName());

		if (gameBean != null) {

			// List<User> tempUsers = tempRoom.getUserList();

			ISFSObject isfsObject = new SFSObject();
			isfsObject.putUtfString(Param.MESSAGE, "Remove Bet Successfully");
			isfsObject.putUtfString(Param.STATUS, "true");
			ref_extension.get().send(Request.BETREMOVECUSTOMISEZEROTONINE, isfsObject, user);

		}

	}

	@Override
	public void getGameDetails(BaseState baseState, String roomname, User user) {

		GameBean gameBean = baseState.getGameBean();

		if (gameBean != null) {

			DBManager.getUserGameDetail_PlayMart(user.getName(), new CallBack() {

				@Override
				public void call(Object... callback) {

					ISFSArray tempHistoryList = (ISFSArray) callback[0];

					ISFSObject tempSFSObj = new SFSObject();

					tempSFSObj.putSFSArray(Param.USER_GAME_LIST, tempHistoryList);
					print("Response ::getSharePointDetailsByUserId:: Prames ::: " + tempSFSObj.getDump());

					print("Response ::getSharePointDetailsByUserId:: Prames ::: " + tempSFSObj.getDump());

					GameMainExtension.extension.send(Request.USER_GAME_DETAILS_DAY_WISE__PLAYMART, tempSFSObj, user);

				}
			});

		}

	}

	@Override
	public void getGameDetailsDateWise(BaseState baseState, String roomname, User user, String startDate,
			String EndDate) {

		GameBean gameBean = baseState.getGameBean();

		if (gameBean != null) {

			DBManager.getUserGameTurnOver(user.getName(), startDate, EndDate, new CallBack() {

				@Override
				public void call(Object... callback) {

					ISFSArray tempHistoryList = (ISFSArray) callback[0];
					ISFSObject tempSFSObj = new SFSObject();
					tempSFSObj.putSFSArray(Param.USER_GAME_LIST, tempHistoryList);
					print("Response ::getSharePointDetailsByUserId:: Prames ::: " + tempSFSObj.getDump());
					GameMainExtension.extension.send(Request.USER_GAME_DETAILS_DATE_WISE_PLAYMART, tempSFSObj, user);

				}
			});

		}

	}

	@Override
	public void sendUserbetsDetails(BaseState baseState, String roomname, String sessionid, User user) {
		Utils.Logger(GameMainExtension.extension, "sessionid:::::::::::::::::::" + sessionid + "roomname" + roomname);

		String betnos = "";
		double betamount = 0;

		ISFSArray isfsArray = new SFSArray();

		List<String> temproulettebeanList = TicketPrint.getTempRouletteBetBeans();
		List<RouletteBetBeans> temproulettebean = new ArrayList<RouletteBetBeans>();
		SessionBean oldtempSession = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
				.getValueByKey(sessionid);
		UserBetBean tempolduserbetbean = oldtempSession.getUserBetBeanByUserId(user.getName());
		HashMap<String, RouletteBetBeans> tempRoulettebetBeanMap = tempolduserbetbean.getUserRouletteBets();

		System.out.println("tempolduserbetbean::::::::::::::" + tempolduserbetbean.toString());

		System.out.println("tempRoulettebetBeanMap:::::::::::::::" + tempRoulettebetBeanMap.toString());

		HashMap<String, List<RouletteBetBeans>> ticketGenerateHashMap = TicketPrint.getTicketGenerateHashMap();

		for (Map.Entry<String, RouletteBetBeans> tempRouletteBetBeans : tempRoulettebetBeanMap.entrySet()) {
			RouletteBetBeans tempRouletteBetBeanssinglechance = tempRoulettebetBeanMap
					.get((String) tempRouletteBetBeans.getKey());
			ISFSObject isfsObject = new SFSObject();
			betnos = tempRouletteBetBeanssinglechance.getBetNos();
			betamount = tempRouletteBetBeanssinglechance.getBetAmount();

			isfsObject.putUtfString(Param.BETNO, betnos);
			isfsObject.putDouble(Param.BETAMOUNT, betamount);
			isfsArray.addSFSObject(isfsObject);

			temproulettebean.add(tempRouletteBetBeanssinglechance);

		}
		String ticketid = "";

		try {

			DBManager.insertPlayMartsql(sessionid, tempolduserbetbean, 0, baseState.getGameBean());
			ticketid = baseState.getGameBean().getTicketid();
			ticketGenerateHashMap.put(ticketid, temproulettebean);
			temproulettebeanList.add(ticketid);
		} catch (Exception e) {

			System.out.println("error::::::::::::::::::::::::::::::e" + e);
		}

		GameBean gameBean = baseState.getGameBean();

		// TicketPrint.setTicketGenerateHashMap(ticketGenerateHashMap);

		if (gameBean != null) {

			// List<User> tempUsers = tempRoom.getUserList();

			System.out.println("hello");

			System.out.println("isfsArray:::::::::::::::::" + isfsArray);

			ISFSObject isfsObject1 = new SFSObject();
			isfsObject1.putUtfString(Param.SESSIONID, sessionid);
			isfsObject1.putUtfString(Param.USERID, user.getName());
			isfsObject1.putUtfString(Param.TICKETID, ticketid);
			isfsObject1.putUtfString(Param.USERID, user.getName());
			isfsObject1.putSFSArray("BETDETAILS", isfsArray);

			GameMainExtension.extension.send(Request.PRINT_BET_NUMBERS_PLAYMART, isfsObject1, user);

		}

		tempolduserbetbean.setUserRouletteBetsbean(new HashMap<String, RouletteBetBeans>());

		tempolduserbetbean.setTotalBetAmount("0");

		oldtempSession.setSessionBetAmount(0);
	}

	@Override
	public void UsersDayWiseResultDetails_PlayMart(BaseState baseState, String roomaname, User user) {

		GameBean gameBean = baseState.getGameBean();

		if (gameBean != null) {

			DBManager.PlayMart_getUsersDayWiseResult(new CallBack() {

				@Override
				public void call(Object... callback) {

					ISFSArray tempHistoryList = (ISFSArray) callback[0];
					ISFSObject tempSFSObj = new SFSObject();
					tempSFSObj.putSFSArray(Param.USER_GAME_LIST, tempHistoryList);
					print("Response ::PlayMart_getUsersDayWiseResult playmart:: Prames ::: " + tempSFSObj.getDump());
					GameMainExtension.extension.send(Request.GET_USERS_DAY_WISE_RESULT_PLAYMART, tempSFSObj, user);

				}
			});

		}

	}

	@Override
	public void betCancelByTicketId(BaseState baseState, String roomaname, String sessionid, User user,
			String ticket_id, int gameid, double totalbetamount) {
		Utils.Logger(GameMainExtension.extension, "baseState:::::::::::::" + baseState + " roomaname::::::::"
				+ roomaname + "sessionid:::::::::::::::::" + sessionid);

		String betnos = "";
		double betamount = 0;

		ISFSArray isfsArray = new SFSArray();
		HashMap<String, List<RouletteBetBeans>> ticketGenerateHashMap = TicketPrint.getTicketGenerateHashMap();

		List<RouletteBetBeans> tempRouletteBetBeans = TicketPrint.getTicketGenerateList(ticket_id);

		Utils.Logger(GameMainExtension.extension,
				"tempRouletteBetBeans::::::::::::::::" + tempRouletteBetBeans.toString());

		for (RouletteBetBeans rouletteBetBeans : tempRouletteBetBeans) {

			ISFSObject isfsObject = new SFSObject();
			betnos = rouletteBetBeans.getBetNos();
			betamount = rouletteBetBeans.getBetAmount();

			isfsObject.putUtfString(Param.BETNO, betnos);
			isfsObject.putDouble(Param.BETAMOUNT, betamount);
			isfsArray.addSFSObject(isfsObject);

		}

		DBManager.getAllCancelTicketByTicketid(user.getName(), ticket_id, gameid, totalbetamount, new CallBack() {

			@Override
			public void call(Object... values) {

				ISFSObject isfsObject1 = new SFSObject();
				isfsObject1.putUtfString(Param.SESSIONID, sessionid);
				isfsObject1.putUtfString(Param.USERID, user.getName());
				isfsObject1.putUtfString(Param.TICKETID, ticket_id);
				isfsObject1.putUtfString(Param.USERID, user.getName());
				isfsObject1.putSFSArray("BETDETAILS", isfsArray);
				isfsObject1.putUtfString(Param.MESSAGE, "cancel bet successfully");

				Utils.Logger(GameMainExtension.extension, "isfsObject1::::::::::::::::::::" + isfsObject1.getDump());

				ref_extension.get().send(Request.CANCEL_BET_NUMBERS_BY_TICKET_PLAYMART, isfsObject1, user);

				if (tempRouletteBetBeans.size() > 0) {
					tempRouletteBetBeans.remove(tempRouletteBetBeans.size() - 1);
					ticketGenerateHashMap.remove(ticket_id);

				}
				// TODO Auto-generated method stub

			}
		});

	}

	@Override
	public void betClaimByTicketId(BaseState baseState, String roomaname, String sessionid, User user, String ticket_id,
			int gameid, String gametype) {
		Utils.Logger(GameMainExtension.extension,
				"PLAYMART::::::::::::::::::::::::GameEvnets::::::::::::::::::::::::::betClaimByTicket:::"
						+ baseState.getGameBean() + "roomname::::::::::::" + roomaname + "user::::::::::"
						+ user.getName() + "gameid:::::::::::::::" + gameid + " gmaetype:::::" + gametype);
		GameBean gameBean = baseState.getGameBean();

		if (gameBean != null) {

			DBManager.getAllGamesClaimStatus(user.getName(), ticket_id, gameid, gametype, new CallBack() {

				@Override
				public void call(Object... callback) {

					ISFSObject tempSFSObj = (ISFSObject) callback[0];

					print("Response ::betClaimByTicket:: Prames ::: " + tempSFSObj.getDump());
					GameMainExtension.extension.send(Request.CLAIM_BET_NUMBERS_BY_TICKET_PM, tempSFSObj, user);

				}
			});

		}

	}

	@Override
	public void getAllbetsByTicketId(BaseState baseState, String roomname, User user, String ticketid) {

		GameBean gameBean = baseState.getGameBean();

		if (gameBean != null) {

			DBManager.getAllbetsByTicketIdPlayMart(ticketid, new CallBack() {

				@Override
				public void call(Object... callback) {

					ISFSArray tempHistoryList = (ISFSArray) callback[0];
					ISFSObject tempSFSObj = new SFSObject();
					tempSFSObj.putSFSArray(Param.BET_LIST, tempHistoryList);
					print("Response ::getAllbetsByTicketId:: Prames ::: " + tempSFSObj.getDump());
					GameMainExtension.extension.send(Request.GET_BET_ALL_DETAILS_SC, tempSFSObj, user);

				}
			});
		}
	}

}
