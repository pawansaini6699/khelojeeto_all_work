package com.latestfunroulette.playMart.common.interfaces;

public interface IGloblaIdPlayMart {
	
	void updateId();

	int getCurrentId();

	int getNextId();

	String getNextId(String f);

}
