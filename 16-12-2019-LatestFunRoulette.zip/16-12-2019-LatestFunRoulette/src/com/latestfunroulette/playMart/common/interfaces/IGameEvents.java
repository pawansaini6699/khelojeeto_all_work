package com.latestfunroulette.playMart.common.interfaces;

import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.base.interfaces.BaseState;
import com.smartfoxserver.v2.entities.User;

public interface IGameEvents {

	void sendLiveTime(BaseState pState);

	void sendPlayerWaiting(BaseState pState);

	void sendbetPlace(BaseState pState, int time);

	void clearBet(BaseState pState, double betAmount, User user);

	void onRebetRoulette(BaseState pState, User user, String session_id);

	// void gameResultWaitingState(BaseState pState);

	void gameResultState(BaseState pState);

//	void sendOnlineLobbyEvent(BaseState pstState, String loginid);

	void currentSystemTmer(int time);

	void specificClearBet(BaseState pstState, double betamount, User user);

	public void newSessionGenarate(BaseState baseState);

	void betSave(BaseState baseState, User user, String session_id, String roomname);

	void betRemoveUser(BaseState baseState, User user);

	public void betinsertOnTime(BaseState baseState, long currenttime);

	public void onJoinSendUserData(BaseState baseState, String loginId);

	public void onLeaveUserRoom(BaseState baseState, String loginin);

	void betSaveOnTime(BaseState baseState);

	default void print(String msg) {
		Utils.Logger(GameMainExtension.extension, "GameEvents :::: " + msg);
	}

	void getGameDetails(BaseState baseState, String roomname, User user);

	void getGameDetailsDateWise(BaseState baseState, String roomname, User user, String StartDate, String endDate);

	void sendUserbetsDetails(BaseState baseState, String roomaname, String sessionid, User user);

	void UsersDayWiseResultDetails_PlayMart(BaseState baseState, String roomaname, User user);

	void betCancelByTicketId(BaseState baseState, String roomaname, String sessionid, User user, String ticket_id,int gameid,double betamount);

	void betClaimByTicketId(BaseState baseState, String roomaname, String sessionid, User user, String ticket_id,
			int gameid, String gametypeid);

	void getAllbetsByTicketId(BaseState baseState, String roomname, User user, String ticketid);
}