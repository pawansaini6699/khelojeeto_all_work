package com.latestfunroulette.playMart.client;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import com.latestfunroulette.cache.beans.Player;
import com.latestfunroulette.common.CallBack;
import com.latestfunroulette.common.Constants.Events;
import com.latestfunroulette.common.DBManager;
import com.latestfunroulette.common.Utils;
import com.latestfunroulette.extension.GameMainExtension;
import com.latestfunroulette.playMart.base.interfaces.BaseState;
import com.latestfunroulette.playMart.cache.beans.GameBean;
import com.latestfunroulette.playMart.cache.beans.RouletteBetBeans;
import com.latestfunroulette.playMart.cache.beans.SessionBean;
import com.latestfunroulette.playMart.cache.beans.UserBetBean;
import com.smartfoxserver.v2.entities.Room;
import com.smartfoxserver.v2.entities.User;
import com.smartfoxserver.v2.entities.data.ISFSObject;
import com.smartfoxserver.v2.extensions.SFSExtension;

import scala.ref.WeakReference;

public class UpdateGameWinAmountPlayMart {
	
	@SuppressWarnings("unused")
	private WeakReference<SFSExtension> ref_extension = null;

	public UpdateGameWinAmountPlayMart(SFSExtension extension) {
		ref_extension = new WeakReference<SFSExtension>(extension);
	}

	public static void updateWinAmount(BaseState basestate, String pSession, int pWinnumber, Room roomname,
			int jackport, String ticketid) {

		new Thread() {
			@Override
			public void run() {

				Utils.Logger(GameMainExtension.extension,
						"UpdateGameWinAmountManager" + "sessionid" + pSession + " winnnumber" + pWinnumber);

				GameBean gameBean = basestate.getGameBean();
				Player player = GameMainExtension.cache.getPlayer().getValueByKey(gameBean.getUserid());
				SessionBean tempSession = GameMainExtension.gamecachePlayMart.getGameSessionBySessionId()
						.getValueByKey(pSession);
				Room tempRoom = GameMainExtension.extension.getParentZone().getRoomByName(gameBean.getRoomName());

				Utils.Logger(GameMainExtension.extension,
						"UpdateGameWinAmountPlayMart:::::::::::::::::::::::::sessionbean" + tempSession);
				double winamount = 0;
				double amount;
				long tempWinnumberBetAmount = 0;
				String tempWinamount = "";
				int userexistStatus = 1;
				if (tempSession != null) {

					List<UserBetBean> tempUserBetBeans = tempSession.getAllUserBets();
					if (tempUserBetBeans != null) {
						for (int u = 0; u < tempUserBetBeans.size(); u++) {
							UserBetBean tempUser = tempUserBetBeans.get(u);
							int gameid = tempUser.getGameId();
							User tempSFSUser = tempRoom.getUserByName(tempUser.getUserId());

							if (tempUser != null && tempUser.isBetStatus()) {
								List<String> tempStrings = TicketPrint.getTempRouletteBetBeans();

								System.out.println(
										"UpdateGameWinAmountPlayMart:::::::::::::tempStrings:::::::::" + tempStrings);

								if (tempStrings != null && tempStrings.size() > 0) {

									for (String ticketno : tempStrings) {

										System.out.println("UpdateGameWinAmountPlayMart:::::::::::::ticketno:::::::::"
												+ tempStrings);

										RouletteBetBeans tEMPBeans = TicketPrint
												.getRouletteBeanByWinningNumberandTicketId(ticketno,
														String.valueOf(pWinnumber));

										if (tEMPBeans != null) {

											tempWinnumberBetAmount = (long) tEMPBeans.getSplitBetAmount();
											Utils.Logger(GameMainExtension.extension,
													"UpdateGameWinAmountPlayMart:::::::::::::::::::::tempWinnumberBetAmount::"
															+ tempWinnumberBetAmount + "jackport" + jackport);

											Utils.Logger(GameMainExtension.extension,
													"UpdateGameWinAmountPlayMart:::::::::::::::::::::tempWinnumberBetAmount::"
															+ tempWinnumberBetAmount + "jackport" + jackport);

											winamount = tempWinnumberBetAmount * 9 * jackport;
										} else {
											winamount = 0;
										}

										gameBean.setWinner(String.valueOf(winamount));

// BigDecimal tempBigDecimal = new BigDecimal((tempWinnumberBetAmount *36));
										tempWinamount = String.valueOf(winamount);

										Utils.Logger(GameMainExtension.extension,
												"UpdateGameWinAmountManager::::::::" + "tempWinamount" + tempWinamount);

										if (tempSFSUser != null) {
											Utils.Logger(GameMainExtension.extension,
													"---------- UpdateUserCreditsbeforeTakeHandler----------userexistStatus "
															+ userexistStatus);

											userexistStatus = 0;
										}

										gameBean.setTotalsessionwinamount(String.valueOf(winamount));
										GameMainExtension.gamecachePlayMart.getGames().add(gameBean);

										DBManager.updateUserWinAmountsqlPlayMart(tempUser.getUserId(), jackport,
												tempWinamount, pWinnumber, pSession, ticketno, new CallBack() {

													@Override
													public void call(Object... callback) {

														ISFSObject isfsObject = (ISFSObject) callback[0];

// isfsObject.putUtfString(Param.WINAMOUNT,
// String.valueOf(winamountuser));
														Utils.Logger(GameMainExtension.extension,
																"---------- UpdateUserCreditsbeforeTakeHandler----------response "
																		+ isfsObject.getDump());
														GameMainExtension.extension.send(Events.UPDATEUSERCREDITS,
																isfsObject, tempSFSUser);

													}
												});

										DBManager.updateUserWinAmountMongoPlayMart(tempUser.getUserId(), pSession,
												jackport, pWinnumber, tempWinamount, userexistStatus,
												player.getChips());

									}

									Utils.Logger(GameMainExtension.extension,
											"::::::::: UpdateGameWinAmount :::::::::::::totalsessionbetamount"
													+ tempSession.getTotalBetAmount()
													+ "::::::::::: winamount ::::::::::::::::" + winamount);
									DBManager.updateLiveTimeDataPlayMart(tempSession.getTotalBetAmount(),
											String.valueOf(winamount), gameid,jackport);

								} else {

									RouletteBetBeans tempRoulettebeansPlayMart = tempUser
											.getUserplayerData(String.valueOf(pWinnumber));

									if (tempRoulettebeansPlayMart != null) {
										amount = (tempRoulettebeansPlayMart.getSplitBetAmount());
										winamount = amount * 10 * jackport;
										winamount = BigDecimal.valueOf(winamount).setScale(2, RoundingMode.HALF_UP)
												.doubleValue();
										Utils.Logger(GameMainExtension.extension,
												"PLAYMART ::::::::::::::::::::::::::::::::::tempRoulettebeansPlayMart "
														+ winamount);
									} else {
										Utils.Logger(GameMainExtension.extension,
												"PLAYMART:::::::::::::::::::::::::::tempRoulettebeansSingle "
														+ tempRoulettebeansPlayMart);
										tempRoulettebeansPlayMart = new RouletteBetBeans();
									}

									gameBean.setWinner(String.valueOf(winamount));

									tempWinamount = String.valueOf(winamount);

									Utils.Logger(GameMainExtension.extension,
											"UpdateGameWinAmountManager::::::::" + "tempWinamount" + tempWinamount);

									if (tempSFSUser != null) {
										Utils.Logger(GameMainExtension.extension,
												"---------- UpdateUserCreditsbeforeTakeHandler----------userexistStatus "
														+ userexistStatus);

										userexistStatus = 0;
									}

									gameBean.setTotalsessionwinamount(String.valueOf(winamount));
									gameBean.setJackport(jackport);
									GameMainExtension.gamecachePlayMart.getGames().add(gameBean);

									DBManager.updateUserWinAmountsqlPlayMart(tempUser.getUserId(), jackport,
											tempWinamount, pWinnumber, pSession, ticketid, new CallBack() {

												@Override
												public void call(Object... callback) {

													{

														ISFSObject isfsObject = (ISFSObject) callback[0];

// isfsObject.putUtfString(Param.WINAMOUNT,
// String.valueOf(winamountuser));
														Utils.Logger(GameMainExtension.extension,
																"---------- UpdateUserCreditsbeforeTakeHandler----------response "
																		+ isfsObject.getDump());
														GameMainExtension.extension.send(Events.UPDATEUSERCREDITS,
																isfsObject, tempSFSUser);
													}

												}
											});
								}

								DBManager.updateUserWinAmountMongoPlayMart(tempUser.getUserId(), pSession, jackport,
										pWinnumber, tempWinamount, userexistStatus, player.getChips());

							}
							Utils.Logger(GameMainExtension.extension,
									"::::::::: UpdateGameWinAmount :::::::::::::totalsessionbetamount"
											+ tempSession.getTotalBetAmount() + "::::::::::: winamount ::::::::::::::::"
											+ winamount);
							DBManager.updateLiveTimeDataPlayMart(tempSession.getTotalBetAmount(),
									String.valueOf(winamount), gameid,jackport);

						}
					}

				}

			}

		}.start();
	}

}