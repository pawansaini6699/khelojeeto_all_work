package com.latestfunroulette.playMart.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.latestfunroulette.playMart.cache.beans.RouletteBetBeans;

public class TicketPrint {

	private TicketPrint() {

	}

	static HashMap<String, List<RouletteBetBeans>> ticketGenerateHashMap = new HashMap<String, List<RouletteBetBeans>>();

	static List<String> tempRouletteBetBeans = new ArrayList<String>();

	public static List<RouletteBetBeans> getTicketGenerateList(String ticketid) {
		return ticketGenerateHashMap.get(ticketid);
	}

	public static List<String> getTempRouletteBetBeans() {
		return tempRouletteBetBeans;
	}

	public static void setTempRouletteBetBeans(List<String> tempRouletteBetBeans) {
		TicketPrint.tempRouletteBetBeans = tempRouletteBetBeans;
	}

	public static HashMap<String, List<RouletteBetBeans>> getTicketGenerateHashMap() {
		return ticketGenerateHashMap;
	}

	public static void setTicketGenerateHashMap(HashMap<String, List<RouletteBetBeans>> ticketGenerateHashMap) {
		TicketPrint.ticketGenerateHashMap = ticketGenerateHashMap;
	}

	public static RouletteBetBeans isBetNoExist(String betNo, String ticketid) {

		if (ticketGenerateHashMap.containsKey(ticketid)) {
			List<RouletteBetBeans> temprRouletteBetBeans = ticketGenerateHashMap.get(ticketid);

			for (RouletteBetBeans rouletteBetBeans : temprRouletteBetBeans) {

				if (rouletteBetBeans.getBetNos().equals(betNo)) {

					return rouletteBetBeans;
				}
			}
		}
		return null;

	}

	public static boolean isTicketExist(String ticketno) {

		return ticketno == null ? false : ticketGenerateHashMap.containsKey(ticketno);

	}

	public static RouletteBetBeans getRouletteBeanByWinningNumberandTicketId(String ticketno, String pWinnumber) {

		List<RouletteBetBeans> tempRouletteBetBeans = TicketPrint.getTicketGenerateList(ticketno);
		if (tempRouletteBetBeans == null)
			return null;

		for (RouletteBetBeans tempBeans : tempRouletteBetBeans) {

			if (tempBeans.getBetNos().equals(pWinnumber)) {

				return tempBeans;
			}

		}
		return null;
	}
}
